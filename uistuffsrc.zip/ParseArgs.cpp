#ifndef PARSE_ARGS
#define PARSE_ARGS						1.0.3.0


#ifndef MAX_ARGS
#define MAX_ARGS						1024
#endif

#ifndef MAX_ARG_LEN
#define MAX_ARG_LEN						8192
#endif


LPTSTR arg[MAX_ARGS];
int arglen[MAX_ARGS];
int numargs = 0;
wchar_t allargs[MAX_ARG_LEN] = L"";


#define PARSE_BREAK_SPACES				0x0001
#define PARSE_BREAK_COMMAS				0x0002
#define PARSE_SLASHES_KLUDGE			0x0004
#define	PARSE_QUOTES_KLUDGE				0x0008
#define PARSE_EQUALS_KLUDGE				0x0010
#define PARSE_ONE_ARG_KLUDGE			0x0020
#define PARSE_RETAIN_QUOTES				0x0040
#define PARSE_FORCE_UPPERCASE			0x0080
#define PARSE_NO_TRIM					0x0100
#define PARSE_IGNORE_QUOTES				0x0200
#define PARSE_EQ_QT_KLUDGE				0x0400
#define PARSE_EXCL_RANGE_KLUDGE			0x0800
#define PARSE_TWO_ARG_KLUDGE			0x1000
#define PARSE_BREAK_TABS				0x2000
#define PARSE_ONE_ARG_KEEP_QUOTES		0x4000



int ParseArgs( LPTSTR inString, unsigned int flags, unsigned int FinalArg = 0 )
{
	/*
		flags:  bit 0  - break args at spaces
				bit 1  - break args at commas (either bit 0 or bit 1 must be set)
				bit 2  - slashes kludge:   treat /a/b like /a /b
				bit 3  - quotes kludge:    treat /a"foo" like /a:"foo"
				bit 4  - equals kludge:    break at first unquoted equals sign
				bit 5  - one-arg kludge:   if arg does not begin with /, allow unquoted spaces
				bit 6  - don't swallow double quotes
				bit 7  - force uppercase
				bit 8  - don't trim spaces from the right
				bit 9  - disable all special handling of double quotes
				bit 10 - set PARSE_RETAIN_QUOTES after an unquoted equals sign
				bit 11 - retain double quotes and spaces in exclusion ranges ( /[!...] )
				bit 12 - two-arg kludge
				bit 13 - break at tabs only, not other whitespace
				bit 14 - combine with PARSE_ONE_ARG_KLUDGE to retain quotes in the one (non-option) argument
	*/

	if ( !inString )
		return -1;

	numargs		= 0;

	int argnum	= 0;
	int i		= 0;
	int a		= 0;
	int b		= 0;
	wchar_t ch	= '\0';
	BOOL quote  = FALSE;
	BOOL adv    = FALSE;
	BOOL done   = FALSE;
	int eqkl    = 0;
	int xrkl	= 0;
	int upkl	= 0;

	
	if ( flags & PARSE_BREAK_SPACES )
		flags &= ~PARSE_BREAK_TABS;

	if ( ( flags & ( PARSE_BREAK_SPACES | PARSE_BREAK_COMMAS | PARSE_EQUALS_KLUDGE | PARSE_BREAK_TABS ) ) == 0 )
		flags |= PARSE_BREAK_SPACES;

	for ( i = 0; i < MAX_ARGS; i++ ) {
		arg[i] = NULL;
		arglen[i] = 0;
	}

	allargs[0] = '\0';
	
	for ( i = 0; !done; i++ ) {
		ch = inString[i];
		adv = FALSE;

		if ( ( ch == '"' ) && !a && ( ( flags & ( PARSE_ONE_ARG_KLUDGE | PARSE_ONE_ARG_KEEP_QUOTES ) ) == ( PARSE_ONE_ARG_KLUDGE | PARSE_ONE_ARG_KEEP_QUOTES ) ) )
			flags |= PARSE_RETAIN_QUOTES;

		if ( ( ch == '"' ) && ( ( flags & PARSE_IGNORE_QUOTES ) == 0 ) ) {
			quote = !quote;

			if ( quote && ( a == 2 ) && ( arg[argnum][0] == '/' ) && ( iswalpha( arg[argnum][1] ) ) && ( flags & PARSE_QUOTES_KLUDGE ) ) {
				if ( flags & PARSE_RETAIN_QUOTES ) {
					if ( b < ( MAX_ARG_LEN - 1 ) )
						allargs[b++] = ':';
				}
				else
					ch = ':';
			}
			else if ( ( ( flags & PARSE_RETAIN_QUOTES ) == 0 ) && ( ( xrkl & PARSE_EXCL_RANGE_KLUDGE ) == 0 ) )
				continue;
		}

		if ( iswspace( ch ) && ( a == 0 ) && !quote )
			if ( !( flags & PARSE_BREAK_TABS ) || ( ch != '\t' ) )
				continue;

		if ( ( a == 0 ) && ( ch != '/' ) && ( ( flags & ( PARSE_BREAK_SPACES | PARSE_ONE_ARG_KLUDGE ) ) == ( PARSE_BREAK_SPACES | PARSE_ONE_ARG_KLUDGE ) ) ) {
			flags &= ~PARSE_BREAK_SPACES;
			if ( flags & PARSE_ONE_ARG_KEEP_QUOTES )
				flags |= PARSE_RETAIN_QUOTES;
		}

		if ( iswspace( ch ) && !quote && ( a == 1 ) && ( argnum > 0 ) && ( flags & PARSE_EQUALS_KLUDGE ) && ( arg[argnum][0] == '=' ) )
			continue;

		if ( iswspace( ch ) && !quote && ( flags & PARSE_BREAK_SPACES ) && ( ( xrkl & PARSE_EXCL_RANGE_KLUDGE ) == 0 ) )
			adv = TRUE;

		if ( ( ch == ',' ) && !quote && ( flags & PARSE_BREAK_COMMAS ) )
			adv = TRUE;

		if ( ( ch == '\t' ) && !quote && ( flags & PARSE_BREAK_TABS ) )
			adv = TRUE;

		if ( ( ch == ']' ) && !quote && ( xrkl & PARSE_EXCL_RANGE_KLUDGE ) )
			xrkl = 0;

		if ( ( flags & PARSE_SLASHES_KLUDGE ) && ( ch == ':' ) && a )
			if ( iswalpha( inString[i - 1] ) && ( inString[i + 1] == '/' ) && ( inString[i + 2] == '/' ) )
				upkl = 1;

		if ( ( ch == '/' ) && !quote && !upkl && ( a > 1 ) && ( arg[argnum][0] == '/' ) && ( flags & PARSE_SLASHES_KLUDGE ) ) {
			argnum++;
			a = 0;
			b++;
			allargs[b] = '\0';
			xrkl = 0;
		}

		if ( ( ch == '=' ) && !quote && ( eqkl == 0 ) && ( a > 0 ) && ( arg[argnum][0] != '/' ) && ( flags & PARSE_EQUALS_KLUDGE ) ) {
			argnum++;
			a = 0;
			b++;
			allargs[b] = '\0';
			eqkl = argnum;
			xrkl = 0;
			flags &= ~( PARSE_BREAK_SPACES | PARSE_BREAK_COMMAS );
			//- Printf( L"   * equals kludge invoked; eqkl = %d\n", eqkl );

			if ( flags & PARSE_EQ_QT_KLUDGE )
				flags |= PARSE_IGNORE_QUOTES;
		}
		else if ( ( ch == '=' ) && !quote && ( flags & PARSE_EQUALS_KLUDGE ) ) {
			eqkl = -1;
			flags &= ~( PARSE_BREAK_SPACES | PARSE_BREAK_COMMAS );

			if ( flags & PARSE_EQ_QT_KLUDGE )
				flags |= PARSE_IGNORE_QUOTES;
		}

		if ( ch == '\0' ) {
			if ( a )
				argnum++;

			xrkl = 0;
			upkl = 0;
			done = TRUE;
			continue;
		}

		if ( adv ) {
			if ( ( flags & PARSE_TWO_ARG_KLUDGE ) && ( a > 0 ) && ( arg[argnum][0] != '/' ) )
				flags &= ~( PARSE_BREAK_SPACES | PARSE_BREAK_COMMAS );

			argnum++;
			a = 0;
			b++;
			allargs[b] = '\0';
			quote = FALSE;
			xrkl = 0;
			upkl = 0;

			if ( FinalArg )
				if ( argnum == FinalArg )
					flags = ( flags & ~( PARSE_BREAK_SPACES | PARSE_BREAK_COMMAS ) ) | PARSE_RETAIN_QUOTES;

			continue;
		}

		if ( b >= ( MAX_ARG_LEN - 1 ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Buffer overflow: b = %d, MAX_ARG_LEN = %d \r\n", b, MAX_ARG_LEN );
			return -1;
		}

		if ( argnum < MAX_ARGS ) {
			if ( a == 0 )
				arg[argnum] = allargs + b;

			if ( flags & PARSE_FORCE_UPPERCASE )
				ch = towupper( ch );

			a++;
			arglen[argnum]  = a;
			allargs[b++] = ch;
			allargs[b]   = '\0';

			if ( ( ch == '!' ) && ( a == 3 ) )
				if ( wcscmp( arg[argnum], L"/[!" ) == 0 )
					xrkl = ( flags & PARSE_EXCL_RANGE_KLUDGE );
		}

	}

	if ( ( flags & PARSE_NO_TRIM ) == 0 ) {
		for ( i = 0; i < argnum; i++ ) {
			while ( ( arglen[i] > 0 ) && iswspace( arg[i][arglen[i] - 1] ) ) {
				arglen[i]--;
				arg[i][arglen[i]] = '\0';
			}
		}
	}

	numargs = argnum;
	return argnum;
}


#ifdef		ATEST_CMD

DLLExports int WINAPI atest( LPTSTR inString )
{
	if ( !inString )
		return 1;


	int k			= 0;
	ParseArgs( inString, PARSE_BREAK_SPACES | PARSE_SLASHES_KLUDGE | PARSE_EXCL_RANGE_KLUDGE );


	for ( int i = 0; i < numargs; i++ ) {
		if ( arglen[i] ) {
			Printf( L"arg[%d] = %s\r\n", i, arg[i] );
			k++;
		}
	}

	Printf( L"\r\nTotal found: %d\r\n", k );
	return 0;
}

#endif	//	ATEST_CMD

#endif


/*
	1.0.1.0		2021-10-15
				Added PARSE_BREAK_TABS to break at tabs, but not other whitespace characters.

	1.0.2.0		2022-01-02
				Added a kludge to prevent splitting URLs at slashes when PARSE_SLASHES_KLUDGE is set.

	1.0.3.0		2022-03-02
				Added PARSE_ONE_ARG_KEEP_QUOTES to retain quotes in the one (non-option) argument.

*/
