
//		Sources differ for a couple of these (mediumpurple and palevioletred);
//		in both cases I think an uppercase B is commonly misread as an 8.
//		This table agrees with  http://www.w3.org/TR/css3-color/  and
//		http://en.wikipedia.org/wiki/X11_color_names
//
//		"Gray" is consistently spelled with an A in this table.  It is up to
//		the application, if desired, to check for "Grey" and substitute an
//		A for the E.

#ifndef W3CCOLORS_INCLUDED
#define W3CCOLORS_INCLUDED			1.10

#define NUM_W3C_COLORS				140
#define MAX_W3C_COLOR_NAME_LEN		21
#define W3C_COLOR_UNDEFINED			0xffffffff


struct W3CColorPair {
	wchar_t Name[MAX_W3C_COLOR_NAME_LEN];
	DWORD Value;
};

W3CColorPair W3CColor[NUM_W3C_COLORS] = {
	{ L"AliceBlue",				0xf0f8ff },
	{ L"AntiqueWhite",			0xfaebd7 },
	{ L"Aqua",					0x00ffff },
	{ L"Aquamarine",			0x7fffd4 },
	{ L"Azure",					0xf0ffff },
	{ L"Beige",					0xf5f5dc },
	{ L"Bisque",				0xffe4c4 },
	{ L"Black",					0x000000 },
	{ L"BlanchedAlmond",		0xffebcd },
	{ L"Blue",					0x0000ff },
	{ L"BlueViolet",			0x8a2be2 },
	{ L"Brown",					0xa52a2a },
	{ L"BurlyWood",				0xdeb887 },
	{ L"CadetBlue",				0x5f9ea0 },
	{ L"Chartreuse",			0x7fff00 },
	{ L"Chocolate",				0xd2691e },
	{ L"Coral",					0xff7f50 },
	{ L"CornflowerBlue",		0x6495ed },
	{ L"Cornsilk",				0xfff8dc },
	{ L"Crimson",				0xdc143c },
	{ L"Cyan",					0x00ffff },
	{ L"DarkBlue",				0x00008b },
	{ L"DarkCyan",				0x008b8b },
	{ L"DarkGoldenrod",			0xb8860b },
	{ L"DarkGray",				0xa9a9a9 },
	{ L"DarkGreen",				0x006400 },
	{ L"DarkKhaki",				0xbdb76b },
	{ L"DarkMagenta",			0x8b008b },
	{ L"DarkOliveGreen",		0x556b2f },
	{ L"DarkOrange",			0xff8c00 },
	{ L"DarkOrchid",			0x9932cc },
	{ L"DarkRed",				0x8b0000 },
	{ L"DarkSalmon",			0xe9967a },
	{ L"DarkSeaGreen",			0x8fbc8f },
	{ L"DarkSlateBlue",			0x483d8b },
	{ L"DarkSlateGray",			0x2f4f4f },
	{ L"DarkTurquoise",			0x00ced1 },
	{ L"DarkViolet",			0x9400d3 },
	{ L"DeepPink",				0xff1493 },
	{ L"DeepSkyBlue",			0x00bfff },
	{ L"DimGray",				0x696969 },
	{ L"DodgerBlue",			0x1e90ff },
	{ L"FireBrick",				0xb22222 },
	{ L"FloralWhite",			0xfffaf0 },
	{ L"ForestGreen",			0x228b22 },
	{ L"Fuchsia",				0xff00ff },
	{ L"Gainsboro",				0xdcdcdc },
	{ L"GhostWhite",			0xf8f8ff },
	{ L"Gold",					0xffd700 },
	{ L"Goldenrod",				0xdaa520 },
	{ L"Gray",					0x808080 },
	{ L"Green",					0x008000 },
	{ L"GreenYellow",			0xadff2f },
	{ L"Honeydew",				0xf0fff0 },
	{ L"Hotpink",				0xff69b4 },
	{ L"IndianRed",				0xcd5c5c },
	{ L"Indigo",				0x4b0082 },
	{ L"Ivory",					0xfffff0 },
	{ L"Khaki",					0xf0e68c },
	{ L"Lavender",				0xe6e6fa },
	{ L"LavenderBlush",			0xfff0f5 },
	{ L"LawnGreen",				0x7cfc00 },
	{ L"LemonChiffon",			0xfffacd },
	{ L"LightBlue",				0xadd8e6 },
	{ L"LightCoral",			0xf08080 },
	{ L"LightCyan",				0xe0ffff },
	{ L"LightGoldenrodYellow",	0xfafad2 },
	{ L"LightGray",				0xd3d3d3 },
	{ L"LightGreen",			0x90ee90 },
	{ L"LightPink",				0xffb6c1 },
	{ L"LightSalmon",			0xffa07a },
	{ L"LightSeaGreen",			0x20b2aa },
	{ L"LightSkyBlue",			0x87cefa },
	{ L"LightSlateGray",		0x778899 },
	{ L"LightSteelBlue",		0xb0c4de },
	{ L"LightYellow",			0xffffe0 },
	{ L"Lime",					0x00ff00 },
	{ L"LimeGreen",				0x32cd32 },
	{ L"Linen",					0xfaf0e6 },
	{ L"Magenta",				0xff00ff },
	{ L"Maroon",				0x800000 },
	{ L"MediumAquaMarine",		0x66cdaa },
	{ L"MediumBlue",			0x0000cd },
	{ L"MediumOrchid",			0xba55d3 },
	{ L"MediumPurple",			0x9370db },
	{ L"MediumSeaGreen",		0x3cb371 },
	{ L"MediumSlateBlue",		0x7b68ee },
	{ L"MediumSpringGreen",		0x00fa9a },
	{ L"MediumTurquoise",		0x48d1cc },
	{ L"MediumVioletRed",		0xc71585 },
	{ L"MidnightBlue",			0x191970 },
	{ L"MintCream",				0xf5fffa },
	{ L"MistyRose",				0xffe4e1 },
	{ L"Moccasin",				0xffe4b5 },
	{ L"NavajoWhite",			0xffdead },
	{ L"Navy",					0x000080 },
	{ L"OldLace",				0xfdf5e6 },
	{ L"Olive",					0x808000 },
	{ L"OliveDrab",				0x6b8e23 },
	{ L"Orange",				0xffa500 },
	{ L"OrangeRed",				0xff4500 },
	{ L"Orchid",				0xda70d6 },
	{ L"PaleGoldenrod",			0xeee8aa },
	{ L"PaleGreen",				0x98fb98 },
	{ L"PaleTurquoise",			0xafeeee },
	{ L"PaleVioletRed",			0xdb7093 },
	{ L"PapayaWhip",			0xffefd5 },
	{ L"PeachPuff",				0xffdab9 },
	{ L"Peru",					0xcd853f },
	{ L"Pink",					0xffc0cb },
	{ L"Plum",					0xdda0dd },
	{ L"PowderBlue",			0xb0e0e6 },
	{ L"Purple",				0x800080 },
	{ L"Red",					0xff0000 },
	{ L"RosyBrown",				0xbc8f8f },
	{ L"RoyalBlue",				0x4169e1 },
	{ L"SaddleBrown",			0x8b4513 },
	{ L"Salmon",				0xfa8072 },
	{ L"SandyBrown",			0xf4a460 },
	{ L"SeaGreen",				0x2e8b57 },
	{ L"Seashell",				0xfff5ee },
	{ L"Sienna",				0xa0522d },
	{ L"Silver",				0xc0c0c0 },
	{ L"SkyBlue",				0x87ceeb },
	{ L"SlateBlue",				0x6a5acd },
	{ L"SlateGray",				0x708090 },
	{ L"Snow",					0xfffafa },
	{ L"SpringGreen",			0x00ff7f },
	{ L"SteelBlue",				0x4682b4 },
	{ L"Tan",					0xd2b48c },
	{ L"Teal",					0x008080 },
	{ L"Thistle",				0xd8bfd8 },
	{ L"Tomato",				0xff6347 },
	{ L"Turquoise",				0x40e0d0 },
	{ L"Violet",				0xee82ee },
	{ L"Wheat",					0xf5deb3 },
	{ L"White",					0xffffff },
	{ L"WhiteSmoke",			0xf5f5f5 },
	{ L"Yellow",				0xffff00 },
	{ L"YellowGreen",			0x9acd32 }
};


unsigned int _W3Cxdigval( wchar_t ch )
{
	if ( ( ch >= '0' ) && ( ch <= '9' ) )
		return ch - '0';
	else if ( ( ch >= 'a' ) && ( ch <= 'f' ) )
		return ch - 'a' + 10;
	else if ( ( ch >= 'A' ) && ( ch <= 'F' ) )
		return ch - 'A' + 10;
	else
		return 0;
}


int W3CColorValue( LPTSTR ColorName, BOOL AllowHex = FALSE )
{
	if ( ColorName == NULL )
		return W3C_COLOR_UNDEFINED;

	wchar_t Temp[MAX_W3C_COLOR_NAME_LEN] = L"";
	wchar_t ch = 0x00;
	int j = 0;



	if ( AllowHex && ( ColorName[0] == '#' ) ) {
		wchar_t *ch1		= ColorName + 1;
		DWORD Value			= 0x000000;
		unsigned int k		= 0;


		while ( iswxdigit( *ch1 ) ) {
			Value = ( Value << 4 ) | _W3Cxdigval( *ch1 );
			k++;
			ch1++;
		}

		if ( ( *ch1 == '\0' ) && ( k == 6 ) )
			return Value;

		if ( ( *ch1 == '\0' ) && ( k == 3 ) )
			return ( ( Value & 0x000f00 ) * 0x1100 ) | ( ( Value & 0x0000f0 ) * 0x110 ) | ( ( Value & 0x00000f ) * 0x11 );
	}
	

	for ( size_t i = 0; ColorName[i]; i++ ) {
		ch = towupper( ColorName[i] );

		if ( iswspace( ch ) )
			continue;

		if ( ( ch == 'E' ) && ( i > 1 ) )
			if ( ( towupper( ColorName[i - 2] ) == 'G' ) && ( towupper( ColorName[i - 1] ) == 'R' ) )
				if ( towupper( ColorName[i + 1] ) == 'Y' )
					ch = 'A';

		if ( j < ( MAX_W3C_COLOR_NAME_LEN - 1 ) ) {
			Temp[j++] = ch;
			Temp[j] = 0x00;
		}
	}

	if ( Temp[0] == 0x00 )
		return W3C_COLOR_UNDEFINED;

	for ( int i = 0; i < NUM_W3C_COLORS; i++ )
		if ( _wcsicmp( W3CColor[i].Name, Temp ) == 0 )
			return W3CColor[i].Value;

	return W3C_COLOR_UNDEFINED;
}


int W3CColorIndex( unsigned int ColorValue )
{
	for ( int i = 0; i < NUM_W3C_COLORS; i++ )
		if ( W3CColor[i].Value == ColorValue )
			return i;

	return -1;
}


#endif // W3CCOLORS_INCLUDED
