
//		sc_hotkeys.cpp --	hotkeys as used in shortcut files,
//							*not* the same as tcc plugin hotkeys


#ifndef SC_HOTKEYS_VERSION
#define SC_HOTKEYS_VERSION			1.0.0.0


#define NUM_SHIFTERS 7
#define MAX_SHIFTKEY_NAME_LEN 10
#define NUM_NAMED_KEYS 84
#define MAX_KEY_NAME_LEN 14


wchar_t ShiftKeyNames[NUM_SHIFTERS][MAX_SHIFTKEY_NAME_LEN] = {
	L"C-", L"Ctrl-", L"Control-", L"A-", L"Alt-", L"S-", L"Shift-" };


WORD ShiftKeyValues[NUM_SHIFTERS] = {
	0x0200, 0x0200, 0x0200, 0x0400, 0x0400, 0x0100, 0x0100 };


wchar_t KeyNames[NUM_NAMED_KEYS][MAX_KEY_NAME_LEN] = {
	L"Backspace", L"Bksp", L"Tab", L"Enter", L"Return", L"Esc", L"PageUp", L"PgUp", L"PageDown", L"PgDn",
	L"End", L"Home", L"Left", L"Up", L"Right", L"Down", L"Insert", L"Ins", L"Delete", L"Del",
	L"Num0", L"Num1", L"Num2", L"Num3", L"Num4", L"Num5", L"Num6", L"Num7", L"Num8", L"Num9",
	L"Num*", L"*", L"Num+", L"Num-", L"Num/",
	L"F1", L"F2", L"F3", L"F4", L"F5", L"F6", L"F7", L"F8", L"F9", L"F10", L"F11", L"F12",
	L"F13", L"F14", L"F15", L"F16", L"F17", L"F18", L"F19", L"F20", L"F21", L"F22", L"F23", L"F24",
	L";", L"Semicolon", L"=", L"Equals", L",", L"Comma", L"-", L"Minus", L".", L"Period",
	L"/", L"Slash", L"Grave", L"`", L"[", L"LeftBracket", L"\\", L"Backslash", L"]", L"RightBracket", L"'", L"Apostrophe", L"Quote",
	L"Space", L"Spacebar" };
	

WORD KeyValues[NUM_NAMED_KEYS] = {
	0x08, 0x08, 0x09, 0x0d, 0x0d, 0x1b, 0x21, 0x21, 0x22, 0x22,
	0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x2d, 0x2d, 0x2e, 0x2e,
	0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69,
	0x6a, 0x6a, 0x6b, 0x6d, 0x6f,
	0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7a, 0x7b,
	0x7c, 0x7d, 0x7e, 0x7f, 0x80, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87,
	0xba, 0xba, 0xbb, 0xbb, 0xbc, 0xbc, 0xbd, 0xbd, 0xbe, 0xbe,
	0xbf, 0xbf, 0xc0, 0xc0, 0xdb, 0xdb, 0xdc, 0xdc, 0xdd, 0xdd, 0xde, 0xde, 0xde,
	0x20, 0x20 };




int GetHotkeyName( int Key, LPTSTR outName )
{
	if ( !outName )
		return -1;

	if ( !Key ) {
		wcscpy_s( outName, SHORT_BUF_LEN, L"None" );
		return 0;
	}

	int BaseKey = ( Key & 0xff );
	wchar_t ShortBuf[SHORT_BUF_LEN] = L"";

	outName[0] = '\0';

	if ( Key & 0x0200 )
		wcscat_s( outName, SHORT_BUF_LEN, L"Control-" );

	if ( Key & 0x0100 )
		wcscat_s( outName, SHORT_BUF_LEN, L"Shift-" );

	if ( Key & 0x0400 )
		wcscat_s( outName, SHORT_BUF_LEN, L"Alt-" );


	if ( ( ( BaseKey >= 'A' ) && ( BaseKey <= 'Z' ) ) || ( ( BaseKey >= '0' ) && ( BaseKey <= '9' ) ) ) {
		int i = (int) wcslen( outName );
		if ( i < ( SHORT_BUF_LEN - 1 ) ) {
			outName[i++] = BaseKey;
			outName[i] = '\0';
		}
		return 0;
	}

	for ( int i = 0; i < NUM_NAMED_KEYS; i++ )
		if ( KeyValues[i] == BaseKey ) {
			wcscat_s( outName, SHORT_BUF_LEN, KeyNames[i] );
			return 0;
		}

	swprintf( ShortBuf, SHORT_BUF_LEN, L"0x%02X", BaseKey );
	wcscat_s( outName, SHORT_BUF_LEN, ShortBuf );
	return 0;
}



int ParseHotkey( LPTSTR Keyname )
{
	if ( !Keyname )
		return -1;

	if ( Keyname[0] == '\0' )
		return -1;
		
	if ( !_wcsicmp( Keyname, L"None" ) )
		return 0;
	
	
	int i = 0, s = 0, l = 0, rv = 0;
	wchar_t ch = '\0';
	
	do {
		s = 0;
		for ( int k = 0; k < NUM_SHIFTERS; k++ ) {
			l = (int) wcslen( ShiftKeyNames[k] );

			if ( !_wcsnicmp( ShiftKeyNames[k], Keyname + i, l ) ) {
				i += l;
				s = 1;
				rv |= ShiftKeyValues[k];
			}
		}
	}
	while ( s );

	if ( Keyname[i] == '\0' )
		return -1;

	ch = towupper( Keyname[i] );

	if ( ( Keyname[i + 1] == '\0' ) & ( ( ( ch >= 'A' ) && ( ch <= 'Z' ) ) || ( ( ch >= '0' ) && ( ch <= '9' ) ) ) )
		rv |= ch;
	else
		for ( int k = 0; k < NUM_NAMED_KEYS; k++ )
			if ( !_wcsicmp( KeyNames[k], Keyname + i ) )
				rv |= KeyValues[k];
	
	if ( rv & 0xff )
		return rv;
	else
		return -1;
}


#endif	//	SC_HOTKEYS_VERSION
