
//			OSD command, and related commands, functions, and structures:


#ifndef OSD_VERSION
#define OSD_VERSION					1.0.11.1


#ifndef MACRO_STR
#define MACRO_EXP( arg )			#arg
#define MACRO_STR( arg )			MACRO_EXP( arg )
#endif


#ifdef	OSD_ANGLES
#include <math.h>
#endif	//	OSD_ANGLES


#ifdef	OSD_OSDIMG_CMD
#include <GdiPlus.h>
using namespace Gdiplus;
#endif	//	OSD_OSDIMG_CMD


#ifdef	OSD_READ_FILE
#ifndef	MMFILES_INCLUDED
#include "mmfiles.cpp"
#endif	//	MMFILES_INCLUDED
#endif	//	OSD_READ_FILE


#ifdef OSD_ESCAPES
#include "ExpandEscapes.cpp"
#endif	//	OSD_ESCAPES


#ifdef OSD_TAB_OPTION
#include "FindMyWindow.cpp"
#endif	//	OSD_TAB_OPTION


#if defined OSD_OSD_CMD || defined OSD_PCTBAR_CMD || defined OSD_OSDIMG_CMD
#include "w3ccolors.cpp"
#endif	//	OSD_OSD_CMD || OSD_PCTBAR_CMD || OSD_OSDIMG_CMD


#define OSD_ID_MAX					1023
#define OSD_TIMEOUT_MAX				( 60 * 60 * 24 )
#define OSD_MSEC_MIN				20
#define OSD_TEXT_HEIGHT_MIN			4
#define OSD_TEXT_HEIGHT_MAX			256
#define OSD_TEXT_HEIGHT_DEFAULT		18
#define OSD_ALPHA_MIN				0x30
#define OSD_ALPHA_MAX				0xff
#define OSD_ALPHA_DEFAULT			0xe0
#define OSD_FADE_DELAY				15
#define OSD_FADE_STEP				2
#define OSD_FADE_IN_STEP			4
#define OSD_BLINK_MIN				100
#define OSD_BLINK_MAX				5000
#define OSD_BLINK_DEFAULT			500
#define OSD_MAX_FILE_LINES			64
#define OSD_DROPSHADOW_DISTANCE		3
#define OSD_STYLE_MAX				4096
#define OSD_STYLES_GLOBAL			100
#define OSD_MONITOR_DEFAULT			1024
#define OSD_MAX_MONITORS			64

#define OSD_PCTBAR_SIZE_MIN			8
#define OSD_PCTBAR_SIZE_MAX			8192
#define OSD_PCTBAR_DEFAULT_WIDTH	200
#define OSD_PCTBAR_DEFAULT_HEIGHT	40
#define OSD_PCTBAR_DEFAULT_ID		999

#define OSD_IMG_SIZE_MIN			16
#define OSD_IMG_SIZE_MAX			1024
#define OSD_IMG_SIZE_DEFAULT		200
#define OSD_IMG_DEFAULT_ID			998


//			Bits used in the bitmapped Flags value:

#define OSD_LEFT					0x00001
#define OSD_RIGHT					0x00002
#define OSD_HCENTER					0x00003
#define OSD_X_BITS					0x00003
#define OSD_TOP						0x00004
#define OSD_BOTTOM					0x00008
#define OSD_VCENTER					0x0000c
#define OSD_Y_BITS					0x0000c
#define OSD_ADD_OFFSET				0x00080
#define OSD_DING					0x00100
#define OSD_ITALIC					0x00200
#define OSD_UNDERLINE				0x00400
#define OSD_SHOW_VALUE				0x00400
#define OSD_CENTER_JUSTIFY			0x00800
#define OSD_RIGHT_JUSTIFY			0x01000
#define OSD_JUSTIFY_BITS			0x01800
#define OSD_FADE_OUT				0x02000
#define OSD_SHADOW					0x04000
#define OSD_DEBUG					0x08000
#define OSD_NOT_TRANSP				0x10000
#define OSD_COLOR_TRANS				0x20000
#define OSD_MY_TAB					0x40000
#define OSD_FADE_IN					0x80000


//			Bits used in Fading value:

#define OSD_FADING_OUT				0x80
#define OSD_FADING_IN				0x40
#define OSD_SHOULD_FADE				0x20


#define WM_FADENOW					0x0642



wchar_t OSDWindowClass[256]			= L"";
ATOM OSDWindowAtom					= 0;


struct _OSDWindowData {
	BYTE PeakAlpha;
	BYTE CurrentAlpha;
	BYTE Fading;
	BYTE Blink;
	COLORREF BackColor;
	DWORD LayeredAttribs;
	unsigned int Timeout;
	unsigned int BlinkRate;
};

struct _FindOSDWindows {
	unsigned int Count;
	unsigned int WindowID;
	HWND SkipWindow;
	UINT Msg;
};

struct _DrawOSDTextArgs {
	LPTSTR Text;
	LPTSTR FontName;
	unsigned int TextSize;
	int Weight;
	int TextAngle;
	COLORREF ShadowColor;
};

struct _DrawPercentBarArgs {
	unsigned int Dividend;
	unsigned int Divisor;
	unsigned int SizeX;
	unsigned int SizeY;
	COLORREF ShadowColor;
};


UINT_PTR OSDTimerID						= 4242;
UINT_PTR OSDBlinkTimerID				= 4264;

unsigned int OSDCtrlBreakFlag	= 0;

BOOL OSD_IsWinPE				= FALSE;

int OSD_Offscreen				= -2048000;


#ifdef	OSD_OSDIMG_CMD

ULONG_PTR GdiplusToken			= NULL;
GdiplusStartupInput StartupInput;

#endif	//	OSD_OSDIMG_CMD

typedef BOOL ( WINAPI _GetScrollBarInfoProc ) ( HWND Window, LONG Which, SCROLLBARINFO *ScrollbarInfo );
_GetScrollBarInfoProc *GetScrollBarInfoProc		= NULL;



//			syntax text for the OSD command:

#ifdef	OSD_OSD_CMD

#ifdef	OSD_FULL_HELP

const wchar_t OSDHelpText[] = L"Display text on the screen.\n\
\n\
OSD /C /FONT=n /N /POS=y,x /RGB=r,g,b /TIME=n /V text\r\n\n\
\t/C\tclose OSD windows\n\
\t/FONT=\ttext height in pixels \t(18)\n\
\t/N\tdo not wait for timeout\n\
\t/POS=\tposition on screen \t(0,0)\n\
\t/RGB=\tset the text color \t(0,255,0)\n\
\t/TIME=\ttimeout in seconds \t(10)\n\
\t/V\tvertical text\n\
\t/LEFT, /RIGHT, /HCENTER:  override any /POS= x value\n\
\t/TOP, /BOTTOM, /VCENTER:  override any /POS= y value  \n\
\t/FACE=\ttypeface name or family\n\
\t/I\titalic typeface\n\
\t/U\tunderline text\n\
\t/B=\ttext weight; 1 thin, 4 normal, 7 bold\n\
\t/COLOR=\tspecify color as a TCC color number, 0 - 15\n\
\t/ALPHA=\ttransparency; 64 (ghostly) to 255 (opaque)\n\
\t/FADE\tfade the window out\n\
\n\
Any leading or trailing whitespace will be stripped from the text.\n\
See osd.html for more options and features.\n";

#else	//	OSD_FULL_HELP

const wchar_t OSDHelpText[] = L"Display text on the screen.\n\
\n\
OSD /C /FONT=n /N /POS=y,x /RGB=r,g,b /TIME=n /V text\r\n\n\
\t/C\tclose OSD windows\n\
\t/FONT=\ttext height in pixels \t(18)\n\
\t/N\tdo not wait for timeout\n\
\t/POS=\tposition on screen \t(0,0)\n\
\t/RGB=\tset the text color \t(0,255,0)\n\
\t/TIME=\ttimeout in seconds \t(10)\n\
\t/V\tvertical text\n\
\t/LEFT, /RIGHT, /HCENTER:  override any /POS= x value\n\
\t/TOP, /BOTTOM, /VCENTER:  override any /POS= y value\n\
\n\
Any leading or trailing whitespace will be stripped from the text.\n";

#endif	//	OSD_FULL_HELP

#endif	//	OSD_OSD_CMD


#ifdef	OSD_OSD_VARS

const wchar_t _OSDHelpText[] = L"_OSD \r\n\n\
Returns the total number of OSD windows currently  \n\
open in this instance of the plugin.\n";


const wchar_t _OSDVerHelpText[] = L"_OSDVER \r\n\n\
Returns the version of OSD in this plugin.  \n";


const wchar_t F_OSDHelpText[] = L"@OSD[id] \r\n\n\
Returns the number of OSD windows with the specified  \n\
id currently open in this instance of the plugin.\n";

#endif	//	OSD_OSD_VARS


#ifdef	OSD_PCTBAR_CMD

const wchar_t PctBarHelpText[] = L"Display an on-screen percentage bar.\n\
\n\
PCTBAR /N /POS=y,x /RGB=r,g,b /TIME=n /SIZE=w,h /ID=n /C num/denom \r\n\n\
\t/N\tdo not wait for timeout\n\
\t/POS=\tposition on screen \t(0,0)\n\
\t/RGB=\tset the window color\t(0,255,0)\n\
\t/TIME=\ttimeout in seconds \t(4)\n\
\t/SIZE=\tset the window size \t(200,40)\n\
\t/ID=\twindow ID       \t(999)\n\
\t/C\talso close any OSD windows with the same ID\n\
\t/V\talso show the value as a percentage\n\
\t/COLOR=\tspecify color as a TCC color number, 0 - 15\n\
\t/ALPHA=\ttransparency; 64 (ghostly) to 255 (opaque)\n\
\t/FADE\tfade the window out\n\
\t/LEFT, /RIGHT, /HCENTER:  override any /POS= x value\n\
\t/TOP, /BOTTOM, /VCENTER:  override any /POS= y value  \n\
\n\
num (the numerator) is required.  denom (the denominator) is  \n\
optional, and defaults to 100.\n";

#endif	//	OSD_PCTBAR_CMD


#ifdef	OSD_OSDIMG_CMD

const wchar_t OsdImgHelpText[] = L"Display an on-screen graphic image.\n\
\n\
OSDIMG /N /POS=y,x /TIME=n /SIZE=w,h /ID=n /C /I=n /BG imagefile \r\n\n\
\t/N\tdo not wait for timeout\n\
\t/POS=\tposition on screen \t(0,0)\n\
\t/TIME=\ttimeout in seconds \t(4)\n\
\t/SIZE=\tset the window size \t(200,0)\n\
\t/ID=\twindow ID       \t(998)\n\
\t/C\talso close any OSD windows with the same ID\n\
\t/ALPHA=\ttransparency; 64 (ghostly) to 255 (opaque)\n\
\t/FADE\tfade the window out\n\
\t/LEFT, /RIGHT, /HCENTER:  override any /POS= x value\n\
\t/TOP, /BOTTOM, /VCENTER:  override any /POS= y value  \n\
\t/I=\ticon index\n\
\t/BG\tmake color at top left corner transparent\n\
\n\
The filename is required.\n";

#endif	//	OSD_OSDIMG_CMD


const wchar_t OSD_RegKeyName[]			= L"Software\\JPPlugins\\OSD";
const wchar_t OSD_TypefaceValueName[]	= L"Typeface";
const wchar_t OSD_HeightValueName[]		= L"Height";
const wchar_t OSD_WeightValueName[]		= L"Weight";
const wchar_t OSD_ItalicsValueName[]	= L"Italics";
const wchar_t OSD_UnderlineValueName[]	= L"Underline";
const wchar_t OSD_RGBValueName[]		= L"RGB";
const wchar_t OSD_AlphaValueName[]		= L"Alpha";
const wchar_t OSD_ShadowValueName[]		= L"Shadow";
const wchar_t OSD_TimeoutValueName[]	= L"Timeout";
const wchar_t OSD_MaxLinesValueName[]	= L"MaxLines";
const wchar_t OSD_PBTimeoutValueName[]	= L"PercentBarTimeout";



const DWORD ColorTable[16] =  { 0x000000, 0x800000, 0x008000, 0x808000, 0x000080, 0x800080, 0x008080, 0xc0c0c0,
								0x808080, 0xff0000, 0x00ff00, 0xffff00, 0x0000ff, 0xff00ff, 0x00ffff, 0xffffff };





BOOL _OSD_IsFile( LPTSTR Filename )
{
	if ( !Filename )
		return FALSE;
	else if ( Filename[0] == '\0' )
		return FALSE;


	DWORD Attr = GetFileAttributes( Filename );


	if ( Attr == INVALID_FILE_ATTRIBUTES )
		return FALSE;

	if ( Attr & FILE_ATTRIBUTE_DIRECTORY )
		return FALSE;

	return TRUE;
}



BOOL WINAPI ControlBreakProc( DWORD CtrlType )
{
	if ( ( CtrlType == CTRL_C_EVENT ) || ( CtrlType = CTRL_BREAK_EVENT ) )
		OSDCtrlBreakFlag++;

	return FALSE;
}



BOOL CALLBACK CloseOSDWindowSub( HWND hWnd, LPARAM lParam )
{
	_FindOSDWindows *FindOSDWindows		= (_FindOSDWindows*) lParam;

	wchar_t WinClass[SHORT_BUF_LEN]		= L"";
	wchar_t WinTitle[SHORT_BUF_LEN]		= L"";
	wchar_t IDTitle[SHORT_BUF_LEN]		= L"";


	if ( FindOSDWindows->SkipWindow )
		if ( hWnd == FindOSDWindows->SkipWindow )
			return TRUE;

	GetClassName( hWnd, WinClass, SHORT_BUF_LEN );
	if ( wcscmp( WinClass, OSDWindowClass ) )
		return TRUE;

	if ( FindOSDWindows->WindowID != -1 ) {
		wsprintf( IDTitle, L"OSD #%u", FindOSDWindows->WindowID );

		GetWindowText( hWnd, WinTitle, SHORT_BUF_LEN );
		if ( wcscmp( WinTitle, IDTitle ) )
			return TRUE;
	}

	if ( FindOSDWindows->Msg )
		SendMessage( hWnd, FindOSDWindows->Msg, 0, 0 );

	FindOSDWindows->Count++;
	return TRUE;
}



unsigned int CloseOSDWindowsByID( unsigned int WindowID, HWND SkipWindow = NULL )
{
	_FindOSDWindows FindOSDWindows;


	FindOSDWindows.Count		= 0;
	FindOSDWindows.WindowID		= WindowID;
	FindOSDWindows.SkipWindow	= SkipWindow;
	FindOSDWindows.Msg			= WM_CLOSE;

	EnumWindows( CloseOSDWindowSub, (LPARAM) &FindOSDWindows );

	return FindOSDWindows.Count;
}



unsigned int CloseAllOSDWindows( )
{
	return CloseOSDWindowsByID( -1 );
}



unsigned int FadeOSDWindowsByID( unsigned int WindowID )
{
	_FindOSDWindows FindOSDWindows;


	FindOSDWindows.Count		= 0;
	FindOSDWindows.WindowID		= WindowID;
	FindOSDWindows.SkipWindow	= NULL;
	FindOSDWindows.Msg			= WM_FADENOW;

	EnumWindows( CloseOSDWindowSub, (LPARAM) &FindOSDWindows );

	return FindOSDWindows.Count;
}



BOOL CALLBACK CountOSDWindowSub( HWND hWnd, LPARAM lParam )
{
	_FindOSDWindows *FindOSDWindows		= (_FindOSDWindows*) lParam;

	wchar_t WinClass[SHORT_BUF_LEN]		= L"";
	wchar_t WinTitle[SHORT_BUF_LEN]		= L"";
	wchar_t IDTitle[SHORT_BUF_LEN]		= L"";


	GetClassName( hWnd, WinClass, SHORT_BUF_LEN );
	if ( wcscmp( WinClass, OSDWindowClass ) )
		return TRUE;

	if ( FindOSDWindows->WindowID != -1 ) {
		wsprintf( IDTitle, L"OSD #%u", FindOSDWindows->WindowID );

		GetWindowText( hWnd, WinTitle, SHORT_BUF_LEN );
		if ( wcscmp( WinTitle, IDTitle ) )
			return TRUE;
	}

	FindOSDWindows->Count++;
	return TRUE;
}



unsigned int CountOSDWindows( unsigned int WindowID )
{
	_FindOSDWindows FindOSDWindows;


	FindOSDWindows.Count		= 0;
	FindOSDWindows.WindowID		= WindowID;

	EnumWindows( CountOSDWindowSub, (LPARAM) &FindOSDWindows );

	return FindOSDWindows.Count;
}



DWORD _OSD_SwapBytes( DWORD Color )
{
	return ( ( Color & 0xff0000 ) >> 16 ) | ( Color & 0x00ff00 ) | ( ( Color & 0x0000ff ) << 16 );
}



LRESULT CALLBACK OsdWindowProc( HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam )
{
	switch ( Msg ) {

	case WM_CLOSE :
		KillTimer( hWnd, OSDTimerID );
		KillTimer( hWnd, OSDBlinkTimerID );
		free( (void*) GetWindowLongPtr( hWnd, GWLP_USERDATA ) );
		DestroyWindow( hWnd );
		break;

	case WM_TIMER :

		if ( wParam == OSDTimerID ) {
			_OSDWindowData *WindowData = (_OSDWindowData*) GetWindowLongPtr( hWnd, GWLP_USERDATA );
			BOOL Finito = TRUE;

			if ( WindowData ) {

				if ( WindowData->Fading & OSD_FADING_IN ) {
					int NewAlpha = WindowData->CurrentAlpha + OSD_FADE_IN_STEP;

					if ( NewAlpha >= WindowData->PeakAlpha ) {
						NewAlpha = WindowData->PeakAlpha;
						WindowData->Fading &= ~OSD_FADING_IN;

						if ( WindowData->Timeout )
							SetTimer( hWnd, OSDTimerID, WindowData->Timeout, NULL );
						else
							KillTimer( hWnd, OSDTimerID );

						if ( WindowData->Blink && WindowData->BlinkRate )
							SetTimer( hWnd, OSDBlinkTimerID, WindowData->BlinkRate, NULL );
					}

					WindowData->CurrentAlpha = (BYTE) NewAlpha;
					SetLayeredWindowAttributes( hWnd, WindowData->BackColor, WindowData->CurrentAlpha, WindowData->LayeredAttribs );
					Finito = FALSE;
				}
				else if ( WindowData->Fading & OSD_SHOULD_FADE )
					WindowData->Fading = ( WindowData->Fading & ~OSD_SHOULD_FADE ) | OSD_FADING_OUT;

				if ( WindowData->Fading & OSD_FADING_OUT ) {
					if ( WindowData->CurrentAlpha == WindowData->PeakAlpha ) {
						SetTimer( hWnd, OSDTimerID, OSD_FADE_DELAY, NULL );

						if ( WindowData->Blink ) {
							KillTimer( hWnd, OSDBlinkTimerID );
							ShowWindow( hWnd, SW_SHOW );
						}
					}

					if ( WindowData->CurrentAlpha >= OSD_FADE_STEP ) {
						WindowData->CurrentAlpha -= OSD_FADE_STEP;
						SetLayeredWindowAttributes( hWnd, WindowData->BackColor, WindowData->CurrentAlpha, WindowData->LayeredAttribs );
						Finito = FALSE;
					}
				}
			}

			if ( Finito ) {
				KillTimer( hWnd, OSDTimerID );
				KillTimer( hWnd, OSDBlinkTimerID );
				free( WindowData );
				DestroyWindow( hWnd );
			}
		}
		else if ( wParam == OSDBlinkTimerID ) {
			_OSDWindowData *WindowData = (_OSDWindowData*) GetWindowLongPtr( hWnd, GWLP_USERDATA );

			if ( WindowData ) {
				WindowData->Blink ^= 1;
				ShowWindow( hWnd, ( WindowData->Blink & 1 ) ? SW_HIDE : SW_SHOW );
			}
		}

		break;

	case WM_DESTROY :
		PostQuitMessage( 0 );
		break;

	/*
	case WM_NCHITTEST :
		return HTNOWHERE;
	*/

	case WM_FADENOW :
		{
			_OSDWindowData *WindowData = (_OSDWindowData*) GetWindowLongPtr( hWnd, GWLP_USERDATA );

			if ( WindowData ) {
				if ( WindowData->Blink ) {
					KillTimer( hWnd, OSDBlinkTimerID );
					ShowWindow( hWnd, SW_SHOW );
				}

				WindowData->Fading = OSD_FADING_OUT;
				SetTimer( hWnd, OSDTimerID, OSD_FADE_DELAY, NULL );
			}
			else {
				KillTimer( hWnd, OSDTimerID );
				KillTimer( hWnd, OSDBlinkTimerID );
				free( WindowData );
				DestroyWindow( hWnd );
			}
		}

		break;

	default :
		//	wprintf( L"   * Some window message:  Msg = 0x%08x   wParam = 0x%08x   lParam = 0x%08x \n", Msg, wParam, lParam );
		return DefWindowProc( hWnd, Msg, wParam, lParam );
	}

	return 0;
}



struct _GetMonitorHandleData {
	int Which;
	int Count;
	HMONITOR Handle;
};



BOOL CALLBACK GetMonitorHandleProc( HMONITOR hMonitor, HDC hdcMonitor, LPRECT lprcMonitor, LPARAM dwData )
{
	if ( !dwData )
		return TRUE;

	_GetMonitorHandleData *Data = (_GetMonitorHandleData*) dwData;

	if ( Data->Which == Data->Count ) {
		Data->Handle = hMonitor;
		return FALSE;
	}

	Data->Count += 1;
	return TRUE;
}



HMONITOR GetMonitorHandle( int Monitor )
{
	_GetMonitorHandleData Data = { Monitor, 0, NULL };

	EnumDisplayMonitors( NULL, NULL, GetMonitorHandleProc, (LPARAM) &Data );
	return Data.Handle;
}



#ifdef	OSD_ANGLES

double dbiggest( double v1, double v2 )
{
	if ( v1 >= v2 )
		return v1;
	else
		return v2;
}



int RotateRectCorners( RECT *TextArea, RECT *FillArea, int Angle )
{
	if ( !TextArea || !FillArea )
		return -1;

	
	*FillArea = *TextArea;
	
	Angle = ( Angle + 360 ) % 360;

	if ( Angle == 0 )
		return 0;


	int TextWidth = ( TextArea->right - TextArea->left );
	int TextHeight = ( TextArea->bottom - TextArea->top );
	int FillWidth = 0, FillHeight = 0;
	int quadrant = Angle / 90;
	double pi = 4 * atan( 1.0 );
	double pi_2 = 2 * atan( 1.0 );
	double rad = ( Angle * pi ) / 180.0;

	double x0 = TextArea->left;
	double y0 = TextArea->top;
	double x1 = x0 + ( TextWidth * cos( rad ) );
	double y1 = y0 - ( TextWidth * sin( rad ) );
	double x2 = x0 + ( TextHeight * cos( rad - pi_2 ) );
	double y2 = y0 + ( TextHeight * sin( rad - pi_2 ) );
	double x3 = x1 + x2;
	double y3 = y1 + y2;

	//	wprintf( L"   * Angle = %d  (%f, %f)  (%f, %f)  (%f, %f)\n", Angle, x1, y1, x2, y2, x3, y3 );


	FillWidth = (int) dbiggest( abs( x2 - x1 ), abs( x3 - x0 ) );
	FillHeight = (int) dbiggest( abs( y2 - y1 ), abs( y3 - y0 ) );
	//	wprintf( L"   * FillWidth = %d   FillHeight = %d\n", FillWidth, FillHeight );

	FillArea->right = FillArea->left + FillWidth;
	FillArea->bottom = FillArea->top + FillHeight;


	switch ( quadrant ) {
	case 0 :
		TextArea->top -= (int) y1;
		break;

	case 1 :
		TextArea->top = FillHeight;
		TextArea->left -= (int) x1;
		break;

	case 2 :
		TextArea->top += (int) y2;
		TextArea->left = FillWidth;
		break;

	case 3 :
		TextArea->left -= (int) x2;
		break;
	}

	TextArea->bottom = TextArea->top + TextHeight;
	TextArea->right = TextArea->left + TextWidth;
	return 0;
}

#else	//  OSD_ANGLES

int RotateRectCorners( RECT *TextArea, RECT *FillArea, int Angle )		//  alternate with no trig support:
{
	if ( !TextArea || !FillArea )
		return -1;

	
	*FillArea = *TextArea;
	
	Angle = ( Angle + 360 ) % 360;

	if ( !Angle )
		return 0;


	int TextWidth = ( TextArea->right - TextArea->left );
	int TextHeight = ( TextArea->bottom - TextArea->top );


	if ( Angle >= 270 ) {
		TextArea->bottom = TextArea->top + TextWidth;
		TextArea->left += TextHeight;
		TextArea->right = TextArea->left + TextHeight;
		FillArea->bottom = FillArea->top + TextWidth;
		FillArea->right = FillArea->left + TextHeight;
	}
	else if ( Angle >= 180 ) {
		TextArea->top += TextHeight;
		TextArea->left += TextWidth;
		TextArea->bottom = TextArea->top + TextHeight;
		TextArea->right = TextArea->left + TextWidth;
	}
	else if ( Angle >= 90 ) {
		TextArea->top += TextWidth;
		TextArea->bottom = TextArea->top + TextWidth;
		TextArea->right = TextArea->left + TextHeight;
		FillArea->bottom = FillArea->top + TextWidth;
		FillArea->right = FillArea->left + TextHeight;
	}

	return 0;
}

#endif	//	OSD_ANGLES



DWORD ContrastyPrimaryColor( DWORD Color1, DWORD Color2 )
{
	DWORD rv		= 0x000000;


	if ( ( Color1 & 0x800000 ) == 0 )
		rv |= 0xff0000;

	if ( ( Color1 & 0x008000 ) == 0 )
		rv |= 0x00ff00;

	if ( ( Color2 & 0x000080 ) == 0 )
		rv |= 0x0000ff;

	return rv;
}



unsigned int _OSD_Lum( COLORREF Color )
{
	unsigned int Red	= ( Color & 0x0000ff );
	unsigned int Green	= ( Color & 0x00ff00 ) >> 8;
	unsigned int Blue	= ( Color & 0xff0000 ) >> 16;

	
	return ( Red * 299 / 255 ) + ( Green * 587 / 255 ) + ( Blue * 114 / 255 );
}



COLORREF _OSD_Shade( COLORREF Color, double factor )
{
	int R		= GetRValue( Color );
	int G		= GetGValue( Color );
	int B		= GetBValue( Color );
	int NewR	= (int) ( R * ( 1.0 - factor ) );
	int NewG	= (int) ( G * ( 1.0 - factor ) );
	int NewB	= (int) ( B * ( 1.0 - factor ) );

	return RGB( NewR, NewG, NewB );
}



COLORREF _OSD_Tint( COLORREF Color, double factor )
{
	int R		= GetRValue( Color );
	int G		= GetGValue( Color );
	int B		= GetBValue( Color );
	int NewR	= (int) ( R + ( 255 - R ) * factor );
	int NewG	= (int) ( G + ( 255 - G ) * factor );
	int NewB	= (int) ( B + ( 255 - B ) * factor );

	return RGB( NewR, NewG, NewB );
}



COLORREF DefaultShadowColor( COLORREF Color )
{
	unsigned int lum	= _OSD_Lum( Color );


	if ( lum >= 200 )
		return _OSD_Shade( Color, 0.75 );
	else
		return _OSD_Tint( Color, 0.40 );
}



int OSD_AdjustForScrollBars( HWND hWnd, RECT *WindowRect )
{
	if ( !hWnd || !WindowRect || !GetScrollBarInfoProc )
		return -1;


	SCROLLBARINFO HScrollInfo;
	SCROLLBARINFO VScrollInfo;

	int rv				= 0;


	memset( &HScrollInfo, 0x00, sizeof( SCROLLBARINFO ) );
	memset( &VScrollInfo, 0x00, sizeof( SCROLLBARINFO ) );
	HScrollInfo.cbSize	= sizeof( SCROLLBARINFO );
	VScrollInfo.cbSize	= sizeof( SCROLLBARINFO );

	if ( GetScrollBarInfoProc( hWnd, OBJID_HSCROLL, &HScrollInfo ) )
		if ( ( HScrollInfo.rgstate[0] & STATE_SYSTEM_INVISIBLE ) == 0 )
			WindowRect->bottom -= HScrollInfo.dxyLineButton, rv++;

	if ( GetScrollBarInfoProc( hWnd, OBJID_VSCROLL, &VScrollInfo ) )
		if ( ( VScrollInfo.rgstate[0] & STATE_SYSTEM_INVISIBLE ) == 0 )
			WindowRect->right -= VScrollInfo.dxyLineButton, rv++;

	return rv;
}



int OSD_ClientRectToScreenRect( HWND hWnd, RECT *Rect )
{
	if ( !hWnd || !Rect )
		return -1;


	if ( !GetClientRect( hWnd, Rect ) )
		return GetLastError();

	SetLastError( 0 );

	MapWindowPoints( hWnd, NULL, (POINT*) Rect, 2 );
	return GetLastError();
}



int OSD_AdjustWindowsTerminalClientRect( RECT *Rect )
{
	if ( !Rect )
		return -1;


	int TitleHeight		= GetSystemMetrics( SM_CYSIZE );
	int ScrollWidth		= GetSystemMetrics( SM_CXVSCROLL );


	if ( ( Rect->bottom - Rect->top ) > ( 5 * TitleHeight ) )
		Rect->top += ( TitleHeight * 2 );

	if ( ( Rect->right - Rect->top ) > ( 5 * ScrollWidth ) )
		Rect->right -= ScrollWidth;

	return 0;
}



int OSD_AdjustConEmuRect( RECT *Rect )
{
	if ( !Rect )
		return -1;


	int ScrollWidth		= GetSystemMetrics( SM_CXVSCROLL );


	if ( ( Rect->right - Rect->top ) > ( 5 * ScrollWidth ) )
		Rect->right -= ScrollWidth;

	return 0;
}



/*
COLORREF DefaultShadowColor( COLORREF Color )
{
	COLORREF rv			= 0x000000;
	unsigned int lum	= _OSD_Lum( Color );


	if ( lum >= 500 )
		rv = 0x4f4f2f;					//	if it's bright, return dark slate gray (lum. 271)
	else if ( lum < 200 )
		rv = 0x696969;					//	if it's quite dark, return dim gray (lum. 410)
	else
		rv = 0x000000;					//  in the middle, return black (lum. 0)

	return rv;
}
*/



int DrawOSDText( HWND hWnd, HDC Draw, DWORD Flags, COLORREF Color, COLORREF BackColor, void *Args )
{
	if ( !hWnd || !Draw || !Args )
		return -1;


	_DrawOSDTextArgs *args		= (_DrawOSDTextArgs*) Args;
	DWORD Italic				= 0;
	DWORD Underline				= 0;
	HFONT FontHandle			= NULL;
	RECT TextArea				= { 0, 0, 10, 10 };
	RECT FillArea				= { 0, 0, 10, 10 };
	unsigned int TextWidth		= 0;
	unsigned int TextHeight		= 0;
	int DropShadowDistance		= OSD_DROPSHADOW_DISTANCE;
	int TextAngle				= args->TextAngle;
	unsigned int DrawTextFlags	= DT_NOCLIP | DT_NOPREFIX;
	HBRUSH BGBrush				= NULL;


	if ( ( TextAngle < -360 ) || ( TextAngle > 360 ) )
		TextAngle = 0;

	if ( Flags & OSD_DEBUG )
		BackColor = 0xfc0000;

	if ( Flags & OSD_ITALIC )
		Italic = TRUE;

	if ( Flags & OSD_UNDERLINE )
		Underline = TRUE;


	switch ( Flags & OSD_JUSTIFY_BITS ) {

	case OSD_CENTER_JUSTIFY :
		DrawTextFlags |= DT_CENTER;
		break;

	case OSD_RIGHT_JUSTIFY :
		DrawTextFlags |= DT_RIGHT;
		break;
	}


	if ( args->TextSize > ( 12 * OSD_DROPSHADOW_DISTANCE ) )
		DropShadowDistance = args->TextSize / 12;


	FontHandle = CreateFont( -MulDiv( args->TextSize, GetDeviceCaps( Draw, LOGPIXELSY ), 72 ), 0, TextAngle * 10, TextAngle * 10, args->Weight, Italic, Underline, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, NONANTIALIASED_QUALITY, FF_DONTCARE, args->FontName );
	if ( !FontHandle )
		return 1;

	SelectObject( Draw, FontHandle );
	SetTextColor( Draw, Color );
	SetBkColor( Draw, BackColor );
	SetBkMode( Draw, OPAQUE );

	DrawText( Draw, args->Text, -1, &TextArea, DT_CALCRECT | DT_NOCLIP | DT_NOPREFIX );
	TextWidth = TextArea.right;
	TextHeight = TextArea.bottom;
	FillArea = TextArea;

	RotateRectCorners( &TextArea, &FillArea, TextAngle );

	if ( Flags & OSD_SHADOW ) {
		FillArea.right += DropShadowDistance;
		FillArea.bottom += DropShadowDistance;
	}

	SetWindowPos( hWnd, HWND_TOPMOST, OSD_Offscreen, OSD_Offscreen, FillArea.right, FillArea.bottom, SWP_SHOWWINDOW );


	BGBrush = CreateSolidBrush( BackColor );
	if ( BGBrush ) {
		FillRect( Draw, &FillArea, BGBrush );
		DeleteObject( BGBrush );
	}

	if ( Flags & OSD_SHADOW ) {
		RECT ShadowArea;
		ShadowArea.top		= TextArea.top		+ DropShadowDistance;
		ShadowArea.bottom	= TextArea.bottom	+ DropShadowDistance;
		ShadowArea.left		= TextArea.left		+ DropShadowDistance;
		ShadowArea.right	= TextArea.right	+ DropShadowDistance;

		SetTextColor( Draw, args->ShadowColor );

		DrawText( Draw, args->Text, -1, &ShadowArea, DrawTextFlags );

		SetTextColor( Draw, Color );
		SetBkMode( Draw, TRANSPARENT );
	}

	DrawText( Draw, args->Text, -1, &TextArea, DrawTextFlags );
	DeleteObject( FontHandle );
	return 0;
}



int DrawPercentBar( HWND hWnd, HDC Draw, DWORD Flags, COLORREF Color, COLORREF BackColor, void *Args )
{
	if ( !hWnd || !Draw || !Args )
		return -1;


	_DrawPercentBarArgs *args	= (_DrawPercentBarArgs*) Args;

	unsigned int Dividend		= args->Dividend;
	unsigned int Divisor		= args->Divisor;
	unsigned int SizeX			= args->SizeX;
	unsigned int SizeY			= args->SizeY;

	RECT WindowArea				= { 0, 0, 10, 10 };
	RECT FrameArea				= { 0, 0, 10, 10 };
	RECT FillArea				= { 0, 0, 10, 10 };
	BOOL Thicker				= TRUE;

	HBRUSH BGBrush				= NULL;
	HBRUSH FGBrush				= NULL;
	HBRUSH HatchBrush			= NULL;



	if ( !SizeX )
		SizeX = OSD_PCTBAR_DEFAULT_WIDTH;

	if ( !SizeY )
		SizeY = OSD_PCTBAR_DEFAULT_HEIGHT;

	if ( SizeX < 10 )
		SizeX = 10;

	if ( SizeY < 5 )
		SizeY = 5;

	if ( !Divisor )
		Divisor = 100;

	if ( Dividend > Divisor )
		Dividend = Divisor;

	if ( ( SizeX < 40 ) || ( SizeY < 16 ) )
		Flags &= ~OSD_SHOW_VALUE;

	if ( Flags & OSD_DEBUG )
		BackColor = 0xfc0000;


	SetBkColor( Draw, BackColor );
	SetBkMode( Draw, OPAQUE );

	WindowArea.top		= 0;
	WindowArea.left		= 0;
	WindowArea.right	= SizeX;
	WindowArea.bottom	= SizeY;

	FrameArea			= WindowArea;
	FillArea			= WindowArea;


	if ( FrameArea.bottom > FrameArea.right )
		FillArea.top = FrameArea.bottom - ( ( FrameArea.bottom * Dividend ) / Divisor );
	else
		FillArea.right = ( FrameArea.right * Dividend ) / Divisor;

	if ( Flags & OSD_SHADOW ) {
		WindowArea.right	+= OSD_DROPSHADOW_DISTANCE;
		WindowArea.bottom	+= OSD_DROPSHADOW_DISTANCE;
	}

	SetWindowPos( hWnd, HWND_TOPMOST, OSD_Offscreen, OSD_Offscreen, WindowArea.right, WindowArea.bottom, SWP_SHOWWINDOW );

	BGBrush = CreateSolidBrush( BackColor );
	if ( BGBrush ) {
		FillRect( Draw, &WindowArea, BGBrush );
		DeleteObject( BGBrush );
	}

	FGBrush = CreateSolidBrush( Color );

	if ( FGBrush ) {

		if ( Flags & OSD_SHADOW ) {
			RECT ShadFrame;
			//  RECT ShadFill;
			ShadFrame.top		= FrameArea.top		+ OSD_DROPSHADOW_DISTANCE;
			ShadFrame.bottom	= FrameArea.bottom	+ OSD_DROPSHADOW_DISTANCE;
			ShadFrame.left		= FrameArea.left	+ OSD_DROPSHADOW_DISTANCE;
			ShadFrame.right		= FrameArea.right	+ OSD_DROPSHADOW_DISTANCE;
			//	ShadFill.top		= FillArea.top		+ OSD_DROPSHADOW_DISTANCE;
			//	ShadFill.bottom		= FillArea.bottom	+ OSD_DROPSHADOW_DISTANCE;
			//	ShadFill.left		= FillArea.left		+ OSD_DROPSHADOW_DISTANCE;
			//	ShadFill.right		= FillArea.right	+ OSD_DROPSHADOW_DISTANCE;


			/*
			if ( Flags & OSD_PTC_HATCH ) {
				HBRUSH ShadowBrush = CreateHatchBrush( HS_BDIAGONAL, DefaultShadowColor( Color ) );
				if ( ShadowBrush ) {
					SetBkMode( Draw, TRANSPARENT );
					SelectObject( Draw, ShadowBrush );
					Rectangle( Draw, ShadFrame.left, ShadFrame.top, ShadFrame.right, ShadFrame.bottom );
					DeleteObject( ShadowBrush );
				}
			}

			HBRUSH ShadowBrush = CreateSolidBrush( DefaultShadowColor( Color ) );
			if ( ShadowBrush ) {
				FrameRect( Draw, &ShadFrame, ShadowBrush );
				FillRect( Draw, &ShadFill, ShadowBrush );
				DeleteObject( ShadowBrush );
			}
			*/

			HBRUSH ShadowBrush = CreateSolidBrush ( args->ShadowColor );
			if ( ShadowBrush ) {
				FillRect( Draw, &ShadFrame, ShadowBrush );
				SetBkMode( Draw, TRANSPARENT );
				DeleteObject( ShadowBrush );
			}
		}

		if ( Flags & OSD_ITALIC )
			HatchBrush = CreateHatchBrush( HS_BDIAGONAL, Color );
		else if ( Flags & OSD_CENTER_JUSTIFY )
			HatchBrush = CreateHatchBrush( HS_DIAGCROSS, Color );

		if ( HatchBrush ) {
			SelectObject( Draw, HatchBrush );
			Rectangle( Draw, FrameArea.left, FrameArea.top, FrameArea.right, FrameArea.bottom );
			DeleteObject( HatchBrush );
			HatchBrush = NULL;
		}


		FrameRect( Draw, &FrameArea, FGBrush );
		FillRect( Draw, &FillArea, FGBrush );

		if ( Flags & OSD_SHOW_VALUE ) {

			wchar_t PctText[SHORT_BUF_LEN]	= L"";
			COLORREF TextColor = ( _OSD_Lum( Color ) >= 600 ) ? 0x000000 : 0xffffff;
			RECT TextArea = { 0, 0, 10, 10 };
			int TextSize = 9;


			if ( TextColor == BackColor )
				TextColor ^= 0x010000;

			if ( ( SizeY / 2 ) > ( SizeX / 5 ) )
				TextSize = SizeX / 5;
			else
				TextSize = SizeY / 2;


			swprintf( PctText, SHORT_BUF_LEN, L"%5.1f%%", Dividend * 100.0 / Divisor );

			HFONT FontHandle = CreateFont( -MulDiv( TextSize, GetDeviceCaps( Draw, LOGPIXELSY ), 72 ), 0, 0, 0, 400, 0, 0, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, NONANTIALIASED_QUALITY, FF_DONTCARE, L"Arial" );
			if ( FontHandle ) {

				SelectObject( Draw, FontHandle );
				SetTextColor( Draw, TextColor );
				SetBkColor( Draw, BackColor );
				SetBkMode( Draw, TRANSPARENT );
						
				DrawText( Draw, PctText, -1, &TextArea, DT_CALCRECT | DT_NOCLIP | DT_NOPREFIX );

				if ( TextArea.right < (signed) SizeX ) {
					TextArea.left	+= ( ( SizeX - TextArea.right ) / 2 );
					TextArea.right	+= ( ( SizeX - TextArea.right ) / 2 );
				}

				if ( TextArea.bottom < (signed) SizeY ) {
					TextArea.top	+= ( ( SizeY - TextArea.bottom ) / 2 );
					TextArea.bottom	+= ( ( SizeY - TextArea.bottom ) / 2 );
				}

				DrawText( Draw, PctText, -1, &TextArea, DT_NOCLIP | DT_NOPREFIX );
				DeleteObject( FontHandle );
			}
		}

		DeleteObject( FGBrush );
	}

	return 0;
}



#ifdef	OSD_OSDIMG_CMD

int DrawOSDImage( HWND hWnd, HDC Draw, DWORD Flags, COLORREF Color, COLORREF BackColor, void *Args )
{
	if ( !hWnd || !Draw || !Args )
		return -1;


	SIZE *ImageSize		= (LPSIZE) Args;


	SetWindowPos( hWnd, HWND_TOPMOST, OSD_Offscreen, OSD_Offscreen, ImageSize->cx, ImageSize->cy, SWP_SHOWWINDOW );

	return 0;
}

#endif	//	OSD_OSDIMG_CMD



HWND CreateOSDWindow( unsigned int WindowID, unsigned int Timeout, int x, int y, COLORREF Color, COLORREF Color2, DWORD Flags, BYTE Alpha, WORD Blink, int Monitor, void *Args, int DrawRoutine( HWND hWnd, HDC Draw, DWORD Flags, COLORREF Color, COLORREF BackColor, void *Args ) )
{
	HWND hWnd						= NULL;
	HDC Draw						= NULL;
	COLORREF BackColor				= 0x000000;
	DWORD LayeredAttribs			= LWA_COLORKEY | LWA_ALPHA;
	RECT ScreenArea					= { 0, 0, 0, 0 };
	RECT WindowArea					= { 0, 0, 0, 0 };
	int WindowX						= 0;
	int WindowY						= 0;
	int WindowWidth					= 0;
	int WindowHeight				= 0;

#ifdef OSD_TAB_OPTION

	HWND MyTabWindow				= NULL;
	unsigned int MyWindowType		= MY_WINDOW_UNKNOWN;

#endif	//	OSD_TAB_OPTION

	BOOL GotTargetRect				= FALSE;

	wchar_t WinTitle[SHORT_BUF_LEN]	= L"";



	//		Get screen area:  (for relative positioning)


#ifdef OSD_TAB_OPTION

	if ( Flags & OSD_MY_TAB ) {
		FindMyWindow( &MyWindowType, &MyTabWindow );

		if ( ( MyWindowType < MY_WINDOW_CONSOLE ) || ( ( MyWindowType > MY_WINDOW_CONEMU ) && ( MyWindowType != MY_WINDOW_WINDOWS_TERMINAL ) ) )
			MyTabWindow = NULL;

		if ( MyTabWindow ) {
			if ( GetWindowRect( MyTabWindow, &ScreenArea ) ) {

				GotTargetRect = TRUE;

				if ( ( MyWindowType == MY_WINDOW_CONSOLE ) || ( MyWindowType == MY_WINDOW_WINDOWS_TERMINAL ) )
					if ( OSD_ClientRectToScreenRect( MyTabWindow, &ScreenArea ) )
						GotTargetRect = FALSE;

				if ( GotTargetRect ) {

					switch ( MyWindowType ) {

					case MY_WINDOW_CONSOLE :

						break;

					case MY_WINDOW_CONEMU :

						OSD_AdjustConEmuRect( &ScreenArea );
						break;

					case MY_WINDOW_WINDOWS_TERMINAL :

						OSD_AdjustWindowsTerminalClientRect( &ScreenArea );
						break;

					default :

						OSD_AdjustForScrollBars( MyTabWindow, &ScreenArea );

					}

					if ( ( Flags & OSD_X_BITS ) == 0 )
						Flags |= OSD_LEFT;

					if ( ( Flags & OSD_Y_BITS ) == 0 )
						Flags |= OSD_TOP;

					Flags |= OSD_ADD_OFFSET;
				}
			}
		}
	}

#endif	//	OSD_TAB_OPTION

	if ( !GotTargetRect ) {
		if ( Monitor < 0 ) {
			ScreenArea.left		= GetSystemMetrics( SM_XVIRTUALSCREEN );
			ScreenArea.top		= GetSystemMetrics( SM_YVIRTUALSCREEN );
			ScreenArea.right	= ScreenArea.left  + GetSystemMetrics( SM_CXVIRTUALSCREEN );
			ScreenArea.bottom	= ScreenArea.top   + GetSystemMetrics( SM_CYVIRTUALSCREEN );
		}
		else {
			HMONITOR MonitorHandle	= NULL;
			MONITORINFO MonitorInfo;
			BOOL Good				= FALSE;

		
			MonitorInfo.cbSize = sizeof( MONITORINFO );

			if ( Monitor >= GetSystemMetrics( SM_CMONITORS ) )
				MonitorHandle = MonitorFromWindow( GetDesktopWindow(), MONITOR_DEFAULTTOPRIMARY );
			else
				MonitorHandle = GetMonitorHandle( Monitor );

			if ( MonitorHandle ) {
				if ( GetMonitorInfo( MonitorHandle, &MonitorInfo ) ) {
					ScreenArea = MonitorInfo.rcWork;
					Good = TRUE;
				}
			}

			if ( !Good )
				SystemParametersInfo( SPI_GETWORKAREA, 0, &ScreenArea, 0 );
		}
	}


	//		Sanity check a few parameters:

	if ( Alpha < OSD_ALPHA_MIN )
		Alpha = OSD_ALPHA_MAX;

	if ( ( Blink < OSD_BLINK_MIN ) || ( Blink > OSD_BLINK_MAX ) )
		Blink = 0;


	//		Pick a default background color:

	if ( Flags & OSD_NOT_TRANSP ) {
		BackColor = Color;
		LayeredAttribs &= ( ~LWA_COLORKEY );
	}
	else if ( Flags & OSD_COLOR_TRANS )
		BackColor = Color;
	else
		BackColor = ContrastyPrimaryColor( Color, Color2 );


	//		I use the window title to store the OSD window ID:  (the title is invisible)

	wsprintf( WinTitle, L"OSD #%u", WindowID );


	//		Create the window, and get a handle to draw on it:

	hWnd = CreateWindowEx( WS_EX_TOOLWINDOW | WS_EX_TOPMOST | WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_NOACTIVATE, OSDWindowClass, WinTitle, WS_POPUP, OSD_Offscreen, OSD_Offscreen, 50, 50, NULL, NULL, MyDLLHandle, NULL );
	if ( !hWnd )
		return NULL;

	Draw = GetDC( hWnd );
	if ( !Draw ) {
		DestroyWindow( hWnd );
		return NULL;
	}


	if ( ( GetDeviceCaps( Draw, BITSPIXEL ) * GetDeviceCaps( Draw, PLANES ) ) < 16 ) {
		//		Fixes for low-color modes:  disable alpha blending (fades)

		LayeredAttribs &= ( ~LWA_ALPHA );
		Flags	&= ~( OSD_FADE_OUT | OSD_FADE_IN );
		Alpha	= OSD_ALPHA_MAX;
		Blink	= 0;
	}

	//		Set the window's transparency and alpha:

	if ( LayeredAttribs )
		SetLayeredWindowAttributes( hWnd, BackColor, ( Flags & OSD_FADE_IN ) ? 0 : Alpha, LayeredAttribs );

	//		Create and attach a private data area for use by the fade and blink timers:

	_OSDWindowData *WindowData = (_OSDWindowData*) malloc( sizeof( _OSDWindowData ) );
	if ( WindowData ) {
		WindowData->PeakAlpha		= Alpha;
		WindowData->CurrentAlpha	= ( Flags & OSD_FADE_IN ) ? OSD_ALPHA_MIN : Alpha;
		WindowData->BackColor		= BackColor;
		WindowData->LayeredAttribs	= LayeredAttribs;
		WindowData->Fading			= ( ( Flags & OSD_FADE_OUT ) ? OSD_SHOULD_FADE : 0 ) | ( ( Flags & OSD_FADE_IN ) ? OSD_FADING_IN : 0 );
		WindowData->Blink			= ( Blink ) ? 0x80 : 0;
		WindowData->Timeout			= Timeout;
		WindowData->BlinkRate		= Blink;
	}

	SetWindowLongPtr( hWnd, GWLP_USERDATA, (LONG_PTR) WindowData );


	//		Call the routine responsible for sizing the window and drawing in it:

	if ( DrawRoutine != NULL )
		DrawRoutine( hWnd, Draw, Flags, Color, BackColor, Args );


	//		Get the current window size (set by DrawRoutine() ):

	GetWindowRect( hWnd, &WindowArea );
	WindowWidth		= WindowArea.right - WindowArea.left;
	WindowHeight	= WindowArea.bottom - WindowArea.top;


	//		Now figure out where it should go, based on x, y, and Flags, the window size, and the screen area:
	
	switch ( Flags & OSD_X_BITS ) {
	case OSD_LEFT :
		WindowX = ScreenArea.left;
		break;

	case OSD_RIGHT :
		WindowX = ScreenArea.right - WindowWidth;
		break;

	case OSD_HCENTER :
		WindowX = ( ( ScreenArea.right - ScreenArea.left ) / 2 ) + ScreenArea.left - ( WindowWidth / 2 );
		break;

	default :
		WindowX = x;
	}

	switch ( Flags & OSD_Y_BITS ) {
	case OSD_TOP :
		WindowY = ScreenArea.top;
		break;

	case OSD_BOTTOM :
		WindowY = ScreenArea.bottom - WindowHeight;
		break;

	case OSD_VCENTER :
		WindowY = ( ( ScreenArea.bottom - ScreenArea.top ) / 2 ) + ScreenArea.top - ( WindowHeight / 2 );
		break;

	default :
		WindowY = y;
	}

	if ( ( Flags & OSD_X_BITS ) && ( Flags & OSD_ADD_OFFSET ) )
		WindowX += x;

	if ( ( Flags & OSD_Y_BITS ) && ( Flags & OSD_ADD_OFFSET ) )
		WindowY += y;


	//		Move the window -- this will make it visible to the user for the first time:

	SetWindowPos( hWnd, HWND_TOPMOST, WindowX, WindowY, WindowArea.right - WindowArea.left, WindowArea.bottom - WindowArea.top, SWP_SHOWWINDOW );


	//		Make a noise, if desired:

	if ( Flags & OSD_DING )
		PlaySound( (LPCTSTR) SND_ALIAS_SYSTEMASTERISK, NULL, SND_ALIAS_ID | SND_ASYNC );


	//		Clean up and start any timers which are needed:

	ReleaseDC( hWnd, Draw );

	if ( Flags & OSD_FADE_IN )
		SetTimer( hWnd, OSDTimerID, OSD_FADE_DELAY, NULL );
	else if ( Timeout )
		SetTimer( hWnd, OSDTimerID, Timeout, NULL );

	if ( Blink && ( ( Flags & OSD_FADE_IN ) == 0 ) )
		SetTimer( hWnd, OSDBlinkTimerID, Blink, NULL );

	return hWnd;
}



HWND MakeOsdWindow( LPTSTR Text, unsigned int Timeout, int WindowX, int WindowY, unsigned int TextSize, COLORREF TextColor, COLORREF ShadowColor, DWORD Flags, LPTSTR FontName, int FontWeight, unsigned int WindowID, BYTE Alpha, WORD BlinkRate, int Monitor, int TextAngle )
{
	_DrawOSDTextArgs DrawArgs;

	if ( TextAngle )
		if ( wcschr( Text, '\n' ) || wcschr( Text, '\r' ) )
			TextAngle = 0;

	DrawArgs.Text		= Text;
	DrawArgs.FontName	= FontName;
	DrawArgs.TextSize	= TextSize;
	DrawArgs.Weight		= FontWeight;
	DrawArgs.TextAngle	= TextAngle;

	if ( ShadowColor > 0x00ffffff )
		DrawArgs.ShadowColor	= DefaultShadowColor( TextColor );
	else
		DrawArgs.ShadowColor	= ShadowColor;


	return CreateOSDWindow( WindowID, Timeout, WindowX, WindowY, TextColor, DrawArgs.ShadowColor, Flags, Alpha, BlinkRate, Monitor, &DrawArgs, DrawOSDText );
}



HWND MakePctBarWindow( unsigned int Dividend, unsigned int Divisor, unsigned int Timeout, int WindowX, int WindowY, unsigned int SizeX, unsigned int SizeY, COLORREF Color, COLORREF ShadowColor, DWORD Flags, unsigned int WindowID, BYTE Alpha, WORD BlinkRate, int Monitor )
{
	_DrawPercentBarArgs DrawArgs;

	DrawArgs.Dividend	= Dividend;
	DrawArgs.Divisor	= Divisor;
	DrawArgs.SizeX		= SizeX;
	DrawArgs.SizeY		= SizeY;

	if ( ShadowColor > 0x00ffffff )
		DrawArgs.ShadowColor	= DefaultShadowColor( Color );
	else
		DrawArgs.ShadowColor	= ShadowColor;


	return CreateOSDWindow( WindowID, Timeout, WindowX, WindowY, Color, DrawArgs.ShadowColor, Flags, Alpha, BlinkRate, Monitor, &DrawArgs, DrawPercentBar );
}



DWORD OSD_RegReadDWord( LPCTSTR KeyName, LPCTSTR ValueName, DWORD Min, DWORD Max, DWORD Default )
{
	BOOL Good			= FALSE;
	HKEY KeyHandle		= NULL;
	DWORD Value			= 0;
	DWORD ValueType		= 0;
	DWORD ValueSize		= 0;


	if ( RegOpenKeyEx( HKEY_CURRENT_USER, KeyName, 0, KEY_READ, &KeyHandle ) == ERROR_SUCCESS ) {

		Value = 0;
		ValueType = 0;
		ValueSize = sizeof( DWORD );

		if ( RegQueryValueEx( KeyHandle, ValueName, NULL, &ValueType, (BYTE*) &Value, &ValueSize ) == ERROR_SUCCESS )
			if ( ( ValueType == REG_DWORD ) && ( Value >= Min ) && ( Value <= Max ) )
				Good = TRUE;

		RegCloseKey( KeyHandle );
	}


	if ( !Good ) {
		if ( RegOpenKeyEx( HKEY_LOCAL_MACHINE, KeyName, 0, KEY_READ, &KeyHandle ) == ERROR_SUCCESS ) {

			Value = 0;
			ValueType = 0;
			ValueSize = sizeof( DWORD );

			if ( RegQueryValueEx( KeyHandle, ValueName, NULL, &ValueType, (BYTE*) &Value, &ValueSize ) == ERROR_SUCCESS )
				if ( ( ValueType == REG_DWORD ) && ( Value >= Min ) && ( Value <= Max ) )
					Good = TRUE;

			RegCloseKey( KeyHandle );
		}
	}


	if ( Good )
		return Value;
	else
		return Default;
}



DWORD OSD_RegGetDWord( LPCTSTR KeyName, LPCTSTR ValueName, DWORD Style, DWORD Min, DWORD Max, DWORD Default )
{
	BOOL Good			= FALSE;
	HKEY KeyHandle		= NULL;
	DWORD Value			= 0;
	DWORD ValueType		= 0;
	DWORD ValueSize		= 0;

	wchar_t KeyNameFull[SHORT_BUF_LEN]		= L"";


	swprintf_s( KeyNameFull, SHORT_BUF_LEN, L"%s\\#%04x %s\\%u", KeyName, GetCurrentProcessId(), PLUGIN_NAME, Style );


	if ( RegOpenKeyEx( HKEY_CURRENT_USER, KeyNameFull, 0, KEY_READ, &KeyHandle ) == ERROR_SUCCESS ) {

		Value = 0;
		ValueType = 0;
		ValueSize = sizeof( DWORD );

		if ( RegQueryValueEx( KeyHandle, ValueName, NULL, &ValueType, (BYTE*) &Value, &ValueSize ) == ERROR_SUCCESS )
			if ( ( ValueType == REG_DWORD ) && ( Value >= Min ) && ( Value <= Max ) )
				Good = TRUE;

		RegCloseKey( KeyHandle );
	}


	if ( !Good ) {
		swprintf_s( KeyNameFull, SHORT_BUF_LEN, L"%s\\%u", KeyName, Style );

		if ( RegOpenKeyEx( HKEY_CURRENT_USER, KeyNameFull, 0, KEY_READ, &KeyHandle ) == ERROR_SUCCESS ) {

			Value = 0;
			ValueType = 0;
			ValueSize = sizeof( DWORD );

			if ( RegQueryValueEx( KeyHandle, ValueName, NULL, &ValueType, (BYTE*) &Value, &ValueSize ) == ERROR_SUCCESS )
				if ( ( ValueType == REG_DWORD ) && ( Value >= Min ) && ( Value <= Max ) )
					Good = TRUE;

			RegCloseKey( KeyHandle );
		}
	}


	if ( !Good ) {
		if ( RegOpenKeyEx( HKEY_LOCAL_MACHINE, KeyNameFull, 0, KEY_READ, &KeyHandle ) == ERROR_SUCCESS ) {

			Value = 0;
			ValueType = 0;
			ValueSize = sizeof( DWORD );

			if ( RegQueryValueEx( KeyHandle, ValueName, NULL, &ValueType, (BYTE*) &Value, &ValueSize ) == ERROR_SUCCESS )
				if ( ( ValueType == REG_DWORD ) && ( Value >= Min ) && ( Value <= Max ) )
					Good = TRUE;

			RegCloseKey( KeyHandle );
		}
	}


	if ( Good )
		return Value;
	else
		return Default;
}



int OSD_RegGetString( LPCTSTR KeyName, LPCTSTR ValueName, DWORD Style, LPTSTR outString )
{
	BOOL Good			= FALSE;
	HKEY KeyHandle		= NULL;
	DWORD ValueType		= 0;
	DWORD ValueSize		= 0;

	wchar_t KeyNameFull[SHORT_BUF_LEN]		= L"";
	wchar_t temp[SHORT_BUF_LEN]				= L"";


	swprintf_s( KeyNameFull, SHORT_BUF_LEN, L"%s\\#%04x %s\\%u", KeyName, GetCurrentProcessId(), PLUGIN_NAME, Style );


	if ( RegOpenKeyEx( HKEY_CURRENT_USER, KeyNameFull, 0, KEY_READ, &KeyHandle ) == ERROR_SUCCESS ) {
		ValueType = 0;
		ValueSize= SHORT_BUF_LEN * sizeof( wchar_t );
		memset( temp, 0x00, ValueSize );

		if ( RegQueryValueEx( KeyHandle, ValueName, NULL, &ValueType, (BYTE*) temp, &ValueSize ) == ERROR_SUCCESS )
			if ( ( ValueType == REG_SZ ) && temp[0] )
				Good = TRUE;

		RegCloseKey( KeyHandle );
	}


	if ( !Good ) {
		swprintf_s( KeyNameFull, SHORT_BUF_LEN, L"%s\\%u", KeyName, Style );

		if ( RegOpenKeyEx( HKEY_CURRENT_USER, KeyNameFull, 0, KEY_READ, &KeyHandle ) == ERROR_SUCCESS ) {

			ValueType = 0;
			ValueSize = SHORT_BUF_LEN * sizeof( wchar_t );
			memset( temp, 0x00, ValueSize );

			if ( RegQueryValueEx( KeyHandle, ValueName, NULL, &ValueType, (BYTE*) temp, &ValueSize ) == ERROR_SUCCESS )
				if ( ( ValueType == REG_SZ ) && temp[0] )
					Good = TRUE;

			RegCloseKey( KeyHandle );
		}
	}


	if ( !Good ) {
		if ( RegOpenKeyEx( HKEY_LOCAL_MACHINE, KeyNameFull, 0, KEY_READ, &KeyHandle ) == ERROR_SUCCESS ) {

			ValueType = 0;
			ValueSize = SHORT_BUF_LEN * sizeof( wchar_t );
			memset( temp, 0x00, ValueSize );

			if ( RegQueryValueEx( KeyHandle, ValueName, NULL, &ValueType, (BYTE*) temp, &ValueSize ) == ERROR_SUCCESS )
				if ( ( ValueType == REG_SZ ) && temp[0] )
					Good = TRUE;

			RegCloseKey( KeyHandle );
		}
	}
	

	if ( Good ) {
		wcscpy_s( outString, SHORT_BUF_LEN, temp );
		return (int) wcslen( temp );
	}
	else
		return 0;
}



int OSD_RegWriteDWord( LPCTSTR KeyName, LPCTSTR ValueName, DWORD Style, DWORD Value )
{
	HKEY KeyHandle		= NULL;
	DWORD Flags			= 0;
	DWORD ValueSize		= sizeof( DWORD );
	DWORD t				= Value;
	int rv				= 1;

	wchar_t KeyNameFull[SHORT_BUF_LEN]		= L"";


	if ( Style <= OSD_STYLES_GLOBAL )
		swprintf_s( KeyNameFull, SHORT_BUF_LEN, L"%s\\%u", KeyName, Style );
	else {
		swprintf_s( KeyNameFull, SHORT_BUF_LEN, L"%s\\#%04x %s\\%u", KeyName, GetCurrentProcessId(), PLUGIN_NAME, Style );
		Flags |= REG_OPTION_VOLATILE;
	}


	if ( RegCreateKeyEx( HKEY_CURRENT_USER, KeyNameFull, 0, NULL, Flags, KEY_READ | KEY_WRITE, NULL, &KeyHandle, NULL ) == ERROR_SUCCESS ) {

		if ( RegSetValueEx( KeyHandle, ValueName, 0, REG_DWORD, (BYTE*) &t, ValueSize ) == ERROR_SUCCESS )
			rv = 0;

		RegCloseKey( KeyHandle );
	}

	return rv;
}



int OSD_RegWriteString( LPCTSTR KeyName, LPCTSTR ValueName, DWORD Style, LPCTSTR Value )
{
	HKEY KeyHandle		= NULL;
	DWORD Flags			= 0;
	DWORD ValueSize		= 0;
	int rv				= 1;

	wchar_t KeyNameFull[SHORT_BUF_LEN]	= L"";


	if ( Style <= OSD_STYLES_GLOBAL )
		swprintf_s( KeyNameFull, SHORT_BUF_LEN, L"%s\\%u", KeyName, Style );
	else {
		swprintf_s( KeyNameFull, SHORT_BUF_LEN, L"%s\\#%04x %s\\%u", KeyName, GetCurrentProcessId(), PLUGIN_NAME, Style );
		Flags |= REG_OPTION_VOLATILE;
	}


	if ( RegCreateKeyEx( HKEY_CURRENT_USER, KeyNameFull, 0, NULL, Flags, KEY_READ | KEY_WRITE, NULL, &KeyHandle, NULL ) == ERROR_SUCCESS ) {

		ValueSize = sizeof( wchar_t ) * ( (DWORD) wcslen( Value ) + 1 );

		if ( RegSetValueEx( KeyHandle, ValueName, 0, REG_SZ, (BYTE*) Value, ValueSize ) == ERROR_SUCCESS )
			rv = 0;

		RegCloseKey( KeyHandle );
	}

	return rv;
}



int OSD_RegDelTree( HKEY RootKey, LPCTSTR KeyName )
{
	HKEY KeyHandle	= NULL;
	DWORD Index		= 0;
	int rv			= 0;

	wchar_t SubkeyName[SHORT_BUF_LEN]		= L"";
	wchar_t SubkeyFullName[SHORT_BUF_LEN]	= L"";
	DWORD BufferSize						= SHORT_BUF_LEN;


	if ( RegOpenKeyEx( RootKey, KeyName, 0, KEY_ALL_ACCESS, &KeyHandle ) == ERROR_SUCCESS ) {

		while ( RegEnumKeyEx( KeyHandle, Index, SubkeyName, &BufferSize, NULL, NULL, NULL, NULL ) == ERROR_SUCCESS ) {

			wcscpy_s( SubkeyFullName, SHORT_BUF_LEN, KeyName );
			wcscat_s( SubkeyFullName, SHORT_BUF_LEN, L"\\" );
			wcscat_s( SubkeyFullName, SHORT_BUF_LEN, SubkeyName );

			if ( OSD_RegDelTree( RootKey, SubkeyFullName ) == 0 )
				Index = 0;
			else
				Index++;

			SubkeyName[0] = '\0';
			BufferSize = SHORT_BUF_LEN;
		}

		RegCloseKey( KeyHandle );
	}


	if ( RegDeleteKey( RootKey, KeyName ) )
		rv = 1;

	return rv;
}



int OSD_RemoveTempRegKey( LPCTSTR KeyName )
{
	wchar_t KeyNameWithId[SHORT_BUF_LEN]	= L"";


	swprintf_s( KeyNameWithId, SHORT_BUF_LEN, L"%s\\#%04x %s", KeyName, GetCurrentProcessId(), PLUGIN_NAME );
	OSD_RegDelTree( HKEY_CURRENT_USER, KeyNameWithId );
	return 0;
}



#ifdef	OSD_READ_FILE

int OSDReadFileText( LPTSTR Filename, LPTSTR Buffer, size_t BufferLen, unsigned int MaxLines, unsigned int CodePage, unsigned int CodePageEbcdic )
{
	if ( !Filename || !Buffer )
		return -1;

	if ( Filename[0] == '\0' )
		return -1;

	if ( !MaxLines )
		MaxLines = 1;


	wchar_t FullName[MAX_FILENAME_LEN]	= L"";
	wchar_t Line[SHORT_BUF_LEN]			= L"";
	_MMFile MMFile;



	if ( _wcsicmp( Filename, MM_CLIP_FILENAME ) ) {
		QueryTrueName( Filename, FullName );
		if ( FullName[0] == '\0' )
			return 1;

		if ( !_OSD_IsFile( FullName ) )
			return 1;
	}
	else
		wcscpy_s( FullName, MAX_FILENAME_LEN, MM_CLIP_FILENAME );


	if ( OpenMMFile( &MMFile, FullName, MM_FLAG_ALLOW_EBCDIC, CodePage, CodePageEbcdic ) )
		return 1;


	for ( unsigned int i = 0; i < MaxLines; i++ ) {
		Line[0] = '\0';
		if ( MMGetLine( &MMFile, Line, SHORT_BUF_LEN, MMGL_FLAG_SPLIT_LONG_LINES ) )
			break;

		wcscat_s( Buffer, BufferLen, Line );

		if ( i < ( MaxLines - 1 ) )
			wcscat_s( Buffer, BufferLen, L"\n" );
	}

	CloseMMFile( &MMFile );
	return 0;
}

#endif	//	OSD_READ_FILE



unsigned int ScaledFontSize( unsigned int TextSize, int Monitor )
{
	HMONITOR MonitorHandle			= NULL;
	MONITORINFO MonitorInfo;
	RECT ScreenArea					= { 0, 0, 0, 0 };
	unsigned int MonitorHeight		= 0;
	BOOL Good						= FALSE;


	if ( Monitor < 0 )
		MonitorHeight = GetSystemMetrics( SM_CYVIRTUALSCREEN );
	else {
		memset( &MonitorInfo, 0x00, sizeof( MONITORINFO ) );
		MonitorInfo.cbSize = sizeof( MONITORINFO );

		if ( Monitor >= GetSystemMetrics( SM_CMONITORS ) )
			MonitorHandle = MonitorFromWindow( GetDesktopWindow(), MONITOR_DEFAULTTOPRIMARY );
		else
			MonitorHandle = GetMonitorHandle( Monitor );

		if ( MonitorHandle ) {
			if ( GetMonitorInfo( MonitorHandle, &MonitorInfo ) ) {
				MonitorHeight = MonitorInfo.rcWork.bottom - MonitorInfo.rcWork.top;
				Good = TRUE;
			}
		}

		if ( !Good ) {
			SystemParametersInfo( SPI_GETWORKAREA, 0, &ScreenArea, 0 );
			MonitorHeight = ScreenArea.bottom - ScreenArea.top;
		}
	}


	if ( ( MonitorHeight >= 400 ) && ( MonitorHeight <= 20480 ) ) {
		TextSize = ( TextSize * MonitorHeight ) / 1024;

		if ( TextSize < OSD_TEXT_HEIGHT_MIN )
			TextSize = OSD_TEXT_HEIGHT_MIN;
		else if ( TextSize > OSD_TEXT_HEIGHT_MAX )
			TextSize = OSD_TEXT_HEIGHT_MAX;
	}

	return TextSize;
}



#if defined OSD_OSD_CMD || defined OSD_PCTBAR_CMD || defined OSD_OSDIMG_CMD

BOOL IsOptionWithArgs( LPTSTR String, LPTSTR Option, wchar_t **ch, BOOL Uppercase )
{
	if ( !String || !Option )
		return FALSE;
	else if ( ( String[0] == '\0' ) || ( Option[0] == '\0' ) )
		return FALSE;

	size_t l = wcslen( Option );

	if ( _wcsnicmp( String, Option, l ) )
		return FALSE;

	if ( !IsColonOrEquals( String[l] ) )
		return FALSE;

	if ( Uppercase )
		_wcsupr_s( String, MAX_ARG_LEN );

	if ( ch )
		*ch = String + l + 1;

	return TRUE;
}



int IsOsdCommonOption( LPTSTR String, DWORD *Flags, int *WindowX, int *WindowY, int *Monitor )
{
	if ( !String || !Flags || !WindowX || !WindowY || !Monitor )
		return 0;


	wchar_t *ch		= NULL;


	if ( !wcscmp( String, L"/$" ) ) {
		*Flags |= OSD_DEBUG;
		return 1;
	}
	else if ( !_wcsicmp( String, L"/LEFT" ) || !_wcsicmp( String, L"/L" ) ) {
		*Flags = ( *Flags & ( ~OSD_X_BITS ) ) | OSD_LEFT;
		return 1;
	}
	else if ( !_wcsicmp( String, L"/RIGHT" ) || !_wcsicmp( String, L"/R" ) ) {
		*Flags = ( *Flags & ( ~OSD_X_BITS ) ) | OSD_RIGHT;
		return 1;
	}
	else if ( !_wcsicmp( String, L"/HCENTER" ) || !_wcsicmp( String, L"/HC" ) ) {
		*Flags = ( *Flags & ( ~OSD_X_BITS ) ) | OSD_HCENTER;
		return 1;
	}
	else if ( !_wcsicmp( String, L"/TOP" ) || !_wcsicmp( String, L"/T" ) ) {
		*Flags = ( *Flags & ( ~OSD_Y_BITS ) ) | OSD_TOP;
		return 1;
	}
	else if ( !_wcsicmp( String, L"/BOTTOM" ) || !_wcsicmp( String, L"/B" ) ) {
		*Flags = ( *Flags & ( ~OSD_Y_BITS ) ) | OSD_BOTTOM;
		return 1;
	}
	else if ( !_wcsicmp( String, L"/VCENTER" ) || !_wcsicmp( String, L"/VC" ) ) {
		*Flags = ( *Flags & ( ~OSD_Y_BITS ) ) | OSD_VCENTER;
		return 1;
	}
	else if ( !_wcsicmp( String, L"/CENTER" ) || !_wcsicmp( String, L"/CTR" ) ) {
		*Flags = ( *Flags & ( ~ ( OSD_X_BITS | OSD_Y_BITS ) ) ) | OSD_HCENTER | OSD_VCENTER;
		return 1;
	}
	else if ( IsOptionWithArgs( String, L"/POS", &ch, TRUE ) ) {
		if ( ParseSignedInt( ch, WindowY, &ch ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad Y value: \"%s\"\r\n", ch );
			return -1;
		}

		if ( ( *ch != ',' ) && ( *ch != ';' ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad separator: \"%s\"\r\n", ch );
			return -1;
		}

		ch++;
		if ( ParseSignedInt( ch, WindowX, NULL ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad X value: \"%s\"\r\n", ch );
			return -1;
		}

		return 1;
	}
	else if ( IsOptionWithArgs( String, L"/XY", &ch, TRUE ) ) {
		if ( ParseSignedInt( ch, WindowX, &ch ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad X value: \"%s\"\r\n", ch );
			return -1;
		}

		if ( ( *ch == ',' ) || ( *ch == ';' ) ) {
			ch++;

			if ( ParseSignedInt( ch, WindowY, NULL ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad Y value: \"%s\"\r\n", ch );
				return -1;
			}
		}
		else if ( *ch ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Syntax error (expected a comma): \"%s\"\r\n", String );
			return -1;
		}
		else
			*WindowY = 0;

		return 1;
	}
	else if ( IsOptionWithArgs( String, L"/OFFSET", &ch, TRUE ) ) {
		if ( ParseSignedInt( ch, WindowY, &ch ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad Y value: \"%s\"\r\n", ch );
			return -1;
		}

		if ( ( *ch != ',' ) && ( *ch != ';' ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad separator: \"%s\"\r\n", ch );
			return -1;
		}

		ch++;
		if ( ParseSignedInt( ch, WindowX, NULL ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad X value: \"%s\"\r\n", ch );
			return -1;
		}

		*Flags |= OSD_ADD_OFFSET;
		return 1;
	}
	else if ( !_wcsicmp( String, L"/OFFSET" ) ) {
		*Flags |= OSD_ADD_OFFSET;
		return 1;
	}
	else if ( !_wcsicmp( String, L"/FADE" ) || !_wcsicmp( String, L"/F" ) ) {
		*Flags |= OSD_FADE_OUT;
		return 1;
	}
	else if ( !_wcsicmp( String, L"/FADEIN" ) || !_wcsicmp( String, L"/FI" ) ) {
		*Flags |= OSD_FADE_IN;
		return 1;
	}
	else if ( !_wcsicmp( String, L"/DING" ) ) {
		*Flags |= OSD_DING;
		return 1;
	}
	else if ( ( IsOptionWithArgs( String, L"/MONITOR", &ch, TRUE ) ) || ( IsOptionWithArgs( String, L"/M", &ch, TRUE ) ) ) {
		if ( ParseSignedInt( ch, Monitor, NULL ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad monitor value: \"%s\"\r\n", ch );
			return -1;
		}

		if ( *Monitor > OSD_MAX_MONITORS ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Monitor number is 0 - %u: %d\r\n", OSD_MAX_MONITORS, *Monitor );
			return -1;
		}

		if ( *Monitor == 0 )
			*Monitor = OSD_MONITOR_DEFAULT;
		else if ( *Monitor > 0 )
			*Monitor -= 1;

		return 1;
	}

#ifdef OSD_TAB_OPTION

	else if ( !_wcsicmp( String, L"/TAB" ) ) {
		*Flags |= OSD_MY_TAB;
		return 1;
	}

#endif	//	OSD_TAB_OPTION

	else
		return 0;
}



int IsOsdColorOption( LPTSTR String, COLORREF *Color )
{
	if ( !String || !Color )
		return 0;


	wchar_t *ch			= NULL;

	
	if ( IsOptionWithArgs( String, L"/RGB", &ch, TRUE ) ) {
		unsigned int Red = 0, Green = 0, Blue = 0;

		if ( ParseInt( ch, &Red, &ch ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad Red value: \"%s\"\r\n", ch );
			return -1;
		}

		if ( Red > 0xff ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Red value must be 0 - 255: %u\r\n", Red );
			return -1;
		}

		if ( ( *ch != ',' ) && ( *ch != ';' ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad separator: \"%s\"\r\n", ch );
			return -1;
		}

		ch++;

		if ( ParseInt( ch, &Green, &ch ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad Green value: \"%s\"\r\n", ch );
			return -1;
		}

		if ( Green > 0xff ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Green value must be 0 - 255: %u\r\n", Red );
			return -1;
		}

		if ( ( *ch != ',' ) && ( *ch != ';' ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad separator: \"%s\"\r\n", ch );
			return -1;
		}

		ch++;

		if ( ParseInt( ch, &Blue, NULL ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad Blue value: \"%s\"\r\n", ch );
			return -1;
		}

		if ( Blue > 0xff ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Blue value must be 0 - 255: %u\r\n", Red );
			return -1;
		}

		*Color = RGB( Red, Green, Blue );
		return 1;
	}
	else if ( ( IsOptionWithArgs( String, L"/COLOR", &ch, TRUE ) ) || ( IsOptionWithArgs( String, L"/K", &ch, TRUE ) ) ) {
		unsigned int fg		= 255;
		unsigned int bg		= 255;

		StripQuotes( ch );

		if ( iswalpha( *ch ) ) {
			ParseColors( ch, (int*) &fg, (int*) &bg );

			if ( ( fg > 15 ) || ( bg != 255 ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Unknown color name: \"%s\"\r\n", ch );
				return -1;
			}
		}
		else if ( ParseInt( ch, &fg, NULL ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad color value: \"%s\"\r\n", ch );
			return -1;
		}

		if ( fg > 15 ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Color must be 0 - 15: %u\r\n", fg );
			return -1;
		}

		*Color = ColorTable[ fg ];
		return 1;
	}
	else if ( IsOptionWithArgs( String, L"/HUE", &ch, TRUE ) ) {
		StripQuotes( ch );

		DWORD Hue = W3CColorValue( ch, TRUE );

		if ( Hue == W3C_COLOR_UNDEFINED ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Unknown W3C color name: \"%s\"\r\n", ch );
			return -1;
		}

		*Color = _OSD_SwapBytes( Hue );
		return 1;
	}
	else
		return 0;
}



int IsOsdTimeoutOption( LPTSTR String, unsigned int *Timeout )
{
	if ( !String || !Timeout )
		return 0;


	wchar_t *ch			= NULL;


	if ( IsOptionWithArgs( String, L"/TIME", &ch, TRUE ) || IsOptionWithArgs( String, L"/T", &ch, TRUE ) ) {
		if ( ParseInt( ch, Timeout, NULL ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad timeout value: \"%s\"\r\n", ch );
			return -1;
		}

		if ( *Timeout > OSD_TIMEOUT_MAX ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Timeout must be 0 - %u: %u\r\n", OSD_TIMEOUT_MAX, *Timeout );
			return -1;
		}

		*Timeout *= 1000;
		return 1;
	}
	else if ( IsOptionWithArgs( String, L"/MS", &ch, TRUE ) ) {
		if ( ParseInt( ch, Timeout, NULL ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad timeout value: \"%s\"\r\n", ch );
			return -1;
		}

		if ( ( *Timeout && ( *Timeout < OSD_MSEC_MIN ) ) || ( *Timeout > ( OSD_TIMEOUT_MAX * 1000 ) ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Timeout must be %u - %u: %u\r\n", OSD_MSEC_MIN, ( OSD_TIMEOUT_MAX * 1000 ), *Timeout );
			return -1;
		}

		return 1;
	}
	else
		return 0;
}



int IsOsdStyleOption( LPTSTR String, unsigned int *Style )
{
	if ( !String || !Style )
		return 0;


	wchar_t *ch			= String + 1;


	if ( IsOptionWithArgs( String, L"/STYLE", &ch, TRUE ) || ( ( String[0] == '/' ) && iswdigit( String[1] ) ) ) {
		if ( ParseInt( ch, Style, NULL ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad style value: \"%s\"\r\n", ch );
			return -1;
		}

		if ( ( *Style == 0 ) || ( *Style > OSD_STYLE_MAX ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Style must be 1 - %u: %u\r\n", OSD_STYLE_MAX, *Style );
			return -1;
		}

		return 1;
	}
	else
		return 0;
}

#endif	//	OSD_OSD_CMD || OSD_PCTBAR_CMD || OSD_OSDIMG_CMD


#ifdef	OSD_OSD_CMD


int CALLBACK FaceExistsProc( const LOGFONT *LogFont, const TEXTMETRIC *TextMetric, DWORD FontType, LPARAM lParam )
{
	BOOL *Found = (BOOL*) lParam;


	*Found = TRUE;
	return FALSE;
}



BOOL FaceExists( LPTSTR FaceName, HDC DeviceContext )
{
	if ( !FaceName )
		return FALSE;
	else if ( FaceName[0] == '\0' )
		return FALSE;


	LOGFONT FontInfo;
	BOOL Found = FALSE;


	memset( &FontInfo, 0x00, sizeof( LOGFONT ) );
	FontInfo.lfCharSet = ANSI_CHARSET;
	wcscpy_s( FontInfo.lfFaceName, LF_FACESIZE, FaceName );

	EnumFontFamiliesEx( DeviceContext, &FontInfo, FaceExistsProc, (LPARAM) &Found, 0 );

	return Found;
}



struct PickFaceStruct {
	DWORD DesiredFamily;
	wchar_t FaceName[SHORT_BUF_LEN];
};



int CALLBACK PickFaceProc( const LOGFONT *ThisFace, const TEXTMETRIC *FaceMetric, DWORD FontType, LPARAM lParam )
{
	PickFaceStruct *FoundFace = (PickFaceStruct*) lParam;


	if ( FontType != TRUETYPE_FONTTYPE )
		return 1;

	if ( ( ThisFace->lfPitchAndFamily & 0xfff0 ) == ( FoundFace->DesiredFamily & 0xfff0 ) ) {
		wcscpy_s( FoundFace->FaceName, SHORT_BUF_LEN, ThisFace->lfFaceName );
		return 0;
	}

	return 1;
}



int PickATypeFace( DWORD FontFamily, LPTSTR outFaceName )
{
	if ( !outFaceName )
		return -1;


	HDC Screen = GetDC( NULL );

	int f = ( FontFamily >> 4 ) & 0x07;

	wchar_t DefaultFaceNames[5][4][19] = {
		{ L"Palatino Linotype", L"Book Antiqua", L"Garamond", L"Times New Roman" },
		{ L"Century Gothic", L"Verdana", L"Tahoma", L"Arial" },
		{ L"Lucida Console", L"Consolas", L"Letter Gothic", L"Courier New" },
		{ L"Lucida Handwriting", L"Lucida Calligraphy", L"Monotype Corsiva", L"Comic Sans MS" },
		{ L"Algerian", L"Bauhaus 93", L"Snap ITC", L"Harlow Solid" }
	};


	if ( ( f >= 1 ) && ( f <= 5 ) ) {
		for ( int j = 0; j < 4; j++ ) {
			if ( FaceExists( DefaultFaceNames[f - 1][j], Screen ) ) {
				wcscpy_s( outFaceName, SHORT_BUF_LEN, DefaultFaceNames[f - 1][j] );
				ReleaseDC( NULL, Screen );
				return 0;
			}
		}
	}


	LOGFONT FontInfo;
	PickFaceStruct FoundFace;


	FontFamily &= 0xfff0;

	memset( &FontInfo, 0x00, sizeof( LOGFONT ) );
	FontInfo.lfCharSet = ANSI_CHARSET;
	FoundFace.DesiredFamily = FontFamily;
	FoundFace.FaceName[0] = '\0';


	EnumFontFamiliesEx( Screen, &FontInfo, PickFaceProc, (LPARAM) &FoundFace, 0 );

	if ( FoundFace.FaceName[0] ) {
		wcscpy_s( outFaceName, SHORT_BUF_LEN, FoundFace.FaceName );
		ReleaseDC( NULL, Screen );
		return 0;
	}

	ReleaseDC( NULL, Screen );
	return 1;
}



DWORD CheckFontFamilyName( LPTSTR FontName )
{
	if ( !FontName )
		return FF_DONTCARE;

	if ( !_wcsicmp( FontName, L"(Roman)" ) )
		return FF_ROMAN;

	if ( !_wcsicmp( FontName, L"(Swiss)" ) )
		return FF_SWISS;

	if ( !_wcsicmp( FontName, L"(Script)" ) )
		return FF_SCRIPT;

	if ( !_wcsicmp( FontName, L"(Modern)" ) )
		return FF_MODERN;

	if ( !_wcsicmp( FontName, L"(Decorative)" ) )
		return FF_DECORATIVE;

	if ( !_wcsicmp( FontName, L"(Deco)" ) )
		return FF_DECORATIVE;

	return FF_DONTCARE;
}



int VerticalizeText( LPTSTR inString, LPTSTR outString )
{
	if ( !inString || !outString )
		return -1;

	if ( inString == outString )
		return -1;


	size_t i = 0, j = 0;
	wchar_t ch = '\0', last = '\0';

	do {
		last = ch;
		ch = inString[i++];

		if ( ch && iswcntrl( ch ) ) {
			if ( iswcntrl( last ) || ( iswspace( last ) ) )
				continue;

			ch = 0x20;
		}

		outString[j++] = ch;
		if ( ch )
			outString[j++] = '\n';

	} while ( ch );

	if ( j > 1 )
		if ( outString[j - 2] == '\n' )
			outString[j - 2] = '\0';

	return 0;
}



int OSD_StripChar( LPTSTR String, wchar_t Char )
{
	if ( !String || !Char )
		return -1;


	wchar_t *ch		= String;
	size_t j		= 0;
	int k			= 0;
	BOOL done		= 0;


	do {
		if ( *ch == Char )
			k++;
		else
			String[j++] = *ch;

		done |= ( *ch == '\0' );
		ch++;
	}
	while ( !done );

	return k;
}



DLLExports int WINAPI osd( LPTSTR inString )
{
	if ( !inString )
		return -1;


	LPTSTR Text				= NULL;
	unsigned int Timeout	= OSD_RegReadDWord( OSD_RegKeyName, OSD_TimeoutValueName, OSD_MSEC_MIN, OSD_TIMEOUT_MAX * 1000, 10000 );
	DWORD Flags				= 0;
	int WindowX				= 0;
	int WindowY				= 0;
	HWND hWnd				= NULL;
	unsigned int WindowID	= 0;
	unsigned int TextSize	= 0;
	unsigned int Alpha		= 0;
	unsigned int BlinkRate	= 0;
	unsigned int Style		= 0;
	int Monitor				= OSD_MONITOR_DEFAULT;
	int FontWeight			= -1;
	COLORREF TextColor		= 0x00ff00;
	COLORREF ShadowColor	= W3C_COLOR_UNDEFINED;
	BOOL ColorSpecified		= FALSE;
	BOOL ItalicSpecified	= FALSE;
	BOOL UnderlineSpecified	= FALSE;
	BOOL ShadowSpecified	= FALSE;
	BOOL AlphaSpecified		= FALSE;
	int TextAngle			= 0;
	BOOL Wait				= TRUE;
	BOOL Verticalize		= FALSE;
	BOOL ForceUppercase		= FALSE;
	BOOL Escapes			= FALSE;
	BOOL FontScaled			= FALSE;
	BOOL CloseWindow		= FALSE;
	BOOL CloseAllWindows	= FALSE;
	BOOL FadeWindowsNow		= FALSE;
	BOOL FadeAllWindowsNow	= FALSE;
	BOOL Quiet				= FALSE;
	BOOL Save				= FALSE;
	wchar_t *ch				= NULL;
	int sv					= 0;
	int rv					= 0;

	wchar_t Typeface[SHORT_BUF_LEN]		= L"";
	DWORD FontFamily					= 0;

	wchar_t InputBuffer[MAX_ARG_LEN]	= L"";
	unsigned int MaxLines				= OSD_RegReadDWord( OSD_RegKeyName, OSD_MaxLinesValueName, 0, OSD_MAX_FILE_LINES, 5 );
	unsigned int CodePage				= 0;
	unsigned int CodePageEbcdic			= 0;

	const wchar_t DefaultFont[]		= L"Verdana";



	ParseArgs( inString, PARSE_BREAK_SPACES | PARSE_SLASHES_KLUDGE | PARSE_ONE_ARG_KLUDGE | PARSE_RETAIN_QUOTES | PARSE_NO_TRIM );


	for ( int i = 0; i < numargs; i++ ) {
		ch = NULL;

		if ( !wcsncmp( arg[i], L"/?", 2 ) )
			return ShowCmdHelp( OSDHelpText, ( arg[i][2] == '?' ), __FILE__, MACRO_STR( OSD_VERSION ) );
		else if ( sv = IsOsdCommonOption( arg[i], &Flags, &WindowX, &WindowY, &Monitor ) ) {
			if ( sv < 0 )
				return 1;
		}
		else if ( sv = IsOsdColorOption( arg[i], &TextColor ) ) {
			if ( sv < 0 )
				return 1;

			ColorSpecified = TRUE;
		}
		else if ( sv = IsOsdTimeoutOption( arg[i], &Timeout ) ) {
			if ( sv < 0 )
				return 1;
		}
		else if ( sv = IsOsdStyleOption( arg[i], &Style ) ) {
			if ( sv < 0 )
				return 1;
		}
		else if ( IsOptionWithArgs( arg[i], L"/FONT", &ch, TRUE ) || IsOptionWithArgs( arg[i], L"/H", &ch, TRUE ) ) {
			if ( ParseInt( ch, &TextSize, NULL ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad height value: \"%s\"\r\n", ch );
				return 1;
			}

			if ( ( TextSize < OSD_TEXT_HEIGHT_MIN ) || ( TextSize > OSD_TEXT_HEIGHT_MAX ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Text height must be %u - %u: %u\r\n", OSD_TEXT_HEIGHT_MIN, OSD_TEXT_HEIGHT_MAX, TextSize );
				return 1;
			}
		}
		else if ( !_wcsicmp( arg[i], L"/FS" ) )
			FontScaled = TRUE;
		else if ( !_wcsicmp( arg[i], L"/N" ) )
			Wait = FALSE;
		else if ( IsOptionWithArgs( arg[i], L"/N", &ch, TRUE ) ) {

			while ( *ch ) {

				switch ( *ch ) {

				case 'A' :
					Alpha = 0;
					AlphaSpecified = TRUE;
					break;

				case 'B' :
					FontWeight = FW_NORMAL;
					break;

				case 'F' :
					Flags &= ~OSD_FADE_OUT;
					break;

				case 'I' :
					Flags &= ( ~OSD_ITALIC );
					ItalicSpecified = TRUE;
					break;

				case 'S' :
					Flags &= ( ~OSD_SHADOW );
					ShadowSpecified = TRUE;
					break;

				case 'U' :
					Flags &= ( ~OSD_UNDERLINE );
					UnderlineSpecified = TRUE;
					break;

#ifdef OSD_ESCAPES

				case 'X' :
					Escapes = FALSE;

#endif	//	 OSD_ESCAPES

				}

				ch++;
			}
		}
		else if ( !_wcsnicmp( arg[i], L"/CP", 3 ) ) {
			if ( ParseCodePageOption( arg[i], &CodePage, &CodePageEbcdic ) )
				return 1;
		}
		else if ( !_wcsicmp( arg[i], L"/C" ) )
			CloseWindow = TRUE;
		else if ( IsOptionWithArgs( arg[i], L"/C", &ch, TRUE ) ) {
			if ( ParseInt( ch, &WindowID, NULL ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad ID value: \"%s\"\r\n", ch );
				return 1;
			}

			if ( WindowID > OSD_ID_MAX ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Window ID must be 0 - %u: %u\r\n", OSD_ID_MAX, WindowID );
				return 1;
			}

			CloseWindow = TRUE;
		}
		else if ( !_wcsicmp( arg[i], L"/FADENOW" ) )
			FadeWindowsNow = TRUE;
		else if ( IsOptionWithArgs( arg[i], L"/FADENOW", &ch, TRUE ) ) {
			if ( ParseInt( ch, &WindowID, NULL ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad ID value: \"%s\"\r\n", ch );
				return 1;
			}

			if ( WindowID > OSD_ID_MAX ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Window ID must be 0 - %u: %u\r\n", OSD_ID_MAX, WindowID );
				return 1;
			}

			FadeWindowsNow = TRUE;
		}
		else if ( !_wcsicmp( arg[i], L"/FADEALLNOW" ) )
			FadeAllWindowsNow = FadeWindowsNow = TRUE;
		else if ( !_wcsicmp( arg[i], L"/CA" ) )
			CloseAllWindows = TRUE;
		else if ( IsOptionWithArgs( arg[i], L"/ID", &ch, TRUE ) ) {
			if ( ParseInt( ch, &WindowID, NULL ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad ID value: \"%s\"\r\n", ch );
				return 1;
			}

			if ( WindowID > OSD_ID_MAX ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Window ID must be 0 - %u: %u\r\n", OSD_ID_MAX, WindowID );
				return 1;
			}
		}
		else if ( !_wcsicmp( arg[i], L"/V" ) )
			Verticalize = TRUE;
		else if ( !_wcsicmp( arg[i], L"/CJ" ) )
			Flags = ( Flags & ~OSD_RIGHT_JUSTIFY ) | OSD_CENTER_JUSTIFY;
		else if ( !_wcsicmp( arg[i], L"/LJ" ) )
			Flags &= ~OSD_JUSTIFY_BITS;
		else if ( !_wcsicmp( arg[i], L"/RJ" ) )
			Flags = ( Flags & ~OSD_CENTER_JUSTIFY ) | OSD_RIGHT_JUSTIFY;
		else if ( ( IsOptionWithArgs( arg[i], L"/FACE", &ch, FALSE ) ) || ( IsOptionWithArgs( arg[i], L"/F", &ch, FALSE ) ) ) {
			StripQuotes( ch );

			if ( *ch )
				wcscpy_s( Typeface, SHORT_BUF_LEN, ch );
			else {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Missing typeface name\r\n" );
				return 1;
			}
		}
		else if ( !_wcsicmp( arg[i], L"/ITALIC" ) || !_wcsicmp( arg[i], L"/I" ) )
			Flags |= OSD_ITALIC, ItalicSpecified = TRUE;
		else if ( !_wcsicmp( arg[i], L"/UNDERLINE" ) || !_wcsicmp( arg[i], L"/U" ) )
			Flags |= OSD_UNDERLINE, UnderlineSpecified = TRUE;
		else if ( !_wcsicmp( arg[i], L"/SHADOW" ) || !_wcsicmp( arg[i], L"/DS" ) )
			Flags |= OSD_SHADOW, ShadowSpecified = TRUE;
		else if ( IsOptionWithArgs( arg[i], L"/SHADOW", &ch, TRUE ) || IsOptionWithArgs( arg[i], L"/DS", &ch, TRUE ) ) {
			StripQuotes( ch );

			DWORD Color = W3CColorValue( ch, TRUE );

			if ( Color == W3C_COLOR_UNDEFINED ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Unknown W3C color name: \"%s\"\r\n", ch );
				return 1;
			}

			ShadowColor = _OSD_SwapBytes( Color );
			Flags |= OSD_SHADOW;
			ShadowSpecified = TRUE;
		}
		else if ( IsOptionWithArgs( arg[i], L"/B", &ch, TRUE ) || IsOptionWithArgs( arg[i], L"/BOLD", &ch, TRUE ) ) {
			if ( ParseInt( ch, (unsigned int *) &FontWeight, NULL ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad weight value: \"%s\"\r\n", ch );
				return 1;
			}

			if ( ( FontWeight >= 100 ) && ( FontWeight <= 900 ) && ( ( FontWeight % 100 ) == 0 ) )
				FontWeight /= 100;

			if ( ( FontWeight < 0 ) || ( FontWeight > 9 ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Font weight must be 0 - 9: %d\r\n", FontWeight );
				return 1;
			}

			FontWeight *= 100;
		}
		else if ( !_wcsicmp( arg[i], L"/BOOK" ) ) {
			Flags &= ( ~( OSD_ITALIC | OSD_UNDERLINE | OSD_SHADOW ) );
			ItalicSpecified = TRUE;
			UnderlineSpecified = TRUE;
			ShadowSpecified = TRUE;
			FontWeight = FW_NORMAL;
		}
		else if ( !_wcsicmp( arg[i], L"/UC" ) )
			ForceUppercase = TRUE;
		else if ( !_wcsicmp( arg[i], L"/ALPHA" ) || !_wcsicmp( arg[i], L"/A" ) )
			Alpha = OSD_ALPHA_DEFAULT, AlphaSpecified = TRUE;
		else if ( ( IsOptionWithArgs( arg[i], L"/ALPHA", &ch, TRUE ) ) || ( IsOptionWithArgs( arg[i], L"/A", &ch, TRUE ) ) ) {
			if ( ParseInt( ch, &Alpha, NULL ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad alpha value: \"%s\"\r\n", ch );
				return 1;
			}

			if ( ( Alpha < OSD_ALPHA_MIN ) || ( Alpha > OSD_ALPHA_MAX ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Alpha value must be %u - %u: %u\r\n", OSD_ALPHA_MIN, OSD_ALPHA_MAX, Alpha );
				return 1;
			}

			AlphaSpecified = TRUE;
		}
		else if ( !_wcsicmp( arg[i], L"/BLINK" ) )
			BlinkRate = OSD_BLINK_DEFAULT;
		else if ( IsOptionWithArgs( arg[i], L"/BLINK", &ch, TRUE ) ) {
			if ( ParseInt( ch, &BlinkRate, NULL ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad blink rate value: \"%s\"\r\n", ch );
				return 1;
			}

			if ( ( BlinkRate > 0 ) && ( ( BlinkRate < OSD_BLINK_MIN ) || ( BlinkRate > OSD_BLINK_MAX ) ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Blink rate must be zero or %u - %u: %u\r\n", OSD_BLINK_MIN, OSD_BLINK_MAX, BlinkRate );
				return 1;
			}
		}

#ifdef	OSD_ANGLES

		else if ( IsOptionWithArgs( arg[i], L"/ANGLE", &ch, TRUE ) ) {
			if ( ParseSignedInt( ch, &TextAngle, NULL ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad angle: \"%s\"\r\n", ch );
				return 1;
			}

			if ( ( TextAngle < -360 ) || ( TextAngle > 360 ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Angle must be -360\u00b0 to 360\u00b0: %d\r\n", TextAngle );
				return 1;
			}
		}

#endif	//	OSD_ANGLES

		else if ( !_wcsicmp( arg[i], L"/UP" ) )
			TextAngle = 90;
		else if ( !_wcsicmp( arg[i], L"/DOWN" ) )
			TextAngle = 270;
		else if ( !_wcsicmp( arg[i], L"/INVERT" ) )
			TextAngle = 180;
		else if ( !_wcsicmp( arg[i], L"/Q" ) )
			Quiet = TRUE;
		else if ( IsOptionWithArgs( arg[i], L"/MAXLINES", &ch, TRUE ) ) {
			if ( ParseInt( ch, &MaxLines, NULL ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad MaxLines value: \"%s\"\r\n", ch );
				return 1;
			}

			if ( MaxLines > OSD_MAX_FILE_LINES ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"MaxLines must be 0 - %u: %u\r\n", OSD_MAX_FILE_LINES, MaxLines );
				return 1;
			}
		}
		else if ( !_wcsicmp( arg[i], L"/SAVE" ) )
			Save = TRUE;
		else if ( IsOptionWithArgs( arg[i], L"/SAVE", &ch, TRUE ) ) {
			if ( ParseInt( ch, &Style, NULL ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad style value: \"%s\"\r\n", ch );
				return 1;
			}

			if ( !Style || ( Style > OSD_STYLE_MAX ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Style must be 1 - %u: %u\r\n", OSD_STYLE_MAX, Style );
				return 1;
			}

			Save = TRUE;
		}

#ifdef OSD_ESCAPES

		else if ( !_wcsicmp( arg[i], L"/X" ) )
			Escapes = TRUE;

#endif	//	OSD_ESCAPES

		else if ( arg[i][0] == '/' ) {
			_wcsupr_s( arg[i], MAX_ARG_LEN );
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Unknown option: \"%s\"\r\n", arg[i] );
			return 1;
		}
		else if ( !Text )
			Text = arg[i];
		else {
			_wcsupr_s( arg[i], MAX_ARG_LEN );
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Syntax error: \"%s\"\r\n", arg[i] );
			return 1;
		}
	}



	if ( CloseAllWindows ) {
		unsigned int k		= CloseAllOSDWindows();

		if ( !Text ) {
			if ( k )
				return 0;
			else {
				if ( !Quiet ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"No OSD windows found\r\n" );
				}
				return 2;
			}
		}
	}
	else if ( CloseWindow || FadeWindowsNow ) {
		unsigned int k		= 0;
		
		if ( CloseWindow )
			k = CloseOSDWindowsByID( WindowID );
		else if ( FadeAllWindowsNow )
			k = FadeOSDWindowsByID( -1 );
		else
			k = FadeOSDWindowsByID( WindowID );

		if ( !Text ) {
			if ( k )
				return 0;
			else {
				if ( !Quiet ) {
					DisplayErrorHeader();

					if ( FadeAllWindowsNow )
						Qprintf( ERRHANDLE, L"No OSD windows found\r\n" );
					else
						Qprintf( ERRHANDLE, L"OSD window %u not found\r\n", WindowID );
				}
				return 2;
			}
		}
	}



	FontFamily = CheckFontFamilyName( Typeface );
	if ( FontFamily )
		PickATypeFace( FontFamily, Typeface );

	

	if ( Style && !Save ) {

		if ( Typeface[0] == '\0' )
			OSD_RegGetString( OSD_RegKeyName, OSD_TypefaceValueName, Style, Typeface );

		if ( !TextSize )
			TextSize = OSD_RegGetDWord( OSD_RegKeyName, OSD_HeightValueName, Style, OSD_TEXT_HEIGHT_MIN, OSD_TEXT_HEIGHT_MAX, 0 );

		if ( FontWeight < 0 ) {
			FontWeight = OSD_RegGetDWord( OSD_RegKeyName, OSD_WeightValueName, Style, 0, 9, 0xffff );

			if ( FontWeight < 10 )
				FontWeight *= 100;
			else
				FontWeight = -1;
		}

		if ( !ColorSpecified )
			TextColor = _OSD_SwapBytes( OSD_RegGetDWord( OSD_RegKeyName, OSD_RGBValueName, Style, 0x000000, 0xffffff, 0x00ff00 ) );

		if ( !AlphaSpecified )
			Alpha = OSD_RegGetDWord( OSD_RegKeyName, OSD_AlphaValueName, Style, OSD_ALPHA_MIN, OSD_ALPHA_MAX, 0 );

		if ( !ItalicSpecified ) {
			DWORD t = OSD_RegGetDWord( OSD_RegKeyName, OSD_ItalicsValueName, Style, 0, 0xffff, -1 );

			if ( t < 0x1000 ) {
				if ( t )
					Flags |= OSD_ITALIC;
				else
					Flags &= ( ~OSD_ITALIC );
			}
		}

		if ( !UnderlineSpecified ) {
			DWORD t = OSD_RegGetDWord( OSD_RegKeyName, OSD_UnderlineValueName, Style, 0, 0xffff, -1 );

			if ( t < 0x1000 ) {
				if ( t )
					Flags |= OSD_UNDERLINE;
				else
					Flags &= ( ~OSD_UNDERLINE );
			}
		}

		if ( !ShadowSpecified ) {
			DWORD t = OSD_RegGetDWord( OSD_RegKeyName, OSD_ShadowValueName, Style, 0, 0xffff, -1 );

			if ( t < 0x1000 ) {
				if ( t )
					Flags |= OSD_SHADOW;
				else
					Flags &= ( ~OSD_SHADOW );
			}
		}
	}


	if ( !TextSize )
		TextSize = OSD_TEXT_HEIGHT_DEFAULT;

	if ( FontScaled )
		TextSize = ScaledFontSize( TextSize, Monitor );

	if ( FontWeight < 0 )
		FontWeight = Typeface[0] ? FW_DONTCARE : FW_BOLD;

	if ( Typeface[0] == '\0' )
		wcscpy_s( Typeface, SHORT_BUF_LEN, DefaultFont );

	if ( !Alpha )
		Alpha = OSD_ALPHA_MAX;



	if ( Style && Save ) {
		OSD_RegWriteString( OSD_RegKeyName, OSD_TypefaceValueName,	Style, Typeface );
		OSD_RegWriteDWord( OSD_RegKeyName, OSD_HeightValueName,		Style, TextSize );
		OSD_RegWriteDWord( OSD_RegKeyName, OSD_WeightValueName,		Style, FontWeight / 100 );
		OSD_RegWriteDWord( OSD_RegKeyName, OSD_RGBValueName,		Style, _OSD_SwapBytes( TextColor ) );
		OSD_RegWriteDWord( OSD_RegKeyName, OSD_AlphaValueName,		Style, Alpha );
		OSD_RegWriteDWord( OSD_RegKeyName, OSD_ItalicsValueName,	Style, ( Flags & OSD_ITALIC ) ? 1 : 0 );
		OSD_RegWriteDWord( OSD_RegKeyName, OSD_UnderlineValueName,	Style, ( Flags & OSD_UNDERLINE ) ? 1 : 0 );
		OSD_RegWriteDWord( OSD_RegKeyName, OSD_ShadowValueName,		Style, ( Flags & OSD_SHADOW ) ? 1 : 0 );
	}



	if ( Save && !Text )
		return 0;

	if ( !Text ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Missing text\r\n" );
		return 1;
	}

	if ( Wait && !Timeout ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Timeout may be zero only if /N is specified.\r\n" );
		return 1;
	}


#ifdef	OSD_READ_FILE

	if ( MaxLines && ( Text[0] == '@' ) && Text[1] ) {
		OSDReadFileText( Text + 1, InputBuffer, MAX_ARG_LEN, MaxLines, CodePage, CodePageEbcdic );
		if ( InputBuffer[0] )
			Text = InputBuffer;
	}

#endif	//	OSD_READ_FILE

	
	if ( Escapes )
		ExpandEscapes( Text, MAX_ARG_LEN );

	if ( Verticalize ) {
		VerticalizeText( Text, inString );
		Text = inString;
		Flags = ( Flags & ~OSD_RIGHT_JUSTIFY ) | OSD_CENTER_JUSTIFY;
	}

	if ( wcschr( Text, '\a' ) ) {
		Flags |= OSD_DING;
		OSD_StripChar( Text, '\a' );
	}

	if ( ForceUppercase )
		_wcsupr_s( Text, MAX_ARG_LEN );



	hWnd = MakeOsdWindow( Text, Timeout, WindowX, WindowY, TextSize, TextColor, ShadowColor, Flags, Typeface, FontWeight, WindowID, Alpha, BlinkRate, Monitor, TextAngle );


	if ( !hWnd ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Can\u2019t create OSD window\r\n" );
		return 2;
	}

	if ( Wait ) {
		OSDCtrlBreakFlag = 0;
		SetConsoleCtrlHandler( ControlBreakProc, TRUE );

		while ( IsWindow( hWnd ) ) {
			if ( OSDCtrlBreakFlag ) {
				SendMessage( hWnd, WM_CLOSE, 0, 0 );
				rv = 3;
				Sleep( 20 );
			}
			else {
				Sleep( 40 );
				tty_yield( 0 );
			}
		}

		SetConsoleCtrlHandler( ControlBreakProc, FALSE );
	}

	return rv;
}

#endif	//	OSD_OSD_CMD



#ifdef	OSD_OSD_VARS

DLLExports int WINAPI _osd( LPTSTR outString )
{
	if ( !outString )
		return -1;


	unsigned int Count		= CountOSDWindows( -1 );

	wsprintf( outString, L"%u", Count );
	return 0;
}



DLLExports int WINAPI _osdver( LPTSTR outString )
{
	if ( !outString )
		return -1;


	MultiByteToWideChar( CP_ACP, MB_PRECOMPOSED, MACRO_STR( OSD_VERSION ), -1, outString, MAX_ARG_LEN );
	return 0;
}



DLLExports int WINAPI f_osd( LPTSTR String )
{
	if ( !String )
		return -1;


	unsigned int WindowID	= 0;
	unsigned int Count		= 0;


	ParseArgs( String, PARSE_BREAK_COMMAS | PARSE_FORCE_UPPERCASE );


	if ( arglen[0] ) {
		if ( ParseInt( arg[0], &WindowID, NULL ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad ID value: \"%s\"\r\n", arg[0] );
			return -1;
		}

		if ( WindowID > OSD_ID_MAX ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Window ID must be 0 - %u: %u\r\n", OSD_ID_MAX, WindowID );
			return -1;
		}
	}

	Count = CountOSDWindows( WindowID );
	wsprintf( String, L"%u", Count );
	return 0;
}

#endif	//	OSD_OSD_VARS



#ifdef	OSD_PCTBAR_CMD

DLLExports int WINAPI pctbar( LPTSTR inString )
{
	if ( !inString )
		return -1;


	unsigned int Dividend	= 0;
	unsigned int Divisor	= 100;
	unsigned int Timeout	= OSD_RegReadDWord( OSD_RegKeyName, OSD_PBTimeoutValueName, OSD_MSEC_MIN, OSD_TIMEOUT_MAX * 1000, 4000 );
	unsigned int Style		= 0;
	int WindowX				= 0;
	int WindowY				= 0;
	unsigned int WindowID	= OSD_PCTBAR_DEFAULT_ID;
	DWORD Flags				= 0;
	DWORD Color				= 0x00ff00;
	COLORREF ShadowColor	= W3C_COLOR_UNDEFINED;
	unsigned int SizeX		= 0;
	unsigned int SizeY		= 0;
	unsigned int Alpha		= 0;
	unsigned int BlinkRate	= 0;
	int Monitor				= OSD_MONITOR_DEFAULT;
	BOOL DividendSpecified	= FALSE;
	BOOL ColorSpecified		= FALSE;
	BOOL AlphaSpecified		= FALSE;
	BOOL ShadowSpecified	= FALSE;
	BOOL CloseWindow		= FALSE;
	BOOL Wait				= TRUE;
	wchar_t *ch				= NULL;
	int sv					= 0;
	int rv					= 0;

	HWND hWnd				= NULL;



	ParseArgs( inString, PARSE_BREAK_SPACES | PARSE_SLASHES_KLUDGE | PARSE_FORCE_UPPERCASE );


	for ( int i = 0; i < numargs; i++ ) {
		ch = NULL;

		if ( !wcsncmp( arg[i], L"/?", 2 ) )
			return ShowCmdHelp( PctBarHelpText, ( arg[i][2] == '?' ), __FILE__, MACRO_STR( OSD_VERSION ) );
		else if ( sv = IsOsdCommonOption( arg[i], &Flags, &WindowX, &WindowY, &Monitor ) ) {
			if ( sv < 0 )
				return 1;
		}
		else if ( sv = IsOsdColorOption( arg[i], &Color ) ) {
			if ( sv < 0 )
				return 1;

			ColorSpecified = TRUE;
		}
		else if ( sv = IsOsdTimeoutOption( arg[i], &Timeout ) ) {
			if ( sv < 0 )
				return 1;
		}
		else if ( sv = IsOsdStyleOption( arg[i], &Style ) ) {
			if ( sv < 0 )
				return 1;
		}
		else if ( !_wcsicmp( arg[i], L"/C" ) )
			CloseWindow = TRUE;
		else if ( IsOptionWithArgs( arg[i], L"/C", &ch, TRUE ) ) {
			if ( ParseInt( ch, &WindowID, NULL ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad ID value: \"%s\"\r\n", ch );
				return 1;
			}

			if ( WindowID > OSD_ID_MAX ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Window ID must be 0 - %u: %u\r\n", OSD_ID_MAX, WindowID );
				return 1;
			}

			CloseWindow = TRUE;
		}
		else if ( !_wcsicmp( arg[i], L"/N" ) )
			Wait = FALSE;
		else if ( IsOptionWithArgs( arg[i], L"/ID", &ch, TRUE ) ) {
			if ( ParseInt( ch, &WindowID, NULL ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad ID value: \"%s\"\r\n", ch );
				return 1;
			}

			if ( WindowID > OSD_ID_MAX ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Window ID must be 0 - %u: %u\r\n", OSD_ID_MAX, WindowID );
				return 1;
			}
		}
		else if ( !_wcsicmp( arg[i], L"/I" ) )
			Flags = ( Flags & ~OSD_CENTER_JUSTIFY ) | OSD_ITALIC;
		else if ( !_wcsicmp( arg[i], L"/J" ) )
			Flags = ( Flags & ~OSD_ITALIC ) | OSD_CENTER_JUSTIFY;
		else if ( !_wcsicmp( arg[i], L"/SHADOW" ) || !_wcsicmp( arg[i], L"/DS" ) )
			Flags |= OSD_SHADOW, ShadowSpecified = TRUE;
		else if ( IsOptionWithArgs( arg[i], L"/SHADOW", &ch, TRUE ) || IsOptionWithArgs( arg[i], L"/DS", &ch, TRUE ) ) {
			StripQuotes( ch );

			DWORD Color = W3CColorValue( ch, TRUE );

			if ( Color == W3C_COLOR_UNDEFINED ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Unknown W3C color name: \"%s\"\r\n", ch );
				return 1;
			}

			ShadowColor = _OSD_SwapBytes( Color );
			Flags |= OSD_SHADOW;
			ShadowSpecified = TRUE;
		}
		else if ( !_wcsicmp( arg[i], L"/V" ) )
			Flags |= OSD_SHOW_VALUE;
		else if ( !_wcsicmp( arg[i], L"/ALPHA" ) || !_wcsicmp( arg[i], L"/A" ) )
			Alpha = OSD_ALPHA_DEFAULT, AlphaSpecified = TRUE;
		else if ( ( IsOptionWithArgs( arg[i], L"/ALPHA", &ch, TRUE ) ) || ( IsOptionWithArgs( arg[i], L"/A", &ch, TRUE ) ) ) {
			if ( ParseInt( ch, &Alpha, NULL ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad alpha value: \"%s\"\r\n", ch );
				return 1;
			}

			if ( ( Alpha < OSD_ALPHA_MIN ) || ( Alpha > OSD_ALPHA_MAX ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Alpha value must be %u - %u: %u\r\n", OSD_ALPHA_MIN, OSD_ALPHA_MAX, Alpha );
				return 1;
			}

			AlphaSpecified = TRUE;
		}
		else if ( IsOptionWithArgs( arg[i], L"/SIZE", &ch, TRUE ) || IsOptionWithArgs( arg[i], L"/S", &ch, TRUE ) ) {
			wchar_t *sep1 = NULL;

			if ( ParseInt( ch, &SizeX, &sep1 ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad SizeX value: \"%s\"\r\n", ch );
				return 1;
			}

			if ( ( SizeX < OSD_PCTBAR_SIZE_MIN ) || ( SizeX > OSD_PCTBAR_SIZE_MAX ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"SizeX must be %u - %u: %u\r\n", OSD_PCTBAR_SIZE_MIN, OSD_PCTBAR_SIZE_MAX, SizeX );
				return 1;
			}

			if ( *sep1 ) {
				if ( ( *sep1 != ',' ) && ( *sep1 != ';' ) ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Syntax error: %s\r\n", arg[i] );
					return 1;
				}

				sep1++;

				if ( ParseInt( sep1, &SizeY, NULL ) ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad SizeY value: \"%s\"\r\n", sep1 );
					return 1;
				}

				if ( ( SizeY < OSD_PCTBAR_SIZE_MIN ) || ( SizeY > OSD_PCTBAR_SIZE_MAX ) ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"SizeY must be %u - %u: %u\r\n", OSD_PCTBAR_SIZE_MIN, OSD_PCTBAR_SIZE_MAX, SizeY );
					return 1;
				}
			}
			else {
				if ( SizeX > ( OSD_PCTBAR_DEFAULT_HEIGHT * 2 ) )
					SizeY = OSD_PCTBAR_DEFAULT_HEIGHT;
				else
					SizeY = OSD_PCTBAR_DEFAULT_WIDTH;
			}
		}
		else if ( arg[i][0] == '/' ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Unknown option: \"%s\"\r\n", arg[i] );
			return 1;
		}
		else if ( !DividendSpecified ) {
			if ( ParseInt( arg[i], &Dividend, &ch ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad numerator value: \"%s\"\r\n", arg[i] );
				return 1;
			}

			DividendSpecified = TRUE;

			if ( ( *ch == '%' ) && ( ch[1] == '\0' ) )
				Divisor = 100;
			else if ( *ch == '/' ) {
				ch++;

				if ( ParseInt( ch, &Divisor, NULL ) ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad denominator value: \"%s\"\r\n", ch );
					return 1;
				}

				if ( !Divisor ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Denominator cannot be zero\r\n\n" );
					return 1;
				}
			}
			else if ( *ch ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Expected a / and denominator: \"%s\"\r\n", ch );
				return 1;
			}
		}
		else {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Syntax error: \"%s\"\r\n", arg[i] );
			return 1;
		}
	}



	if ( !DividendSpecified ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Missing numerator\r\n" );
		return 1;
	}

	if ( Dividend > Divisor )
		Dividend = Divisor;

	if ( Wait && !Timeout ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Timeout may be zero only if /N is specified.\r\n" );
		return 1;
	}


	if ( Style ) {
		if ( !ColorSpecified )
			Color = _OSD_SwapBytes( OSD_RegGetDWord( OSD_RegKeyName, OSD_RGBValueName, Style, 0x000000, 0xffffff, 0x00ff00 ) );

		if ( !AlphaSpecified )
			Alpha = OSD_RegGetDWord( OSD_RegKeyName, OSD_AlphaValueName, Style, OSD_ALPHA_MIN, OSD_ALPHA_MAX, OSD_ALPHA_MAX );

		if ( !ShadowSpecified ) {
			DWORD t = OSD_RegGetDWord( OSD_RegKeyName, OSD_ShadowValueName, Style, 0, 0xffff, -1 );

			if ( t < 0x1000 ) {
				if ( t )
					Flags |= OSD_SHADOW;
				else
					Flags &= ( ~OSD_SHADOW );
			}
		}
	}


	if ( ( Alpha < OSD_ALPHA_MIN ) || ( Alpha > OSD_ALPHA_MAX ) )
		Alpha = OSD_ALPHA_MAX;

	if ( !SizeX )
		SizeX = OSD_PCTBAR_DEFAULT_WIDTH;

	if ( !SizeY )
		SizeY = OSD_PCTBAR_DEFAULT_HEIGHT;




	hWnd = MakePctBarWindow( Dividend, Divisor, Timeout, WindowX, WindowY, SizeX, SizeY, Color, ShadowColor, Flags, WindowID, Alpha, BlinkRate, Monitor );


	if ( !hWnd ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Can\u2019t create OSD window\r\n" );
		return 2;
	}

	if ( CloseWindow )
		CloseOSDWindowsByID( WindowID, hWnd );

	if ( Wait ) {
		OSDCtrlBreakFlag = 0;
		SetConsoleCtrlHandler( ControlBreakProc, TRUE );

		while ( IsWindow( hWnd ) ) {
			if ( OSDCtrlBreakFlag ) {
				SendMessage( hWnd, WM_CLOSE, 0, 0 );
				rv = 3;
				Sleep( 20 );
			}
			else {
				Sleep( 40 );
				tty_yield( 0 );
			}
		}

		SetConsoleCtrlHandler( ControlBreakProc, FALSE );
	}

	return rv;
}

#endif	//	OSD_PCTBAR_CMD



#ifdef	OSD_OSDIMG_CMD

DLLExports int WINAPI osdimg( LPTSTR inString )
{
	if ( !inString )
		return -1;


	wchar_t Filename[MAX_FILENAME_LEN]		= L"";

	unsigned int Timeout		= 4000;
	DWORD Flags					= OSD_NOT_TRANSP;
	int WindowX					= 0;
	int WindowY					= 0;
	unsigned int SizeX			= OSD_IMG_SIZE_DEFAULT;
	unsigned int SizeY			= 0;
	unsigned int WindowID		= OSD_IMG_DEFAULT_ID;
	unsigned int Alpha			= 0;
	unsigned int BlinkRate		= 0;
	unsigned int IconIndex		= 0;
	unsigned int BGPoint		= 0;
	unsigned int BGOffset		= 0;
	int Monitor					= OSD_MONITOR_DEFAULT;
	COLORREF BackColor			= 0x000000;
	BOOL AlphaSpecified			= FALSE;
	BOOL Wait					= TRUE;
	BOOL CloseWindow			= FALSE;
	BOOL GetIcon				= FALSE;
	unsigned int ResourceType	= IMAGE_ICON;
	wchar_t *ch					= NULL;
	int sv = 0;
	int rv = 0;

	Bitmap *ImgBitmap			= NULL;
	Graphics *WinCanvas			= NULL;
	SIZE DrawArgs;
	unsigned int ImgHeight		= 0;
	unsigned int ImgWidth		= 0;
	double ImgAspect			= 0.0;

	HWND hWnd					= NULL;


	ParseArgs( inString, PARSE_BREAK_SPACES | PARSE_SLASHES_KLUDGE | PARSE_FORCE_UPPERCASE );


	for ( int i = 0; i < numargs; i++ ) {
		ch = NULL;

		if ( !wcsncmp( arg[i], L"/?", 2 ) )
			return ShowCmdHelp( OsdImgHelpText, ( arg[i][2] == '?' ), __FILE__, MACRO_STR( OSD_VERSION ) );
		else if ( sv = IsOsdCommonOption( arg[i], &Flags, &WindowX, &WindowY, &Monitor ) ) {
			if ( sv < 0 )
				return 1;
		}
		else if ( sv = IsOsdColorOption( arg[i], &BackColor ) ) {
			if ( sv < 0 )
				return 1;

			Flags = ( Flags & ( ~OSD_NOT_TRANSP ) ) | OSD_COLOR_TRANS;
		}
		else if ( sv = IsOsdTimeoutOption( arg[i], &Timeout ) ) {
			if ( sv < 0 )
				return 1;
		}
		else if ( !_wcsicmp( arg[i], L"/C" ) )
			CloseWindow = TRUE;
		else if ( IsOptionWithArgs( arg[i], L"/C", &ch, TRUE ) ) {
			if ( ParseInt( ch, &WindowID, NULL ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad ID value: \"%s\"\r\n", ch );
				return 1;
			}

			if ( WindowID > OSD_ID_MAX ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Window ID must be 0 - %u: %u\r\n", OSD_ID_MAX, WindowID );
				return 1;
			}

			CloseWindow = TRUE;
		}
		else if ( IsOptionWithArgs( arg[i], L"/I", &ch, TRUE ) || IsOptionWithArgs( arg[i], L"/INDEX", &ch, TRUE ) ) {
			if ( ParseInt( ch, &IconIndex, NULL ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad icon index: \"%s\"\r\n", ch );
				return 1;
			}

			GetIcon = TRUE;
		}
		else if ( !_wcsicmp( arg[i], L"/N" ) )
			Wait = FALSE;
		else if ( IsOptionWithArgs( arg[i], L"/ID", &ch, TRUE ) ) {
			if ( ParseInt( ch, &WindowID, NULL ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad ID value: \"%s\"\r\n", ch );
				return 1;
			}

			if ( WindowID > OSD_ID_MAX ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Window ID must be 0 - %u: %u\r\n", OSD_ID_MAX, WindowID );
				return 1;
			}
		}
		else if ( !_wcsicmp( arg[i], L"/ALPHA" ) || !_wcsicmp( arg[i], L"/A" ) )
			Alpha = OSD_ALPHA_DEFAULT, AlphaSpecified = TRUE;
		else if ( ( IsOptionWithArgs( arg[i], L"/ALPHA", &ch, TRUE ) ) || ( IsOptionWithArgs( arg[i], L"/A", &ch, TRUE ) ) ) {
			if ( ParseInt( ch, &Alpha, NULL ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad alpha value: \"%s\"\r\n", ch );
				return 1;
			}

			if ( ( Alpha < OSD_ALPHA_MIN ) || ( Alpha > OSD_ALPHA_MAX ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Alpha value must be %u - %u: %u\r\n", OSD_ALPHA_MIN, OSD_ALPHA_MAX, Alpha );
				return 1;
			}

			AlphaSpecified = TRUE;
		}
		else if ( IsOptionWithArgs( arg[i], L"/SIZE", &ch, TRUE ) || IsOptionWithArgs( arg[i], L"/S", &ch, TRUE ) ) {
			wchar_t *sep1 = NULL;

			if ( ParseInt( ch, &SizeX, &sep1 ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad SizeX value: \"%s\"\r\n", ch );
				return 1;
			}

			if ( ( SizeX && ( SizeX < OSD_IMG_SIZE_MIN ) ) || ( SizeX > OSD_IMG_SIZE_MAX ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"SizeX must be %u - %u: %u\r\n", OSD_IMG_SIZE_MIN, OSD_IMG_SIZE_MAX, SizeX );
				return 1;
			}

			if ( *sep1 ) {
				if ( ( *sep1 != ',' ) && ( *sep1 != ';' ) ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Syntax error: %s\r\n", arg[i] );
					return 1;
				}

				sep1++;

				if ( ParseInt( sep1, &SizeY, NULL ) ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad SizeY value: \"%s\"\r\n", sep1 );
					return 1;
				}

				if ( ( SizeY && ( SizeY < OSD_IMG_SIZE_MIN ) ) || ( SizeY > OSD_IMG_SIZE_MAX ) ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"SizeY must be %u - %u: %u\r\n", OSD_IMG_SIZE_MIN, OSD_IMG_SIZE_MAX, SizeY );
					return 1;
				}
			}
			else
				SizeY = 0;
		}
		else if ( !_wcsicmp( arg[i], L"/BG" ) )
			BGPoint = 1, BGOffset = 0;
		else if ( IsOptionWithArgs( arg[i], L"/BG", &ch, TRUE ) ) {
			if ( ParseInt( ch, &BGPoint, &ch ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad BGPoint value: \"%s\"\r\n", arg[i] );
				return 1;
			}

			if ( ( BGPoint < 1 ) || ( BGPoint > 9 ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"BGPoint must be 1 - 9: %u\r\n", BGPoint );
				return 1;
			}

			if ( ( *ch == ',' ) || ( *ch == ';' ) ) {
				if ( ParseInt( ch + 1, &BGOffset, NULL ) ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad BGOffset value: \"%s\"\r\n", ch );
					return 1;
				}

				if ( BGOffset > 10 ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"BGOffset must be 0 - 10: %u\r\n", BGOffset );
					return 1;
				}
			}
			else if ( *ch == '\0' )
				BGOffset = 0;
			else {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Syntax error: \"%s\"\r\n", arg[i] );
				return 1;
			}
		}
		else if ( arg[i][0] == '/' ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Unknown option: \"%s\"\r\n", arg[i] );
			return 1;
		}
		else if ( Filename[0] == '\0' )
			QueryTrueName( arg[i], Filename );
		else {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Syntax error: \"%s\"\r\n", arg[i] );
			return 1;
		}
	}


	if ( ( Alpha < OSD_ALPHA_MIN ) || ( Alpha > OSD_ALPHA_MAX ) )
		Alpha = OSD_ALPHA_MAX;

	if ( Filename[0] == '\0' ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Missing filename\r\n" );
		return 1;
	}

	if ( !_OSD_IsFile( Filename ) ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"File not found: \"%s\"\r\n", Filename );
		return 2;
	}

	ch = wcsrchr( Filename, '.' );
	if ( ch ) {
		if ( !_wcsicmp( ch, L".dll" ) || !_wcsicmp( ch, L".exe" ) )
			GetIcon = TRUE;
	}



	if ( GetIcon ) {
		HICON LargeIcon			= NULL;
		HICON SmallIcon			= NULL;


		ExtractIconEx( Filename, IconIndex, &LargeIcon, &SmallIcon, 1 );

		if ( LargeIcon )
			ImgBitmap = new Bitmap( LargeIcon );
		else if ( SmallIcon )
			ImgBitmap = new Bitmap( SmallIcon );

		if ( ImgBitmap ) {
			if ( ( ImgBitmap->GetHeight() == 0 ) || ( ImgBitmap->GetWidth() == 0 ) ) {
				delete ImgBitmap;
				ImgBitmap = NULL;
			}
		}

		if ( LargeIcon )
			DestroyIcon( LargeIcon );

		if ( SmallIcon )
			DestroyIcon( SmallIcon );
	}


	if ( !ImgBitmap ) {
		ImgBitmap = new Bitmap( Filename, FALSE );
		if ( !ImgBitmap ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Unable to load image from file \"%s\"\r\n", Filename );
			return 2;
		}
	}


	ImgHeight	= ImgBitmap->GetHeight();
	ImgWidth	= ImgBitmap->GetWidth();

	if ( !ImgHeight || !ImgWidth ) {
		DisplayErrorHeader();

		if ( GetIcon )
			Qprintf( ERRHANDLE, L"Can\u2019t load icon #%u from file \"%s\"\r\n", IconIndex, Filename );
		else
			Qprintf( ERRHANDLE, L"Can\u2019t load image from file \"%s\"\r\n", Filename );

		delete ImgBitmap;
		return 2;
	}
	

	if ( BGPoint ) {
		Color PixelColor = 0x00000000;
		unsigned int x = 0, y = 0;

		if ( ( BGOffset >= ( ImgHeight / 2 ) ) || ( BGOffset >= ( ImgWidth / 2 ) ) )
			BGOffset = 0;

		switch ( BGPoint ) {

		case 1 :
			x = BGOffset;
			y = BGOffset;
			break;

		case 2 :
			x = ImgWidth / 2;
			y = BGOffset;
			break;

		case 3 :
			x = ImgWidth - BGOffset - 1;
			y = BGOffset;
			break;

		case 4 :
			x = BGOffset;
			y = ImgHeight / 2;
			break;

		case 5 :
			x = ImgWidth / 2;
			y = ImgHeight / 2;
			break;

		case 6 :
			x = ImgWidth - BGOffset - 1;
			y = ImgHeight / 2;
			break;

		case 7 :
			x = BGOffset;
			y = ImgHeight - BGOffset - 1;
			break;

		case 8 :
			x = ImgWidth / 2;
			y = ImgHeight - BGOffset - 1;
			break;

		case 9 :
			x = ImgWidth - BGOffset - 1;
			y = ImgHeight - BGOffset - 1;
			break;
		}

		if ( ImgBitmap->GetPixel( x, y, &PixelColor ) == Ok ) {
			BackColor = PixelColor.ToCOLORREF();
			Flags = ( Flags & ( ~OSD_NOT_TRANSP ) ) | OSD_COLOR_TRANS;
		}
	}


	ImgAspect	= (double) ImgWidth / (double) ImgHeight;

	if ( !SizeX && !SizeY ) {
		//	scale image to default size:

		if ( ImgWidth == ImgHeight )
			SizeX = SizeY = OSD_IMG_SIZE_DEFAULT;
		else if ( ImgAspect > 1.0 )
			SizeX = OSD_IMG_SIZE_DEFAULT, SizeY = (unsigned int) ( OSD_IMG_SIZE_DEFAULT / ImgAspect );
		else
			SizeY = OSD_IMG_SIZE_DEFAULT, SizeX = (unsigned int) ( OSD_IMG_SIZE_DEFAULT * ImgAspect );
	}
	else if ( !SizeY ) {
		SizeY = (unsigned int) ( SizeX / ImgAspect );

		if ( SizeY > OSD_IMG_SIZE_MAX )
			SizeY = OSD_IMG_SIZE_MAX, SizeX = (unsigned int) ( OSD_IMG_SIZE_MAX * ImgAspect );
	}
	else if ( !SizeX ) {
		SizeX = (unsigned int) ( SizeY * ImgAspect );

		if ( SizeX > OSD_IMG_SIZE_MAX )
			SizeX = OSD_IMG_SIZE_MAX, SizeY = (unsigned int) ( OSD_IMG_SIZE_MAX / ImgAspect );
	}

	//	wprintf( L"   * ImgHeight = %u   ImgWidth = %u   ImgAspect = %f\n", ImgHeight, ImgWidth, ImgAspect );
	//	wprintf( L"   * SizeX = %u   SizeY = %u\n", SizeX, SizeY );


	DrawArgs.cx	= SizeX;
	DrawArgs.cy	= SizeY;


	hWnd = CreateOSDWindow( WindowID, Timeout, WindowX, WindowY, BackColor, BackColor, Flags, Alpha, BlinkRate, Monitor, &DrawArgs, DrawOSDImage );


	if ( !hWnd ) {
		DisplayErrorHeader();
		Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Can\u2019t create OSD window\r\n" );
		return 2;
	}

	WinCanvas = new Graphics( hWnd, FALSE );
	if ( WinCanvas ) {
		WinCanvas->DrawImage( ImgBitmap, 0, 0, SizeX, SizeY );
		delete WinCanvas;
	}

	delete ImgBitmap;


	if ( CloseWindow )
		CloseOSDWindowsByID( WindowID, hWnd );

	if ( Wait ) {
		OSDCtrlBreakFlag = 0;
		SetConsoleCtrlHandler( ControlBreakProc, TRUE );

		while ( IsWindow( hWnd ) ) {
			if ( OSDCtrlBreakFlag ) {
				SendMessage( hWnd, WM_CLOSE, 0, 0 );
				rv = 3;
				Sleep( 20 );
			}
			else {
				Sleep( 40 );
				tty_yield( 0 );
			}
		}

		SetConsoleCtrlHandler( ControlBreakProc, FALSE );
	}

	return rv;
}

#endif	//	OSD_OSDIMG_CMD



int _OSD_IsWinPE()
{
	HKEY KeyHandle		= NULL;
	DWORD ValueSize		= SHORT_BUF_LEN * sizeof( wchar_t );
	DWORD ValueType		= 0;
	int rv				= 0;

	wchar_t ValueString[SHORT_BUF_LEN]		= L"";



	if ( RegOpenKeyEx( HKEY_LOCAL_MACHINE, L"Software\\Microsoft\\Windows NT\\CurrentVersion\\WinPE", 0, KEY_READ, &KeyHandle ) == ERROR_SUCCESS ) {

		if ( RegQueryValueEx( KeyHandle, L"Version", NULL, &ValueType, (BYTE*) ValueString, &ValueSize ) == ERROR_SUCCESS )
			if ( ( ValueType == REG_SZ ) && ValueString[0] )
				rv = 1;
		
		RegCloseKey( KeyHandle );
	}
	
	return rv;
}



int OSD_Initialize()
{
	wchar_t VersionStr[32]	= L"";
	HKEY KeyHandle			= NULL;
	HMODULE User32Handle	= NULL;

#ifdef	OSD_OSDIMG_CMD

	GdiplusToken = 0;

	int gdi = GdiplusStartup( &GdiplusToken, &StartupInput, NULL );
	if ( gdi ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Error %d initializing GDI+\r\n", gdi );
		return 0;
	}

#endif	//	OSD_OSDIMG_CMD


	WNDCLASSEX OsdWinClass;

	OsdWinClass.cbSize			= sizeof( WNDCLASSEX );
	OsdWinClass.style			= 0;
	OsdWinClass.lpfnWndProc		= OsdWindowProc;
	OsdWinClass.cbClsExtra		= 0;
	OsdWinClass.cbWndExtra		= sizeof( LONG_PTR );
	OsdWinClass.hInstance		= MyDLLHandle;
	OsdWinClass.hIcon			= NULL;
	OsdWinClass.hCursor			= NULL;
	OsdWinClass.hbrBackground	= 0;
	OsdWinClass.lpszMenuName	= NULL;
	OsdWinClass.lpszClassName	= OSDWindowClass;
	OsdWinClass.hIconSm			= NULL;

	MultiByteToWideChar( CP_ACP, MB_PRECOMPOSED, MACRO_STR( OSD_VERSION ), -1, VersionStr, 32 );
	wsprintf( OSDWindowClass, L"OSD window %s \u2022 %s %04X", VersionStr, PLUGIN_NAME, GetCurrentProcessId() );

	OSDWindowAtom = RegisterClassEx( &OsdWinClass );
	if ( OSDWindowAtom )
		Sleep( 50 );

	if ( _OSD_IsWinPE() ) {
		OSD_IsWinPE		= TRUE;
		OSD_Offscreen	= 0;
	}

	if ( RegCreateKeyEx( HKEY_CURRENT_USER, OSD_RegKeyName, 0, NULL, 0, KEY_READ | KEY_WRITE, NULL, &KeyHandle, NULL ) == ERROR_SUCCESS )
		RegCloseKey( KeyHandle );

	User32Handle = GetModuleHandle( L"User32.dll" );
	if ( User32Handle )
		GetScrollBarInfoProc = (_GetScrollBarInfoProc*) GetProcAddress( User32Handle, "GetScrollBarInfo" );
	else
		GetScrollBarInfoProc = NULL;

	return OSDWindowAtom;
}



int OSD_Shutdown()
{

	if ( OSDWindowAtom ) {
		CloseAllOSDWindows();
		UnregisterClass( OSDWindowClass, MyDLLHandle );
	}

	OSD_RemoveTempRegKey( OSD_RegKeyName );

#ifdef	OSD_OSDIMG_CMD

	if ( GdiplusToken )
		GdiplusShutdown( GdiplusToken );

#endif	//	OSD_OSDIMG_CMD

	return 0;
}


#endif	//	OSD_VERSION


/*

		1.0.7.1		2021-10-31
					Help text is now displayed via ShowHelpText().  Changes to
					the way the source file version is handled.

		1.0.7.2		2021-11-23
					Updates mmfiles.cpp to 1.4.4.0, ExpandEscapes.cpp to 1.0.3.
					Tweaks to error messages, and other minor code cleanup.

		1.0.8.0		2022-09-09
					Bug fix:  /FADENOW was not closing windows opened with /FADE.
					Added undocumented option /FADEALLNOW.  Made the default
					drop shadow darker.

		1.0.9.0		2022-11-21
					Added /TAB, to position OSD window relative to Take Command's
					tab window.

		1.0.9.2		2022-12-25
					#ifdef out a bunch of parsing code which is not needed when
					no commands are desired.

		1.0.10.0	2022-12-27
					Added /J option to PCTBAR for diamond crosshatch.

		1.0.11.0	2023-07-06
					Added /FADEIN.

		1.0.11.1	2023-07-06
					Made /TAB a compile-time option; #define OSD_TAB_OPTION
					to enable it.

*/
