
//		SoundVol.cpp  --  code to get and set the sound volume and mute state


#ifndef GET_SET_SOUNDVOL_VER
#define GET_SET_SOUNDVOL_VER			1.0.5.1


/**********************************************************

	Before you #include this file, you can:

	#define SOUNDVOL_CMD
			to include the SOUNDVOL command

	#define VOLUME_VAR
			to include the _VOLUME and _MUTE variables

	#define VOLUME_VAR_HELP_TEXT
			to include help text for _VOLUME and _MUTE


**********************************************************/



#ifndef MACRO_STR
#define MACRO_EXP( arg )				#arg
#define MACRO_STR( arg )				MACRO_EXP( arg )
#endif


#include <mmdeviceapi.h>
#include <endpointvolume.h>
#include <Functiondiscoverykeys_devpkey.h>


#define ACTION_GET_BOTH					0
#define ACTION_SET_VOLUME				1
#define ACTION_SET_MUTE					2
#define ACTION_SET_BOTH					3



#ifdef SOUNDVOL_CMD

#ifdef OSD_VERSION

const wchar_t SoundVolHelpText[] = L"Display or change the master sound volume. \n\
\n\
SOUNDVOL /B /M /O /Q /U vol\r\n\n\
\t/B\tbeep after change\n\
\t/M\tmute\n\
\t/O\tOSD\n\
\t/Q\tquietly\n\
\t/U\tunmute\n\
\tvol\tnew value for the volume, 0 - 100\n\n\
If /Q is not specified, the current volume will be displayed.\n";

#else	//	OSD_VERSION

const wchar_t SoundVolHelpText[] = L"Display or change the master sound volume.\n\
\n\
SOUNDVOL /B /M /Q /U vol\r\n\n\
\t/B\tbeep after change\n\
\t/M\tmute\n\
\t/Q\tquietly\n\
\t/U\tunmute\n\
\tvol\tnew value for the volume, 0 - 100\n\n\
If /Q is not specified, the current volume will be displayed.\n";

#endif	//	OSD_VERSION

#endif	//	SOUNDVOL_CMD


#ifdef VOLUME_VAR_HELP_TEXT

const wchar_t _VolumeHelpText[] = L"_VOLUME \r\n\
\n\
Returns the sound volume, 0 - 100; or -1 if  \n\
the volume can\u2019t not be determined.  \n";


const wchar_t _MuteHelpText[] = L"_MUTE \r\n\
\n\
Return 1 if muted, 0 if not, or -1 if the  \n\
mute state can\u2019t be determined.  \n";

#endif	//	VOLUME_VAR_HELP_TEXT



int GetSetSoundVolumeXP( int Action, unsigned int *Volume, unsigned int *Mute )
{
	//  Much indebted to:  http://www.qsl.net/i2phd/mixer/index.html

	if ( !Volume || !Mute )
		return -1;


	if ( ( Action < ACTION_GET_BOTH ) || ( Action > ACTION_SET_BOTH ) )
		Action = ACTION_GET_BOTH;

	WAVEFORMATEX WaveFormat;
	HWAVEOUT WaveOutHandle = NULL;
	HMIXER MixerHandle = NULL;
	MIXERCAPS MixerInfo;
	MIXERLINE MixerLineInfo;

	DWORD MasterLineID = 0, MainLineID = 0, FirstLineID = 0;
	BOOL FoundMaster = FALSE, FoundMain = FALSE, FoundFirst = FALSE;

	MIXERLINECONTROLS MixerLineControls;
	MIXERCONTROL VolumeControl, MuteControl;
	DWORD VolumeControlID = 0xdeadbeef, MuteControlID = 0xdeadbeef;
	MIXERCONTROLDETAILS VolumeDetails, MuteDetails;
	MIXERCONTROLDETAILS_UNSIGNED VolumeValue, MuteValue;
	int temp = 0;


	WaveFormat.wFormatTag      = WAVE_FORMAT_PCM;
	WaveFormat.nChannels       = 2;
	WaveFormat.nSamplesPerSec  = 44100;
	WaveFormat.wBitsPerSample  = 16;
	WaveFormat.nBlockAlign     = 4;
	WaveFormat.nAvgBytesPerSec = 176400;
	WaveFormat.cbSize          = 0;

	if ( waveOutOpen( &WaveOutHandle, WAVE_MAPPER, &WaveFormat, NULL, 0, NULL ) )
		return 2;

	if ( mixerOpen( &MixerHandle, (unsigned int) WaveOutHandle, NULL, 0, MIXER_OBJECTF_HWAVEOUT ) ) {
		waveOutClose( WaveOutHandle );
		return 2;
	}

	waveOutClose( WaveOutHandle );

	if ( mixerGetDevCaps( (unsigned int) MixerHandle, &MixerInfo, sizeof( MIXERCAPS ) ) ) {
		mixerClose( MixerHandle );
		return 2;
	}

	for ( unsigned int i = 0; i < MixerInfo.cDestinations; i++ ) {
		MixerLineInfo.cbStruct = sizeof( MIXERLINE );
		MixerLineInfo.dwDestination = i;
		if ( mixerGetLineInfo( (HMIXEROBJ) MixerHandle, &MixerLineInfo, MIXER_GETLINEINFOF_DESTINATION ) == 0 ) {

			if ( MixerLineInfo.cControls ) {
				if ( !FoundFirst ) {
					FirstLineID = MixerLineInfo.dwLineID;
					FoundFirst = TRUE;
				}
				if ( !FoundMaster && ( _wcsnicmp( MixerLineInfo.szShortName, L"Master", 6 ) == 0 ) ) {
					MasterLineID = MixerLineInfo.dwLineID;
					FoundMaster = TRUE;
				}
				if ( !FoundMaster && ( _wcsnicmp( MixerLineInfo.szName, L"Master", 6 ) == 0 ) ) {
					MasterLineID = MixerLineInfo.dwLineID;
					FoundMaster = TRUE;
				}
				if ( !FoundMain && ( _wcsnicmp( MixerLineInfo.szShortName, L"Main", 4 ) == 0 ) ) {
					MainLineID = MixerLineInfo.dwLineID;
					FoundMain = TRUE;
				}
				if ( !FoundMain && ( _wcsnicmp( MixerLineInfo.szName, L"Main", 4 ) == 0 ) ) {
					MainLineID = MixerLineInfo.dwLineID;
					FoundMain = TRUE;
				}
			}
		}
	}

	if ( !FoundFirst ) {
		mixerClose( MixerHandle );
		return 2;
	}

	if ( !FoundMaster ) {
		if ( FoundMain )
			MasterLineID = MainLineID;
		else
			MasterLineID = FirstLineID;
	}

	mixerGetLineInfo( (HMIXEROBJ) MixerHandle, &MixerLineInfo, MIXER_GETLINEINFOF_DESTINATION );


	MixerLineControls.cbStruct = sizeof( MIXERLINECONTROLS );
	MixerLineControls.dwLineID = MasterLineID;
	MixerLineControls.cControls = 1;
	MixerLineControls.dwControlType = MIXERCONTROL_CONTROLTYPE_VOLUME;
	MixerLineControls.pamxctrl = &VolumeControl;
	MixerLineControls.cbmxctrl = sizeof( MIXERCONTROL );

	if ( mixerGetLineControls( (HMIXEROBJ) MixerHandle, &MixerLineControls, MIXER_GETLINECONTROLSF_ONEBYTYPE ) ) {
		mixerClose( MixerHandle );
		return 2;
	}
	VolumeControlID = VolumeControl.dwControlID;

	MixerLineControls.cbStruct = sizeof( MIXERLINECONTROLS );
	MixerLineControls.dwLineID = MasterLineID;
	MixerLineControls.cControls = 1;
	MixerLineControls.dwControlType = MIXERCONTROL_CONTROLTYPE_MUTE;
	MixerLineControls.pamxctrl = &MuteControl;
	MixerLineControls.cbmxctrl = sizeof( MIXERCONTROL );

	if ( mixerGetLineControls( (HMIXEROBJ) MixerHandle, &MixerLineControls, MIXER_GETLINECONTROLSF_ONEBYTYPE ) == 0 )
		MuteControlID = MuteControl.dwControlID;

	if ( Action == ACTION_GET_BOTH ) {
		VolumeDetails.cbStruct = sizeof( MIXERCONTROLDETAILS );
		VolumeDetails.dwControlID = VolumeControlID;
		VolumeDetails.cChannels = 1;
		VolumeDetails.hwndOwner = NULL;
		VolumeDetails.cMultipleItems = 0;
		VolumeDetails.cbDetails = sizeof( MIXERCONTROLDETAILS_UNSIGNED );
		VolumeDetails.paDetails = &VolumeValue;

		if ( mixerGetControlDetails( (HMIXEROBJ) MixerHandle, &VolumeDetails, MIXER_GETCONTROLDETAILSF_VALUE ) ) {
			mixerClose( MixerHandle );
			return 2;
		}

		if ( MuteControlID != 0xdeadbeef ) {
			MuteDetails.cbStruct = sizeof( MIXERCONTROLDETAILS );
			MuteDetails.dwControlID = MuteControlID;
			MuteDetails.cChannels = 1;
			MuteDetails.hwndOwner = NULL;
			MuteDetails.cMultipleItems = 0;
			MuteDetails.cbDetails = sizeof ( MIXERCONTROLDETAILS_UNSIGNED );
			MuteDetails.paDetails = &MuteValue;

			if ( mixerGetControlDetails( (HMIXEROBJ) MixerHandle, &MuteDetails, MIXER_GETCONTROLDETAILSF_VALUE ) )
				MuteValue.dwValue = 0;
		}
		else
			MuteValue.dwValue = 0;

		temp = VolumeValue.dwValue * 200 / 0xffff;
		*Volume = VolumeValue.dwValue * 100 / 0xffff + ( temp & 1 );
		*Mute = ( MuteValue.dwValue ? 1 : 0 );
	}

	if ( Action & ACTION_SET_VOLUME ) {
		VolumeDetails.cbStruct = sizeof( MIXERCONTROLDETAILS );
		VolumeDetails.dwControlID = VolumeControlID;
		VolumeDetails.cChannels = 1;
		VolumeDetails.hwndOwner = NULL;
		VolumeDetails.cMultipleItems = 0;
		VolumeDetails.cbDetails = sizeof( MIXERCONTROLDETAILS_UNSIGNED );
		VolumeDetails.paDetails = &VolumeValue;
		VolumeValue.dwValue = *Volume * 0xffff / 100;

		if ( mixerSetControlDetails( (HMIXEROBJ) MixerHandle, &VolumeDetails, MIXER_SETCONTROLDETAILSF_VALUE ) ) {
			mixerClose( MixerHandle );
			return 2;
		}
	}

	if ( ( Action & ACTION_SET_MUTE ) && ( MuteControlID != 0xdeadbeef ) ) {
		MuteDetails.cbStruct = sizeof( MIXERCONTROLDETAILS );
		MuteDetails.dwControlID = MuteControlID;
		MuteDetails.cChannels = 1;
		MuteDetails.hwndOwner = NULL;
		MuteDetails.cMultipleItems = 0;
		MuteDetails.cbDetails = sizeof( MIXERCONTROLDETAILS_UNSIGNED );
		MuteDetails.paDetails = &MuteValue;
		MuteValue.dwValue = ( *Mute ? 1 : 0 );

		if ( mixerSetControlDetails( (HMIXEROBJ) MixerHandle, &MuteDetails, MIXER_SETCONTROLDETAILSF_VALUE ) ) {
			mixerClose( MixerHandle );
			return 2;
		}
	}

	mixerClose( MixerHandle );
	return 0;
}



int GetSetSoundVolumeVista( int Action, unsigned int *Volume, unsigned int *Mute, LPTSTR outDeviceName, size_t buflen )
{
	//  Steals shamelessly from:  http://www.codeproject.com/Tips/233484/Change-Master-Volume-in-Visual-Cplusplus

	if ( !Volume || !Mute )
		return -1;


	if ( ( Action < ACTION_GET_BOTH ) || ( Action > ACTION_SET_BOTH ) )
		Action = ACTION_GET_BOTH;

	float VolumeValue = 0.0;
	BOOL MuteValue = FALSE;

	HRESULT hr = NULL;

	IMMDeviceEnumerator *devEnum = NULL;
	hr = CoCreateInstance( __uuidof( MMDeviceEnumerator ), NULL, CLSCTX_INPROC_SERVER, __uuidof( IMMDeviceEnumerator ), (LPVOID *) &devEnum );

	if ( hr )
		return 2;


	IMMDevice *defaultDevice = NULL;
	hr = devEnum->GetDefaultAudioEndpoint( eRender, eConsole, &defaultDevice );
	devEnum->Release();

	if ( hr )
		return 2;

	if ( outDeviceName && ( buflen >= 40 ) ) {
		IPropertyStore *Properties		= NULL;
		PROPVARIANT DeviceName;


		defaultDevice->OpenPropertyStore( STGM_READ, &Properties );

		if ( Properties ) {
			PropVariantInit( &DeviceName );
			Properties->GetValue( PKEY_Device_FriendlyName, &DeviceName );

			if ( DeviceName.vt == VT_LPWSTR )
				wcsncpy_s( outDeviceName, buflen, DeviceName.pwszVal, _TRUNCATE );

			Properties->Release();
		}
	}


	IAudioEndpointVolume *endpointVolume = NULL;
	hr = defaultDevice->Activate( __uuidof( IAudioEndpointVolume ), CLSCTX_INPROC_SERVER, NULL, (LPVOID *) &endpointVolume );
	defaultDevice->Release();

	if ( hr )
		return 2;


	if ( Action == ACTION_GET_BOTH ) {
		hr = endpointVolume->GetMasterVolumeLevelScalar( &VolumeValue );

		if ( hr ) {
			endpointVolume->Release();
			return 2;
		}

		hr = endpointVolume->GetMute( &MuteValue );

		*Volume = (int) ( VolumeValue * 100.0 + 0.5 );
		*Mute = ( MuteValue != 0 );
	}

	if ( Action & ACTION_SET_VOLUME ) {
		if ( *Volume > 100 )
			VolumeValue = 1.0;
		else
			VolumeValue = *Volume / 100.0f;

		hr = endpointVolume->SetMasterVolumeLevelScalar( VolumeValue, NULL );

		if ( hr ) {
			endpointVolume->Release();
			return 2;
		}
	}

	if ( Action & ACTION_SET_MUTE )
		hr = endpointVolume->SetMute( ( *Mute != 0 ), NULL );


	hr = endpointVolume->Release();

	return 0;
}



int GetSetSoundVolume( int Action, unsigned int *Volume, unsigned int *Mute, LPTSTR outDeviceName, size_t buflen )
{
	if ( OSVerInfo.dwMajorVersion > 5 )
		return GetSetSoundVolumeVista( Action, Volume, Mute, outDeviceName, buflen );
	else
		return GetSetSoundVolumeXP( Action, Volume, Mute );
}



int GetSetSoundVolume( int Action, unsigned int *Volume, unsigned int *Mute )
{
	return GetSetSoundVolume( Action, Volume, Mute, NULL, 0 );
}



#ifdef VOLUME_VAR

DLLExports int WINAPI _volume( LPTSTR outString )
{
	if ( !outString )
		return 1;


	unsigned int Volume = 0, Mute = 0;


	if ( GetSetSoundVolume( 0, &Volume, &Mute ) )
		wcscpy_s( outString, MAX_ARG_LEN, L"*Error*" );
	else
		_ltow_s( Volume, outString, MAX_ARG_LEN, 10 );

	return 0;
}



DLLExports int WINAPI _mute( LPTSTR outString )
{
	if ( !outString )
		return 1;


	unsigned int Volume = 0, Mute = 0;


	if ( GetSetSoundVolume( 0, &Volume, &Mute ) )
		wcscpy_s( outString, MAX_ARG_LEN, L"*Error*" );
	else
		_ltow_s( Mute, outString, MAX_ARG_LEN, 10 );

	return 0;
}

#endif	//	VOLUME_VAR



#ifdef SOUNDVOL_CMD

DLLExports int WINAPI soundvol( LPTSTR inString )
{
	if ( !inString )
		return -1;


	wchar_t DeviceName[SHORT_BUF_LEN]		= L"";

	unsigned int Volume	= 0;
	unsigned int Mute	= 0;
	int Action			= ACTION_GET_BOTH;
	BOOL Beep			= FALSE;
	BOOL Quietly		= FALSE;

#ifdef OSD_VERSION

	BOOL Osd			= FALSE;

#endif	//	OSD_VERSION


	ParseArgs( inString, PARSE_BREAK_SPACES | PARSE_SLASHES_KLUDGE );


	for ( int i = 0; i < numargs; i++ ) {
		if ( arglen[i] ) {

			if ( !wcsncmp( arg[i], L"/?", 2 ) )
				return ShowCmdHelp( SoundVolHelpText, ( arg[i][2] == '?' ), __FILE__, MACRO_STR( GET_SET_SOUNDVOL_VER ) );
			else if ( !_wcsicmp( arg[i], L"/B" ) )
				Beep = TRUE;
			else if ( !_wcsicmp( arg[i], L"/M" ) ) {
				Mute = 1;
				Action |= ACTION_SET_MUTE;
			}

#ifdef OSD_VERSION

			else if ( !_wcsicmp( arg[i], L"/O" ) )
				Osd = TRUE;

#endif	//	OSD_VERSION

			else if ( !_wcsicmp( arg[i], L"/Q" ) )
				Quietly = TRUE;
			else if ( !_wcsicmp( arg[i], L"/U" ) ) {
				Mute = 0;
				Action |= ACTION_SET_MUTE;
			}
			else if ( arg[i][0] == '/' ) {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Unknown option: \"%s\"\r\n", arg[i] );
				return 1;
			}
			else if ( iswdigit( arg[i][0] ) ) {
				if ( ParseInt( arg[i], &Volume, NULL ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad volume: \"%s\"\r\n", arg[i] );
					return 1;
				}

				if ( Volume > 100 ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Volume must be 0 - 100\r\n" );
					return 1;
				}

				Action |= ACTION_SET_VOLUME;
			}
			else {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Syntax error: \"%s\"\r\n", arg[i] );
				return 1;
			}

		}
	}

	if ( GetSetSoundVolume( Action, &Volume, &Mute, DeviceName, SHORT_BUF_LEN ) ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Error getting or setting mixer values\r\n" );
		return 2;
	}

	if ( Action )													//	If we changed either the volume or the mute state,
		GetSetSoundVolume( ACTION_GET_BOTH, &Volume, &Mute );		//	get 'em both again so both variables are correct :


#ifdef OSD_VERSION

	if ( Osd ) {
		DWORD Color				= 0xffff00;
		DWORD Flags				= OSD_RIGHT | OSD_BOTTOM | OSD_ADD_OFFSET | OSD_FADE_OUT;
		unsigned int WindowID	= 0x04cd;
		BYTE Alpha				= 0xc0;
		unsigned int Time		= 5000;

		wchar_t NoteStr[]		= L"\u266b\u2006";
		wchar_t MuteStr[]		= L"\u2573\u2006";

		wchar_t VolMute10[]		= L"\U0001f507\u2006";
		wchar_t VolHigh10[]		= L"\U0001f50a\u2006";

		LPTSTR VolumeIcon		= NULL;
		unsigned int TextSize	= 40;


		if ( Mute )
			Color = 0x0000ff;

		if ( ( OSVerInfo.dwMajorVersion > 10 ) || ( ( OSVerInfo.dwMajorVersion == 10 ) && ( OSVerInfo.dwBuildNumber >= 19041 ) ) ) {
			VolumeIcon = Mute ? VolMute10 : VolHigh10;
			TextSize = 30;
		}
		else {
			VolumeIcon = Mute ? MuteStr : NoteStr;
			TextSize = 40;
		}


		CloseOSDWindowsByID( WindowID );
		MakePctBarWindow( Volume, 100, Time, -25, -30, 40, 200, Color, -1, Flags | OSD_ITALIC, WindowID, Alpha, 0, OSD_MONITOR_DEFAULT );
		MakeOsdWindow( VolumeIcon, Time, -17, -235, TextSize, Color, -1, Flags, L"Arial", 400, WindowID, Alpha, 0, OSD_MONITOR_DEFAULT, 0 );
	}

#endif	//	OSD_VERSION


	if ( Action && Beep )
		MessageBeep( MB_OK );

	if ( !Quietly ) {
		Printf( L"Sound volume is %u", Volume );
		if ( Mute )
			Printf( L" (muted)" );

		if ( DeviceName[0] )
			Printf( L" on \u201c%s\u201d", DeviceName );

		Printf( L".\r\n" );
	}

	return 0;
}

#endif	//	SOUNDVOL_CMD


#endif	//	GET_SET_SOUNDVOL_VER


/*

	1.0.0.0		2022-04-22

	1.0.1.0		2022-04-25
				Added _volume() function export.

	1.0.2.0		2022-04-26
				Added _mute() function and soundvol() command exports.
				#defines for all supported actions.

	1.0.3.0		2023-01-03
				SOUNDVOL changes:  Fixed a bug which could prevent values from
				being reported correctly; added /Q; cosmetic OSD tweaks; help
				text changes

	1.0.4.0		2023-02-01
				SOUNDVOL now displays the friendly name of the default output
				device.  (Vista and later only; does anyone still use XP?)

	1.0.4.1		2023-02-02
				Added help text for the _VOLUME and _MUTE variables;
				#define VOLUME_VAR_HELP_TEXT to include it.

	1.0.5.0		2023-04-03
				If Windows 10 version 2004 or later, the OSD display uses
				Unicode U+1F507 and U+1F50A for 'muted' and 'unmuted'.

	1.0.5.1		2023-05-18
				Moved the OSD window slightly up and to the left.

*/
