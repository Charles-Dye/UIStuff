
//		Canonicalize filename, with special extensions for shell objects :

#ifndef CANONICALIZE_SPECIAL_VERSION
#define CANONICALIZE_SPECIAL_VERSION		1.0.0.0


#include <ShlObj.h>


#define NUM_CSIDL_NAMES				63
#define MAX_CSIDL_NAME_LEN			24
#define MAX_CSIDL_FANCY_NAME_LEN	25


wchar_t CSIDLNames[NUM_CSIDL_NAMES][MAX_CSIDL_NAME_LEN] = { L"DESKTOP", L"INTERNET", L"PROGRAMS", L"CONTROLS",
	L"PRINTERS", L"PERSONAL", L"FAVORITES", L"STARTUP", L"RECENT", L"SENDTO", L"BITBUCKET", L"STARTMENU",
	L"MYMUSIC", L"MYVIDEO", L"DESKTOPDIRECTORY", L"DRIVES", L"NETWORK", L"NETHOOD", L"FONTS", L"TEMPLATES",
	L"COMMONSTARTMENU", L"COMMON_PROGRAMS", L"COMMON_STARTUP", L"COMMON_DESKTOPDIRECTORY", L"APPDATA",
	L"PRINTHOOD", L"LOCAL_APPDATA", L"ALTSTARTUP", L"COMMON_ALTSTARTUP", L"COMMON_FAVORITES", L"INTERNET_CACHE",
	L"COOKIES", L"HISTORY", L"COMMON_APPDATA", L"WINDOWS", L"SYSTEM", L"PROGRAM_FILES", L"MYPICTURES", L"PROFILE",
	L"SYSTEMX86", L"PROGRAM_FILESX86", L"PROGRAM_FILES_COMMON", L"PROGRAM_FILES_COMMONX86", L"COMMON_TEMPLATES",
	L"COMMON_DOCUMENTS", L"COMMON_ADMINTOOLS", L"ADMINTOOLS", L"CONNECTIONS", L"COMMON_MUSIC", L"COMMON_PICTURES",
	L"COMMON_VIDEO", L"RESOURCES", L"RESOURCES_LOCALIZED", L"COMMON_OEM_LINKS", L"CDBURN_AREA",
	L"COMPUTERSNEARME", L"SAMPLEMUSIC", L"SAMPLEPLAYLISTS", L"SAMPLEPICTURES", L"SAMPLEVIDEOS", L"MYDOCUMENTS",
	L"PHOTOALBUMS", L"PLAYLISTS" };

wchar_t CSIDLFancyNames[NUM_CSIDL_NAMES][MAX_CSIDL_FANCY_NAME_LEN] = { L"Desktop", L"Internet Explorer", L"Programs", L"Control Panel",
	L"Printers", L"Documents", L"Favorites", L"Startup", L"Recent", L"SendTo", L"Recycle Bin", L"Start Menu",
	L"Music", L"Video", L"Desktop Directory", L"Computer", L"Network", L"NetHood", L"Fonts", L"Templates",
	L"Common Start Menu", L"Common Programs", L"Common Startup", L"Common Desktop Directory", L"App Data",
	L"PrintHood", L"Local App Data", L"Alt Startup", L"Common Alt Startup", L"Common Favorites", L"Internet Cache",
	L"Cookies", L"History", L"Common App Data", L"Windows", L"System", L"Program Files", L"Pictures", L"Profile",
	L"System x86", L"Program Files x86", L"Program Files Common", L"Program Files Common x86", L"Common Templates",
	L"Common Documents", L"Common Admin Tools", L"Admin Tools", L"Connections", L"Common Music", L"Common Pictures",
	L"Common Video", L"Resources", L"Localized Resources", L"Common OEM Links", L"CD Burn Area",
	L"Computers Near Me", L"Sample Music", L"Sample Playlists", L"Sample Pictures", L"Sample Videos", L"My Documents",
	L"Photo Albums", L"Playlists" };

int CSIDLValues[NUM_CSIDL_NAMES] = { CSIDL_DESKTOP, CSIDL_INTERNET, CSIDL_PROGRAMS, CSIDL_CONTROLS,
	CSIDL_PRINTERS, CSIDL_PERSONAL, CSIDL_FAVORITES, CSIDL_STARTUP, CSIDL_RECENT, CSIDL_SENDTO, CSIDL_BITBUCKET, CSIDL_STARTMENU,
	CSIDL_MYMUSIC, CSIDL_MYVIDEO, CSIDL_DESKTOPDIRECTORY, CSIDL_DRIVES, CSIDL_NETWORK, CSIDL_NETHOOD, CSIDL_FONTS, CSIDL_TEMPLATES,
	CSIDL_COMMON_STARTMENU, CSIDL_COMMON_PROGRAMS, CSIDL_COMMON_STARTUP, CSIDL_COMMON_DESKTOPDIRECTORY, CSIDL_APPDATA,
	CSIDL_PRINTHOOD, CSIDL_LOCAL_APPDATA, CSIDL_ALTSTARTUP, CSIDL_COMMON_ALTSTARTUP, CSIDL_COMMON_FAVORITES, CSIDL_INTERNET_CACHE,
	CSIDL_COOKIES, CSIDL_HISTORY, CSIDL_COMMON_APPDATA, CSIDL_WINDOWS, CSIDL_SYSTEM, CSIDL_PROGRAM_FILES, CSIDL_MYPICTURES, CSIDL_PROFILE,
	CSIDL_SYSTEMX86, CSIDL_PROGRAM_FILESX86, CSIDL_PROGRAM_FILES_COMMON, CSIDL_PROGRAM_FILES_COMMONX86, CSIDL_COMMON_TEMPLATES,
	CSIDL_COMMON_DOCUMENTS, CSIDL_COMMON_ADMINTOOLS, CSIDL_ADMINTOOLS, CSIDL_CONNECTIONS, CSIDL_COMMON_MUSIC, CSIDL_COMMON_PICTURES,
	CSIDL_COMMON_VIDEO, CSIDL_RESOURCES, CSIDL_RESOURCES_LOCALIZED, CSIDL_COMMON_OEM_LINKS, CSIDL_CDBURN_AREA,
	CSIDL_COMPUTERSNEARME, 0x40, 0x41, 0x42, 0x43, CSIDL_PERSONAL, 0x45, 0x3f };



int CanonicalizeFilenameEx( LPTSTR inFilename, LPTSTR outCanonicalized )
{
	if ( !inFilename || !outCanonicalized )
		return -1;


	wchar_t Filename[MAX_FILENAME_LEN]	= L"";
	wchar_t Temp[MAX_FILENAME_LEN]		= L"";

	wchar_t *sep1 = NULL;
	unsigned long int csidl = ULONG_MAX;


	if ( ( inFilename[0] == '<' ) && wcschr( inFilename, '>' ) ) {
		wchar_t temp[SHORT_BUF_LEN] = L"";
		int j = 0;
		wchar_t ch = '\0';

		for ( int i = 1; inFilename[i]; i++ ) {
			ch = inFilename[i];
			if ( ch == '>' )
				break;

			if ( j < ( SHORT_BUF_LEN - 1 ) ) {
				temp[j++] = towupper( ch );
				temp[j] = '\0';
			}
		}

		if ( temp[0] ) {
			if ( iswdigit( temp[0] ) ) {
				if ( ( temp[0] == '0' ) && ( towupper( temp[1] ) == 'X' ) && iswxdigit( temp[2] ) )
					csidl = wcstoul( temp + 2, &sep1, 16 );
				else
					csidl = wcstoul( temp, &sep1, 10 );

				if ( *sep1 || ( csidl >= 0x100 ) )
					csidl = ULONG_MAX;
			}
			else {
				LPTSTR str = temp;
				if ( !wcsncmp( temp, L"CSIDL_", 6 ) && temp[6] )
					str += 6;

				for ( int i = 0; i < NUM_CSIDL_NAMES; i++ ) {
					if ( !wcscmp( str, CSIDLNames[i] ) )
						csidl = CSIDLValues[i];
					else if ( !_wcsicmp( temp, CSIDLFancyNames[i] ) )
						csidl = CSIDLValues[i];
				}
			}

			if ( csidl != ULONG_MAX ) {
				Filename[0] = '\0';
				SHGetFolderPath( NULL, csidl, NULL, SHGFP_TYPE_CURRENT, Filename );

				if ( Filename[0] ) {
					wchar_t *remainder = wcschr( inFilename, '>' ) + 1;

					if ( ( Filename[(int) wcslen( Filename ) - 1] != '/' ) && ( Filename[(int) wcslen( Filename ) -1] != '\\' ) && ( *remainder != '/' ) && ( *remainder != '//' ) )
						wcscat_s( Filename, MAX_FILENAME_LEN, L"\\" );

					wcscat_s( Filename, MAX_FILENAME_LEN, remainder );
				}
			}
		}
	}
	else if ( ( inFilename[0] == '~' ) && ( ( inFilename[1] == '\\' ) || ( inFilename[1] == '/' ) || ( inFilename[1] == '\0' ) ) ) {
		Filename[0] = '\0';
		SHGetFolderPath( NULL, CSIDL_PROFILE, NULL, SHGFP_TYPE_CURRENT, Filename );

		if ( inFilename[1] )
			wcscat_s( Filename, MAX_FILENAME_LEN, inFilename + 1 );
	}


	if ( Filename[0] == '\0' )
		wcscpy_s( Filename, MAX_FILENAME_LEN, inFilename );

	ReplaceChar( Filename, '/', '\\' );			//	SlashesToBackslashes( Filename );

	if ( Filename[0] )
		QueryTrueName( Filename, outCanonicalized );

	//  Printf(  L"   * CanonicalizeFilenameEx( \"%s\" ) -> \"%s\"\r\n", inFilename, outCanonicalized );
	return 0;
}


#endif	//	CANONICALIZE_SPECIAL_VERSION
