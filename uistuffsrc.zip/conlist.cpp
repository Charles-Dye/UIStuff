
//		Stuff for paging and highlighting console output:


#ifndef C_CONLIST
#define C_CONLIST					1.0.10.6


#ifndef _INC_CONIO
#include <conio.h>
#endif


#ifndef MACRO_STR
#define MACRO_EXP( arg )			#arg
#define MACRO_STR( arg )			MACRO_EXP( arg )
#endif

#define C_CONLIST_VER_STRING		MACRO_STR( C_CONLIST )


#ifndef USER_ABORT
#define USER_ABORT					-3
#endif

#ifndef FORCE_USER_ABORT
#define FORCE_USER_ABORT			0x800003
#endif

#ifndef LF
#define LF							0x0a
#endif

#ifndef CR
#define CR							0x0d
#endif




unsigned int CL_PauseLines			= 0;
unsigned int CL_PauseCount			= 0;
unsigned int CL_PauseTime			= 0;
unsigned int CL_AbortFlag			= 0;
unsigned int CL_GetKeyAbortFlag		= 0;


const wchar_t CL_PauseText[]		= L"\r   \u2500\u2500 Press a key to continue \u2500\u2500 ";
const wchar_t CL_UnpauseText[]		= L"\r                                                            \r";

BYTE CL_FirstColor[16]				= { 0x0f, 0x1f, 0x2f, 0x3f, 0x4f, 0x5f, 0x6f, 0x70, 0x8f, 0x9f, 0xa0, 0xb0, 0xcf, 0xd0, 0xe0, 0xf2 };
BYTE CL_SecondColor[16]				= { 0x0e, 0x1b, 0x2b, 0x3e, 0x4b, 0x5b, 0x6b, 0x79, 0x8b, 0x9b, 0xa9, 0xb9, 0xc0, 0xde, 0xec, 0xf0 };
BYTE CL_ThirdColor[16]				= { 0x0b, 0x16, 0x20, 0x30, 0x40, 0x50, 0x60, 0x74, 0x80, 0x90, 0xaf, 0xbf, 0xcd, 0xd6, 0xe4, 0xf4 };

BYTE CL_Normal						= 0;
BYTE CL_Highlight					= 0;
BYTE CL_Highlight2					= 0;
BYTE CL_Reverse						= 0;
BYTE CL_ReverseHighlight			= 0;
BYTE CL_ReverseHighlight2			= 0;





int CL_ConsoleHandle( HANDLE inHandle ) {
	if ( !inHandle )
		return 0;

	if ( ( inHandle == (HANDLE) STD_INPUT_HANDLE ) || ( inHandle == (HANDLE) STD_OUTPUT_HANDLE ) || ( inHandle == (HANDLE) STD_ERROR_HANDLE ) )
		inHandle = GetStdHandle( (DWORD) inHandle );

	DWORD Mode = UINT_MAX;
	int rv = GetConsoleMode( inHandle, &Mode );

	if ( ( rv == 0 ) || ( Mode == UINT_MAX ) )
		return 0;
	else
		return 1;
}


int CL_ConsoleHandle( DWORD inHandle )
{
	return CL_ConsoleHandle( (HANDLE) inHandle );
}



WORD CL_HighlightAttr()
{
	HANDLE ConsoleHandle		= NULL;
	CONSOLE_SCREEN_BUFFER_INFO ConsoleInfo;
	WORD rv						= 0;
	int fg = 0, bg = 0;
	WORD hl						= 0;


	ConsoleHandle = CreateFile( L"conout$", GENERIC_READ | GENERIC_WRITE, FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL );
	if ( ConsoleHandle == INVALID_HANDLE_VALUE )
		return 0x0007;

	memset( &ConsoleInfo, 0x00, sizeof( CONSOLE_SCREEN_BUFFER_INFO ) );
	GetConsoleScreenBufferInfo( ConsoleHandle, &ConsoleInfo );
	rv = ConsoleInfo.wAttributes;

	fg = ( rv & 0x0f );
	bg = ( rv & 0xf0 ) >> 4;

	if ( fg == CL_SecondColor[bg] )
		hl = CL_FirstColor[bg];
	else
		hl = CL_SecondColor[bg];

	SetConsoleTextAttribute( ConsoleHandle, hl );
	CloseHandle( ConsoleHandle );
	return rv;
}



int CL_RestoreAttr( WORD Attr )
{
	HANDLE ConsoleHandle		= NULL;


	ConsoleHandle = CreateFile( L"conout$", GENERIC_READ | GENERIC_WRITE, FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL );
	if ( ConsoleHandle == INVALID_HANDLE_VALUE )
		return 1;

	SetConsoleTextAttribute( ConsoleHandle, Attr );
	CloseHandle( ConsoleHandle );
	return 0;
}



int CL_ShowCtrlBreak()
{
	WORD Attr		= CL_HighlightAttr();


	_cputws( L"\r ^C \r\n" );
	CL_RestoreAttr( Attr );
	return USER_ABORT;
}



BYTE CL_PickHighlightColor( BOOL Disable )
{
	CL_Normal				= 0;
	CL_Highlight			= 0;
	CL_Highlight2			= 0;
	CL_Reverse				= 0;
	CL_ReverseHighlight		= 0;
	CL_ReverseHighlight2	= 0;


	if ( Disable || !CL_ConsoleHandle( STD_OUTPUT_HANDLE ) )
		return 0;


	wchar_t temp[SHORT_BUF_LEN]			= L"";

	int fg = 0, bg = 0;
	unsigned int Normal = 0, Inverse = 0;
	int efg = -1, ebg = -1;


	GetAttribute( &Normal, &Inverse );
	fg = Normal & 0x0f;
	bg = ( Normal & 0xf0 ) >> 4;

	if ( fg == bg )
		return 0;


	GetEnvironmentVariable( L"Highlight", temp, SHORT_BUF_LEN );

	if ( temp[0] ) {

		if ( !_wcsnicmp( temp, L"inv", 3 ) )
			ebg = ( Normal & 0x07 ), efg = bg;
		else if ( !_wcsnicmp( temp, L"0x", 2 ) ) {
			unsigned int t = 0;
			wchar_t *sep1 = NULL;

			_set_errno( 0 );
			t = wcstoul( temp + 2, &sep1, 16 );

			if ( ( errno == 0 ) && ( *sep1 == '\0' ) )
				efg = t & 0x0f, ebg = t >> 4;
		}
		else
			ParseColors( temp, &efg, &ebg );

		if ( ( ebg == 64 ) && ( efg >= 0 ) && ( efg <= 15 ) )		//  kludge:  values 1024 - 1039 treated as 0 - 15,
			ebg = -1;												//    but with default background color.

		if ( ( efg >= 0 ) && ( ebg >= 0 ) ) {
			if ( ( efg != ebg ) && ( ( efg != fg ) || ( ebg != bg ) ) ) {
				CL_Highlight = ( ebg << 4 ) | efg;
				goto Finish;
			}
		}

		if ( ( efg >= 0 ) && ( ebg == -1 ) )
			if ( ( efg != fg ) && ( efg != bg ) ) {
				CL_Highlight = ( bg << 4 ) | efg;
				goto Finish;
			}

		return 0;
	}

	if ( ( ( bg & 0x08 ) == 0 ) && ( ( fg & 0x08 ) == 0 ) && fg ) {
		CL_Highlight = Normal | 0x08;
		goto Finish;
	}

	if ( Normal == CL_FirstColor[bg] )
		CL_Highlight = CL_SecondColor[bg];
	else
		CL_Highlight = CL_FirstColor[bg];


Finish:

	CL_Normal				= Normal;
	CL_Reverse				= ( ( Normal & 0x0f ) << 4 ) | ( ( Normal & 0xf0 ) >> 4 );
	CL_ReverseHighlight		= ( ( CL_Highlight & 0x0f ) << 4 ) | ( ( CL_Highlight & 0xf0 ) >> 4 );

	CL_Highlight2			= CL_FirstColor[bg];

	if ( ( CL_Highlight2 == Normal ) || ( CL_Highlight2 == CL_Highlight ) ) {
		CL_Highlight2 = CL_SecondColor[bg];

		if ( ( CL_Highlight2 == Normal ) || ( CL_Highlight2 == CL_Highlight ) )
			CL_Highlight2 = CL_ThirdColor[bg];
	}

	CL_ReverseHighlight2	= ( ( CL_Highlight2 & 0x0f ) << 4 ) | ( ( CL_Highlight2 & 0xf0 ) >> 4 );

	return CL_Highlight;
}



BOOL WINAPI GetKey2$( DWORD CtrlType )
{
	if ( ( CtrlType == CTRL_C_EVENT ) || ( CtrlType == CTRL_BREAK_EVENT ) ) {
		CL_GetKeyAbortFlag++;
		return TRUE;
	}

	return FALSE;
}



int GetKey2()
{
	DWORD Now			= 0;
	DWORD EndAfter		= 0;
	DWORD EndBefore		= -1;

	int key				= 0;


	if ( CL_PauseTime ) {
		Now			= GetTickCount();
		EndAfter	= Now + CL_PauseTime;

		if ( EndAfter < Now )
			EndBefore	= Now;
	}


	CL_GetKeyAbortFlag = 0;
	SetConsoleCtrlHandler( GetKey2$, TRUE );


	while ( !_kbhit() ) {
		Sleep( 10 );

		if ( CL_GetKeyAbortFlag ) {
			key = 0x03;
			goto Exit;
		}

		if ( CL_PauseTime ) {
			Now = GetTickCount();
			if ( ( Now >= EndAfter ) && ( ( EndBefore == -1 ) || ( Now < EndBefore ) ) ) {
				key = 0x20;
				goto Exit;
			}
		}
	}

	key = _getwch();
	if ( ( key == 0 ) || ( key == 0xe0 ) )
		key = _getwch() | 0x10000;

Exit :

	SetConsoleCtrlHandler( GetKey2$, FALSE );
	return key;
}



int CL_EndLine()
{
	int key		= 0;
	int rv		= 0;


	if ( CL_Normal )
		SetConsoleTextAttribute( GetStdHandle( STD_OUTPUT_HANDLE ), CL_Normal );

	CrLf();

	if ( CL_AbortFlag == FORCE_USER_ABORT )
		return CL_ShowCtrlBreak();

	if ( CL_PauseCount ) {
		CL_PauseCount--;
		if ( CL_PauseCount == 0 ) {
			CL_PauseCount = CL_PauseLines;
			_cputws( CL_PauseText );

			key = GetKey2();

			_cputws( CL_UnpauseText );

			//	_cwprintf( L"\r\n   key = 0x%02X\r\n", key );

			if ( ( key == 'c' ) || ( key == 'C' ) || ( key == 'a' ) || ( key == 'A' ) )
				CL_PauseLines = CL_PauseCount = 0;
			else if ( key == '/' )
				CL_PauseCount = ( CL_PauseLines / 2 );
			else if ( ( key >= '1' ) && ( key <= '9' ) )
				CL_PauseCount = key - '1' + 1;
			else if ( key == '0' )
				CL_PauseCount = 10;
			else if ( ( key == 0x03 ) || ( key == 0x1b ) )
				CL_AbortFlag = rv = USER_ABORT;

			if ( key == 0x03 )
				CL_ShowCtrlBreak();
		}
	}

	return rv;
}



int CL_EndLine( unsigned int n )
{
	for ( unsigned int i = 0; i < n; i++ )
		if ( CL_EndLine() == USER_ABORT )
			return USER_ABORT;

	return 0;
}



int CL_HasSurrogates( LPTSTR String )
{
	if ( !String )
		return -1;

	int k = 0;
	wchar_t *ch		= String;


	while ( *ch ) {
		if ( ( *ch >= 0xd800 ) && ( *ch <= 0xdfff ) )
			k++;

		ch++;
	}

	return k;
}



int HLputs2( LPTSTR String, BYTE Attr, BYTE crlf )
{
	HANDLE StdoutHandle		= GetStdHandle( STD_OUTPUT_HANDLE );


	if ( CL_Normal ) {
		SetConsoleTextAttribute( StdoutHandle, Attr );
		_cputws( String );

		if ( CL_HasSurrogates( String ) )
			_cputws( L" \b" );

		SetConsoleTextAttribute( StdoutHandle, CL_Normal );
		SetColors( CL_Normal );
	}
	else
		QPuts( String );

	if ( crlf )
		return CL_EndLine( crlf );

	return 0;
}



int HLputs( LPTSTR String, BYTE crlf = 0 )
{
	return HLputs2( String, CL_Highlight, crlf );
}



int HLprintf2( LPTSTR Format, va_list Args )
{
	if ( !Format )
		return -1;
	else if ( Format[0] == '\0' )
		return 0;


	LPTSTR Text				= NULL;
	LPTSTR OutBuf			= NULL;
	size_t TextSize			= 0;
	size_t j				= 0;

	int rv					= 0;


	TextSize = _vscwprintf( Format, Args ) + 16;
	Text	= (LPTSTR) malloc( TextSize * sizeof( wchar_t ) );
	OutBuf	= (LPTSTR) malloc( TextSize * sizeof( wchar_t ) );

	if ( !Text || !OutBuf ) {
		free( Text );
		free( OutBuf );
		return -2;
	}


	vswprintf( Text, TextSize, Format, Args );

	j = 0;
	OutBuf[j] = '\0';


	for ( wchar_t *ch = Text; *ch; ch++ ) {

		switch ( *ch ) {

		case CR :
		case 0x11 :
		case 0x12 :
		case 0x13 :
		case 0x14 :
		case 0x15 :
		case 0x16 :

			break;

		case LF :

			if ( j )
				QPuts( OutBuf );

			if ( CL_EndLine() == USER_ABORT ) {
				rv = USER_ABORT;
				goto Abort;
			}

			j = 0;
			OutBuf[j] = '\0';
			break;

		default :
			OutBuf[j++] = *ch;
			OutBuf[j] = '\0';
		}
	}
	
	if ( j ) {
		QPuts( OutBuf );
		j = 0;
		OutBuf[0] = '\0';
	}


Abort:

	free( Text );
	free( OutBuf );
	return rv;
}



int ColorPuts( BYTE Color, LPTSTR String )
{
	if ( !String )
		return -1;


	SetConsoleTextAttribute( GetStdHandle( STD_OUTPUT_HANDLE ), Color );
	_cputws( String );
	return 0;
}



int HLprintf( LPTSTR Format, ... )
{
	if ( !Format )
		return -1;
	else if ( Format[0] == '\0' )
		return 0;


	if ( CL_AbortFlag == FORCE_USER_ABORT )
		return CL_ShowCtrlBreak();


	va_list Args;

	HANDLE StdoutHandle		= GetStdHandle( STD_OUTPUT_HANDLE );

	LPTSTR Text			= NULL;
	LPTSTR OutBuf		= NULL;
	int TextSize		= 0;
	size_t j			= 0;

	unsigned int CurrentColor		= CL_Normal;
	int rv				= 0;


	va_start( Args, Format );


	if ( !CL_Normal ) {
		rv = HLprintf2( Format, Args );
		va_end( Args );
		return rv;
	}


	TextSize = _vscwprintf( Format, Args ) + 16;
	Text	= (LPTSTR) malloc( TextSize * sizeof( wchar_t ) );
	OutBuf	= (LPTSTR) malloc( TextSize * sizeof( wchar_t ) );

	if ( !Text || !OutBuf ) {
		va_end( Args );
		free( Text );
		free( OutBuf );
		return -2;
	}

	vswprintf( Text, TextSize, Format, Args );
	va_end( Args );

	j = 0;
	OutBuf[j] = '\0';


	for ( wchar_t *ch = Text; *ch; ch++ ) {

		switch ( *ch ) {

		case CR :

			break;

		case LF :

			if ( j )
				ColorPuts( CurrentColor, OutBuf );

			SetConsoleTextAttribute( StdoutHandle, CL_Normal );
			if ( CL_EndLine() == USER_ABORT ) {
				rv = USER_ABORT;
				goto Abort;
			}

			j = 0;
			OutBuf[j] = '\0';
			CurrentColor = CL_Normal;
			break;

		case 0x11 :

			if ( j && ( CurrentColor != CL_Normal ) ) {
				ColorPuts( CurrentColor, OutBuf );
				j = 0;
				OutBuf[j] = '\0';
			}

			CurrentColor = CL_Normal;
			break;

		case 0x12 :

			if ( j && ( CurrentColor != CL_Highlight ) ) {
				ColorPuts( CurrentColor, OutBuf );
				j = 0;
				OutBuf[j] = '\0';
			}

			CurrentColor = CL_Highlight;
			break;

		case 0x13 :

			if ( j && ( CurrentColor != CL_Reverse ) ) {
				ColorPuts( CurrentColor, OutBuf );
				j = 0;
				OutBuf[j] = '\0';
			}

			CurrentColor = CL_Reverse;
			break;

		case 0x14 :

			if ( j && ( CurrentColor != CL_ReverseHighlight ) ) {
				ColorPuts( CurrentColor, OutBuf );
				j = 0;
				OutBuf[j] = '\0';
			}

			CurrentColor = CL_ReverseHighlight;
			break;

		case 0x15 :

			if ( j && ( CurrentColor != CL_Highlight2 ) ) {
				ColorPuts( CurrentColor, OutBuf );
				j= 0;
				OutBuf[j] = '\0';
			}

			CurrentColor = CL_Highlight2;
			break;

		case 0x16 :

			if ( j && ( CurrentColor != CL_ReverseHighlight2 ) ) {
				ColorPuts( CurrentColor, OutBuf );
				j= 0;
				OutBuf[j] = '\0';
			}

			CurrentColor = CL_ReverseHighlight2;
			break;

		default :
			OutBuf[j++] = *ch;
			OutBuf[j] = '\0';
		}
	}
	
	if ( j ) {
		ColorPuts( CurrentColor, OutBuf );
		j = 0;
		OutBuf[0] = '\0';
	}


Abort:

	if ( CurrentColor != CL_Normal ) {
		SetConsoleTextAttribute( StdoutHandle, CL_Normal );
		SetColors( CL_Normal );
	}

	free( Text );
	free( OutBuf );
	return rv;
}




unsigned int CL_GetConsoleHeight( unsigned int Default = 0 )
{
	CONSOLE_SCREEN_BUFFER_INFO ConsoleInfo;
	unsigned int Height		= 0;


	if ( GetConsoleScreenBufferInfo( GetStdHandle( STD_OUTPUT_HANDLE ), &ConsoleInfo ) )
		Height = ConsoleInfo.srWindow.Bottom - ConsoleInfo.srWindow.Top + 1;

	if ( ( Height < 10 ) || ( Height > 100 ) )
		Height = Default;

	return Height;
}


unsigned int CL_GetConsoleWidth( unsigned int Default = 0 )
{
	CONSOLE_SCREEN_BUFFER_INFO ConsoleInfo;
	unsigned int Width		= 0;


	if ( GetConsoleScreenBufferInfo( GetStdHandle( STD_OUTPUT_HANDLE ), &ConsoleInfo ) )
		Width = ConsoleInfo.srWindow.Right - ConsoleInfo.srWindow.Left + 1;

	if ( ( Width < 22 ) || ( Width > 400 ) )
		Width = Default;

	return Width;
}


unsigned int CL_EraseLine()
{
	unsigned int Width		= 0;


	Width = CL_GetConsoleWidth();

	if ( Width ) {
		_cputws( L"\r" );

		for ( unsigned int i = 0; i < ( Width - 1 ); i++ )
			_cputws( L" " );

		_cputws( L"\b " );
	}

	_cputws( L"\r" );
	return Width;
}


unsigned int CL_NoPausing()
{
	CL_PauseLines		= 0;
	CL_PauseCount		= 0;
	CL_PauseTime		= 0;
	CL_AbortFlag		= 0;
	return 0;
}


unsigned int CL_SetPauseLines( unsigned int Default )
{
	unsigned int ConHeight = CL_GetConsoleHeight();


	if ( !ConHeight )
		CL_PauseLines = 0;
	else if ( ( Default >= 3 ) && ( Default < ConHeight ) )
		CL_PauseLines = Default;
	else	
		CL_PauseLines = ConHeight - 2;

	CL_PauseCount = CL_PauseLines;
	return CL_PauseLines;
}



int CL_Handbrake()
{
	if ( CL_PauseLines )
		return 0;
	else if ( !CL_ConsoleHandle( STD_OUTPUT_HANDLE ) )
		return 0;

	if ( GetKeyState( VK_ESCAPE ) & 0x8000 ) {
		CL_SetPauseLines( UINT_MAX );
		CL_PauseCount = 1;

		while ( GetKeyState( VK_ESCAPE ) & 0x8000 )
			Sleep( 10 );

		EatKeystrokes();
	}
	else if ( GetKeyState( VK_CONTROL ) & 0x8000 )
		Sleep( 65 );

	return 0;
}


int CL_ParsePOption( LPTSTR Option, unsigned int *Pause )
{
	if ( !Option )
		return -1;


	if ( !_wcsicmp( Option, L"/P" ) || !_wcsicmp( Option, L"-P" ) )
		*Pause = -1, CL_PauseTime = 0;
	else if ( !_wcsnicmp( Option, L"/P", 2 ) || !_wcsnicmp( Option, L"-P", 2 ) ) {
		wchar_t *ch = Option + 2;
		*Pause = -1;
		CL_PauseTime = 0;

		if ( IsColonOrEquals( *ch ) )
			ch++;

		if ( iswdigit( *ch ) ) {
			if ( ParseInt( ch, &CL_PauseTime, &ch ) ) {
				_wcsupr_s( Option, MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad pause time: \"%s\"\r\n", Option );
				return 1;
			}

			if ( towupper( *ch ) == 'M' )
				ch++;
			else
				CL_PauseTime *= 1000;
		}

		if ( ( *ch == ',' ) || ( *ch == ';' ) ) {
			ch++;

			if ( iswdigit( *ch ) ) {
				if ( ParseInt( ch, Pause, &ch ) ) {
					_wcsupr_s( Option, MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad pause lines: \"%s\"\r\n", Option );
					return 1;
				}

				if ( *Pause > 1000 ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Pause lines must be 0 - 1000: %u\r\n", *Pause );
					return 1;
				}
			}
		}

		if ( *ch ) {
			_wcsupr_s( Option, MAX_ARG_LEN );
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Syntax error: \"%s\"\r\n", Option );
			return 1;
		}

	}

	return 0;
}



BOOL WINAPI CL_CtrlBreakProc( DWORD CtrlType )
{
	if ( ( CtrlType == CTRL_C_EVENT ) || ( CtrlType == CTRL_BREAK_EVENT ) ) {
		CL_AbortFlag = FORCE_USER_ABORT;
		return TRUE;
	}

	return FALSE;
}



#ifdef	HLTEST_CMD

wchar_t HLTestHelpText[] = L"Demonstrate the HLprintf() routine.\r\n\
\n\
HLTEST /I:n /P string\n\
\n\
\t/I:\tstart integer\n\
\t/P\tpage output\n\
\n\
This command does nothing of any value.\n";



DLLExports int WINAPI hltest( LPTSTR inString )
{
	if ( !inString )
		return 1;



	wchar_t FormatString[SHORT_BUF_LEN]		= L"\x12This is a test:\x11 %d x %d = \x13%d";

	BOOL NoColor			= FALSE;
	unsigned int Pause		= 0;
	unsigned int StartInt	= 0;
	LPTSTR DisplayString	= NULL;


	CL_NoPausing();


	ParseArgs( inString, PARSE_BREAK_SPACES | PARSE_SLASHES_KLUDGE | PARSE_ONE_ARG_KLUDGE );

	
	for ( int i = 0; i < numargs; i++ ) {
		if ( !wcscmp( arg[i], L"/?" ) ) {
			QPuts( (LPTSTR) HLTestHelpText );
			return 0;
		}
		else if ( !_wcsicmp( arg[i], L"/D" ) )
			NoColor = TRUE;
		else if ( !_wcsnicmp( arg[i], L"/I", 2 ) ) {
			int j = 2;
			if ( arg[i][j] == ':' )
				j++;

			if ( ParseInt( arg[i] + j, &StartInt, NULL ) ) {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad integer: \"%s\"\r\n", arg[i] );
				return 1;
			}
		}
		else if ( !_wcsnicmp( arg[i], L"/P", 2 ) ) {
			if ( CL_ParsePOption( arg[i], &Pause ) )
				return 1;
		}
		else if ( arg[i][0] == '/' ) {
			_wcsupr_s( arg[i], MAX_ARG_LEN );
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Unknown option: \"%s\"\r\n", arg[i] );
			return 1;
		}
		else if ( !DisplayString )
			DisplayString = arg[i];
		else {
			_wcsupr_s( arg[i], MAX_ARG_LEN );
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Syntax error: \"%s\"\r\n", arg[i] );
			return 1;
		}
	}



	if ( DisplayString )
		wcscat_s( FormatString, SHORT_BUF_LEN, L"\x11\tDisplayString = \x12%s\r\n" );
	else
		wcscat_s( FormatString, SHORT_BUF_LEN, L"\r\n" );


	if ( Pause )
		CL_SetPauseLines( Pause );

	Highlight = CL_PickHighlightColor( NoColor );



	for ( unsigned int i = StartInt; i <= ( StartInt + 10 ); i++ )
		if ( HLprintf( FormatString, i, 7, i * 7, DisplayString ? DisplayString : L"(null)" ) == USER_ABORT ) return 3;


	return 0;
}

#endif	//	HLTEST_CMD



DLLExports int WINAPI _clver$( LPTSTR outString )
{
	if ( !outString )
		return -1;

	MultiByteToWideChar( CP_ACP, MB_PRECOMPOSED, C_CONLIST_VER_STRING, -1, outString, SHORT_BUF_LEN );
	return 0;
}



#endif	//	C_CONLIST


/*

		1.0.10.3	2021-12-17
					Added a convenience function CL_ShowCtrlBreak() to show the highlighted
					^C string on the console.

		1.0.10.4	2022-02-15
					Added #defines for LF and  CR.

		1.0.10.5	2022-04-01
					Now supports two highlight colors.  Added HLputs2().

		1.0.10.6	2023-04-12
					CL_EndLine() tries to reset console text attributes to CL_Normal.

*/
