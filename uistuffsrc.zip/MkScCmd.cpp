#ifndef MKSC_VER
#define MKSC_VER					1.3.14.3


//			MKSC command, @SCINFO, and related functions and data


#ifndef MACRO_STR
#define MACRO_EXP( arg )			#arg
#define MACRO_STR( arg )			MACRO_EXP( arg )
#endif	//	MACRO_STR


#include <ShlObj.h>
#include <shlwapi.h>
#include <Msi.h>

#include "w3ccolors.cpp"
#define EXPAND_ESCAPES_REAL_BACKSPACE
#include "ExpandEscapes.cpp"
#include "CanonicalizeSpecial.cpp"
#include "conlist.cpp"
#include "sc_hotkeys.cpp"



#define LINK_TYPE_UNKNOWN			0
#define LINK_TYPE_FILENAME			1
#define LINK_TYPE_OBJECT			2
#define LINK_TYPE_DARWIN			3
#define LINK_TYPE_PIF				128

#define NUM_GUID_NAMES				6
#define MAX_GUID_NAME_LEN			41
#define MAX_GUID_VALUE_LEN			39

#define NUM_HCP_NAMES				10
#define MAX_HCP_NAME_LEN			40
#define MAX_HCP_VALUE_LEN			125

#define SCINFO_NO_QUOTES			0x0100
#define SCINFO_ESCAPIFY				0x0200
#define SCINFO_SAFECHARS			0x0400

#define DUMPSC_TARGET				0x0002
#define DUMPSC_ARGUMENTS			0x0004
#define DUMPSC_DIRECTORY			0x0008
#define DUMPSC_HOTKEY				0x0010
#define DUMPSC_COMMENT				0x0020
#define DUMPSC_START_MODE			0x0040
#define DUMPSC_ICON					0x0080
#define DUMPSC_UAC_LEVEL			0x0100
#define DUMPSC_CONSOLE_BUFFER_INFO	0x0200
#define DUMPSC_CONSOLE_FONT			0x0400
#define DUMPSC_CONSOLE_PALETTE		0x0800
#define DUMPSC_DEFAULT				0x01fe

#define SCREEN_BUFFER_WIDTH_MIN		40
#define SCREEN_BUFFER_WIDTH_MAX		1000
#define SCREEN_BUFFER_HEIGHT_MIN	5
#define SCREEN_BUFFER_HEIGHT_MAX	9999
#define VIEWPORT_HEIGHT_MAX			100
#define FONT_HEIGHT_MIN				6
#define FONT_HEIGHT_MAX				72




const wchar_t MkScHelpText[]	= L"Create, modify, or display a shortcut file.\n\
\n\
MKSC linkfile target /A: /Bx: /C: /D: /F: /I: /J: /K: /M: /N: /P /S /U: /Z \r\n\
\n\
\t/A:\tcommand-line arguments\n\
\t/Bx:\tset console properties; /B? for a list\n\
\t/C:\tdescriptive comment\n\
\t/D:\tstarting directory\n\
\t/F:\tfields to display; /F? for a list\n\
\t/I:\ticon filename\n\
\t/J:\ticon index (0 = first)\n\
\t/K:\tset hotkey\n\
\t/M:\tstart mode: Normal MINimized MAXimized\n\
\t/N:\tdisable features; /N? for a list\n\
\t/P\tpage output (display mode only)\n\
\t/S \trecurse into subdirectories (display mode only)\n\
\t/U:\tset UAC level: Normal Elevated (Vista and later only) \n\
\t/Z\toverwrite read-only files\n\
\n\
The linkfile is required; it should end in .LNK.  When creating a new\n\
shortcut, target is also required.  All other parameters are optional.\n\
Quote any argument containing spaces or other special characters.\n";


const wchar_t MkSc_OptBHelpText[]	= L"\nMKSC /Bx: sets various console properties:\n\
\n\
\t/BA:n\t\tauto position:  0 disable, 1 enable\n\
\t/BB:n\t\tconsole font weight:  400 normal, 700 bold\n\
\t/BC:n\t\tcursor size:  10 small, 100 large\n\
\t/BD:n\t\tdefault colors, e.g. 0x07 = white on black\n\
\t/BF:name\tconsole font name\n\
\t/BG:x,y\t\tconsole font size, width \u00d7 height\n\
\t/BHn:color\tconsole palette; n: 0 to 15, color: W3C name\n\
\t/BI:n\t\tinsert mode:  0 overtype, 1 insert\n\
\t/BO:x,y\t\twindow position; implies /BA:0\n\
\t/BP:n\t\tpopup colors, e.g. 0xF5 = magenta on bright white\n\
\t/BQ:n\t\tQuickEdit mode:  0 disable, 1 enable\n\
\t/BS:x,y\t\tconsole scrollback buffer size, width \u00d7 height\n";


const wchar_t MkSc_OptFHelpText[]	= L"\nMKSC /F: selects fields to display:\n\
\n\
\tT\tthe link target\n\
\tA\tcommand-line arguments\n\
\tD\tstartup directory\n\
\tK\thotkey\n\
\tC\tcomment\n\
\tM\tstart mode\n\
\tI\ticon filename and index\n\
\tU\tUAC level\n\
\tN\tnormal (default) fields; short for TADKCMIU\n\
\tB\tconsole screen buffer info\n\
\tF\tconsole font info\n\
\tH\tthe console palette\n";


const wchar_t MkSc_OptNHelpText[]	= L"\nMKSC /N: disables features:\n\
\n\
\tC\tdisable highlight (display mode only)\n\
\tD\tdo not canonicalize the /D directory\n\
\tE\tsuppress many error messages (display mode only)\n\
\tH\tdo not search into hidden subdirectories (with /S)\n\
\tI\tdo not canonicalize the /I icon filename\n\
\tJ\tdo not search into junctions (with /S)\n\
\tT\tdo not canonicalize the target filename\n\
\tZ\tdo not search into system subdirectories (with /S)\n";


#ifdef MKSC_VARS_HELP

const wchar_t F_ScInfoHelpText[]	= L"Returns values from a shortcut file.\n\
\n\
@SCINFO[file,info]\n\
\n\
\tfile\tthe file to examine\n\
\tinfo\twhich field to return:\n\
\t\t    0 - target filename or object name (default)  \n\
\t\t    1 - command-line arguments\n\
\t\t    2 - working directory\n\
\t\t    3 - comment\n\
\t\t    4 - hotkey\n\
\t\t    5 - startup window mode\n\
\t\t    6 - icon filename\n\
\t\t    7 - icon index\n\
\t\t    8 - UAC level\n\
\n\
Add 256 to not quote the return string, or 512 to escapify it. \n";

#endif	//	MKSC_VARS_HELP


wchar_t GuidNames[NUM_GUID_NAMES][MAX_GUID_NAME_LEN] = {
	L"Search", L"Help and Support", L"Run...", L"E-mail",
	L"Set Program Access and Defaults", L"Set Program Access and Computer Defaults" };

wchar_t GuidValue[NUM_GUID_NAMES][MAX_GUID_VALUE_LEN] = {
	L"{2559a1f0-21d7-11d4-bdaf-00c04f60b9f0}",
	L"{2559a1f1-21d7-11d4-bdaf-00c04f60b9f0}",
	L"{2559a1f3-21d7-11d4-bdaf-00c04f60b9f0}",
	L"{2559a1f5-21d7-11d4-bdaf-00c04f60b9f0}",
	L"{2559a1f7-21d7-11d4-bdaf-00c04f60b9f0}",
	L"{2559a1f7-21d7-11d4-bdaf-00c04f60b9f0}" };

wchar_t HCPNames[NUM_HCP_NAMES][MAX_HCP_NAME_LEN] = { L"Help and Support Home Page", L"Remote Assistance - Options",
	L"Remote Assistance", L"Advanced System Information", L"My Computer Information", L"Network Diagnostics",
	L"Start Application in Compatibility Mode", L"Program Compatibility Wizard", L"Windows Newsgroups",
	L"Microsoft System Information" };

wchar_t HCPValue[NUM_HCP_NAMES][MAX_HCP_VALUE_LEN] = { L"hcp://system/HomePage.htm",
	L"hcp://cn=microsoft%20corporation,l=redmond,s=washington,c=us/Remote%20Assistance/Escalation/Common/rcscreen1.htm",
	L"hcp://CN=Microsoft%20Corporation,L=Redmond,S=Washington,C=US/Remote%20Assistance/Escalation/Unsolicited/unsolicitedrcui.htm",
	L"hcp://system/sysinfo/sysInfoLaunch.htm", L"hcp://system/sysinfo/sysinfomain.htm", L"hcp://system/netdiag/dglogs.htm",
	L"hcp://system/compatctr/compatmode.htm", L"hcp://system/compatctr/compatmode.htm", L"hcp://system/blurbs/windows_newsgroups.htm",
	L"hcp://system/sysinfo/msinfo.htm" };


const wchar_t EscCharsVarName[]		= L"CEsc_Chars";

const wchar_t EscFlagsVarName[]		= L"CEsc_Flags";

const wchar_t UnsafeChars[]			= L"\"%&<>[]^`|";

const wchar_t EnabledStr[2][9]		= { L"Disabled", L"Enabled" };



struct _ConsolePropsChanges {
	unsigned int BufferX;
	unsigned int BufferY;
	unsigned int WindowX;
	unsigned int WindowY;
	wchar_t FontName[LF_FACESIZE];
	unsigned int FontWeight;
	unsigned int FontX;
	unsigned int FontY;
	unsigned int CursorSize;
	unsigned int QuickEdit;
	unsigned int InsertMode;
	unsigned int AutoPosition;
	unsigned int FullScreen;
	WORD FillColor;
	WORD PopupColor;
	int OriginX;
	int OriginY;
	BOOL UseOrigin;
	COLORREF ColorTable[16];
};



struct _MKSC_FindFont {
	LPTSTR SearchFor;
	LPTSTR FoundFont;
};



int GetStartModeString( int inMode, LPTSTR outString )
{
	if ( !outString )
		return -1;

	if ( ( inMode < 0 ) | ( inMode > 255 ) )
		return -1;

	switch ( inMode ) {

	case SW_SHOWNORMAL :
		wcscpy_s( outString, SHORT_BUF_LEN, L"Normal" );
		break;

	case SW_SHOWMINNOACTIVE :
		wcscpy_s( outString, SHORT_BUF_LEN, L"Minimized" );
		break;

	case SW_MAXIMIZE :
		wcscpy_s( outString, SHORT_BUF_LEN, L"Maximized" );
		break;

	default:
		swprintf( outString, SHORT_BUF_LEN, L"%u", inMode );
	}

	return 0;
}



const NT_CONSOLE_PROPS MKSC_DefaultConsoleProps = {
	{ sizeof( NT_CONSOLE_PROPS ), NT_CONSOLE_PROPS_SIG },		//	DATABLOCK_HEADER
	0x0007, 0x00f5,												//	fill attribute and popup attribute
	{ 100, 9000 }, { 100, 30 }, { 100, 100 },					//	screen buffer size, window size, window position
	0, 100, { 10, 16 },											//	font index, input buffer size, font size
	TMPF_TRUETYPE | TMPF_VECTOR | FF_MODERN,					//	font pitch and family
	FW_NORMAL, L"Lucida Console", 25,							//	font weight, font name, cursor size
	0, 1, 1, 1,													//	full screen, quickedit, insert, auto position
	50, 4, 0,													//	history buffers size and count, discard duplicates
	{	0x0c0c0c, 0xda3700, 0x0ea113, 0xdd963a, 0x1f0fc5, 0x981788, 0x009cc1, 0xcccccc,
		0x767676, 0xff783b, 0x0cc616, 0xd6d661, 0x5648e7, 0x9e00b4, 0xa5f1f9, 0xf2f2f2 }	//	color table

	/*
	{	0x000000, 0x990000, 0x009900, 0x999900, 0x000099, 0x990099, 0x009999, 0xcccccc,
		0x666666, 0xff0000, 0x00ff00, 0xffff00, 0x0000ff, 0xff00ff, 0x00ffff, 0xffffff }	//	alt. color table - web safe colors
	*/
};



int UpdateConsoleProps( IShellLink *ShellLink, _ConsolePropsChanges *Changes )
{
	if ( !ShellLink || !Changes )
		return -1;


	IShellLinkDataList *DataList		= NULL;
	NT_CONSOLE_PROPS *OldConsoleProps	= NULL;
	NT_CONSOLE_PROPS NewConsoleProps;
	BOOL Delete							= FALSE;
	HRESULT rv							= 0;


	if ( FAILED( ShellLink->QueryInterface( IID_IShellLinkDataList, (void**) &DataList ) ) )
		return 1;

	DataList->CopyDataBlock( NT_CONSOLE_PROPS_SIG, (void**) &OldConsoleProps );

	if ( OldConsoleProps ) {
		memcpy( &NewConsoleProps, OldConsoleProps, sizeof( NT_CONSOLE_PROPS ) );
		LocalFree( OldConsoleProps );
		OldConsoleProps = NULL;
		Delete = TRUE;
	}
	else {
		memcpy( &NewConsoleProps, &MKSC_DefaultConsoleProps, sizeof( NT_CONSOLE_PROPS ) );
		Delete = FALSE;
	}

	if ( Changes->BufferX && Changes->BufferY ) {
		NewConsoleProps.dwScreenBufferSize.X	= Changes->BufferX;
		NewConsoleProps.dwScreenBufferSize.Y	= Changes->BufferY;
	}

	if ( Changes->WindowX && Changes->WindowY ) {
		NewConsoleProps.dwWindowSize.X		= Changes->WindowX;
		NewConsoleProps.dwWindowSize.Y		= Changes->WindowY;
	}
	else if ( Changes->BufferX )
		NewConsoleProps.dwWindowSize.X		= Changes->BufferX;

	if ( NewConsoleProps.dwWindowSize.X > NewConsoleProps.dwScreenBufferSize.X )
		NewConsoleProps.dwWindowSize.X = NewConsoleProps.dwScreenBufferSize.X;

	if ( NewConsoleProps.dwWindowSize.Y > NewConsoleProps.dwScreenBufferSize.Y )
		NewConsoleProps.dwWindowSize.Y = NewConsoleProps.dwScreenBufferSize.Y;
	

	if ( Changes->FontName[0] ) {
		wcscpy_s( NewConsoleProps.FaceName, LF_FACESIZE, Changes->FontName );

		if ( !_wcsicmp( Changes->FontName, L"Raster Fonts" ) || !_wcsicmp( Changes->FontName, L"Terminal" ) ) {
			NewConsoleProps.nFont = 0;
			NewConsoleProps.uFontFamily = FF_MODERN;

			if ( Changes->FontY == 0 ) {
				Changes->FontX = 10;
				Changes->FontY = 18;
			}
		}
		else {
			NewConsoleProps.nFont = 0;
			NewConsoleProps.uFontFamily = TMPF_TRUETYPE | TMPF_VECTOR | FF_MODERN;

			if ( Changes->FontY == 0 ) {
				Changes->FontX = 10;
				Changes->FontY = 16;
			}
		}
	}

	if ( Changes->FontWeight )
		NewConsoleProps.uFontWeight = Changes->FontWeight;

	if ( Changes->FontY ) {
		NewConsoleProps.dwFontSize.X = Changes->FontX;
		NewConsoleProps.dwFontSize.Y = Changes->FontY;
	}

	if ( Changes->CursorSize && ( Changes->CursorSize <= 100 ) )
		NewConsoleProps.uCursorSize = Changes->CursorSize;

	if ( Changes->QuickEdit )
		NewConsoleProps.bQuickEdit = Changes->QuickEdit & 1;

	if ( Changes->InsertMode )
		NewConsoleProps.bInsertMode = Changes->InsertMode & 1;

	if ( Changes->AutoPosition )
		NewConsoleProps.bAutoPosition = Changes->AutoPosition & 1;

	if ( Changes->FullScreen )
		NewConsoleProps.bFullScreen = Changes->FullScreen & 1;

	if ( ( ( Changes->FillColor & 0x00f0 ) >> 4 ) != ( Changes->FillColor & 0x000f ) )
		NewConsoleProps.wFillAttribute = Changes->FillColor;

	if ( ( ( Changes->PopupColor & 0x00f0 ) >> 4 ) != ( Changes->PopupColor & 0x000f ) )
		NewConsoleProps.wPopupFillAttribute = Changes->PopupColor;

	if ( Changes->UseOrigin ) {
		NewConsoleProps.dwWindowOrigin.X = Changes->OriginX;
		NewConsoleProps.dwWindowOrigin.Y = Changes->OriginY;
	}

	for ( unsigned int i = 0; i < 16; i++ )
		if ( Changes->ColorTable[i] )
			NewConsoleProps.ColorTable[i] = Changes->ColorTable[i] & 0x00ffffff;


	if ( Delete )
		DataList->RemoveDataBlock( NT_CONSOLE_PROPS_SIG );

	DataList->AddDataBlock( &NewConsoleProps );
	DataList->Release();
	return 0;
}



int TestGuidNames( LPTSTR inString )
{
	if ( !inString )
		return -1;

	int j = 0, found = -1;

	if ( inString[0] == '&' )
		if ( iswalpha( inString[1] ) )
			j++;

	for ( int i = 0; i < NUM_GUID_NAMES; i++ )
		if ( !_wcsicmp( inString + j, GuidNames[i] ) )
			found = i;

	if ( found != -1 ) {
		wcscpy_s( inString, MAX_FILENAME_LEN, L"shell:::" );
		wcscat_s( inString, MAX_FILENAME_LEN, GuidValue[found] );
		return 0;
	}

	return 1;
}



int TestHCPNames( LPTSTR inString )
{
	if ( !inString )
		return -1;

	for ( int i = 0; i < NUM_HCP_NAMES; i++ )
		if ( !_wcsicmp( inString, HCPNames[i] ) ) {
			wcscpy_s( inString, MAX_FILENAME_LEN, HCPValue[i] );
			return 0;
		}

	return 1;
}



int SearchShellFolderForName( ITEMIDLIST **FolderIDL, LPTSTR Name, ITEMIDLIST **IDList )
{
	if ( !FolderIDL || !Name || !IDList )
		return -1;

	IShellFolder *Desktop	= NULL;
	IShellFolder *Folder	= NULL;

	SHGetDesktopFolder( &Desktop );
	if ( !Desktop )
		return -1;

	Desktop->BindToObject( *FolderIDL, NULL, IID_IShellFolder, (void**) &Folder );
	Desktop->Release();

	if ( !Folder )
		return -1;


	wchar_t DisplayName[SHORT_BUF_LEN]		= L"";

	IEnumIDList *Search			= NULL;
	ITEMIDLIST *FoundItem		= NULL;
	STRRET StrRet;
	HRESULT Result				= 0;


	Folder->EnumObjects( NULL, SHCONTF_FOLDERS | SHCONTF_NONFOLDERS | SHCONTF_INCLUDEHIDDEN, &Search );

	if ( Search ) {
		Result = Search->Next( 1, &FoundItem, NULL );

		while ( Result != S_FALSE ) {
			if ( Result != NOERROR )
				break;

			memset( &StrRet, 0x00, sizeof( STRRET ) );
			StrRet.uType = STRRET_WSTR;
			Folder->GetDisplayNameOf( FoundItem, SHGDN_NORMAL, &StrRet );

			DisplayName[0] = '\0';
			StrRetToBuf( &StrRet, FoundItem, DisplayName, SHORT_BUF_LEN );

			if ( DisplayName[0] ) {
				if ( !_wcsicmp( DisplayName, Name ) ) {
					*IDList = (ITEMIDLIST*) ILCombine( *FolderIDL, FoundItem );
					Search->Release();
					Folder->Release();
					ILFree( *FolderIDL );
					*FolderIDL = NULL;
					return 0;
				}
			}

			CoTaskMemFree( FoundItem );
			Result = Search->Next( 1, &FoundItem, NULL );
		}

		Search->Release();
		Search = NULL;
	}

	Folder->Release();
	ILFree( *FolderIDL );
	*FolderIDL = NULL;
	return 1;
}



int SearchShellFolderForName( int CSIDL, LPTSTR Name, ITEMIDLIST **IDList )
{
	if ( !Name || !IDList )
		return -1;


	ITEMIDLIST *FolderIDL	= NULL;


	SHGetFolderLocation( NULL, CSIDL, NULL, 0, &FolderIDL );

	if ( !FolderIDL )
		return -1;

	return SearchShellFolderForName( &FolderIDL, Name, IDList );
}



int SearchShellFolderForName( LPTSTR Guid, LPTSTR Name, ITEMIDLIST **IDList )
{
	if ( !Guid || !Name || !IDList )
		return -1;

	ITEMIDLIST *FolderIDL	= NULL;
	IShellFolder *Desktop	= NULL;

	SHGetDesktopFolder( &Desktop );
	if ( !Desktop )
		return -1;

	Desktop->ParseDisplayName( NULL, NULL, Guid, NULL, &FolderIDL, NULL );
	Desktop->Release();
	if ( !FolderIDL )
		return -1;

	return SearchShellFolderForName( &FolderIDL, Name, IDList );
}



int SearchCSIDLsForName( LPTSTR Name, ITEMIDLIST **IDList )
{
	if ( !Name || !IDList )
		return -1;

	SHFILEINFO TestFileInfo;
	ITEMIDLIST *TestList = NULL;

	for ( int i = 0; i < 0x50; i++ ) {
		TestList = NULL;
		TestFileInfo.szDisplayName[0] = '\0';

		SHGetFolderLocation( NULL, i, NULL, 0, &TestList );

		if ( TestList ) {
			TestFileInfo.szDisplayName[0] = '\0';
			SHGetFileInfo( (LPCTSTR) TestList, 0, &TestFileInfo, sizeof( SHFILEINFO ), SHGFI_DISPLAYNAME | SHGFI_PIDL );

			if ( TestFileInfo.szDisplayName[0] )
				if ( !_wcsicmp( Name, TestFileInfo.szDisplayName ) ) {
					*IDList = TestList;
					return 0;
				}

			ILFree( TestList );
		}
	}

	return 1;
}



int GetIDListFromSymbolicName( LPTSTR Name, ITEMIDLIST **IDList )
{
	if ( !Name || !IDList )
		return -1;


	//  first look in our built-in list of symbolic names :

	for ( int i = 0; i < NUM_CSIDL_NAMES; i++ )
		if ( !_wcsicmp( Name, CSIDLFancyNames[i] ) ) {
			SHGetFolderLocation( NULL, CSIDLValues[i], NULL, 0, IDList );
			return 0;
		}

	if ( !_wcsnicmp( Name, L"CSIDL_", 6 ) )
		if ( Name[6] )
			for ( int i = 0; i < NUM_CSIDL_NAMES; i++ )
				if ( !_wcsicmp( Name + 6, CSIDLNames[i] ) ) {
					SHGetFolderLocation( NULL, CSIDLValues[i], NULL, 0, IDList );
					return 0;
				}


	//  if it's not in the list, try ParseDisplayName() :

	ITEMIDLIST *TestList = NULL;
	IShellFolder *ShellFolder = NULL;
	wchar_t Temp[MAX_FILENAME_LEN] = L"";

	TestGuidNames( Name );		// there are a few more names that we can convert to guids

	if ( ( OSVerInfo.dwMajorVersion == 5 ) && OSVerInfo.dwMinorVersion )	// under windows xp / server 2003,
		TestHCPNames( Name );												// also try some hcp:// pages

	if ( !wcsncmp( Name, L"::{", 3 ) )
		if ( iswxdigit( Name[3] ) && ( Name[ wcslen( Name ) - 1 ] == '}' ) ) {
			wcscpy_s( Temp, MAX_FILENAME_LEN, L"shell:" );
			wcscat_s( Temp, MAX_FILENAME_LEN, Name );
		}

	if ( Temp[0] == '\0' )
		wcscpy_s( Temp, MAX_FILENAME_LEN, Name );


	//	try ParseDisplayName() :

	SHGetDesktopFolder( &ShellFolder );

	if ( ShellFolder ) {
		ShellFolder->ParseDisplayName( NULL, NULL, Temp, NULL, &TestList, NULL );
		ShellFolder->Release();
		ShellFolder = NULL;
	}

	if ( TestList ) {
		*IDList = TestList;
		return 0;
	}
	

	//	try Control Panel :

	if ( SearchShellFolderForName( CSIDL_CONTROLS, Name, IDList ) == 0 )
		return 0;

	//	try Control Panel categories :

	if ( OSVerInfo.dwMajorVersion >= 6 )
		if ( SearchShellFolderForName( L"shell:::{26EE0668-A00A-44D7-9371-BEB064C98683}", Name, IDList ) == 0 )
			return 0;

	//	try Administrative Tools :

	if ( SearchShellFolderForName( CSIDL_COMMON_ADMINTOOLS, Name, IDList ) == 0 )
		return 0;

	if ( SearchShellFolderForName( CSIDL_ADMINTOOLS, Name, IDList ) == 0 )
		return 0;

	//	try Printers :

	if ( SearchShellFolderForName( CSIDL_PRINTERS, Name, IDList ) == 0 )
		return 0;

	//	loop through CSIDLs :

	if ( SearchCSIDLsForName( Name, IDList ) == 0 )
		return 0;

	//	give up in disgust :

	return 1;
}



int CopySansQuotes( LPTSTR Source, LPTSTR Destination, unsigned int MaxLength )
{
	if ( !Source || !Destination )
		return -1;

	unsigned int i = 0, j = 0;

	while ( Source[i] ) {
		if ( ( Source[i] != QUOTE ) && ( j < ( MaxLength - 1 ) ) )
			Destination[j++] = Source[i];

		i++;
	}

	Destination[j] = '\0';
	return 0;
}



int CompareOEMToACP( LPCSTR OEMString, LPCSTR ACPString, int StripQuotes )
{
	if ( !OEMString || !ACPString )
		return -1;

	wchar_t OEMToUnicode[MAX_FILENAME_LEN] = L"";
	wchar_t ACPToUnicode[MAX_FILENAME_LEN] = L"";

	MultiByteToWideChar( CP_OEMCP, MB_PRECOMPOSED, OEMString, -1, OEMToUnicode, MAX_FILENAME_LEN );
	MultiByteToWideChar( CP_ACP,   MB_PRECOMPOSED, ACPString, -1, ACPToUnicode, MAX_FILENAME_LEN );

	unsigned int i = 0, j = 0;
	wchar_t ch = '\0';

	if ( StripQuotes & 1 ) {
		i = j = 0;
		do {
			ch = OEMToUnicode[i++];

			if ( ch != QUOTE )
				if ( j < ( MAX_FILENAME_LEN - 1 ) )
					OEMToUnicode[j++] = ch;

		} while ( ch );

		OEMToUnicode[j] = '\0';
	}

	if ( StripQuotes & 2 ) {
		i = j = 0;
		do {
			ch = ACPToUnicode[i++];

			if ( ch != QUOTE )
				if ( j < ( MAX_FILENAME_LEN - 1 ) )
					ACPToUnicode[j++] = ch;

		} while ( ch );

		ACPToUnicode[j] = '\0';
	}

	return wcscmp( OEMToUnicode, ACPToUnicode );
}



LPTSTR MKSC_FindListSep( LPTSTR String )
{
	if ( !String )
		return 0;


	wchar_t *ch = String;

	while ( *ch ) {
		if ( ( *ch == ',' ) || ( *ch == ';' ) )
			return ch;

		ch++;
	}

	return NULL;
}


int DarwinStrToGuidStr( LPTSTR inDarwin, LPTSTR outGuid )
{
	//			https://community.broadcom.com/symantecenterprise/viewdocument/working-with-darwin-descriptors

	if ( !inDarwin || !outGuid )
		return -1;


	const wchar_t DarwinB85[]	= L"!$%&'()*+,-.0123456789=?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^_`abcdefghijklmnopqrstuvwxyz{}~";

	DWORD Guid[4];
	BYTE *GuidB			= (BYTE*) Guid;
	unsigned __int64 t	= 0;
	wchar_t ch			= 0;


	if ( wcslen( inDarwin ) < 20 )
		return 10;

	for ( unsigned int i = 0; i < 20; i++ )
		if ( !wcschr( DarwinB85, inDarwin[i] ) )
			return 11;

	for ( int i = 0; i < 4; i++ ) {
		t = 0;

		for ( int j = 4; j >= 0; j-- ) {
			ch = inDarwin[( 5 * i ) + j];
			t = ( t * 85 ) + ( wcschr( DarwinB85, ch ) - DarwinB85 );
		}

		if ( t >= 0x100000000 )
			return 12;

		Guid[i] = (DWORD) t;
	}

	wsprintf( outGuid, L"{%08X-%04X-%04X-%02X%02X-%02X%02X%02X%02X%02X%02X}", Guid[0], LOWORD( Guid[1] ), HIWORD( Guid[1] ), GuidB[8], GuidB[9], GuidB[10], GuidB[11], GuidB[12], GuidB[13], GuidB[14], GuidB[15] );
	return 0;
}



/*
		The font name in the console properties block must match exactly, including case,
		but chances are the user won't type it that way.  This routine enumerates fonts and
		looks for a font with a matching name, case-insensitively.  If a matching font is
		found, it returns the the font name in its correct case.  If no matching font is
		found, well, tough noogies; not much I can do about that.
*/


int CALLBACK MKSC_EnumFontsProc( const LOGFONT *LogFont, const TEXTMETRIC *TextMetric, DWORD FontType, LPARAM FindFont )
{
	_MKSC_FindFont *Data		= (_MKSC_FindFont*) FindFont;

	
	if ( _wcsicmp( Data->SearchFor, LogFont->lfFaceName ) )
		return 1;
	
	wcscpy_s( Data->FoundFont, LF_FACESIZE, LogFont->lfFaceName );
	return 0;
}



int CorrectFontName( LPTSTR inFont, LPTSTR outFont )
{
	if ( !inFont || !outFont )
		return -1;
	else if ( inFont[0] == '\0' )
		return -1;


	wchar_t Found[SHORT_BUF_LEN]		= L"";

	HDC hdc				= NULL;
	LOGFONT LogFont;
	_MKSC_FindFont FindFont;


	wcscpy_s( outFont, LF_FACESIZE, inFont );

	hdc = GetDC( NULL );
	if ( !hdc )
		return 2;


	memset( &LogFont, 0x00, sizeof( LOGFONT ) );
	LogFont.lfCharSet		= DEFAULT_CHARSET;

	FindFont.SearchFor		= inFont;
	FindFont.FoundFont		= Found;

	EnumFontFamiliesEx( hdc, &LogFont, MKSC_EnumFontsProc, (LPARAM) &FindFont, 0 );
	ReleaseDC( NULL, hdc );

	if ( Found[0] ) {
		wcscpy_s( outFont, LF_FACESIZE, Found );
		return 0;
	}

	return 1;
}



DWORD RgbToBgr( DWORD Color )
{
	return ( ( ( Color & 0x0000ff ) << 16 ) | ( Color & 0x00ff00 ) | ( ( Color & 0xff0000 ) >> 16 ) );
}



int GetPIFFileParams( LPTSTR Filename, LPTSTR Target, LPTSTR Arguments, LPTSTR Comment, LPTSTR Directory, LPTSTR IconFile, int *IconIndex, LPTSTR Hotkey, LPTSTR StartMode, LPTSTR UACMode, unsigned int *LinkType )
{
	if ( !Filename )
		return -1;
	else if ( Filename[0] == '\0' )
		return -1;

	const int PIFBufferSize		= 0x1800;
	const int PIFSigOffset		= 0x0171;
	const char PIFSignature[]	= "MICROSOFT PIFEX";
	const int HeaderLen			= 0x0016;

	BYTE Buffer[PIFBufferSize];
	memset( Buffer, 0x00, PIFBufferSize );

	HANDLE FileHandle = NULL;
	DWORD BytesRead = 0;
	int rv = 0;
	int offset = 0x0187;
	int SectionWin386 = 0, SectionVMM40 = 0, SectionNT40 = 0;

	int StartModeValue = 0;


	if ( LinkType )
		*LinkType = LINK_TYPE_UNKNOWN;


	FileHandle = CreateFile( Filename, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL );
	if ( FileHandle == INVALID_HANDLE_VALUE )
		return -2;

	rv = ReadFile( FileHandle, Buffer, PIFBufferSize, &BytesRead, NULL );
	CloseHandle( FileHandle );

	if ( rv == 0 )
		return -2;

	if ( BytesRead < 0x0188 )
		return -2;

	if ( strcmp( (LPCSTR) Buffer + PIFSigOffset, PIFSignature ) )
		return -2;


	while ( ( offset + 0x0022 ) < (int) BytesRead ) {

		if ( !strcmp( (LPCSTR) ( Buffer + offset ), "WINDOWS NT  4.0" ) )
			SectionNT40 = offset + HeaderLen;
		else if ( !strcmp( (LPCSTR) ( Buffer + offset ), "WINDOWS 386 3.0" ) )
			SectionWin386 = offset + HeaderLen;
		else if ( !strcmp( (LPCSTR) ( Buffer + offset ), "WINDOWS VMM 4.0" ) )
			SectionVMM40 = offset + HeaderLen;

		offset = Buffer[offset + 0x10] | ( Buffer[offset + 0x11] << 8 );
	}


	//		Make Title field null-terminated and remove right-padding:

	Buffer[0x20] = '\0';
	int i = 29;
	while ( ( i >= 0 ) && iswspace( Buffer[0x02 + i] ) )
		Buffer[0x02 + i--] = '\0';

	Comment[0]		= '\0';
	Directory[0]	= '\0';
	IconFile[0]		= '\0';
	*IconIndex		= 0;

	if ( SectionNT40 ) {

		//		Get Target and Arguments:

		if ( Buffer[SectionNT40 + 0x04] || Buffer[SectionNT40 + 0x05] ) {
			Target[0] = '\0';
			Arguments[0] = '\0';
			BOOL quote = FALSE;
			wchar_t *ch = (wchar_t *) ( Buffer + SectionNT40 + 04 );
			int j = 0;

			while ( *ch ) {
				if ( *ch == QUOTE ) {
					quote = !quote;
					ch++;
					continue;
				}

				if ( iswspace( *ch ) && !quote ) {

					while ( iswspace( *ch ) )
						ch++;

					j = 0;

					while ( *ch ) {
						if ( j < ( MAX_ARG_LEN - 1 ) ) {
							Arguments[j++] = *ch;
							Arguments[j] = '\0';
						}
						ch++;
					}
					break;
				}

				if ( j < ( MAX_ARG_LEN - 1 ) ) {
					Target[j++] = *ch;
					Target[j] = '\0';
				}
				ch++;
			}

			if ( ( Arguments[0] == '\0' ) && Buffer[0xa5] )
				MultiByteToWideChar( CP_OEMCP, MB_PRECOMPOSED, (LPCSTR) Buffer + 0xa5, -1, Arguments, MAX_ARG_LEN );
		}
		else {
			MultiByteToWideChar( CP_OEMCP, MB_PRECOMPOSED, (LPCSTR) Buffer + 0x24, -1, Target, MAX_ARG_LEN );
			MultiByteToWideChar( CP_OEMCP, MB_PRECOMPOSED, (LPCSTR) Buffer + 0xa5, -1, Arguments, MAX_ARG_LEN );
		}

		//		Get Comment:

		if ( Buffer[SectionNT40 + 0x03a0] )
			if ( CompareOEMToACP( (LPCSTR) ( Buffer + 0x02 ), (LPCSTR) ( Buffer + SectionNT40 + 0x03a0 ), 0 ) == 0 )
				wcscpy_s( Comment, MAX_ARG_LEN, (LPTSTR) ( Buffer + SectionNT40 + 0x0364 ) );

		//		Get working Directory:

		if ( Buffer[SectionNT40 + 0x052e] )
			if ( CompareOEMToACP( (LPCSTR) ( Buffer + 0x65 ), (LPCSTR) ( Buffer + SectionNT40 + 0x052e ), 2 ) == 0 )
				CopySansQuotes( (LPTSTR) ( Buffer + SectionNT40 + 0x04ae ), Directory, MAX_FILENAME_LEN );

		//		Get IconFile:

		if ( Buffer[SectionNT40 + 0x03be] || Buffer[SectionNT40 + 0x03ec] )
			CopySansQuotes( (LPTSTR) ( Buffer + SectionNT40 + 0x03be ), IconFile, MAX_FILENAME_LEN );
		else if ( SectionVMM40 )
			if ( Buffer[SectionVMM40 + 0x58] )
				MultiByteToWideChar( CP_ACP, MB_PRECOMPOSED, (LPCSTR) ( Buffer + 0x58 ), -1, IconFile, MAX_FILENAME_LEN );

	}
	else {
		MultiByteToWideChar( CP_OEMCP, MB_PRECOMPOSED, (LPCSTR) Buffer + 0x24, -1, Target, MAX_ARG_LEN );
		MultiByteToWideChar( CP_OEMCP, MB_PRECOMPOSED, (LPCSTR) Buffer + 0xa5, -1, Arguments, MAX_ARG_LEN );

		if ( SectionVMM40 )
			if ( Buffer[SectionVMM40 + 0x58] )
				MultiByteToWideChar( CP_ACP, MB_PRECOMPOSED, (LPCSTR) ( Buffer + 0x58 ), -1, IconFile, MAX_FILENAME_LEN );
	}


	//		Get Comment:

	if ( Comment[0] == '\0' )
		if ( Buffer[0x02] )
			MultiByteToWideChar( CP_OEMCP, MB_PRECOMPOSED, (LPCSTR) ( Buffer + 0x02 ), -1, Comment, MAX_ARG_LEN );

	//		Get Directory:

	if ( Directory[0] == '\0' )
		MultiByteToWideChar( CP_OEMCP, MB_PRECOMPOSED, (LPCSTR) ( Buffer + 0x65 ), -1, Directory, MAX_FILENAME_LEN );

	//		Get StartMode:

	if ( SectionWin386 )
		StartModeValue = Buffer[SectionWin386 + 0x12];

	if ( StartModeValue & 0x10 )
		wcscpy_s( StartMode, SHORT_BUF_LEN, L"Minimized" );
	else if ( StartModeValue & 0x20 )
		wcscpy_s( StartMode, SHORT_BUF_LEN, L"Maximized" );
	else
		wcscpy_s( StartMode, SHORT_BUF_LEN, L"Normal" );

	//		Get IconIndex:

	if ( SectionVMM40 && IconFile[0] )
		*IconIndex = Buffer[SectionVMM40 + 0xa8];

	//		Get Hotkey:

	int HotkeyValue = 0, Modifier = 0, VKey = 0;

	if ( SectionWin386 ) {
		HotkeyValue = Buffer[SectionWin386 + 0x18] | ( Buffer[SectionWin386 + 0x19] << 8 );
		Modifier = Buffer[SectionWin386 + 0x1a] | ( Buffer[SectionWin386 + 0x1b] << 8 );
		VKey = MapVirtualKeyEx( HotkeyValue, MAPVK_VSC_TO_VK, 0 );
		Modifier = ( Modifier & 0x0e ) << 7;
	}

	GetHotkeyName( VKey | Modifier, Hotkey );

	wcscpy_s( UACMode, SHORT_BUF_LEN, L"Normal" );

	if ( LinkType )
		*LinkType = LINK_TYPE_PIF;

	return 0;
}



int GetLNKFileParams( LPTSTR Filename, LPTSTR Target, LPTSTR Arguments, LPTSTR Comment, LPTSTR Directory, LPTSTR IconFile, int *IconIndex, LPTSTR Hotkey, LPTSTR StartMode, LPTSTR UACLevel, unsigned int *LinkType, NT_CONSOLE_PROPS **ConsoleProps )
{
	if ( !Filename )
		return -1;
	else if ( Filename[0] == '\0' )
		return -1;


	wchar_t DarwinIdString[SHORT_BUF_LEN]		= L"";

	IShellLink *ShellLink			= NULL;
	IPersistFile *Persist			= NULL;
	ITEMIDLIST *IDList				= NULL;
	IShellLinkDataList *DataLink	= NULL;
	EXP_DARWIN_LINK *DarwinData		= NULL;
	WORD HotkeyValue				= 0;
	int StartModeValue				= 0;
	DWORD LinkFlags					= 0;


	if ( LinkType )
		*LinkType = LINK_TYPE_UNKNOWN;


	if ( FAILED( CoCreateInstance( CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, IID_IShellLink, (LPVOID*) &ShellLink ) ) ) {
		DisplayErrorHeader();
		Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Can\u2019t create shortcut instance\r\n" );
		return 1;
	}

	if ( FAILED( ShellLink->QueryInterface( IID_IPersistFile, (void**) &Persist ) ) ) {
		DisplayErrorHeader();
		Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Can\u2019t create PersistFile instance\r\n" );
		ShellLink->Release();
		return 1;
	}

	if ( FAILED( Persist->Load( Filename, STGM_READ ) ) ) {
		DisplayErrorHeader();
		Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Can\u2019t load file \"%s\"\r\n", Filename );
		Persist->Release();
		ShellLink->Release();
		return 1;
	}

	/*
	if ( FAILED( ShellLink->Resolve( NULL, 0 ) ) ) {
		DisplayErrorHeader();
		Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Can\u2019t resolve link file \"%s\"\r\n", Filename );
		Persist->Release();
		ShellLink->Release();
		return 1;
	}
	*/

	ShellLink->GetPath( Target, MAX_FILENAME_LEN, NULL, 0 );
	ShellLink->GetArguments( Arguments, MAX_ARG_LEN );
	ShellLink->GetWorkingDirectory( Directory, MAX_FILENAME_LEN );
	ShellLink->GetHotkey( &HotkeyValue );
	ShellLink->GetDescription( Comment, MAX_ARG_LEN );
	ShellLink->GetShowCmd( &StartModeValue );
	ShellLink->GetIconLocation( IconFile, MAX_FILENAME_LEN, IconIndex );

	if ( Target[0] && LinkType )
		*LinkType = LINK_TYPE_FILENAME;

	if ( Target[0] == '\0' )
		ShellLink->GetIDList( &IDList );


	ShellLink->QueryInterface( IID_IShellLinkDataList, (void**) &DataLink );
	if ( DataLink ) {
		DataLink->GetFlags( &LinkFlags );

		if ( LinkFlags & SLDF_HAS_DARWINID ) {
			DataLink->CopyDataBlock( EXP_DARWIN_ID_SIG, (void**) &DarwinData );

			if ( DarwinData ) {

				if ( DarwinData->szwDarwinID[0] )
					wcscpy_s( DarwinIdString, SHORT_BUF_LEN, DarwinData->szwDarwinID );
				else if ( DarwinData->szDarwinID[0] )
					MultiByteToWideChar( CP_ACP, 0, DarwinData->szDarwinID, -1, DarwinIdString, SHORT_BUF_LEN );

				LocalFree( DarwinData );
				DarwinData = NULL;
			}
		}

		if ( ConsoleProps )
			DataLink->CopyDataBlock( NT_CONSOLE_PROPS_SIG, (void**) ConsoleProps );

		DataLink->Release();
	}

	
	Persist->Release();
	ShellLink->Release();


	if ( ( Target[0] == '\0' ) && IDList ) {
		SHFILEINFO FileInfo;
		FileInfo.szDisplayName[0] = '\0';
		SHGetFileInfo( (LPCWSTR) IDList, 0, &FileInfo, sizeof( SHFILEINFO ), SHGFI_DISPLAYNAME | SHGFI_PIDL );

		if ( FileInfo.szDisplayName[0] ) {
			wsprintf( Target, L"<%s>", FileInfo.szDisplayName );
			if ( LinkType )
				*LinkType = LINK_TYPE_OBJECT;
		}
	}

	if ( IDList )
		CoTaskMemFree( IDList );


	if ( ( Target[0] == '\0' ) && DarwinIdString[0] ) {
		wchar_t ProductGuid[SHORT_BUF_LEN]		= L"";
		wchar_t ProductName[SHORT_BUF_LEN]		= L"";

		DWORD BufLen			= SHORT_BUF_LEN;


		DarwinStrToGuidStr( DarwinIdString, ProductGuid );

		if ( ProductGuid[0] ) {
			MsiGetProductInfoW( ProductGuid, INSTALLPROPERTY_INSTALLEDPRODUCTNAME, ProductName, &BufLen );
			if ( LinkType )
				*LinkType = LINK_TYPE_DARWIN;
		}

		if ( ProductName[0] )
			wsprintf( Target, L"<<%s>>", ProductName );
		else if ( ProductGuid[0] )
			wsprintf( Target, L"<<%s>>", ProductGuid );
	}


	GetHotkeyName( HotkeyValue, Hotkey );
	GetStartModeString( StartModeValue, StartMode );

	if ( LinkFlags & SLDF_RUNAS_USER )
		wcscpy_s( UACLevel, SHORT_BUF_LEN, L"Elevated" );
	else
		wcscpy_s( UACLevel, SHORT_BUF_LEN, L"Normal" );

	return 0;
}



int GetShortcutParams( LPTSTR Filename, LPTSTR Target, LPTSTR Arguments, LPTSTR Comment, LPTSTR Directory, LPTSTR IconFile, int *IconIndex, LPTSTR Hotkey, LPTSTR StartMode, LPTSTR UACLevel, unsigned int *LinkType, NT_CONSOLE_PROPS **ConsoleProps )
{
	if ( !Filename )
		return -1;
	else if ( Filename[0] == '\0' )
		return -1;

	wchar_t Ext[MAX_FILENAME_LEN] = L"";
	_ExtensionPart( Filename, Ext );


	if ( !_wcsicmp( Ext, L".pif" ) )
		return GetPIFFileParams( Filename, Target, Arguments, Comment, Directory, IconFile, IconIndex, Hotkey, StartMode, UACLevel, LinkType );
	else
		return GetLNKFileParams( Filename, Target, Arguments, Comment, Directory, IconFile, IconIndex, Hotkey, StartMode, UACLevel, LinkType, ConsoleProps );
}



int DumpOneShortcut( LPTSTR Filename, unsigned int Fields )
{
	if ( !Filename )
		return -1;
	else if ( Filename[0] == '\0' )
		return -1;


	if ( !Fields )
		Fields = DUMPSC_DEFAULT;


	wchar_t Target[MAX_FILENAME_LEN]		= L"";
	wchar_t Directory[MAX_FILENAME_LEN]		= L"";
	wchar_t Hotkey[SHORT_BUF_LEN]			= L"";
	wchar_t Comment[MAX_ARG_LEN]			= L"";
	wchar_t Args[MAX_ARG_LEN]				= L"";
	wchar_t StartMode[SHORT_BUF_LEN]		= L"";
	wchar_t IconFile[MAX_FILENAME_LEN]		= L"";
	int IconIndex							= 0;
	wchar_t UACLevel[SHORT_BUF_LEN]			= L"";

	unsigned int NeedConsoleProps			= Fields & ( DUMPSC_CONSOLE_BUFFER_INFO | DUMPSC_CONSOLE_FONT | DUMPSC_CONSOLE_PALETTE );
	NT_CONSOLE_PROPS *ConsoleProps			= NULL;


	if ( GetShortcutParams( Filename, Target, Args, Comment, Directory, IconFile, &IconIndex, Hotkey, StartMode, UACLevel, NULL, NeedConsoleProps ? &ConsoleProps : NULL ) )
		return 1;


	if ( HLprintf( L"\n\x12%s\n", Filename ) == USER_ABORT )
		goto Abort;

	if ( Fields & DUMPSC_TARGET ) {
		Printf( L"   Target       = %s", Target );
		if ( CL_EndLine() == USER_ABORT )
			goto Abort;
	}

	if ( Fields & DUMPSC_ARGUMENTS ) {
		Printf( L"   Arguments    = %s", Args );
		if ( CL_EndLine() == USER_ABORT )
			goto Abort;
	}

	if ( Fields & DUMPSC_DIRECTORY ) {
		Printf( L"   Directory    = %s", Directory );
		if ( CL_EndLine() == USER_ABORT )
			goto Abort;
	}

	if ( Fields & DUMPSC_HOTKEY ) {
		Printf( L"   Hotkey       = %s", Hotkey );
		if ( CL_EndLine() == USER_ABORT )
			goto Abort;
	}

	if ( Fields & DUMPSC_COMMENT ) {
		Printf( L"   Comment      = %s", Comment );
		if ( CL_EndLine() == USER_ABORT )
			goto Abort;
	}

	if ( Fields & DUMPSC_START_MODE ) {
		Printf( L"   StartMode    = %s", StartMode );
		if ( CL_EndLine() == USER_ABORT )
			goto Abort;
	}

	if ( Fields & DUMPSC_ICON ) {
		if ( IconFile[0] )
			Printf( L"   Icon         = %s, %d", IconFile, IconIndex );
		else
			Printf( L"   Icon         = None" );

		if ( CL_EndLine() == USER_ABORT )
			goto Abort;
	}

	if ( ( Fields & DUMPSC_UAC_LEVEL ) && ( OSVerInfo.dwMajorVersion >= 6 ) ) {
		Printf( L"   UAC          = %s", UACLevel );
		if ( CL_EndLine() == USER_ABORT )
			goto Abort;
	}


	if ( ConsoleProps ) {

		if ( Fields & DUMPSC_CONSOLE_BUFFER_INFO ) {
			Printf( L"   Buffer size  = %u \u00d7 %u", ConsoleProps->dwScreenBufferSize.X, ConsoleProps->dwScreenBufferSize.Y );
			if ( CL_EndLine() == USER_ABORT )
				goto Abort;

			Printf( L"   Window size  = %u \u00d7 %u", ConsoleProps->dwWindowSize.X, ConsoleProps->dwWindowSize.Y );
			if ( CL_EndLine() == USER_ABORT )
				goto Abort;
		}

		if ( ( Fields & DUMPSC_CONSOLE_FONT ) && ConsoleProps->FaceName[0] ) {
			Printf( L"   Font         = %s", ConsoleProps->FaceName );

			if ( ConsoleProps->uFontFamily == ( TMPF_TRUETYPE | TMPF_VECTOR | FF_MODERN ) )
				Printf( L" %u", ConsoleProps->dwFontSize.Y );
			else if ( ConsoleProps->uFontFamily == FF_MODERN )
				Printf( L" %u \u00d7 %u", ConsoleProps->dwFontSize.X, ConsoleProps->dwFontSize.Y );

			if ( ConsoleProps->uFontWeight >= FW_BOLD )
				QPuts( L" (bold)" );

			if ( CL_EndLine() == USER_ABORT )
				goto Abort;
		}

		if ( Fields & DUMPSC_CONSOLE_PALETTE ) {
			for ( unsigned int i = 0; i < 16; i++ ) {
				Printf( L"   Color %-2u     = #%06x", i, RgbToBgr( ConsoleProps->ColorTable[i] ) );

				if ( CL_EndLine() == USER_ABORT )
					goto Abort;
			}
		}

		LocalFree( ConsoleProps );
	}

	return 0;


Abort:

	if ( ConsoleProps )
		LocalFree( ConsoleProps );

	return USER_ABORT;
}



int DumpShortcuts( LPTSTR Wildspec, unsigned int Fields, int Recurse, unsigned int *FoundCount )
{
	if ( !Wildspec )
		return -1;

	wchar_t Pathname[MAX_FILENAME_LEN]	= L"";
	wchar_t Ext[MAX_FILENAME_LEN]		= L"";
	wchar_t Fullname[MAX_FILENAME_LEN]	= L"";
	wchar_t SubDir[MAX_FILENAME_LEN]	= L"";
	LPTSTR WildcardPart = NULL;
	WIN32_FIND_DATA FoundItem;
	wchar_t FoundItemExt[MAX_FILENAME_LEN]	= L"";
	HANDLE SearchHandle = NULL;
	int rv = 0, trv = 0, le = 0;

	wchar_t ErrorText[SHORT_BUF_LEN] = L"";

	_PathPart( Wildspec, Pathname );
	_ExtensionPart( Wildspec, Ext );

	
	SearchHandle = FindFirstFile( Wildspec, &FoundItem );

	if ( SearchHandle == INVALID_HANDLE_VALUE ) {
		le = GetLastError();

		if ( ( le != ERROR_FILE_NOT_FOUND ) && ( ( Recurse & RECURSE_NO_ERROR_MSGS ) == 0 ) ) {
			GetErrorText( le, ErrorText );
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"%s \"%s\"\r\n", ErrorText, Wildspec );
			rv = 2;
		}
	}
	else {
		do {
			if ( CL_AbortFlag == FORCE_USER_ABORT ) {
				FindClose( SearchHandle );
				return CL_ShowCtrlBreak();
			}


			if ( FoundItem.dwFileAttributes & ( FILE_ATTRIBUTE_DIRECTORY | FILE_ATTRIBUTE_DEVICE | FILE_ATTRIBUTE_REPARSE_POINT ) )
				continue;

			if ( !wcscmp( Ext, L".**" ) ) {
				_ExtensionPart( FoundItem.cFileName, FoundItemExt );

#ifdef _WIN64
				if ( _wcsicmp( FoundItemExt, L".lnk" ) )
					continue;
#else	//	_WIN64
				if ( _wcsicmp( FoundItemExt, L".lnk" ) )
					if ( _wcsicmp( FoundItemExt, L".pif" ) )
						continue;
#endif	//	_WIN64

			}

			wcscpy_s( Fullname, MAX_FILENAME_LEN, Pathname );
			wcscat_s( Fullname, MAX_FILENAME_LEN, FoundItem.cFileName );
			*FoundCount += 1;

			if ( trv = DumpOneShortcut( Fullname, Fields ) ) {
				if ( trv == USER_ABORT ) {
					FindClose( SearchHandle );
					return USER_ABORT;
				}
				else
					rv = 2;
			}

		}
		while ( FindNextFile( SearchHandle, &FoundItem ) );

		FindClose( SearchHandle );
		SearchHandle = NULL;
	}

	if ( Recurse & RECURSE_NORMAL ) {
		WildcardPart = _FilenamePart( Wildspec, NULL );

		wcscpy_s( SubDir, MAX_FILENAME_LEN, Pathname );
		wcscat_s( SubDir, MAX_FILENAME_LEN, L"*" );

		SearchHandle = FindFirstFile( SubDir, &FoundItem );

		if ( SearchHandle != INVALID_HANDLE_VALUE ) {

			do {
				if ( ( FoundItem.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ) == 0 )
					continue;

				if ( Recurse & RECURSE_NO_JUNCTIONS )
					if ( FoundItem.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT )
						continue;

				if ( Recurse & RECURSE_NO_HIDDEN_DIRS )
					if ( FoundItem.dwFileAttributes & FILE_ATTRIBUTE_HIDDEN )
						continue;

				if ( Recurse & RECURSE_NO_SYSTEM_DIRS )
					if ( FoundItem.dwFileAttributes & FILE_ATTRIBUTE_SYSTEM )
						continue;

				if ( !wcscmp( FoundItem.cFileName, L"." ) )
					continue;

				if ( !wcscmp( FoundItem.cFileName, L".." ) )
					continue;

				wcscpy_s( Fullname, MAX_FILENAME_LEN, Pathname );
				wcscat_s( Fullname, MAX_FILENAME_LEN, FoundItem.cFileName );
				AppendFilename( Fullname, WildcardPart, MAX_FILENAME_LEN );			//	MakeDirectoryName( Fullname, WildcardPart );

				if ( trv = DumpShortcuts( Fullname, Fields, Recurse, FoundCount ) ) {
					if ( trv == USER_ABORT ) {
						FindClose( SearchHandle );
						return USER_ABORT;
					}
					else
						rv = 2;
				}

			}
			while ( FindNextFile( SearchHandle, &FoundItem ) );

			FindClose( SearchHandle );
		}
	}

	return rv;
}



int MKSC_MissingColonError( LPTSTR Arg )
{
	DisplayErrorHeader();
	_wcsupr_s( Arg, MAX_ARG_LEN );
	Qprintf( ERRHANDLE, L"Expected a colon or equals sign: \"%s\"\r\n", Arg );
	return 1;
}



DLLExports int WINAPI mksc( LPTSTR inString )
{
	if ( !inString )
		return -1;



	wchar_t Filename[MAX_FILENAME_LEN]	= L"";
	wchar_t Target[MAX_FILENAME_LEN]	= L"";
	wchar_t Args[MAX_ARG_LEN]			= L"";
	wchar_t Directory[MAX_FILENAME_LEN] = L"";
	wchar_t IconFile[MAX_FILENAME_LEN]	= L"";
	wchar_t Comment[MAX_ARG_LEN]		= L"";

	BOOL SymbolicName					= FALSE;
	BOOL CanonicalizeTarget				= TRUE;
	BOOL CanonicalizeDirectory			= TRUE;
	BOOL CanonicalizeIconFile			= TRUE;
	BOOL OverwriteReadOnly				= FALSE;
	BOOL SetComment						= FALSE;
	BOOL ExpandEscapesInArgs			= FALSE;
	BOOL ExpandEscapesInComment			= FALSE;
	BOOL NoHighlight					= FALSE;
	unsigned int Pause					= 0;

	ITEMIDLIST *IDList					= NULL;
	unsigned int StartMode				= 0;
	int Hotkey							= -1;
	unsigned int IconIndex				= UINT_MAX;
	int NewUAC							= 0;

	BOOL SetDirectory					= FALSE;
	BOOL SetIconFile					= FALSE;
	BOOL SetArgs						= FALSE;
	BOOL SetConsoleProps				= FALSE;
	BOOL Changes						= FALSE;
	BOOL Debug							= FALSE;
	BOOL FixVistaKnownFolderBullshit	= TRUE;

	_ConsolePropsChanges ConsolePropsChanges;
	wchar_t *sep1						= NULL;

	wchar_t Ext[MAX_FILENAME_LEN]		= L"";
	wchar_t TargetExt[MAX_FILENAME_LEN]	= L"";
	wchar_t LinkExt[2][5]				= { L".lnk", L".pif" };

	unsigned int DumpFields				= 0;
	int Recurse							= 0;

	BOOL FileExists						= FALSE;
	DWORD Attributes					= 0;


	memset( &ConsolePropsChanges, 0x00, sizeof( _ConsolePropsChanges ) );
	CL_NoPausing();


	ParseArgs( inString, PARSE_BREAK_SPACES );


	for ( int i = 0; i < numargs; i++ ) {
		if ( arglen[i] ) {

			if ( !wcsncmp( arg[i], L"/?", 2 ) )
				return ShowCmdHelp( MkScHelpText, ( arg[i][2] == '?' ), MACRO_STR( __FILE__ ), MACRO_STR( MKSC_VER ) );
			else if ( !wcscmp( arg[i], L"/$" ) )
				Debug = TRUE;
			else if ( !_wcsnicmp( arg[i], L"/A", 2 ) ) {
				int j = 2;

				if ( towupper( arg[i][j] ) == 'X' )
					ExpandEscapesInArgs = TRUE, j++;

				if ( IsColonOrEquals( arg[i][j] ) )
					j++;
				else
					return MKSC_MissingColonError( arg[i] );

				wcscpy_s( Args, MAX_ARG_LEN, arg[i] + j );
				Changes = SetArgs = TRUE;
			}
			else if ( !_wcsicmp( arg[i], L"/B?" ) ) {
				QPuts( (LPTSTR) MkSc_OptBHelpText );
				return 0;
			}
			else if ( !_wcsnicmp( arg[i], L"/BA", 3 ) ) {
				unsigned int t = 0;
				int j = 3;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;
				else
					return MKSC_MissingColonError( arg[i] );

				if ( ParseInt( arg[i] + j, &t, NULL ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad auto position value: \"%s\"\r\n", arg[i] );
					return 1;
				}

				if ( t )
					ConsolePropsChanges.AutoPosition = 0x8001;
				else
					ConsolePropsChanges.AutoPosition = 0x8000;

				SetConsoleProps = Changes = TRUE;
			}
			else if ( !_wcsnicmp( arg[i], L"/BB", 3 ) ) {
				unsigned int t = 0;
				int j = 3;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;
				else
					return MKSC_MissingColonError( arg[i] );

				if ( ParseInt( arg[i] + j, &t, NULL ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad font weight value: \"%s\"\r\n", arg[i] );
					return 1;
				}

				if ( ( t != FW_NORMAL ) && ( t != FW_BOLD ) ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Font weight must be either %u or %u: %u\r\n", FW_NORMAL, FW_BOLD, t );
					return 1;
				}

				ConsolePropsChanges.FontWeight = t;
				SetConsoleProps = Changes = TRUE;
			}
			else if ( !_wcsnicmp( arg[i], L"/BC", 3 ) ) {
				unsigned int t = 0;
				int j = 3;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;
				else
					return MKSC_MissingColonError( arg[i] );

				if ( ParseInt( arg[i] + j, &t, NULL ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad cursor size value: \"%s\"\r\n", arg[i] );
					return 1;
				}

				if ( ( t < 10 ) || ( t > 100 ) ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Cursor size must be 10 - 100: %u\r\n", t );
					return 1;
				}

				ConsolePropsChanges.CursorSize = t;
				SetConsoleProps = Changes = TRUE;
			}
			else if ( !_wcsnicmp( arg[i], L"/BD", 3 ) ) {
				unsigned int t = 0;
				int j = 3;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;
				else
					return MKSC_MissingColonError( arg[i] );

				if ( ParseInt( arg[i] + j, &t, NULL ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad default color value: \"%s\"\r\n", arg[i] );
					return 1;
				}

				t &= 0xffff;

				if ( ( ( t & 0x00f0 ) >> 4 ) == ( t & 0x000f ) ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Default color must not be invisible: 0x%04X\r\n", t );
					return 1;
				}

				ConsolePropsChanges.FillColor = t;
				SetConsoleProps = Changes = TRUE;
			}
			else if ( !_wcsnicmp( arg[i], L"/BF", 3 ) ) {
				int j = 3;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;
				else
					return MKSC_MissingColonError( arg[i] );

				if ( arg[i][j] == '\0' ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Missing font name: \"%s\"\r\n", arg[i] );
					return 1;
				}

				CorrectFontName( arg[i] + j, ConsolePropsChanges.FontName );		//	wcscpy_s( ConsolePropsChanges.FontName, LF_FACESIZE, arg[i] + j );
				SetConsoleProps = Changes = TRUE;
			}
			else if ( !_wcsnicmp( arg[i], L"/BG", 3 ) ) {
				int j = 3;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;
				else
					return MKSC_MissingColonError( arg[i] );

				if ( ParseInt( arg[i] + j, &( ConsolePropsChanges.FontX ), &sep1 ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad X value: \"%s\"\r\n", arg[i] );
					return 1;
				}

				if ( ConsolePropsChanges.FontX > FONT_HEIGHT_MAX ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Font width must be 0 - %u: %u\r\n", FONT_HEIGHT_MAX, ConsolePropsChanges.FontX );
					return 1;
				}

				if ( ( *sep1 != ',' ) && ( *sep1 != ';' ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Expected a comma: \"%s\"\r\n", arg[i] );
					return 1;
				}

				sep1++;
				if ( ParseInt( sep1, &( ConsolePropsChanges.FontY ), NULL ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad Y value: \"%s\"\r\n", arg[i] );
					return 1;
				}

				if ( ( ConsolePropsChanges.FontY < FONT_HEIGHT_MIN ) || ( ConsolePropsChanges.FontY > FONT_HEIGHT_MAX ) ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Font height must be %u - %u: %u\r\n", FONT_HEIGHT_MIN, FONT_HEIGHT_MAX, ConsolePropsChanges.FontY );
					return 1;
				}

				SetConsoleProps = Changes = TRUE;
			}
			else if ( !_wcsnicmp( arg[i], L"/BH", 3 ) ) {
				wchar_t *ch = arg[i] + 3;
				if ( IsColonOrEquals( *ch ) )
					ch++;


				unsigned int Index		= 0;
				int Color				= 0;


				if ( ParseInt( ch, &Index, &sep1 ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad index value: \"%s\"\r\n", arg[i] );
					return 1;
				}

				if ( Index > 15 ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Index must be 0 - 15: %u\r\n", Index );
					return 1;
				}

				if ( !IsColonOrEquals( *sep1 ) )
					return MKSC_MissingColonError( arg[i] );

				if ( ( sep1[1] == '\0' ) || ( sep1[1] == ',' ) || ( sep1[1] == ';' ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Missing color name:\"%s\"\r\n", arg[i] );
					return 1;
				}


				do {
					ch = sep1 + 1;

					sep1 = MKSC_FindListSep( ch );
					if ( sep1 )
						*sep1 = '\0';

					if ( *ch ) {
						Color = W3CColorValue( ch, TRUE );

						if ( Color == W3C_COLOR_UNDEFINED ) {
							_wcsupr_s( ch, MAX_ARG_LEN );
							DisplayErrorHeader();
							Qprintf( ERRHANDLE, L"Bad color name: \"%s\"\r\n", ch );
							return 1;
						}

						Color = RgbToBgr( Color );
						ConsolePropsChanges.ColorTable[Index] = Color ? Color : 0x80000000;
					}

					Index++;

					if ( sep1 )
						*sep1 = ';';
				}
				while ( sep1 && ( Index < 16 ) );


				SetConsoleProps = Changes = TRUE;
			}
			else if ( !_wcsnicmp( arg[i], L"/BI", 3 ) ) {
				unsigned int t = 0;
				int j = 3;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;
				else
					return MKSC_MissingColonError( arg[i] );

				if ( ParseInt( arg[i] + j, &t, NULL ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad insert value: \"%s\"\r\n", arg[i] );
					return 1;
				}

				if ( t )
					ConsolePropsChanges.InsertMode = 0x8001;
				else
					ConsolePropsChanges.InsertMode = 0x8000;

				SetConsoleProps = Changes = TRUE;
			}
			else if ( !_wcsnicmp( arg[i], L"/BO", 3 ) ) {
				int j = 3;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;
				else
					return MKSC_MissingColonError( arg[i] );


				if ( ParseSignedInt( arg[i] + j, &( ConsolePropsChanges.OriginX ), &sep1 ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad window origin X value: \"%s\"\r\n", arg[i] );
					return 1;
				}

				if ( ( *sep1 != ',' ) && ( *sep1 != ';' ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Expected a comma: \"%s\"\r\n", arg[i] );
					return 1;
				}

				sep1++;
				if ( ParseSignedInt( sep1, &( ConsolePropsChanges.OriginY ), NULL ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad window origin Y value: \"%s\"\r\n", arg[i] );
					return 1;
				}

				ConsolePropsChanges.UseOrigin = TRUE;
				SetConsoleProps = Changes = TRUE;
			}
			else if ( !_wcsnicmp( arg[i], L"/BP", 3 ) ) {
				unsigned int t = 0;
				int j = 3;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;
				else
					return MKSC_MissingColonError( arg[i] );

				if ( ParseInt( arg[i] + j, &t, NULL ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad popup color value: \"%s\"\r\n", arg[i] );
					return 1;
				}

				t &= 0xffff;

				if ( ( ( t & 0x00f0 ) >> 4 ) == ( t & 0x000f ) ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Popup color must not be invisible: 0x%04X\r\n", t );
					return 1;
				}

				ConsolePropsChanges.PopupColor = t;
				SetConsoleProps = Changes = TRUE;
			}
			else if ( !_wcsnicmp( arg[i], L"/BQ", 3 ) ) {
				unsigned int t = 0;
				int j = 3;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;
				else
					return MKSC_MissingColonError( arg[i] );

				if ( ParseInt( arg[i] + j, &t, NULL ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad QuickEdit value: \"%s\"\r\n", arg[i] );
					return 1;
				}

				if ( t )
					ConsolePropsChanges.QuickEdit = 0x8001;
				else
					ConsolePropsChanges.QuickEdit = 0x8000;

				SetConsoleProps = Changes = TRUE;
			}
			else if ( !_wcsnicmp( arg[i], L"/BS", 3 ) ) {
				int j = 3;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;
				else
					return MKSC_MissingColonError( arg[i] );

				if ( ParseInt( arg[i] + j, &( ConsolePropsChanges.BufferX ), &sep1 ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad buffer width value: \"%s\"\r\n", arg[i] );
					return 1;
				}

				if ( ( ConsolePropsChanges.BufferX < SCREEN_BUFFER_WIDTH_MIN ) || ( ConsolePropsChanges.BufferX > SCREEN_BUFFER_WIDTH_MAX ) ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Buffer width must be %u - %u: %u\r\n", SCREEN_BUFFER_WIDTH_MIN, SCREEN_BUFFER_WIDTH_MAX, ConsolePropsChanges.BufferX );
					return 1;
				}

				ConsolePropsChanges.WindowX = ConsolePropsChanges.BufferX;

				if ( ( *sep1 != ',' ) && ( *sep1 != ';' ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Expected a comma: \"%s\"\r\n", arg[i] );
					return 1;
				}

				sep1++;
				if ( ParseInt( sep1, &( ConsolePropsChanges.BufferY ), &sep1 ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad buffer height value: \"%s\"\r\n", arg[i] );
					return 1;
				}

				if ( ( ConsolePropsChanges.BufferY < SCREEN_BUFFER_HEIGHT_MIN ) || ( ConsolePropsChanges.BufferY > SCREEN_BUFFER_HEIGHT_MAX ) ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Buffer height must be %u - %u: %u\r\n", SCREEN_BUFFER_HEIGHT_MIN, SCREEN_BUFFER_HEIGHT_MAX, ConsolePropsChanges.BufferY );
					return 1;
				}

				if ( *sep1 == '\0' ) {
					ConsolePropsChanges.WindowY = 25;

					if ( ConsolePropsChanges.BufferX >= 100 )
						ConsolePropsChanges.WindowY += ( 5 * ( ( ConsolePropsChanges.BufferX - 60 ) / 30 ) );

					if ( ConsolePropsChanges.WindowY > ConsolePropsChanges.BufferY )
						ConsolePropsChanges.WindowY = ConsolePropsChanges.BufferY;

				}
				else if ( ( *sep1 == ',' ) || ( *sep1 == ';' ) ) {

					sep1++;
					if ( ParseInt( sep1, &( ConsolePropsChanges.WindowY ), NULL ) ) {
						_wcsupr_s( arg[i], MAX_ARG_LEN );
						DisplayErrorHeader();
						Qprintf( ERRHANDLE, L"Bad viewport height value: \"%s\"\r\n", arg[i] );
						return 1;
					}

					if ( ( ConsolePropsChanges.WindowY < SCREEN_BUFFER_HEIGHT_MIN ) || ( ConsolePropsChanges.WindowY > VIEWPORT_HEIGHT_MAX ) ) {
						DisplayErrorHeader();
						Qprintf( ERRHANDLE, L"Viewport height must be %u - %u: %u\r\n", SCREEN_BUFFER_HEIGHT_MIN, VIEWPORT_HEIGHT_MAX, ConsolePropsChanges.WindowY );
						return 1;
					}
					else if ( ConsolePropsChanges.WindowY > ConsolePropsChanges.BufferY ) {
						DisplayErrorHeader();
						Qprintf( ERRHANDLE, L"Viewport height cannot be greater than buffer height: %u\r\n", ConsolePropsChanges.WindowY );
						return 1;
					}
				}
				else {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Expected a comma: \"%s\"\r\n", arg[i] );
					return 1;
				}

				SetConsoleProps = Changes = TRUE;
			}
			else if ( !_wcsnicmp( arg[i], L"/BZ", 3 ) ) {
				unsigned int t = 0;
				int j = 3;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;
				else
					return MKSC_MissingColonError( arg[i] );

				if ( ParseInt( arg[i] + j, &t, NULL ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad fullscreen value: \"%s\"\r\n", arg[i] );
					return 1;
				}

				if ( t )
					ConsolePropsChanges.FullScreen = 0x8001;
				else
					ConsolePropsChanges.FullScreen = 0x8000;

				SetConsoleProps = Changes = TRUE;
			}
			else if ( !_wcsnicmp( arg[i], L"/C", 2 ) ) {
				int j = 2;

				if ( towupper( arg[i][j] ) == 'X' )
					ExpandEscapesInComment = TRUE, j++;

				if ( IsColonOrEquals( arg[i][j] ) )
					j++;
				else
					return MKSC_MissingColonError( arg[i] );

				wcscpy_s( Comment, MAX_ARG_LEN, arg[i] + j );
				Changes = SetComment = TRUE;
			}
			else if ( !_wcsnicmp( arg[i], L"/D", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;
				else
					return MKSC_MissingColonError( arg[i] );

				if ( arg[i][j] ) {
					wcscpy_s( Directory, MAX_FILENAME_LEN, arg[i] + j );

					if ( !wcscmp( arg[i] + j, L"*" ) )
						CanonicalizeDirectory = FALSE;
					else if ( ( arg[i][j] == '%' ) && iswalpha( arg[i][j + 1] ) )
						CanonicalizeDirectory = FALSE;
					else if ( ( arg[i][j] == '~' ) && ( ( arg[i][j + 1] == '/' ) || ( arg[i][j + 1] == '\\' ) || ( arg[i][j + 1] == '\0' ) ) )
						CanonicalizeDirectory = FALSE;
				}
				else
					Directory[0] = '\0';

				Changes = SetDirectory = TRUE;
			}
			else if ( !_wcsnicmp( arg[i], L"/F", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				while ( arg[i][j] ) {
					switch ( towupper( arg[i][j++] ) ) {

					case 'A' :
						DumpFields |= DUMPSC_ARGUMENTS;
						break;

					case 'B' :
						DumpFields |= DUMPSC_CONSOLE_BUFFER_INFO;
						break;

					case 'C' :
						DumpFields |= DUMPSC_COMMENT;
						break;

					case 'D' :
						DumpFields |= DUMPSC_DIRECTORY;
						break;

					case 'F' :
						DumpFields |= DUMPSC_CONSOLE_FONT;
						break;

					case 'H' :
						DumpFields |= DUMPSC_CONSOLE_PALETTE;
						break;

					case 'I' :
						DumpFields |= DUMPSC_ICON;
						break;

					case 'K' :
						DumpFields |= DUMPSC_HOTKEY;
						break;

					case 'M' :
						DumpFields |= DUMPSC_START_MODE;
						break;

					case 'N' :
						DumpFields |= DUMPSC_DEFAULT;
						break;

					case 'T' :
						DumpFields |= DUMPSC_TARGET;
						break;

					case 'U' :
						DumpFields |= DUMPSC_UAC_LEVEL;
						break;

					case '?' :
						QPuts( (LPTSTR) MkSc_OptFHelpText );
						return 0;

					default :
						_wcsupr_s( arg[i], MAX_ARG_LEN );
						DisplayErrorHeader();
						Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Unknown field: \"/F:%c\"\r\n", towupper( arg[i][j - 1] ) );
						return 1;
					}
				}
			}
			else if ( !_wcsnicmp( arg[i], L"/I", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;
				else
					return MKSC_MissingColonError( arg[i] );

				if ( !_wcsicmp( arg[i] + j, L"None" ) )
					IconFile[0] = '\0';
				else if ( arg[i][j] )
					wcscpy_s( IconFile, MAX_FILENAME_LEN, arg[i] + j );
				else
					IconFile[0] = '\0';

				Changes = SetIconFile = TRUE;
			}
			else if ( !_wcsnicmp( arg[i], L"/J", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;
				else
					return MKSC_MissingColonError( arg[i] );

				if ( ParseInt( arg[i] + j, &IconIndex, NULL ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Bad icon index: \"%s\"\r\n", arg[i] );
					return 1;
				}

				Changes = TRUE;
			}
			else if ( !_wcsnicmp( arg[i], L"/K", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;
				else
					return MKSC_MissingColonError( arg[i] );

				if ( arg[i][j] ) {
					Hotkey = ParseHotkey( arg[i] + j );

					if ( Hotkey < 0 ) {
						_wcsupr_s( arg[i], MAX_ARG_LEN );
						DisplayErrorHeader();
						Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Unknown key name: \"%s\"\r\n", arg[i] );
						return 1;
					}
				}
				else
					Hotkey = 0;

				Changes = TRUE;
			}
			else if ( !_wcsnicmp( arg[i], L"/M", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;
				else
					return MKSC_MissingColonError( arg[i] );

				if ( towupper( arg[i][j] ) == 'N' )
					StartMode = SW_SHOWNORMAL;
				else if ( !_wcsnicmp( arg[i] + j, L"Min", 3 ) )
					StartMode = SW_SHOWMINNOACTIVE;
				else if ( !_wcsnicmp( arg[i] + j, L"Max", 3 ) )
					StartMode = SW_SHOWMAXIMIZED;
				else {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Bad mode: \"%s\"\r\n", arg[i] );
					return 1;
				}

				Changes = TRUE;
			}
			else if ( !_wcsnicmp( arg[i], L"/N", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				while ( arg[i][j] ) {

					switch ( towupper( arg[i][j] ) ) {

					case 'C' :
						NoHighlight = TRUE;
						break;

					case 'D' :
						CanonicalizeDirectory = FALSE;
						break;

					case 'E' :
						Recurse |= RECURSE_NO_ERROR_MSGS;
						break;

					case 'H' :
						Recurse |= RECURSE_NO_HIDDEN_DIRS;
						break;

					case 'I' :
						CanonicalizeIconFile = FALSE;
						break;

					case 'J' :
						Recurse |= RECURSE_NO_JUNCTIONS;
						break;

					case 'T' :
						CanonicalizeTarget = FALSE;
						break;

					case 'V' :
						FixVistaKnownFolderBullshit = FALSE;
						break;

					case 'Z' :
						Recurse |= RECURSE_NO_SYSTEM_DIRS;
						break;

					case '?' :
						QPuts( (LPTSTR) MkSc_OptNHelpText );
						return 0;

					default :
						DisplayErrorHeader();
						_wcsupr_s( arg[i], MAX_ARG_LEN );
						Qprintf( ERRHANDLE, L"Unknown suboption: \"/N:%c\"\r\n", towupper( arg[i][j] ) );
						return 1;
					}

					j++;
				}
			}
			else if ( !_wcsnicmp( arg[i], L"/P", 2 ) ) {
				if ( CL_ParsePOption( arg[i], &Pause ) )
					return 1;
			}
			else if ( !_wcsicmp( arg[i], L"/S" ) )
				Recurse |= RECURSE_NORMAL;
			else if ( !_wcsnicmp( arg[i], L"/U", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;
				else
					return MKSC_MissingColonError( arg[i] );

				int nu = 0;

				if ( towupper( arg[i][j] ) == 'N' )
					nu = 1;
				else if ( towupper( arg[i][j] ) == 'E' )
					nu = 2;
				else {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Bad UAC mode: \"%s\"\r\n", arg[i] );
					return 1;
				}

				if ( OSVerInfo.dwMajorVersion >= 6 ) {
					NewUAC = nu;
					Changes = TRUE;
				}
			}
			else if ( !_wcsicmp( arg[i], L"/Z" ) )
				OverwriteReadOnly = TRUE;
			else if ( arg[i][0] == '/' ) {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Unknown option: \"%s\"\r\n", arg[i] );
				return 1;
			}
			else if ( Filename[0] == '\0' ) {
				if ( CanonicalizeFilenameEx( arg[i], Filename ) )
					return 1;
			}
			else if ( Target[0] == '\0' ) {
				if ( arg[i][0] == '<' ) {
					if ( arg[i][arglen[i] - 1] == '>' ) {
						wcscpy_s( Target, MAX_FILENAME_LEN, arg[i] + 1 );
						Target[arglen[i] - 2] = '\0';
						_wcsupr_s( Target, MAX_FILENAME_LEN );
						SymbolicName = TRUE;
					}
				}
				else if ( !_wcsnicmp( arg[i], L"shell:::{", 9 ) ) {
					if ( iswxdigit( arg[i][9] ) && ( arg[i][arglen[i] - 1] == '}' ) ) {
						wcscpy_s( Target, MAX_FILENAME_LEN, arg[i] );
						SymbolicName = TRUE;
					}
				}
				else if ( !wcsncmp( arg[i], L"::{", 3 ) ) {
					if ( iswxdigit( arg[i][3] ) && ( arg[i][arglen[i] - 1] == '}' ) ) {
						wcscpy_s( Target, MAX_FILENAME_LEN, L"shell:" );
						wcscat_s( Target, MAX_FILENAME_LEN, arg[i] );
						SymbolicName = TRUE;
					}
				}

				if ( SymbolicName ) {
					if ( GetIDListFromSymbolicName( Target, &IDList ) ) {
						_wcsupr_s( Target, MAX_ARG_LEN );
						DisplayErrorHeader();
						Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Unknown symbolic name: \"%s\"\r\n", Target );
						return 1;
					}
				}
				else {
					wcscpy_s( Target, MAX_FILENAME_LEN, arg[i] );

					if ( ( Target[0] == '%' ) && iswalpha( Target[1] ) )
						CanonicalizeTarget = FALSE;
				}

				Changes = TRUE;
			}
			else {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Syntax error: \"%s\"\r\n", arg[i] );
				return 1;
			}

		}
	}


	if ( ConsolePropsChanges.UseOrigin && ( ConsolePropsChanges.AutoPosition == 0 ) )
		ConsolePropsChanges.AutoPosition = 0x8000;


	if ( IconFile[0] && CanonicalizeIconFile )
		if ( CanonicalizeFilenameEx( IconFile, IconFile ) )
			return 1;


	if ( Args[0] && ExpandEscapesInArgs )
		ExpandEscapes( Args, MAX_ARG_LEN );

	if ( Comment[0] && ExpandEscapesInComment )
		ExpandEscapes( Comment, MAX_ARG_LEN );


	if ( !Changes ) {

		if ( Pause )
			CL_SetPauseLines( Pause );

		CL_PickHighlightColor( NoHighlight );


		if ( Filename[0] == '\0' )
			QueryTrueName( L"*.**", Filename );

		if ( QueryIsDirectory( Filename ) )
			AppendFilename( Filename, L"*.**", MAX_FILENAME_LEN );

		_ExtensionPart( Filename, Ext );
		if ( Ext[0] == '\0' )
			wcscat_s( Filename, MAX_FILENAME_LEN, L".**" );

		if ( !DumpFields )
			DumpFields = DUMPSC_DEFAULT;

		if ( Debug ) {
			Printf( L"Filename:  \"%s\"\r\n", Filename );
			Printf( L"Recurse :  %s\r\n", Recurse ? L"Yes" : L"No" );
			Printf( L"Fields  :  0x%04x\r\n", DumpFields );
		}

		unsigned int FoundCount = 0;
		int rv = 0;

		SetConsoleCtrlHandler( CL_CtrlBreakProc, TRUE );
		rv = DumpShortcuts( Filename, DumpFields, Recurse, &FoundCount );
		SetConsoleCtrlHandler( CL_CtrlBreakProc, FALSE );

		if ( FoundCount == 0 ) {
			DisplayErrorHeader();
			Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"File not found: \"%s\"\r\n", Filename );
			rv = 2;
		}

		if ( rv == USER_ABORT )
			rv = 3;

		return rv;
	}


	if ( Filename[0] == '\0' ) {
		DisplayErrorHeader();
		Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Missing linkfile\r\n" );
		return 1;
	}

	if ( HasWildcards( Filename ) ) {
		DisplayErrorHeader();
		Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Wildcards not allowed when creating or editing: \"%s\"\r\n", Filename );
		return 1;
	}

	if ( QueryIsDirectory( Filename ) ) {
		DisplayErrorHeader();
		Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Filename is a directory: \"%s\"\r\n", Filename );
		return 1;
	}


	if ( CanonicalizeTarget && !SymbolicName ) {

		wchar_t Found[MAX_FILENAME_LEN]	= L"";

		if ( !_PathPart( Target, NULL ) )
			SearchPathForExe( Target, Found );								//	Found = SearchPaths( Target, NULL, 1, NULL, NULL );

		if ( Found[0] ) {
			if ( !_PathPart( Found, NULL ) ) {
				wcscpy_s( Target, MAX_FILENAME_LEN, L"%_cwds" );			//	QueryCurrentDirectory( NULL, Target, 0 );
				ExpandVariables( Target, 1 );
				AppendFilename( Target, Found, MAX_FILENAME_LEN );			//	MakeDirectoryName( Target, Found );
			}
			else
				wcscpy_s( Target, MAX_FILENAME_LEN, Found );
		}
		else {
			wchar_t temp[MAX_FILENAME_LEN] = L"";

			if ( CanonicalizeFilenameEx( Target, temp ) )
				return 1;

			wcscpy_s( Target, MAX_FILENAME_LEN, temp );
		}
	}


	if ( !wcscmp( Directory, L"*" ) ) {
		if ( SymbolicName )
			Directory[0] = '\0';
		else if ( QueryIsDirectory( Target ) )
			wcscpy_s( Directory, MAX_FILENAME_LEN, Target );
		else {
			_PathPart( Target, Directory );
			int l = (int) wcslen( Directory );
			if ( l > 3 )
				if ( ( Directory[l - 1] == '/' ) || ( Directory[l - 1] == '\\' ) )
					Directory[l - 1] = '\0';
		}
	}
	else if ( ( Directory[0] == '~' ) && ( ( Directory[1] == '/' ) || ( Directory[1] == '\\' ) || ( Directory[1] == '\0' ) ) ) {
		wchar_t temp[MAX_FILENAME_LEN] = L"";

		if ( Directory[1] )
			wcscpy_s( temp, MAX_FILENAME_LEN, Directory + 1 );

		wcscpy_s( Directory, MAX_FILENAME_LEN, L"%USERPROFILE%" );

		if ( temp[0] )
			wcscat_s( Directory, MAX_FILENAME_LEN, temp );
	}
	else if ( CanonicalizeDirectory ) {
		if ( CanonicalizeFilenameEx( Directory, Directory ) )
			return 1;
	}


	//		Figure the correct extension for the shortcut file:

	_ExtensionPart( Filename, Ext );
	_ExtensionPart( Target, TargetExt );

	LPTSTR CorrectExtension = LinkExt[0];

	if ( !_wcsicmp( TargetExt, L".com" ) )					//	if the target ends in .com,
		CorrectExtension = LinkExt[1];						//	assume it's a dos executable and make the shortcut a .pif
	else if ( !_wcsicmp( TargetExt, L".exe" ) )				//  if the target ends in .exe
		if ( IsAFile( Target ) ) {							//  and it actually exists,
			DWORD bintype = 0xffffffff;
			GetBinaryType( Target, &bintype );				//  get the executable type;
			if ( bintype == SCS_DOS_BINARY )				//  if it's a dos program,
				CorrectExtension = LinkExt[1];				//  make the shortcut a .pif
		}

	if ( Ext[0] == '\0' )
		wcscat_s( Filename, MAX_FILENAME_LEN, CorrectExtension );
	else if ( _wcsicmp( Ext, CorrectExtension ) && Target[0] ) {
		DisplayErrorHeader();
		_wcsupr_s( CorrectExtension, SHORT_BUF_LEN );
		Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Filename must end in %s: \"%s\"\r\n", CorrectExtension, Filename );
		return 1;
	}


	FileExists = IsAFile( Filename );

	if ( !FileExists && IconFile[0] )
		if ( IconIndex == UINT_MAX )
			IconIndex = 0;


	if ( Debug ) {
		wchar_t temp[SHORT_BUF_LEN]		= L"";

		Printf( L"Filename:     \"%s\"\r\n", Filename );

		if ( SymbolicName )
			Printf( L"Target:       <%s>\r\n", Target );
		else
			Printf( L"Target:       \"%s\"\r\n", Target );

		Printf( L"Args:         \"%s\"\r\n", Args );
		Printf( L"Comment:      \"%s\"\r\n", Comment );
		Printf( L"Directory:    \"%s\"\r\n", Directory );

		GetStartModeString( StartMode, temp );
		Printf( L"StartMode:    %s\r\n", temp );

		if ( Hotkey < 0 )
			temp[0] = '\0';
		else
			GetHotkeyName( Hotkey, temp );

		Printf( L"Hotkey:       %s\r\n", temp );

		Printf( L"Icon:         \"%s\", %d\r\n", IconFile, IconIndex );
		Printf( L"NewUAC:       %d\r\n", NewUAC );


		if ( SetConsoleProps ) {
			if ( ConsolePropsChanges.FontName[0] )
				Printf( L"Font name:    \"%s\"\r\n", ConsolePropsChanges.FontName );

			if ( ConsolePropsChanges.FontY )
				Printf( L"Font size:    %u \u00d7 %u\r\n", ConsolePropsChanges.FontX, ConsolePropsChanges.FontY );

			if ( ConsolePropsChanges.FontWeight )
				Printf( L"Font weight:  %u\r\n", ConsolePropsChanges.FontWeight );

			if ( ConsolePropsChanges.BufferX && ConsolePropsChanges.BufferY )
				Printf( L"Buffer size:  %u \u00d7 %u\r\n", ConsolePropsChanges.BufferX, ConsolePropsChanges.BufferY );

			if ( ConsolePropsChanges.WindowX && ConsolePropsChanges.WindowY )
				Printf( L"Window size:  %u \u00d7 %u\r\n", ConsolePropsChanges.WindowX, ConsolePropsChanges.WindowY );

			if ( ConsolePropsChanges.CursorSize )
				Printf( L"Cursor size:  %u\r\n", ConsolePropsChanges.CursorSize );

			if ( ConsolePropsChanges.QuickEdit )
				Printf( L"QuickEdit:    %s\r\n", EnabledStr[ConsolePropsChanges.QuickEdit & 1] );

			if ( ConsolePropsChanges.InsertMode )
				Printf( L"Insert mode:  %s\r\n", EnabledStr[ConsolePropsChanges.InsertMode & 1] );

			if ( ConsolePropsChanges.AutoPosition )
				Printf( L"Autoposition: %s\r\n", EnabledStr[ConsolePropsChanges.AutoPosition & 1] );

			if ( ConsolePropsChanges.UseOrigin )
				Printf( L"Window pos:   %u, %u\r\n", ConsolePropsChanges.OriginX, ConsolePropsChanges.OriginY );

			if ( ConsolePropsChanges.FillColor )
				Printf( L"Fill color:   0x%04X\r\n", ConsolePropsChanges.FillColor );

			if ( ConsolePropsChanges.PopupColor )
				Printf( L"Popup color:  0x%04X\r\n", ConsolePropsChanges.PopupColor );

			for ( unsigned int i = 0; i < 16; i++ )
				if ( ConsolePropsChanges.ColorTable[i] )
					Printf( L"Color #%2u:    #%06x\r\n", i, RgbToBgr( ConsolePropsChanges.ColorTable[i] ) );
		}
	}


	if ( !FileExists && ( Target[0] == '\0' ) ) {
		DisplayErrorHeader();
		Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"You must specify a target when creating a shortcut.\r\n" );
		return 1;
	}

	if ( FileExists) {
		Attributes = GetFileAttributes( Filename );

		if ( Attributes & FILE_ATTRIBUTE_READONLY ) {
			if ( OverwriteReadOnly )
				SetFileAttributes( Filename, Attributes & ~FILE_ATTRIBUTE_READONLY );
			else {
				DisplayErrorHeader();
				Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"File is read-only: \"%s\"\r\n", Filename );
				return 2;
			}
		}
	}


	IShellLink *ShellLink = NULL;
	IPersistFile *Persist = NULL;

	if ( FAILED( CoCreateInstance( CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, IID_IShellLink, (LPVOID*) &ShellLink ) ) ) {
		DisplayErrorHeader();
		Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Can\u2019t create shortcut instance\r\n" );

		if ( Attributes & FILE_ATTRIBUTE_READONLY )
			SetFileAttributes( Filename, Attributes );

		return 2;
	}

	if ( FAILED( ShellLink->QueryInterface( IID_IPersistFile, (void**) &Persist ) ) ) {
		DisplayErrorHeader();
		Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Can\u2019t create PersistFile instance\r\n" );
		ShellLink->Release();

		if ( Attributes & FILE_ATTRIBUTE_READONLY )
			SetFileAttributes( Filename, Attributes );

		return 2;
	}

	if ( FileExists ) {
		if ( FAILED( Persist->Load( Filename, STGM_READ ) ) ) {
			DisplayErrorHeader();
			Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Can\u2019t load file \"%s\"\r\n", Filename );
			Persist->Release();
			ShellLink->Release();

			if ( Attributes & FILE_ATTRIBUTE_READONLY )
				SetFileAttributes( Filename, Attributes );

			return 2;
		}
	}
	else if ( FixVistaKnownFolderBullshit && ( OSVerInfo.dwMajorVersion >= 6 ) ) {		//  work around annoying vista misbehavior:
		DWORD LinkFlags = 0;
		IShellLinkDataList *DataLink = NULL;
		ShellLink->QueryInterface( IID_IShellLinkDataList, (void**) &DataLink );

		if ( DataLink ) {
			LinkFlags = SLDF_DISABLE_KNOWNFOLDER_RELATIVE_TRACKING;
			DataLink->SetFlags( LinkFlags );
			DataLink->Release();
		}
	}


	//	Make changes....

	if ( Target[0] ) {

		if ( SymbolicName ) {
			ShellLink->SetIDList( IDList );
			ILFree( IDList );
		}
		else
			ShellLink->SetPath( Target );
	}

	if ( SetArgs )
		ShellLink->SetArguments( Args );

	if ( SetDirectory )
		ShellLink->SetWorkingDirectory( Directory );

	if ( SetComment )
		ShellLink->SetDescription( Comment );

	if ( StartMode )
		ShellLink->SetShowCmd( StartMode );

	if ( Hotkey >= 0 )
		ShellLink->SetHotkey( Hotkey );

	if ( !SetIconFile && ( IconIndex != UINT_MAX ) ) {
		int dummy = 0;
		ShellLink->GetIconLocation( IconFile, MAX_FILENAME_LEN, &dummy );

		if ( IconFile[0] == '\0' )
			IconIndex = UINT_MAX;
		else
			SetIconFile = TRUE;
	}

	if ( SetIconFile ) {
		if ( ( IconIndex == UINT_MAX ) || ( IconFile[0] == '\0' ) )
			IconIndex = 0;

		ShellLink->SetIconLocation( IconFile, IconIndex );
	}

	if ( NewUAC && ( OSVerInfo.dwMajorVersion >= 6 ) ) {
		DWORD LinkFlags = 0;
		IShellLinkDataList *DataLink = NULL;
		ShellLink->QueryInterface( IID_IShellLinkDataList, (void**) &DataLink );
		DataLink->GetFlags( &LinkFlags );

		if ( NewUAC == 1 )
			LinkFlags &= ~SLDF_RUNAS_USER;
		else if (NewUAC == 2 )
			LinkFlags |= SLDF_RUNAS_USER;

		if ( DataLink ) {
			DataLink->SetFlags( LinkFlags );
			DataLink->Release();
		}
	}

	if ( SetConsoleProps )
		UpdateConsoleProps( ShellLink, &ConsolePropsChanges );
	
	if ( FAILED( Persist->Save( Filename, TRUE ) ) ) {
		DisplayErrorHeader();
		Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Can\u2019t save file \"%s\"\r\n", Filename );
		Persist->Release();
		ShellLink->Release();

		if ( Attributes & FILE_ATTRIBUTE_READONLY )
			SetFileAttributes( Filename, Attributes );

		return 2;
	}

	// Persist->SaveCompleted( Filename );

	Persist->Release();
	ShellLink->Release();

	if ( Attributes & FILE_ATTRIBUTE_READONLY )
		SetFileAttributes( Filename, Attributes );

	return 0;
}



wchar_t GetCommandSep()
{
	wchar_t temp[SHORT_BUF_LEN]			= L"%@option[commandsep]";


	ExpandVariables( temp, 1 );

	if ( temp[0] && !temp[1] )
		return temp[0];

	return '&';
}



wchar_t GetSynEscChar()
{
	wchar_t temp[SHORT_BUF_LEN]			= L"%@option[escapechar]";


	ExpandVariables( temp, 1 );

	if ( temp[0] && !temp[1] )
		return temp[0];

	return '^';
}



int GetEscChars( LPTSTR Buffer, size_t buflen, unsigned int *outFlags )
{
	if ( !Buffer || !buflen )
		return -1;


	wchar_t temp[SHORT_BUF_LEN]		= L"";

	wchar_t CommandSep	= GetCommandSep();
	wchar_t SynEscChar	= GetSynEscChar();
	unsigned int t		= 0;
	size_t len			= 0;
	wchar_t *sep1		= NULL;


	wcscpy_s( Buffer, buflen, UnsafeChars );
	len = wcslen( Buffer );

	if ( CommandSep ) {
		if ( !wcschr( Buffer, CommandSep ) ) {
			if ( len < ( buflen - 1 ) ) {
				Buffer[len++]	= CommandSep;
				Buffer[len]		= '\0';
			}
		}
	}

	if ( SynEscChar ) {
		if ( !wcschr( Buffer, SynEscChar ) ) {
			if ( len < ( buflen - 1 ) ) {
				Buffer[len++]	= SynEscChar;
				Buffer[len]		= '\0';
			}
		}
	}

	GetEnvironmentVariable( EscCharsVarName, Buffer + len, (DWORD) ( buflen - len ) );

	if ( outFlags ) {
		temp[0] = '\0';
		GetEnvironmentVariable( EscFlagsVarName, temp, SHORT_BUF_LEN );

		if ( temp[0] ) {
			if ( iswdigit( temp[0] ) ) {
				if ( ParseInt( temp, &t, &sep1 ) )
					t = 0;
				else if ( *sep1 )
					t = 0;
			}

			*outFlags = t;
		}
	}

	return 0;
}



int SCInfo_Copy( LPTSTR Source, LPTSTR Destination, unsigned int Flags )
{
	if ( !Source || !Destination )
		return -1;


	wchar_t EscChars[SHORT_BUF_LEN]			= L"";
	unsigned int EscFlags					= FLAG_ESCAPE_ALL_CONTROL | FLAG_ESCAPE_USE_NONSTD;


	if ( Flags & SCINFO_ESCAPIFY ) {
		GetEscChars( EscChars, SHORT_BUF_LEN, &EscFlags );
		Escapify( Source, EscFlags, EscChars, MAX_FILENAME_LEN );
	}
	else if ( Flags & SCINFO_SAFECHARS )
		MakeStringSafe( Source );

	if ( Flags & SCINFO_NO_QUOTES )
		wcscpy_s( Destination, MAX_FILENAME_LEN, Source );
	else {
		wcscpy_s( Destination, MAX_FILENAME_LEN, L"\"" );
		wcscat_s( Destination, MAX_FILENAME_LEN, Source );
		wcscat_s( Destination, MAX_FILENAME_LEN, L"\"" );
	}

	return 0;
}



DLLExports int WINAPI f_scinfo( LPTSTR inString )
{
	if ( !inString )
		return -1;

	ParseArgs( inString, PARSE_BREAK_COMMAS );

	wchar_t Filename[MAX_FILENAME_LEN]		= L"";
	wchar_t Arguments[MAX_FILENAME_LEN]		= L"";
	wchar_t Comment[MAX_FILENAME_LEN]		= L"";
	wchar_t Directory[MAX_FILENAME_LEN]		= L"";
	wchar_t IconFile[MAX_FILENAME_LEN]		= L"";
	int IconIndex							= 0;
	wchar_t Hotkey[SHORT_BUF_LEN]			= L"";
	wchar_t StartMode[SHORT_BUF_LEN]		= L"";
	wchar_t UACLevel[SHORT_BUF_LEN]			= L"";
	unsigned int LinkType					= LINK_TYPE_UNKNOWN;

	NT_CONSOLE_PROPS *ConsoleProps			= NULL;


	unsigned int Field						= 0;
	unsigned int Flags						= 0;

	wchar_t Target[MAX_FILENAME_LEN]		= L"";
	wchar_t StringBuffer[MAX_FILENAME_LEN]	= L"";



	if ( arglen[0] == 0 ) {
		DisplayErrorHeader();
		Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Missing filename\r\n" );
		return -1;
	}

	if ( CanonicalizeFilenameEx( arg[0], Filename ) )
		return -1;

	if ( arglen[1] ) {
		if ( ParseInt( arg[1], &Field, NULL ) ) {
			_wcsupr_s( arg[1], MAX_ARG_LEN );
			DisplayErrorHeader();
			Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Bad field number: \"%s\"\r\n", arg[1] );
			return -1;
		}
	}

	Flags	= Field & 0xff00;
	Field	&= 0x0ff;


	if ( GetShortcutParams( Filename, Target, Arguments, Comment, Directory, IconFile, &IconIndex, Hotkey, StartMode, UACLevel, &LinkType, &ConsoleProps ) )
		return -2;


	if ( ( Field >= 32 ) && ( Field <= 63 ) && !ConsoleProps ) {
		wcscpy_s( inString, MAX_ARG_LEN, L"-1" );
		return 0;
	}


	if ( ( Field >= 48 ) && ( Field <= 63 ) ) {
		if ( Flags & SCINFO_NO_QUOTES )
			wsprintf( inString, L"%u,%u,%u", GetRValue( ConsoleProps->ColorTable[Field - 48] ), GetGValue( ConsoleProps->ColorTable[Field - 48] ), GetBValue( ConsoleProps->ColorTable[Field - 48] ) );
		else if ( Flags & SCINFO_ESCAPIFY )
			wsprintf( inString, L"0x%06X", ConsoleProps->ColorTable[Field - 48] & 0x00ffffff );
		else
			wsprintf( inString, L"#%06x", RgbToBgr( ConsoleProps->ColorTable[Field - 48] ) );

		LocalFree( ConsoleProps );
		return 0;
	}


	switch ( Field ) {

	case 1 :
		SCInfo_Copy( Arguments, inString, Flags );
		break;

	case 2 :
		SCInfo_Copy( Directory, inString, Flags );
		break;

	case 3 :
		SCInfo_Copy( Comment, inString, Flags );
		break;

	case 4 :
		wcscpy_s( inString, SHORT_BUF_LEN, Hotkey );
		break;

	case 5 :
		wcscpy_s( inString, SHORT_BUF_LEN, StartMode );
		break;

	case 6 :
		SCInfo_Copy( IconFile, inString, Flags );
		break;

	case 7 :
		wsprintf( inString, L"%d", IconIndex );
		break;

	case 8 :
		wcscpy_s( inString, SHORT_BUF_LEN, UACLevel );
		break;

	case 31 :
		wsprintf( inString, L"%u", LinkType );
		break;

	case 32 :
		wsprintf( inString, L"%u", ConsoleProps->dwScreenBufferSize.X );
		break;

	case 33 :
		wsprintf( inString, L"%u", ConsoleProps->dwScreenBufferSize.Y );
		break;

	case 34 :
		wsprintf( inString, L"%u", ConsoleProps->dwWindowSize.X );
		break;

	case 35 :
		wsprintf( inString, L"%u", ConsoleProps->dwWindowSize.Y );
		break;

	case 36 :
		SCInfo_Copy( ConsoleProps->FaceName, inString, Flags );
		break;

	case 37 :
		wsprintf( inString, L"%u", ConsoleProps->dwFontSize.X );
		break;

	case 38 :
		wsprintf( inString, L"%u", ConsoleProps->dwFontSize.Y );
		break;

	case 39 :
		wsprintf( inString, L"%u", ConsoleProps->uFontWeight );
		break;

	case 40 :
		wsprintf( inString, L"%u", ConsoleProps->uCursorSize );
		break;

	case 41 :
		wsprintf( inString, L"%u", ConsoleProps->bQuickEdit );
		break;

	case 42 :
		wsprintf( inString, L"%u", ConsoleProps->bInsertMode );
		break;

	case 43 :
		wsprintf( inString, L"%u", ConsoleProps->bAutoPosition );
		break;

	case 44 :

		if ( Flags & 0x100 )
			wsprintf( inString, L"%u", ConsoleProps->wFillAttribute );
		else
			wsprintf( inString, L"0x%04X", ConsoleProps->wFillAttribute );

		break;

	case 45 :

		if ( Flags & 0x100 )
			wsprintf( inString, L"%u", ConsoleProps->wPopupFillAttribute );
		else
			wsprintf( inString, L"0x%04X", ConsoleProps->wPopupFillAttribute );

		break;

	case 46 :
		wsprintf( inString, L"%u,%u", ConsoleProps->dwWindowOrigin.X, ConsoleProps->dwWindowOrigin.Y );
		break;

	/*
	case 47 :
		wsprintf( inString, L"%u", ConsoleProps->bFullScreen );
		break;
	*/

	default :
		SCInfo_Copy( Target, inString, Flags );
	}


	if ( ConsoleProps )
		LocalFree( ConsoleProps );

	return 0;
}


#endif	//	MKSC_VER


/*
		1.1.0		2021-07-30

		1.2.0.0		2021-11-23
					In @SCINFO, adding 512 to the field number escapifies the
					return string.

		1.2.1.0		2021-11-23
					Added /Y to MKSC.

		1.3.0.0		2021-11-23
					Added /P to MKSC.

		1.3.1.0		2021-11-23
					Various changes to help make mksc a standalone plugin:
					#include "hotkeys.cpp"
					Moved DUMPSC_* flags in here where they belong
					Modified the help text to look better in a dialog box
					Included help text for the @SCINFO function

		1.3.2.0		2021-11-24
					Fixed a problem with SearchShellFolderForName() crashing.
					Renamed hotkeys.cpp to sc_hotkeys.cpp.

		1.3.3.0		2021-11-25
					Also #include ShlObj.h and shlwapi.h
					Moved all the funky canonicalization stuff out to a new
					file, CanonicalizeSpecial.cpp

		1.3.4.0		2021-11-27
					Now CanonicalizeFilenameEx() checks for unknown objects and
					objects which do not resolve to a directory.  MKSC and @SCINFO
					now check the return code from CanonicalizeFilenameEx() and
					abort on any error.

		1.3.5.0		2021-11-29
					Added the ability to decode installer 'Darwin' ID strings, and
					return either a product name or a GUID.

		1.3.6.0		2021-12-01
					MKSC:  Added /FB to include console buffer info if available
					@SCINFO:  Added fields 32 - 63 to return various console stuff
					@SCINFO:  Changed the SafeChars flag from 128 to 1024
					De-documented SafeChars support

		1.3.7.0		2021-12-08
					Reworked /N a bit; now /NC disables highlight, /NT prevents
					canonicalizing the target filename.

		1.3.7.1		2021-12-08
					Removed letter field specifiers from @SCINFO

		1.3.8.0		2021-12-09
					Many new /Bx... options to set console properties.

		1.3.9.0		2021-12-13
					Now /BKn: can accept multiple color names, separated by commas
					or semicolons, to define more than one color at a time.

		1.3.10.0	2021-12-15
					Added /FH to dump the console palette.  Renamed /BKn: to /BHn:
					(think H for Hue).

		1.3.11.0	2021-12-16
					Split /FB into /FB (buffer info) and /FF (font info).  Added /F?
					to list available fields.

		1.3.12.0	2021-12-17
					Now MKSC checks for Ctrl-C and Ctrl-Break while dumping shortcuts.
					(Previously this only happened during /P pauses.)  Also, MKSC now
					returns errorlevel 3 for user abort; it was -3.

		1.3.13.0	2021-12-18
					Added /NE to suppress many error messages while dumping files.

		1.3.14.0	2022-01-12
					Removed /X and /Y, replaced them with /AX: and /CX:

		1.3.14.1	2023-04-18
					Updated to latest version of ExpandEscapes.cpp.
					#define EXPAND_ESCAPES_REAL_BACKSPACE

		1.3.14.2	2023-06-13
					Removed calls to QueryIsFile().

		1.3.14.3	2023-06-13
					Moved MissingColonError() into MkScCmd.cpp.

*/
