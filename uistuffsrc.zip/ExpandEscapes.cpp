#ifndef EXPAND_ESCAPES_CPP
#define EXPAND_ESCAPES_CPP				1.1.6.1


#ifndef SURROGATE_MASK
#define SURROGATE_MASK					0xf800
#define SURROGATE_TEST_MASK				0xfc00
#define SURROGATE_VALUE_MASK			0x03ff
#define HIGH_SURROGATE					0xd800
#define LOW_SURROGATE					0xdc00
#define MAX_CODEPOINT					0x10ffff
#endif	//	SURROGATE_MASK

#define ESC_BUFFER_OVERFLOW				-999

#define FLAG_ESCAPE_ALL_NONASCII		0x0001
#define FLAG_ESCAPE_ALL_CONTROL			0x0002
#define FLAG_ESCAPE_USE_NONSTD			0x0004
#define FLAG_ESCAPE_SHORT_FORM_AT_END	0x0008



int ParseOctalEscape( LPCTSTR inValue, LPTSTR outBuffer, size_t BufSize )
{
	if ( !inValue || !outBuffer || !BufSize )
		return 0;

	if ( !iswdigit( inValue[0] ) )
		return 0;


	unsigned int Char			= 0;
	int digcount				= 0;
	size_t j					= wcslen( outBuffer );


	for ( int i = 0; i < 3; i++ ) {
		if ( ( inValue[i] < '0' ) || ( inValue[i] > '7' ) )
			break;

		Char = ( Char << 3 ) | ( inValue[i] - '0' );
		digcount++;
	}

	if ( !Char )
		return 0;

	if ( j < ( BufSize - 1 ) ) {
		outBuffer[j++]	= Char;
		outBuffer[j]	= '\0';
	}
	else
		return ESC_BUFFER_OVERFLOW;

	return digcount;
}



int ParseHexEscape( LPCTSTR inValue, LPTSTR outBuffer, size_t BufSize )
{
	if ( !inValue || !outBuffer || !BufSize )
		return 0;

	if ( !iswxdigit( inValue[0] ) )
		return 0;

	
	unsigned int Char			= 0;
	unsigned int digval			= 0;
	int digcount				= 0;
	wchar_t ch					= '\0';
	size_t j					= wcslen( outBuffer );


	for ( int i = 0; i < 4; i++ ) {
		ch = towupper( inValue[i] );

		if ( ( ch >= '0' ) && ( ch <= '9' ) )
			digval = ch - '0';
		else if ( ( ch >= 'A' ) && ( ch <= 'F' ) )
			digval = ch - 'A' + 10;
		else
			break;

		Char = ( Char << 4 ) | digval;
		digcount++;
	}

	if ( !Char )
		return 0;

	if ( j < ( BufSize - 1 ) ) {
		outBuffer[j++]	= Char;
		outBuffer[j]	= '\0';
	}
	else
		return ESC_BUFFER_OVERFLOW;

	return digcount;
}



int ParseDecEscape( LPCTSTR inValue, LPTSTR outBuffer, size_t BufSize )
{
	if ( !inValue || !outBuffer || !BufSize )
		return 0;

	if ( !iswdigit( inValue[0] ) )
		return 0;


	unsigned int Char			= 0;
	unsigned int digcount		= 0;
	size_t j					= wcslen( outBuffer );


	for ( int i = 0; i < 5; i++ ) {
		if ( ( inValue[i] < '0' ) || ( inValue[i] > '9' ) )
			break;

		Char = ( Char * 10 ) + ( inValue[i] - '0' );
		digcount++;
	}

	if ( !Char || ( Char > 0xffff ) )
		return 0;

	if ( j < ( BufSize - 1 ) ) {
		outBuffer[j++]	= Char;
		outBuffer[j]	= '\0';
	}
	else
		return ESC_BUFFER_OVERFLOW;

	return digcount;
}



int ParseUnicodeEscape( LPCTSTR inValue, int MaxDigits, LPTSTR outBuffer, size_t BufSize )
{
	if ( !inValue || !MaxDigits || !outBuffer || !BufSize )
		return 0;

	if ( !iswxdigit( inValue[0] ) )
		return 0;


	unsigned int CodePoint		= 0;
	unsigned int digval			= 0;
	int digcount				= 0;
	wchar_t ch					= '\0';
	wchar_t LowSurrogate		= '\0';
	wchar_t HighSurrogate		= '\0';
	size_t j					= wcslen( outBuffer );


	for ( int i = 0; i < MaxDigits; i++ ) {
		ch = towupper( inValue[i] );

		if ( ( ch >= '0' ) && ( ch <= '9' ) )
			digval = ch - '0';
		else if ( ( ch >= 'A' ) && ( ch <= 'F' ) )
			digval = ch - 'A' + 10;
		else
			break;

		CodePoint = ( CodePoint << 4 ) | digval;
		if ( CodePoint > MAX_CODEPOINT )
			return 0;

		digcount++;
	}


	if ( !CodePoint || ( ( CodePoint & SURROGATE_MASK ) == HIGH_SURROGATE ) )
		return 0;


	if ( CodePoint < 0x10000 ) {
		if ( j < ( BufSize - 1 ) ) {
			outBuffer[j++]	= CodePoint;
			outBuffer[j]	= '\0';
		}
		else
			return ESC_BUFFER_OVERFLOW;
	}
	else {
		CodePoint -= 0x10000;
		LowSurrogate	= ( CodePoint & SURROGATE_VALUE_MASK ) | LOW_SURROGATE;
		HighSurrogate	= ( CodePoint >> 10 ) | HIGH_SURROGATE;

		if ( j < ( BufSize - 2 ) ) {
			outBuffer[j++]	= HighSurrogate;
			outBuffer[j++]	= LowSurrogate;
			outBuffer[j]	= '\0';
		}
		else
			return ESC_BUFFER_OVERFLOW;
	}

	return digcount;
}



#ifdef EXPAND_ESCAPES_TILDE_EMOJIS

int ParseEmojiEscape( LPCTSTR inValue, LPTSTR outBuffer, size_t BufSize )
{
	if ( !inValue || !outBuffer || !BufSize )
		return 0;

	if ( !iswxdigit( inValue[0] ) )
		return 0;


	unsigned int Char			= 0;
	unsigned int digval			= 0;
	int digcount				= 0;
	wchar_t ch					= '\0';
	size_t j					= wcslen( outBuffer );


	for ( int i = 0; i < 2; i++ ) {
		ch = towupper( inValue[i] );

		if ( ( ch >= '0' ) && ( ch <= '9' ) )
			digval = ch - '0';
		else if ( ( ch >= 'A' ) && ( ch <= 'F' ) )
			digval = ch - 'A' + 10;
		else
			break;

		Char = ( Char << 4 ) | digval;
		digcount++;
	}

	if ( Char > 0x4f )
		return 0;

	if ( j < ( BufSize - 2 ) ) {
		outBuffer[j++]	= 0xd83d;
		outBuffer[j++]	= 0xde00 | Char;
		outBuffer[j]	= '\0';
	}
	else
		return ESC_BUFFER_OVERFLOW;

	return digcount;
}

#endif	//	EXPAND_ESCAPES_TILDE_EMOJIS



int ExpandEscapes( LPTSTR String, size_t buflen, DWORD *CharFrom = NULL )
{
	if ( !String || ( buflen < 20 ) )
		return -1;

	if ( String[0] == '\0' )
		return 0;


	wchar_t *temp		= NULL;
	wchar_t ch2			= '\0';
	size_t j			= 0;
	DWORD *boc			= NULL;
	DWORD ses			= 0;
	int k				= 0;
	int trv				= 0;
	size_t len			= 0;


	temp = (wchar_t*) malloc( buflen * sizeof( wchar_t ) );
	if ( !temp )
		return -2;

	temp[0] = '\0';

	if ( CharFrom ) {
		boc = (DWORD*) calloc( buflen, sizeof( DWORD ) );
		if ( !boc ) {
			free( temp );
			return -2;
		}
	}


	for ( wchar_t *ch = String; *ch; ch++ ) {

		ses = (DWORD) ( ch - String );

		if ( *ch == '\\' ) {
			ch++;
			ch2 = '\0';

			switch ( *ch ) {

			case 'a' :

				ch2 = '\a', k++;
				break;

			case 'b' :

#ifdef EXPAND_ESCAPES_REAL_BACKSPACE

				ch2 = '\b', k++;
				break;

#else	//	EXPAND_ESCAPES_REAL_BACKSPACE

				if ( j ) {
					if ( ( temp[j - 1] != '\n' ) && ( temp[j - 1] != '\r' ) ) {
						BOOL bigchar		= FALSE;

						if ( j > 1 )
							if ( ( ( temp[j - 1] & SURROGATE_TEST_MASK ) == LOW_SURROGATE ) && ( ( temp[j - 2] & SURROGATE_TEST_MASK ) == HIGH_SURROGATE ) )
								bigchar = TRUE;

						if ( bigchar ) {
							temp[--j] = 0;
							temp[--j] = 0;

							if ( boc ) {
								boc[j]		= 0;
								boc[j + 1]	= 0;
							}
						}
						else {
							temp[--j] = '\0';

							if ( boc )
								boc[j] = 0;
						}
					}
				}
				k++;
				break;

#endif	//	EXPAND_ESCAPES_REAL_BACKSPACE

			case 'c' :

				ch2 = ',', k++;
				break;

			case 'e' :

				ch2 = 0x1b, k++;
				break;

			case 'f' :

				ch2 = '\f', k++;
				break;

			case 'k' :

				ch2 = 0x60, k++;
				break;

			case 'n' :

				ch2 = '\n', k++;
				break;

			case 'q' :

				ch2 = 0x22, k++;
				break;

			case 'r' :

				ch2 = '\r', k++;
				break;

			case 's' :
				ch2 = 0x20, k++;
				break;

			case 't' :

				ch2 = '\t', k++;
				break;

			case 'u' :

				trv = ParseUnicodeEscape( ch + 1, 4, temp, buflen );

				if ( trv == ESC_BUFFER_OVERFLOW )
					goto Overflow;
				else if ( trv ) {
					len = wcslen( temp );

					if ( boc )
						for ( size_t L = j; L < len; L++ )
							boc[L] = ses;

					ch += trv;
					j = len;
					k++;
				}
				else
					ch--;

				break;

			case 'U' :

				trv = ParseUnicodeEscape( ch + 1, 8, temp, buflen );

				if ( trv == ESC_BUFFER_OVERFLOW )
					goto Overflow;
				else if ( trv ) {
					len = wcslen( temp );

					if ( boc )
						for ( size_t L = j; L < len; L++ )
							boc[L] = ses;

					ch += trv;
					j = len;
					k++;
				}
				else
					ch--;

				break;

			case 'v' :

				ch2 = '\v', k++;
				break;

			case 'x' :

				trv = ParseHexEscape( ch + 1, temp, buflen );

				if ( trv == ESC_BUFFER_OVERFLOW )
					goto Overflow;
				else if ( trv ) {
					if ( boc )
						boc[j] = ses;

					ch += trv;
					j = wcslen( temp );
					k++;
				}
				else
					ch--;

				break;

			case '#' :

				trv = ParseDecEscape( ch + 1, temp, buflen );

				if ( trv == ESC_BUFFER_OVERFLOW )
					goto Overflow;
				else if ( trv ) {
					if ( boc )
						boc[j] = ses;

					ch += trv;
					j = wcslen( temp );
					k++;
				}
				else
					ch--;

				break;

#ifdef EXPAND_ESCAPES_TILDE_EMOJIS

			case '~' :

				trv = ParseEmojiEscape( ch + 1, temp, buflen );

				if ( trv == ESC_BUFFER_OVERFLOW )
					goto Overflow;
				else if ( trv ) {
					len = wcslen( temp );

					if ( boc )
						for ( size_t L = j; L < len; L++ )
							boc[L] = ses;

					ch += trv;
					j = len;
					k++;
				}
				else
					ch--;

				break;

#endif	//	EXPAND_ESCAPES_TILDE_EMOJIS

			case '0' :
			case '1' :
			case '2' :
			case '3' :
			case '4' :
			case '5' :
			case '6' :
			case '7' :

				trv = ParseOctalEscape( ch, temp, buflen );

				if ( trv == ESC_BUFFER_OVERFLOW )
					goto Overflow;
				else if ( trv ) {
					if ( boc )
						boc[j] = ses;

					ch = ch + trv - 1;
					j = wcslen( temp );
					k++;
				}

				break;

			default :

				ch2 = *ch;
			}

			if ( j >= ( buflen - 1 ) )
				goto Overflow;

			if ( ch2 ) {
				if ( boc )
					boc[j] = ses;

				temp[j++]	= ch2;
				temp[j]		= '\0';
			}
		}
		else {
			if ( j >= ( buflen - 1 ) )
				goto Overflow;
			
			if ( boc )
				boc[j] = ses;

			temp[j++]	= *ch;
			temp[j]		= '\0';
		}

		if ( *ch == '\0' )
			break;
	}
	

	wcscpy_s( String, buflen, temp );

	if ( CharFrom )
		memcpy( CharFrom, boc, ( j + 1 ) * sizeof( DWORD ) );

	free( temp );
	free( boc );
	return k;


Overflow:

	free( temp );
	free( boc );
	return ESC_BUFFER_OVERFLOW;
}



int _MkEsc( wchar_t ch, LPTSTR buf )
{
	if ( !ch || !buf )
		return -1;


	buf[0] = '\\';
	buf[1] = ch;
	buf[2] = '\0';
	return 0;
}



int Escapify( LPTSTR String, unsigned int Flags, LPCTSTR UnsafeCharsList, size_t buflen )
{
	if ( !String || ( buflen < 20 ) )
		return -1;

	if ( String[0] == '\0' )
		return 0;


	wchar_t *temp			= NULL;
	wchar_t esc[12]			= L"";
	int ch					= 0;
	BOOL unsafe				= FALSE;
	BOOL escapeme			= FALSE;
	BOOL endfix				= !( Flags & FLAG_ESCAPE_SHORT_FORM_AT_END );
	size_t j				= 0;
	int k					= 0;


	temp = (wchar_t*) malloc( buflen * sizeof( wchar_t ) );
	if ( !temp )
		return -2;

	temp[0] = '\0';


	for ( wchar_t *t = String; *t; t++ ) {

		esc[0] = '\0';
		ch = *t;
		unsafe		= FALSE;
		escapeme	= FALSE;

		if ( ( ( ch & SURROGATE_TEST_MASK ) == HIGH_SURROGATE ) && ( ( t[1] & SURROGATE_TEST_MASK ) == LOW_SURROGATE ) ) {
			ch = ( ( ch & SURROGATE_VALUE_MASK ) << 10 ) | ( t[1] & SURROGATE_VALUE_MASK );
			ch += 0x10000;
			t++;
		}
		else if ( UnsafeCharsList )
			if ( wcschr( UnsafeCharsList, ch ) )
				unsafe = TRUE;


		if ( ( ch < 0x20 ) || ( ch == 0x7f ) ) {		//	C0 controls and DEL :
			switch ( ch ) {

			case '\a' :

				_MkEsc( 'a', esc );
				break;

			case '\b' :

				_MkEsc( 'b', esc );
				break;

			case '\f' :

				_MkEsc( 'f', esc );
				break;

			case '\n' :

				_MkEsc( 'n', esc );
				break;

			case '\r' :

				_MkEsc( 'r', esc );
				break;

			case '\t' :

				_MkEsc( 't', esc );
				break;

			case '\v' :

				_MkEsc( 'v', esc );
				break;

			default:

				if ( iswxdigit( t[1] ) || ( endfix && ( t[1] == '\0' ) ) )
					swprintf( esc, 12, L"\\x%04x", ch );
				else
					swprintf( esc, 12, L"\\x%02x", ch );
			}
		}
		else if ( ch == '\\' )								//	backslash :
			_MkEsc( '\\', esc );
		else if ( ch >= 0x10000 ) {							//	all Unicode above the BMP :
			if ( iswxdigit( t[1] ) || ( endfix && ( t[1] == '\0' ) ) )
				swprintf( esc, 12, L"\\U%08x", ch );
			else
				swprintf( esc, 12, L"\\U%x", ch );
		}
		else if ( ( ch >= 0x80 ) && ( ch <= 0xa0 ) )		// C1 controls and NBSP :
			escapeme = TRUE;
		else if ( unsafe )									//	user-defined unsafe characters :
			escapeme = TRUE;
		else if ( ( Flags & FLAG_ESCAPE_ALL_NONASCII ) && ( ch >= 0x80 ) )		//	anything not ASCII :
			escapeme = TRUE;
		else if ( ( Flags & FLAG_ESCAPE_ALL_CONTROL ) && iswcntrl( ch ) )		//	any control character :
			escapeme = TRUE;


		if ( escapeme ) {
			if ( iswxdigit( t[1] ) || ( endfix && ( t[1] == '\0' ) ) )
				swprintf( esc, 12, L"\\u%04x", ch );
			else
				swprintf( esc, 12, L"\\u%02x", ch );

			if ( Flags & FLAG_ESCAPE_USE_NONSTD ) {
				switch ( ch ) {

				case 0x1b :

					_MkEsc( 'e', esc );
					break;

				case 0x22 :

					_MkEsc( 'q', esc );
					break;

				case ',' :

					_MkEsc( 'c', esc );
					break;

				case '`' :

					_MkEsc( 'k', esc );
					break;
				}
			}
		}


		if ( esc[0] ) {
			if ( ( j + wcslen( esc ) ) >= buflen )
				goto Overflow;

			wcscat_s( temp, buflen, esc );
			j += wcslen( esc );
			k++;
		}
		else {
			if ( j >= ( buflen - 1 ) )
				goto Overflow;

			temp[j++]	= ch;
			temp[j]		= '\0';
		}
	}


	wcscpy_s( String, buflen, temp );
	free( temp );
	return k;


Overflow:

	free( temp );
	return ESC_BUFFER_OVERFLOW;
}


#endif	//	EXPAND_ESCAPES_CPP


/*

1.1.0		2021-08-12
			Adds Escapify().

1.1.1		2021-10-02
			Adds \#nnnnn as a decimal character escape.  Better handling of some malformed
			escape sequences.

1.1.2		2021-11-23
			When generating numeric escapes, a following null as well as a digit prevents
			generating the short form (because you never know what might be appended....)
			Added FLAG_ESCAPE_USE_NONSTD to allow generating \e and \q.

1.1.4.0		2022-12-08
			Added an option for \b to expand to a regular ASCII backspace
			character, instead of deleting the previous character.  Define
			EXPAND_ESCAPES_REAL_BACKSPACE to enable this behavior.

1.1.5.0		2023-03-22
			When \b follows a surrogate pair, delete both surrogate chars, not just the
			one.  Tweaks to Escapify() to always use long form at the end of the string;
			added a new flag FLAG_ESCAPE_SHORT_FORM_AT_END to disable this behavior.
			Added an optional CharFrom arg to ExpandEscapes() for use by @expfind.

1.1.5.1		2023-03-23
			When FLAG_ESCAPE_USE_NONSTD is set, escapify comma as \c.

1.1.6.0		2023-03-23
			Added optional escape \~nn for emojis.  nn is two hex digits, 00 to 4F.
			Define EXPAND_ESCAPES_TILDE_EMOJIS to enable this escape.

1.1.6.1		2023-03-24
			FLAG_ESCAPE_USE_NONSTD now supports \k for the grave accent.

*/
