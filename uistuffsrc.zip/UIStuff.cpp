
//		UIStuff plugin:  Miscellaneous user-interface features for TCC


#define UNICODE					1
#define _UNICODE				1

#define _CRT_RAND_S

#include <stdio.h>
#include <tchar.h>

#include <windows.h>
#include <mmsystem.h>
#include <mmreg.h>
#include <gdiplus.h>
#include <shlobj.h>
#include <shellapi.h>
#include <shlwapi.h>
#include <math.h>
#include <Psapi.h>


#include "PlugIn.h"
#include "TakeCmd.h"

using namespace Gdiplus;



#define VER_MAJOR				0
#define VER_MINOR				79
#define VER_BUILD				1
#define VER_PATCH				0


#define PLUGIN_NAME				L"UIStuff"

#ifdef _WIN64
#define PLATFORM				L"x64"
#else
#define PLATFORM				L"x86"
#endif

#define MACRO_EXP( arg )		#arg
#define MACRO_STR( arg )		MACRO_EXP( arg )


#define MAX_ARG_LEN				8192
#define MAX_ARGS				1024
#define SHORT_BUF_LEN			1024
#define MAX_FILENAME_LEN		16384

#define MAX_DISPLAY_NAME_LEN	128

#define ERRHANDLE GetStdHandle( STD_ERROR_HANDLE )

#define BS						0x08
#define LF						0x0a
#define CR						0x0d
#define ESC						0x1b
#define QUOTE					0x22


#define MAX_DISPLAY_MONITORS	1024

#define WP_NO_CHANGE			0
#define WP_CENTERED				1
#define WP_STRETCHED			2
#define WP_TILED				3
#define WP_BEST_GUESS			1024

#define RECURSE_NORMAL			1
#define RECURSE_NO_JUNCTIONS	2
#define RECURSE_NO_HIDDEN_DIRS	4
#define RECURSE_NO_SYSTEM_DIRS	8
#define RECURSE_NO_ERROR_MSGS	64

#define PIN_TO_START_MENU		0
#define PIN_TO_TASKBAR			1
#define PIN_UNPIN				2

#define MIN_X_RES				320
#define MAX_X_RES				16384
#define MIN_Y_RES				200
#define MAX_Y_RES				16384
#define MIN_REFRESH				30
#define MAX_REFRESH				1024

#define SR_FLAG_PROMPT			1
#define SR_FLAG_SAVE			2
#define SR_FLAG_NO_REPORT		4
#define SR_FLAG_VERBOSE			8

#define VERB_UNKNOWN			0
#define VERB_USER				1
#define VERB_SYSTEM				2
#define VERB_BOTH				3
#define VERB_F_SAFECHARS		128

#define FFT_VECTOR				128
#define FFT_NO_FAMILY			0xf0

#define FFT_SHOW_LINE_NOS		1
#define FFT_SHOW_TYPES			2
#define FFT_SHOW_SCRIPTS		4
#define FFT_SHOW_PAF			8

#define MAX_CONSOLE2_WINDOWS	32

#ifndef ASSOCF_IS_PROTOCOL
#define ASSOCF_IS_PROTOCOL		0x00001000
#endif	//	ASSOCF_IS_PROTOCOL


HINSTANCE MyDLLHandle			= NULL;

OSVERSIONINFOEXW OSVerInfo;


ULONG_PTR GdiplusToken;
GdiplusStartupInput StartupInput;


typedef BOOL ( WINAPI _GetFontResourceInfoProc ) ( LPCTSTR Filename, LPDWORD BufferSize, LPVOID Buffer, DWORD QueryType );
HMODULE Gdi32Dll		= NULL;
_GetFontResourceInfoProc *GetFontResourceInfo	= NULL;


const wchar_t TCmdClass[]					= L"Afx:00400000:8:";
const wchar_t TCmdClass2[]					= L"XTPMainFrame";
const int TCmdClassLen						= 15;
const wchar_t Console2Class[]				= L"Console_2_Main";
const wchar_t ConEmuClass[]					= L"VirtualConsoleClass";

HWND Console2WindowHandle	= NULL;

DWORD ForegroundLockTimeoutSave				= 0;


const wchar_t ClipboardFilename[] = L"clip:";

const wchar_t StyleName[4][10] = { L"no change", L"centered", L"stretched", L"tiled" };


wchar_t PluginFeatures[] = L"bgcolor,conicon,installfonts,listfonts,minimizeall,mksc,\
screenres,scrnsaver,setfocus,setmousepos,shellverb,soundvol,uistuffhelp,wallpaper,\
_bgcolor,_bgcolorname,_browser,_monitors,_mousex,_mousey,_mute,_muted,_safemode,_shortcut,\
_soundvol,_ssvrname,_ssvrtime,_ssvrup,_volume,_wallpaper,_wallstyle,_winosver,\
@firstfont,@imgcolor,@nextfont,@rgbcompl,@rgblum,@scinfo,@screenres,@shellverb,@shfolder";




const wchar_t InstallFontsHelpText[] = L"Install font files.\n\
\n\
INSTALLFONTS /O /X filename...\r\n\
\n\
\t/O   overwrite existing files\n\
\t/X   delete source files after install\n\
\n\
You must specify at least one filename.  Wildcards  \n\
are supported.\n";


const wchar_t BGColorHelpText[] = L"Display or change the desktop color.\n\
\n\
BGCOLOR /S color\r\n\n\
\t/S   Save to the registry\n\n\
The new color may be specified in decimal or hex, as one\n\
value or three; or as a W3C color name.\n";


const wchar_t ConIconHelpText[] = L"Set the icon for the console window.\n\
\n\
CONICON /C /D /I:n filename\r\n\n\
\t/C   use the icon in TCC.EXE; same as \"%_cmdspec\"\n\
\t/D   restore the system default console icon\n\
\t/I:  icon index within the file (0 = first)\n\
\n\
This command is only useful in a standalone console window.  In a\n\
Take Command tab, changes to the icon are not visible.\n";


const wchar_t ListFontsHelpText[] = L"List available fonts.\n\
\n\
LISTFONTS /C: /D: /F: /P: /T: name\r\n\n\
\t/C:   character set\n\
\t/D:   display more info:  Lines Family Script Type Kount\n\
\t/F:   by family:  Roman Swiss Modern Hand Deco None\n\
\t/P:   pitch:  Fixed Variable\n\
\t/T:   font type:  Raster Vector Opentype Truetype\n\
\n\
The name may contain wildcards; quote it if it contains spaces.\n";


const wchar_t MinimizeAllHelpText[] = L"Minimize or restore all windows.\n\
\n\
MINIMIZEALL /U\r\n\n\
\t/U   Undo the previous MINIMIZEALL\n";


const wchar_t ScreenResHelpText[] = L"Display or change the screen resolution.\n\
\n\
SCREENRES /A /C:bits /D /L /M:monitor /Q /R:rate /X:width /Y:height\r\n\n\
\t/A   show resolution for All monitors\n\
\t/C:  Color depth, bits per pixel\n\
\t/D   Don\u2019t save new settings in the registry\n\
\t/L   List available display modes\n\
\t/M:  Monitor number, 0-based\n\
\t/Q   Quietly (no confirmation prompt)\n\
\t/R:  Refresh rate in Hz\n\
\t/X:  new width in pixels\n\
\t/Y:  new height in pixels\n\n\
/X: and /Y: should be used together.  If none of /C: /R: /X:\n\
or /Y: is specified, the current settings will be displayed.\n";


const wchar_t ScrnSaverHelpText[] = L"Display or change the screen saver settings.\n\
\n\
SCRNSAVER /A /D /E /N /S /T:time /U filename\r\n\n\
\t/A   Activate (run) screen saver now\n\
\t/D   Disable screen saver\n\
\t/E   Enable screen saver\n\
\t/N   None (remove screen saver)\n\
\t/S   Secure (you must log in when screen saver exits)\n\
\t/T:  Timeout, in seconds or as MM:SS\n\
\t/U   Unsecure (login not required when screen saver exits)\n\n\
If the filename has no path, the system directory will be\n\
assumed; if it has no extension, .SCR will be appended.\n";


const wchar_t SetFocusHelpText[] = L"Give focus to the specified window.\n\
\n\
SETFOCUS /C:class /Q \"title\"\r\n\n\
\t/C:  the window Class name\n\
\t/Q   Quietly\n\n\
The title and class names may contain wildcards.  If no title or\n\
class is specified, TCC will be given the focus.\n";


const wchar_t SetMousePosHelpText[] = L"Move the mouse pointer to the specified screen coordinates.\n\
\n\
SETMOUSEPOS /Q /X:x /Y:y\r\n\n\
\t/Q   Quietly\n\
\t/X:  new horizontal position\n\
\t/Y:  new vertical position\n\
\n\
The range of valid coordinates will depend on your screen size.  \n";


/*
const wchar_t SetThemeHelpText[] = L"Apply a Windows theme file.\n\
\n\
SETTHEME filename\r\n\n\
The filename is required.\n  ";
*/


const wchar_t ShellVerbHelpText[] = L"Display or change file associations and shell verbs.\n\
\n\
SHELLVERB /C /D:string /M:string /Q /R /S /U /V:verb /Z ftype=command\r\n\n\
\t/C   replace any safeChars in command with ASCII\n\
\t/D:  Description of file type\n\
\t/M:  Menu name for verb; may include & to set hotkey\n\
\t/Q   Quietly\n\
\t/R   Remove file association, filetype, or shell verb\n\
\t/S   set/display System-wide settings (default)\n\
\t/U   set/display User settings\n\
\t/V:  Verb to display or change\n\
\t/Z   make the specified verb the default\n\
\n\
Ftype may be either a filename extension (beginning with a period),\n\
or else a descriptive file type.  It\u2019s probably best if ftype and\n\
verb do not contain spaces.\n";


#ifdef WIN7PIN_CMDS

const wchar_t StartPinHelpText[] = L"Pin or unpin a shortcut to the Windows 7 Start menu.\n\
\n\
STARTPIN /U filename\r\n\n\
\t/U   Unpin\n\n\
The filename is required; it must end in .LNK.  Supply a\n\
complete pathname, even to unpin.\n";


const wchar_t TaskBarPinHelpText[] = L"Pin or unpin a shortcut to the Windows 7 taskbar.\n\
\n\
TASKBARPIN /U filename\r\n\n\
\t/U   Unpin\n\n\
The filename is required; it must end in .LNK.  Supply a\n\
complete pathname, even to unpin.\n";

#endif	//	WIN7PIN_CMDS

const wchar_t UIStuffHelpHelpText[] = L"Open the UIStuff plugin help file.\n\
\n\
UISTUFFHELP topic\r\n\n\
Opens this plugin\u2019s help file to the specified topic.\n\
If no topic is given, opens the Overview page by default.  \n";


const wchar_t WallpaperHelpText[] = L"Display or change the desktop wallpaper.\n\
\n\
WALLPAPER /B /C /N /R /S /T filename\r\n\n\
\t/B   Best style, based on image size\n\
\t/C   Centered\n\
\t/N   None (remove wallpaper)\n\
\t/R   Recurse\n\
\t/S   Stretched\n\
\t/T   Tiled\n\n\
The filename must end in .BMP, .JPG, .PNG, .GIF or .TIF.  If no\n\
arguments are specified, the current filename will be displayed.\n";



const wchar_t ErrorString[] = L"*Error*";
const wchar_t NoneString[]  = L"*None*";


#include "w3ccolors.cpp"



const wchar_t _FontTypeStr[4][3] = { L"VF", L"RF", L"OT", L"TT" };

struct _FindFontInfo {
	LPTSTR WildSpec;
	DWORD ReqFontType;
	unsigned int ReqPitchAndFamily;
	DWORD Flags;
	DWORD Index;
	ENUMLOGFONTEX FontInfo;
};

struct _FontListItem {
	_FontListItem *Next;
	wchar_t Name[1];
};


_FontListItem *FirstFont = NULL, *LastFont = NULL;


#define NUM_FONT_EXTENSIONS 4

const wchar_t FontExtension[NUM_FONT_EXTENSIONS][5]		= { L".fon", L".fnt", L".ttf", L".otf" };



int DisplayErrorHeader()
{
	wchar_t shortbuf[MAX_ARG_LEN] = L"%_batch";

	Qprintf( ERRHANDLE, L"%s plugin: ", PLUGIN_NAME );

	ExpandVariables( shortbuf, 1 );
	if ( shortbuf[0] == '0' )
		return 0;

	wcscpy_s( shortbuf, MAX_ARG_LEN, L"%_batchname [%_batchline]  " );
	ExpandVariables( shortbuf, 1 );
	Qprintf( ERRHANDLE, shortbuf );

	return 0;
}



//	Deletes all items in a linked list, and zeros the pointer to the first item:

int FreeLinkedList( void **Pointer )
{
	if ( Pointer == NULL )
		return -1;

	size_t *This = (size_t*) *Pointer, Next = NULL;

	while ( This ) {
		Next = *This;
		free( This );
		This = (size_t*) Next;
	}

	*Pointer = NULL;
	return 0;
}



BOOL IsAFile( LPCTSTR Filename )
{
	if ( !Filename )
		return FALSE;
	else if ( Filename[0] == '\0' )
		return FALSE;


	DWORD attr		= GetFileAttributes( Filename );


	if ( attr == INVALID_FILE_ATTRIBUTES )
		return FALSE;

	if ( attr & ( FILE_ATTRIBUTE_DIRECTORY | FILE_ATTRIBUTE_DEVICE ) )
		return FALSE;

	return TRUE;
}



BOOL CALLBACK Console2WindowCheck( HWND hWnd, LPARAM lParam )
{
	if ( lParam == NULL )
		return TRUE;


	wchar_t ClassName[SHORT_BUF_LEN] = L"";

	if ( RealGetWindowClass( hWnd, ClassName, SHORT_BUF_LEN ) == 0 )
		return TRUE;

	if ( wcscmp( ClassName, Console2Class ) )
		return TRUE;

	HWND *Console2hWnd = (HWND*) lParam;

	for ( int i = 0; i < MAX_CONSOLE2_WINDOWS; i++ ) {
		if ( Console2hWnd[i] == NULL ) {
			Console2hWnd[i] = hWnd;
			return TRUE;
		}
	}

	return TRUE;
}



int SameConsoleWindow( DWORD Pid )
{
	DWORD ConsoleWindowPid = 0;

	GetWindowThreadProcessId( GetConsoleWindow(), &ConsoleWindowPid );

	if ( ConsoleWindowPid == Pid )
		return 1;
	else
		return 0;
}



HWND Console2Window()
{
	HWND Console2hWnd[MAX_CONSOLE2_WINDOWS];
	DWORD Console2Pid[MAX_CONSOLE2_WINDOWS];

	for ( int i = 0; i < MAX_CONSOLE2_WINDOWS; i++ )
		Console2hWnd[i] = NULL, Console2Pid[i] = 0;


	EnumWindows( Console2WindowCheck, (LPARAM) Console2hWnd );

	if ( Console2hWnd[0] == NULL )
		return NULL;

	for ( int i = 0; i < MAX_CONSOLE2_WINDOWS; i++ )
		if ( Console2hWnd[i] )
			GetWindowThreadProcessId( Console2hWnd[i], Console2Pid + i );


	DWORD MyPid = GetCurrentProcessId();
	DWORD Pid = MyPid, ParentPid = NULL, LastPid = NULL;

	do {
		ParentPid = GetParentPID( Pid );
		if ( ( ParentPid == Pid ) || ( ParentPid == 0xffffffff ) )
			break;

		LastPid = Pid;
		Pid = ParentPid;

		for ( int i = 0; i < MAX_CONSOLE2_WINDOWS; i++ ) {
			if ( Pid == Console2Pid[i] ) {
				if ( LastPid == MyPid )
					return Console2hWnd[i];
				else if ( SameConsoleWindow( LastPid ) )
					return Console2hWnd[i];
				else
					return NULL;
			}
		}

	} while ( TRUE );

	return NULL;
}



int DummyConsoleOutput( unsigned int n )
{
	for ( unsigned int i = 0; i < n; i++ )
		_cputws( L"A\bB\bC\bD\b \b" );

	return 0;
}



BOOL CALLBACK TakeCmdWindowCheck( HWND hWnd, LPARAM lParam )
{
	if ( lParam == NULL )
		return TRUE;


	wchar_t ClassName[SHORT_BUF_LEN] = L"";

	if ( RealGetWindowClass( hWnd, ClassName, SHORT_BUF_LEN ) == 0 )
		return TRUE;

	if ( _wcsnicmp( ClassName, TCmdClass, TCmdClassLen ) )
		if ( _wcsicmp( ClassName, TCmdClass2 ) )
			return TRUE;

	HWND *TCmdHWnd = (HWND*) lParam;

	for ( int i = 0; i < MAX_CONSOLE2_WINDOWS; i++ ) {
		if ( TCmdHWnd[i] == NULL ) {
			TCmdHWnd[i] = hWnd;
			return TRUE;
		}
	}

	return TRUE;
}



HWND GetTakeCommandWindow()
{
	HWND TCmdHWnd[MAX_CONSOLE2_WINDOWS];
	DWORD TCmdPid[MAX_CONSOLE2_WINDOWS];

	for ( int i = 0; i < MAX_CONSOLE2_WINDOWS; i++ )
		TCmdHWnd[i] = NULL, TCmdPid[i] = 0;


	EnumWindows( TakeCmdWindowCheck, (LPARAM) TCmdHWnd );

	if ( TCmdHWnd[0] == NULL )
		return NULL;

	for ( int i = 0; i < MAX_CONSOLE2_WINDOWS; i++ )
		if ( TCmdHWnd[i] )
			GetWindowThreadProcessId( TCmdHWnd[i], TCmdPid + i );

	/*
	wprintf( L"\n   * Take Command windows:\n\n" );
	for ( int i = 0; i < MAX_CONSOLE2_WINDOWS; i++ )
		if ( TCmdHWnd[i] )
			wprintf( L"   * %02i:  hWnd = 0x%08x   Pid = 0x%08x\n", i, TCmdHWnd[i], TCmdPid[i] );
	*/

	DWORD BufferSize			= 64;
	DWORD ProcessCount			= BufferSize + 1;
	DWORD *ProcessListBuffer	= NULL;


	DummyConsoleOutput( 256 );

	while ( ProcessCount > BufferSize ) {

		if ( ProcessListBuffer ) {
			free( ProcessListBuffer );
			ProcessListBuffer = NULL;
		}

		ProcessListBuffer = (DWORD*) malloc( BufferSize * sizeof( DWORD ) );

		if ( ProcessListBuffer == NULL )
			return NULL;

		ProcessCount = GetConsoleProcessList( ProcessListBuffer, BufferSize );
	}

	if ( ProcessCount == 0 ) {
		if ( ProcessListBuffer )
			free( ProcessListBuffer );

		return NULL;
	}

	/*
	wprintf( L"\n   * Attached processes:\n\n" );
	for ( unsigned int i = 0; i < ProcessCount; i++ )
		if ( ProcessListBuffer[i] )
			wprintf( L"   * %02u:  0x%08x\n", i, ProcessListBuffer[i] );

	wprintf( L"\n" );
	*/

	for ( unsigned int i = 0; i < ProcessCount; i++ ) {
		if ( ProcessListBuffer[i] ) {
			for ( int j = 0; j < MAX_CONSOLE2_WINDOWS; j++ )
				if ( ProcessListBuffer[i] == TCmdPid[j] )
					return TCmdHWnd[j];
		}
	}

	return NULL;
}



BOOL APIENTRY DllMain( HANDLE hModule, DWORD  dwReason, LPVOID lpReserved )
{
	MyDLLHandle = (HINSTANCE) hModule;

	switch( dwReason )	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
	}
	return TRUE;
}



BOOL GetVersion2( OSVERSIONINFOEXW *VerInfo )
{
	if ( !VerInfo )
		return -1;


	typedef NTSTATUS ( WINAPI _RtlGetVersionProc ) ( OSVERSIONINFOEXW *VerInfo );
	HMODULE NtDllHandle						= GetModuleHandle( L"NtDll.dll" );
	_RtlGetVersionProc *RtlGetVersionProc	= NULL;


	memset( VerInfo, 0x00, sizeof( OSVERSIONINFOEXW ) );
	VerInfo->dwOSVersionInfoSize = sizeof( OSVERSIONINFOEXW );

	if ( NtDllHandle )
		RtlGetVersionProc = (_RtlGetVersionProc*) GetProcAddress( NtDllHandle, "RtlGetVersion" );

	if ( RtlGetVersionProc ) {
		RtlGetVersionProc( VerInfo );
		if ( VerInfo->dwMajorVersion >= 6 )
			return TRUE;
	}

	memset( VerInfo, 0x00, sizeof( OSVERSIONINFOEXW ) );
	VerInfo->dwOSVersionInfoSize = sizeof( OSVERSIONINFOEXW );

	return ( GetVersionEx( (OSVERSIONINFOW*) VerInfo ) != 0 );
}



int DisableOneFeature( LPTSTR FeaturesList, LPTSTR FeatureToDisable )
{
	if ( ( FeaturesList == NULL ) || ( FeatureToDisable == NULL ) )
		return -1;

	if ( ( FeaturesList[0] == '\0' ) || ( FeatureToDisable[0] == '\0' ) )
		return -1;

	size_t i = 0, j = 0, base = 0;
	wchar_t ch = '\0', ch2 = '\0';
	BOOL done = FALSE, match = FALSE;

	do {
		// Compare word in 'FeatureToDisable' against word at 'base' :

		i = 0;
		match = TRUE;

		do {
			ch = towupper( FeaturesList[base + i] );
			ch2 = ch;
			if ( ( ch2 == ',' ) || ( ch2 == ';' ) )
				ch2 = '\0';

			match &= ( ch2 == towupper( FeatureToDisable[i] ) );

			i++;
		} while ( ch2 != '\0' );

		if ( match ) {
			// disable the feature:

			if ( ch == '\0' )
				FeaturesList[base] = ch;
			else {
				j = 0;

				do {
					ch = FeaturesList[base + i + j];
					FeaturesList[base + j] = ch;
					j++;
				} while ( ch != '\0' );
			}
		}
		else
			base += i;

	} while ( ch != '\0' );

	i = wcslen( FeaturesList );
	if ( i > 0 )
		if ( ( FeaturesList[i - 1] == ',' ) || ( FeaturesList[i - 1] == ';' ) )
			FeaturesList[i - 1] = '\0';

	return 0;
}



BOOL HasMonitorsVariable()
{
	wchar_t shortbuf[SHORT_BUF_LEN] = L"%_monitors";

	ExpandVariables( shortbuf, 1 );

	return ( iswdigit( shortbuf[0] ) );
}



BOOL HasShortcutVariable()
{
	wchar_t shortbuf[SHORT_BUF_LEN] = L"%_4ver";
	unsigned int VerMajor = 0;
	wchar_t *sep1 = NULL;

	ExpandVariables( shortbuf, 1 );

	VerMajor = wcstoul( shortbuf, &sep1, 10 );
	if ( ( *sep1 != '.' ) && ( *sep1 != ',' ) )
		VerMajor = 0;

	if ( VerMajor < 9 ) return FALSE;

	wcscpy_s( shortbuf, SHORT_BUF_LEN, L"%_cmdproc" );

	ExpandVariables( shortbuf, 1 );

	if ( _wcsicmp( shortbuf, L"TCCLE" ) == 0 )
		return FALSE;

	return TRUE;
}


#include "NewHelp.cpp"


int OSD_Initialize();
int OSD_Shutdown();


DLLExports LPPLUGININFO WINAPI GetPluginInfo( void )
{
	if ( HasMonitorsVariable() )
		DisableOneFeature( PluginFeatures, L"_monitors" );

	if ( HasShortcutVariable() )
		DisableOneFeature( PluginFeatures, L"_shortcut" );

	if ( ( OSVerInfo.dwMajorVersion != 6 ) || ( OSVerInfo.dwMinorVersion != 1 ) ) {

#ifdef WIN7PIN_CMDS

		DisableOneFeature( PluginFeatures, L"startpin" );
		DisableOneFeature( PluginFeatures, L"taskbarpin" );

#endif	//	WIN7PIN_CMDS

		//	DisableOneFeature( PluginFeatures, L"settheme" );
	}

	static PLUGININFO piInfo;

	piInfo.pszDll = (LPTSTR) PLUGIN_NAME;
	piInfo.pszAuthor = (LPTSTR) L"Charles Dye";
	piInfo.pszEmail = (LPTSTR) L"cdye@unm.edu";
	piInfo.pszWWW = (LPTSTR) L"http://prospero.unm.edu/plugins/uistuff.html";
	piInfo.pszDescription = (LPTSTR) L"Various user-interface features";
	piInfo.pszFunctions = (LPTSTR) PluginFeatures;
	piInfo.nMajor = VER_MAJOR;
	piInfo.nMinor = VER_MINOR;
	piInfo.nBuild = VER_BUILD;

	return &piInfo;
}



DLLExports BOOL WINAPI InitializePlugin( void )
{
	int rv = 0;


	GetVersion2( &OSVerInfo );

	SystemParametersInfo( SPI_GETFOREGROUNDLOCKTIMEOUT, 0, &ForegroundLockTimeoutSave, 0 );

	rv = GdiplusStartup( &GdiplusToken, &StartupInput, NULL );
	if ( rv ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Error %d initializing GDI+ -- plugin not loaded!\r\n", rv );
		return -1;
	}

	wchar_t shortbuf[SHORT_BUF_LEN] = L"%[_transient]%[_pipe]%[noloadmsg]";
	ExpandVariables( shortbuf, 1 );

	if ( wcscmp( shortbuf, L"00" ) == 0 )
		Printf( L"%s v%d.%d.%d loaded.\r\n", PLUGIN_NAME, VER_MAJOR, VER_MINOR, VER_BUILD );

	Console2WindowHandle = Console2Window();

	OSD_Initialize();

	GetFontResourceInfo = NULL;
	Gdi32Dll = GetModuleHandle( L"Gdi32.dll" );
	if ( Gdi32Dll )
		GetFontResourceInfo = (_GetFontResourceInfoProc*) GetProcAddress( Gdi32Dll, "GetFontResourceInfoW" );

	return 0;
}



DLLExports BOOL WINAPI ShutdownPlugin( BOOL bEndProcess )
{
	CloseHelpWindow();
	GdiplusShutdown( GdiplusToken );
	FreeLinkedList( (void**) &FirstFont );
	OSD_Shutdown();
	return 0;
}



#include "ParseArgs.cpp"



int ParseInt( LPTSTR inString, unsigned int *outValue, wchar_t **EndChar )
{
	if ( ( inString == NULL ) || ( outValue == NULL ) )
		return -1;

	unsigned int value = 0;
	wchar_t *sep1 = NULL;

	_set_errno( 0 );

	if ( ( inString[0] == '0' ) && ( towupper( inString[1] ) == 'X' ) && ( iswxdigit( inString[2] ) ) ) {
		//  parse hexadecimal

		value = wcstoul( inString + 2, &sep1, 16 );

		if ( errno )
			return -1;
		else if ( ( EndChar == NULL ) && ( *sep1 != '\0' ) )
			return -1;

		*outValue = value;

		if ( EndChar != NULL )
			*EndChar  = sep1;

		return 0;
	}
	else if ( iswdigit( inString[0] ) ) {
		//  parse unsigned

		value = wcstoul( inString, &sep1, 10 );

		if ( errno )
			return -1;
		else if ( ( EndChar == NULL ) && ( *sep1 != '\0' ) )
			return -1;

		*outValue = value;

		if ( EndChar != NULL )
			*EndChar  = sep1;

		return 0;
	}

	return -1;
}



int ParseSignedInt( LPTSTR inString, int *outValue, wchar_t **EndChar )
{
	if ( ( inString == NULL ) || ( outValue == NULL ) )
		return -1;

	int value = 0;
	wchar_t *sep1 = NULL;

	_set_errno( 0 );

	if ( ( inString[0] == '0' ) && ( towupper( inString[1] ) == 'X' ) && ( iswxdigit( inString[2] ) ) ) {
		//  parse hexadecimal

		value = wcstoul( inString + 2, &sep1, 16 );

		if ( errno )
			return -1;
		else if ( ( EndChar == NULL ) && ( *sep1 != '\0' ) )
			return -1;

		*outValue = value;

		if ( EndChar != NULL )
			*EndChar  = sep1;

		return 0;
	}
	else if ( iswdigit( inString[0] ) || ( ( inString[0] == '-' ) && iswdigit( inString[1] ) ) ) {
		//  parse signed integer

		value = wcstol( inString, &sep1, 10 );

		if ( errno )
			return -1;
		else if ( ( EndChar == NULL ) && ( *sep1 != '\0' ) )
			return -1;

		*outValue = value;

		if ( EndChar != NULL )
			*EndChar  = sep1;

		return 0;
	}

	return -1;
}



int ParsePercentage( LPTSTR inString, unsigned int *outValue )
{
	if ( ( inString == NULL ) || ( outValue == NULL ) )
		return -1;
	else if ( iswdigit( inString[0] ) == 0 )
		return -1;

	wchar_t *ch = inString, *sep1 = NULL;
	double value = 0.0;

	_set_errno( 0 );

	value = wcstod( ch, &sep1 );

	if ( *sep1 != '%' )
		return 1;

	sep1++;
	if ( *sep1 )
		return 1;

	if ( errno )
		return 1;

	if ( ( value < -0.0 ) || ( value > 100.0 ) )
		return 2;

	*outValue = (unsigned int) ( value * 100.0 );
	return 0;
}



int ParseSeconds( LPTSTR inString, unsigned int *outValue )
{
	if ( ( inString == NULL ) || ( outValue == NULL ) )
		return -1;

	if ( iswdigit( inString[0] ) == 0 )
		return -1;

	unsigned long int val1 = 0, val2 = 0, val3 = 0;
	wchar_t *sep1 = NULL, *sep2 = NULL, *sep3 = NULL;


	_set_errno( 0 );

	if ( ( inString[0] == '0' ) && ( towupper( inString[1] ) == 'X' ) && ( iswxdigit( inString[2] ) ) ) {
		val1 = wcstoul( inString + 2, &sep1, 16 );

		if ( errno )
			return -1;
	}
	else {
		val1 = wcstoul( inString, &sep1, 10 );

		if ( errno )
			return -1;
	}

	if ( *sep1 == 0x00 ) {
		if ( val1 > ( 60 * 60 * 24 ) )
			return -1;

		*outValue = val1;
		return 0;
	}
	else if ( ( *sep1 != ':' ) && ( *sep1 != '.' ) )
		return -1;

	sep1++;
	if ( iswdigit( *sep1 ) == 0 )
		return -1;

	_set_errno( 0 );

	val2 = wcstoul( sep1, &sep2, 10 );

	if ( errno )
		return -1;

	if ( val2 >= 60 )
		return -1;

	if ( *sep2 == 0x00 ) {
		if ( val1 > ( 60 * 24 ) )
			return -1;
		else if ( val2 >= 60 )
			return -1;
		else if ( ( ( 60 * val1 ) + val2 ) > ( 60 * 60 * 24 ) )
			return -1;

		*outValue = ( 60 * val1 ) + val2;
		return 0;
	}
	else if ( ( *sep2 != ':' ) && ( *sep2 != '.' ) )
		return -1;

	sep2++;
	if ( iswdigit( *sep2 ) == 0 )
		return -1;

	_set_errno( 0 );

	val3 = wcstoul( sep2, &sep3, 10 );

	if ( errno )
		return -1;

	if ( *sep3 != 0x00 )
		return -1;

	if ( val1 > 24 )
		return -1;
	else if ( val2 >= 60 )
		return -1;
	else if ( val3 >= 60 )
		return -1;
	else if ( ( ( 60 * 60 * val1 ) + ( 60 * val2 ) + val3 ) > ( 60 * 60 * 24 ) )
		return -1;

	*outValue = ( 60 * 60 * val1 ) + ( 60 * val2 ) + val3;
	return 0;
}



BOOL IsColonOrEquals( wchar_t ch )
{
	return ( ( ch == ':' ) || ( ch == '=' ) );
}



BOOL IsSlashOrBackslash( wchar_t ch )
{
	return ( ( ch == '\\' ) || ( ch == '/' ) );
}



int StripQuotes( LPTSTR String )
{
	if ( !String )
		return -1;


	size_t i	= 0;
	size_t j	= 0;
	wchar_t ch	= '\0';
	int k		= 0;


	do {
		ch = String[i++];
		if ( ch == QUOTE ) {
			k++;
			continue;
		}

		String[j++] = ch;
	}
	while ( ch );
	
	return k;
}


#include "OsdCmd.cpp"


//	Adds a filename onto a directory name, adding a slash if needed.

int AppendFilename( LPTSTR Path, LPTSTR Filename, size_t BufferSize )
{
	if ( !Path || !Filename )
		return -1;

	
	BOOL NeedSlash		= FALSE;

	for ( size_t i = 0; Path[i]; i++ ) {
		if ( ( Path[i] == '/' ) || ( Path[i] == '\\' ) || ( Path[i] == ':' ) )
			NeedSlash = FALSE;
		else
			NeedSlash = TRUE;
	}

	if ( ( Filename[0] == '/' ) || ( Filename[0] == '\\' ) )
		NeedSlash = FALSE;
	
	if ( NeedSlash )
		wcscat_s( Path, BufferSize, L"\\" );

	wcscat_s( Path, BufferSize, Filename );
	return 0;
}


LPTSTR _PathPart( LPTSTR Filename, LPTSTR outPath )
{
	if ( Filename == NULL )
		return NULL;
	else if ( Filename[0] == 0x00 )
		return NULL;


	BOOL FoundSlash			= FALSE;
	size_t EndOfPathPart	= -1;


	for ( size_t i = 0; Filename[i]; i++ ) {
		if ( ( Filename[i] == '/' ) || ( Filename[i] == '\\' ) ) {
			EndOfPathPart = i;
			FoundSlash = TRUE;
		}
		else if ( ( Filename[i] == ':' ) && !FoundSlash )
			EndOfPathPart = i;
	}

	if ( EndOfPathPart == -1 )
		return NULL;

	if ( outPath ) {
		for ( size_t i = 0; i <= EndOfPathPart; i++ )
			outPath[i] = Filename[i];

		outPath[EndOfPathPart + 1] = 0x00;
		return outPath;
	}

	return Filename;
}


LPTSTR _FilenamePart( LPTSTR Filename, LPTSTR outFilename )
{
	if ( Filename == NULL )
		return NULL;
	else if ( Filename[0] == 0x00 )
		return NULL;


	BOOL FoundSlash			= FALSE;
	size_t EndOfPathPart	= -1;


	for ( size_t i = 0; Filename[i]; i++ ) {
		if ( ( Filename[i] == '/' ) || ( Filename[i] == '\\' ) ) {
			EndOfPathPart = i;
			FoundSlash = TRUE;
		}
		else if ( ( Filename[i] == ':' ) && !FoundSlash )
			EndOfPathPart = i;
	}

	if ( EndOfPathPart == -1 ) {
		if ( outFilename ) {
			wcscpy_s( outFilename, MAX_FILENAME_LEN, Filename );
			return outFilename;
		}
		else
			return Filename;
	}

	if ( outFilename ) {
		wcscpy_s( outFilename, MAX_FILENAME_LEN, Filename + EndOfPathPart + 1 );
		return outFilename;
	}
	else
		return Filename + EndOfPathPart + 1;
}



LPTSTR _ExtensionPart( LPTSTR Filename, LPTSTR outExt )
{
	if ( !Filename )
		return NULL;
	else if ( Filename[0] == '\0' )
		return NULL;


	LPTSTR Ext			= NULL;


	if ( outExt )
		outExt[0] = '\0';

	for ( size_t i = 0; Filename[i]; i++ ) {
		if ( ( Filename[i] == '/' ) || ( Filename[i] == '\\' ) || ( Filename[i] == ':' ) )
			Ext = NULL;
		else if ( Filename[i] == '.' )
			Ext = Filename + i;
	}

	if ( !Ext )
		return NULL;

	if ( outExt ) {
		wcscpy_s( outExt, MAX_FILENAME_LEN, Ext );
		return outExt;
	}

	return Ext;
}



int _AddWildcardIfDirectory( LPTSTR Filename, size_t BufferSize )
{
	if ( Filename == NULL )
		return -1;
	else if ( Filename[0] == 0x00 )
		return -1;


	if ( QueryIsDirectory( Filename ) )
		AppendFilename( Filename, L"*", BufferSize );

	return 0;
}



int ShowCmdHelp( LPCTSTR HelpText, BOOL ShowVersion, LPCSTR SourceFile, LPCSTR SourceFileVer )
{
	wchar_t File[MAX_FILENAME_LEN]		= L"";
	wchar_t Ver[SHORT_BUF_LEN]			= L"";


	QPuts( (LPTSTR) HelpText );

	if ( ShowVersion ) {
		Printf( L"\r\n\t\t\t\t%s  %u.%u.%u (%s)\r\n", PLUGIN_NAME, VER_MAJOR, VER_MINOR, VER_BUILD, PLATFORM );

		if ( SourceFile && SourceFileVer ) {
			MultiByteToWideChar( CP_ACP, MB_PRECOMPOSED, SourceFile, -1, File, MAX_FILENAME_LEN );
			MultiByteToWideChar( CP_ACP, MB_PRECOMPOSED, SourceFileVer, -1, Ver, SHORT_BUF_LEN );
			StripQuotes( File );
			Printf( L"\t\t\t\t%s  %s\r\n", _FilenamePart( File, NULL), Ver );
		}
	}

	return 0;
}



int ShowCmdHelp( LPCTSTR HelpText, BOOL ShowVersion )
{
	QPuts( (LPTSTR) HelpText );

	if ( ShowVersion )
		Printf( L"\r\n\t\t\t\t%s  %u.%u.%u (%s)\r\n", PLUGIN_NAME, VER_MAJOR, VER_MINOR, VER_BUILD, PLATFORM );

	return 0;
}



//		-------------------------------------------------------
//
//		Moved all the sound volume stuff out to SoundVol.cpp :

#define VOLUME_VAR
#define SOUNDVOL_CMD
#include "SoundVol.cpp"

//		old names for the sound variables:

DLLExports int WINAPI _soundvol( LPTSTR outString )
{
	return _volume( outString );
}

DLLExports int WINAPI _muted( LPTSTR outString )
{
	return _mute( outString );
}

//		-------------------------------------------------------



int SearchAppPaths( LPTSTR inFilename, HKEY RootKey, LPTSTR outFullname )
{
	if ( ( inFilename == NULL ) || ( outFullname == NULL ) || ( RootKey == NULL ) )
		return -1;
	else if ( inFilename[0] == '\0' )
		return -1;

	wchar_t KeyName[MAX_FILENAME_LEN]	= L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\";
	wchar_t Data[MAX_FILENAME_LEN]		= L"";
	HKEY KeyHandle = NULL;
	DWORD DataType = 0, DataSize = MAX_FILENAME_LEN * sizeof( wchar_t );
	int rv = 0;


	wcscat_s( KeyName, MAX_FILENAME_LEN, inFilename );

	if ( RegOpenKeyEx( RootKey, KeyName, 0, KEY_READ, &KeyHandle ) )
		return 1;

	rv = RegQueryValueEx( KeyHandle, NULL, NULL, &DataType, (BYTE *) Data, &DataSize );

	RegCloseKey( KeyHandle );

	if ( rv != ERROR_SUCCESS )
		return 1;

	if ( ( DataType != REG_SZ ) && ( DataType != REG_EXPAND_SZ ) )
		return 1;

	if ( ( DataType == REG_EXPAND_SZ ) && ( wcschr( Data, '%' ) != NULL ) ) {
		wchar_t temp[MAX_FILENAME_LEN] = L"";
		ExpandEnvironmentStrings( Data, temp, MAX_FILENAME_LEN );
		wcscpy_s( Data, MAX_FILENAME_LEN, temp );
	}

	if ( !IsAFile( Data ) )
		return 1;

	wcscpy_s( outFullname, MAX_FILENAME_LEN, Data );
	return 0;
}


int SearchPathForExe( LPTSTR inFilename, LPTSTR outFullname )
{
	if ( ( inFilename == NULL ) || ( outFullname == NULL ) )
		return -1;
	else if ( inFilename[0] == '\0' )
		return -1;

	outFullname[0] = '\0';

	if ( SearchAppPaths( inFilename, HKEY_CURRENT_USER, outFullname ) == 0 )
		return 0;

	if ( SearchAppPaths( inFilename, HKEY_LOCAL_MACHINE, outFullname ) == 0 )
		return 0;

	SearchPath( NULL, inFilename, NULL, MAX_FILENAME_LEN, outFullname, NULL );

	if ( outFullname[0] )
		return 0;

	return 1;
}


int GetConEmuCFilename( LPTSTR outString )
{
	if ( outString == NULL )
		return -1;


	DWORD BufferSize			= 64;
	DWORD ProcessCount			= BufferSize + 1;
	DWORD *ProcessListBuffer	= NULL;


	while ( ProcessCount > BufferSize ) {

		if ( ProcessListBuffer ) {
			free( ProcessListBuffer );
			ProcessListBuffer = NULL;
		}

		ProcessListBuffer = (DWORD*) malloc( BufferSize * sizeof( DWORD ) );

		if ( ProcessListBuffer == NULL )
			return 1;

		ProcessCount = GetConsoleProcessList( ProcessListBuffer, BufferSize );
	}

	if ( ProcessCount == 0 ) {
		if ( ProcessListBuffer )
			free( ProcessListBuffer );

		return 1;
	}


	wchar_t Filename[MAX_FILENAME_LEN]			= L"";
	LPTSTR BaseName			= NULL;
	HANDLE ProcessHandle	= NULL;
	int rv					= 1;


	for ( unsigned int i = 0; i < ProcessCount; i++ ) {
		Filename[0] = 0x00;
		
		ProcessHandle = OpenProcess( PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, ProcessListBuffer[i] );

		if ( ProcessHandle ) {
			GetModuleFileNameEx( ProcessHandle, NULL, Filename, MAX_FILENAME_LEN );
			CloseHandle( ProcessHandle );
			ProcessHandle = NULL;
		}

		if ( Filename[0] ) {
			BaseName = _FilenamePart( Filename, NULL );

			if ( BaseName ) {
				if ( _wcsicmp( BaseName, L"ConEmuC64.exe" ) == 0 ) {
					wcscpy_s( outString, MAX_FILENAME_LEN, Filename );
					rv = 0;
					break;
				}
				else if ( _wcsicmp( BaseName, L"ConEmuC.exe" ) == 0 ) {
					wcscpy_s( outString, MAX_FILENAME_LEN, Filename );
					rv = 0;
					break;
				}
			}
		}
	}

	free( ProcessListBuffer );
	return rv;
}


BOOL CALLBACK ConEmuWindowCheck( HWND hWnd, LPARAM lParam )
{
	if ( lParam == NULL )
		return TRUE;


	wchar_t ClassName[SHORT_BUF_LEN] = L"";

	if ( RealGetWindowClass( hWnd, ClassName, SHORT_BUF_LEN ) == 0 )
		return TRUE;

	if ( wcscmp( ClassName, ConEmuClass ) )
		return TRUE;

	HWND *ConEmuWindow = (HWND*) lParam;

	if ( *ConEmuWindow == NULL )
		*ConEmuWindow = hWnd;

	return TRUE;
}


HWND GetConEmuWindow()
{
	wchar_t Filename[MAX_FILENAME_LEN]			= L"";
	wchar_t CmdBuffer[MAX_FILENAME_LEN + 32]	= L"";
	HWND ConEmuHandle							= NULL;
	unsigned int Value							= 0;


	if ( GetConEmuCFilename( Filename ) )
		return NULL;

	wsprintf( CmdBuffer, L"\"%s\" /GUIMACRO IsConEmu > nul:", Filename );

	if ( Command( CmdBuffer, 0 ) )
		return NULL;


	Filename[0] = 0x00;
	GetEnvironmentVariable( L"ConEmuHWND", Filename, MAX_FILENAME_LEN );
	if ( Filename[0] ) {
		if ( ParseInt( Filename, &Value, NULL ) == 0 ) {
			Filename[0] = 0x00;
			RealGetWindowClass( (HWND) Value, Filename, MAX_FILENAME_LEN );

			if ( wcscmp( Filename, ConEmuClass ) == 0 )
				return (HWND) Value;
		}
	}

	EnumWindows( ConEmuWindowCheck, (LPARAM) &ConEmuHandle );

	return ConEmuHandle;
}


BOOL IsClipboard( LPTSTR Filename )
{
	if ( Filename == NULL )
		return FALSE;

	if ( _wcsicmp( Filename, ClipboardFilename ) )
		return FALSE;
	else
		return TRUE;
}


int ReplaceChar( LPTSTR String, wchar_t FromChar, wchar_t ToChar )
{
	if ( !String )
		return -1;

	if ( !FromChar || !ToChar || ( FromChar == ToChar ) )
		return 0;


	int n = 0;


	for ( size_t i = 0; String[i]; i++ ) {
		if ( String[i] == FromChar ) {
			String[i] = ToChar;
			n++;
		}
	}

	return n;
}



int GetErrorText( int Error, LPTSTR outString )
{
	if ( outString == NULL )
		return -1;

	if ( Error == -1 )
		wcscpy_s( outString, SHORT_BUF_LEN, L"Unknown error." );
	else if ( FormatMessage( FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS | FORMAT_MESSAGE_MAX_WIDTH_MASK, NULL, Error, 0, outString, SHORT_BUF_LEN, NULL ) == 0 )
		Sprintf( outString, L"Error %d", Error );

	size_t l = wcslen( outString );

	if ( l > 0 )
		while ( iswspace( outString[l - 1] ) ) {
			l--;
			outString[l] = '\0';
		}

	return 0;
}



int ProcessElevated( DWORD Pid )
{
	HANDLE ProcessHandle		= NULL;
	HANDLE ProcessToken			= NULL;
	TOKEN_ELEVATION Elevated	= { 0 };
	DWORD ReturnSize			= 0;

	int rv						= 0;


	ProcessHandle = OpenProcess( PROCESS_QUERY_LIMITED_INFORMATION, FALSE, Pid );
	if ( ProcessHandle ) {
		if ( OpenProcessToken( ProcessHandle, TOKEN_QUERY, &ProcessToken ) ) {
			if ( GetTokenInformation( ProcessToken, TokenElevation, &Elevated, sizeof( TOKEN_ELEVATION ), &ReturnSize ) )
				rv = Elevated.TokenIsElevated ? 1 : 0;

			CloseHandle( ProcessToken );
		}

		CloseHandle( ProcessHandle );
	}

	return rv;
}



int RunningElevated()
{
	return ProcessElevated( GetCurrentProcessId() );
}



#include "CanonicalizeSpecial.cpp"



#ifdef WIN7PIN_CMDS

int GetShellErrorText( int Error, LPTSTR outString )
{
	if ( outString == NULL )
		return -1;

	switch ( Error ) {
		case -1:
			wcscpy_s( outString, SHORT_BUF_LEN, L"Unknown error." );
			break;

		case 0:
			wcscpy_s( outString, SHORT_BUF_LEN, L"The operating system is out of memory or resources." );
			break;

		case SE_ERR_SHARE:
			wcscpy_s( outString, SHORT_BUF_LEN, L"A sharing violation occurred." );
			break;

		case SE_ERR_ASSOCINCOMPLETE:
			wcscpy_s( outString, SHORT_BUF_LEN, L"The file name association is invalid or incomplete." );
			break;

		case SE_ERR_DDETIMEOUT:
			wcscpy_s( outString, SHORT_BUF_LEN, L"The DDE transaction could not be completed because the request timed out." );
			break;

		case SE_ERR_DDEFAIL:
			wcscpy_s( outString, SHORT_BUF_LEN, L"The DDE transaction failed." );
			break;

		case SE_ERR_DDEBUSY:
			wcscpy_s( outString, SHORT_BUF_LEN, L"The DDE transaction could not be completed because other DDE transactions were being processed." );
			break;

		case SE_ERR_NOASSOC:
			wcscpy_s( outString, SHORT_BUF_LEN, L"There is no application associated with the given file name extension. This error will also be returned if you attempt to print a file that is not printable." );
			break;

		default:
			GetErrorText( Error, outString );
	}

	return 0;
}


int PinShortcut( LPTSTR inString, int Mode )
{
	if ( inString == NULL )
		return -1;


	wchar_t Filename[MAX_FILENAME_LEN] = L"";
	LPTSTR FilenameExt = NULL;
	int rv = 0;
	wchar_t ErrorText[SHORT_BUF_LEN] = L"";


	ParseArgs( inString, PARSE_BREAK_SPACES | PARSE_SLASHES_KLUDGE );

	for ( int i = 0; i < numargs; i++ ) {
		if ( arglen[i] ) {
			if ( wcscmp( arg[i], L"/?" ) == 0 ) {
				Printf( ( Mode & PIN_TO_TASKBAR ) ? TaskBarPinHelpText : StartPinHelpText );
				return 0;
			}
			else if ( _wcsicmp( arg[i], L"/U" ) == 0 )
				Mode |= PIN_UNPIN;
			else if ( arg[i][0] == '/' ) {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Unknown option: \"%s\"\r\n", arg[i] );
				return 1;
			}
			else if ( Filename[0] == 0x00 )
				//  QueryTrueName( arg[i], Filename );
				CanonicalizeFilename( arg[i], Filename );
			else {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Syntax error: \"%s\"\r\n", arg[i] );
				return 1;
			}

		}
	}

	if ( Filename[0] == 0x00 ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Missing filename\r\n" );
		return 1;
	}

	FilenameExt = _ExtensionPart( Filename, NULL );

	if ( FilenameExt == NULL )
		wcscat_s( Filename, MAX_FILENAME_LEN, L".lnk" );
	else if ( _wcsicmp( FilenameExt, L".lnk" ) ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Filename must end in .LNK: \"%s\"\r\n", Filename );
		return 1;
	}

	const wchar_t ShellVerb[4][13] = { L"startpin", L"taskbarpin", L"startunpin", L"taskbarunpin" };

	rv = (int) ShellExecute( NULL, ShellVerb[Mode & 3], Filename, NULL, NULL, 0 );

	if ( rv <= 32 ) {
		GetShellErrorText( rv, ErrorText );
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, ( Mode & PIN_UNPIN ) ? L"Error unpinning \"%s\": %s\r\n" : L"Error pinning \"%s\": %s\r\n", Filename, ErrorText );
		return 2;
	}

	return 0;
}


DLLExports int WINAPI startpin( LPTSTR inString )
{
	return PinShortcut( inString, PIN_TO_START_MENU );
}


DLLExports int WINAPI taskbarpin( LPTSTR inString )
{
	return PinShortcut( inString, PIN_TO_TASKBAR );
}

#endif	//	WIN7PIN_CMDS



long int GetRegStringValue( HKEY KeyHandle, LPTSTR ValueName )
{
	if ( KeyHandle == NULL )
		return -1;

	wchar_t shortbuf[SHORT_BUF_LEN] = L"";
	DWORD ValueType = 0, DataSize = SHORT_BUF_LEN * sizeof( wchar_t );
	wchar_t *sep1 = NULL;
	long int rv = 0;

	if ( RegQueryValueEx( KeyHandle, ValueName, NULL, &ValueType, (BYTE *) shortbuf, &DataSize ) )
		return -1;
	
	if ( DataSize < 4 )
		return -1;


	_set_errno( 0 );
	rv = wcstol( shortbuf, &sep1, 10 );

	if ( errno )
		return -1;

	if ( ( *sep1 != 0x00 ) && ( iswspace( *sep1 ) == 0 ) )
		return -1;

	return rv;
}



int SetRegStringValue( HKEY KeyHandle, LPCTSTR ValueName, long int Value )
{
	if ( KeyHandle == NULL )
		return -1;

	wchar_t shortbuf[SHORT_BUF_LEN] = L"";
	DWORD ValueType = 0, DataSize = 0;
	int rv = 0;

	DataSize = ( wsprintf( shortbuf, L"%d", Value ) + 1 ) * sizeof( wchar_t );

	rv = RegSetValueEx( KeyHandle, ValueName, 0, REG_SZ, (BYTE *) shortbuf, DataSize );

	return rv;
}



int SetRegString( HKEY KeyHandle, LPCTSTR ValueName, LPCTSTR Value )
{
	if ( ( KeyHandle == NULL ) || ( ValueName == NULL ) || ( Value == NULL ) )
		return -1;

	return RegSetValueEx( KeyHandle, ValueName, 0, REG_SZ, (BYTE *) Value, ( (int) wcslen( Value ) + 1 ) * sizeof( wchar_t ) );
}



int ShuffleColors( int Colors )
{
	if ( ( Colors < 0 ) || ( Colors > 0xffffff ) )
		return -1;

	return ( ( ( Colors & 0xff ) << 16 ) | ( Colors & 0xff00 ) | ( ( Colors & 0xff0000 ) >> 16 ) );
}



DLLExports int WINAPI bgcolor( LPTSTR inString )
{
	if ( !inString )
		return -1;


	wchar_t ErrorText[SHORT_BUF_LEN]		= L"";

	unsigned int BGColor		= W3C_COLOR_UNDEFINED;
	int WhichColor				= COLOR_BACKGROUND;
	unsigned int val1			= W3C_COLOR_UNDEFINED;
	unsigned int val2			= W3C_COLOR_UNDEFINED;
	unsigned int val3			= W3C_COLOR_UNDEFINED;
	COLORREF BGColorShuffled	= 0;
	BOOL Save					= FALSE;
	BOOL DefaultUser			= FALSE;
	int rv = 0;

	const wchar_t KeyName[]					= L"Control Panel\\Colors";
	const wchar_t DefaultUserKeyName[]		= L".DEFAULT\\Control Panel\\Colors";
	const wchar_t BackgroundValueName[]		= L"Background";

	HKEY KeyHandle				= NULL;
	wchar_t Temp[SHORT_BUF_LEN]	= L"";


	ParseArgs( inString, PARSE_BREAK_SPACES | PARSE_ONE_ARG_KLUDGE );

	for ( int i = 0; i < numargs; i++ ) {
		if ( arglen[i] ) {
			if ( !wcsncmp( arg[i], L"/?", 2 ) )
				return ShowCmdHelp( BGColorHelpText, ( arg[i][2] == '?' ) );
			else if ( !_wcsicmp( arg[i], L"/S" ) )
				Save = TRUE;
			else if ( !_wcsicmp( arg[i], L"/DU" ) )
				DefaultUser = TRUE;
			else if ( arg[i][0] == '/' ) {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Unknown option: \"%s\"\r\n", arg[i] );
				return 1;
			}
			else if ( iswalpha( arg[i][0] ) && ( val1 == W3C_COLOR_UNDEFINED ) ) {
				val1 = W3CColorValue( arg[i], TRUE );

				if ( val1 == W3C_COLOR_UNDEFINED ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Unknown color name: \"%s\"\r\n", arg[i] );
					return 1;
				}
			}
			else if ( iswdigit( arg[i][0] ) && ( val1 == W3C_COLOR_UNDEFINED ) ) {
				if ( ParseInt( arg[i], &val1, NULL ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad color value: \"%s\"\r\n", arg[i] );
					return 1;
				}
			}
			else if ( iswdigit( arg[i][0] ) && ( val2 == W3C_COLOR_UNDEFINED ) ) {
				if ( ParseInt( arg[i], &val2, NULL ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad color value: \"%s\"\r\n", arg[i] );
					return 1;
				}
			}
			else if ( iswdigit( arg[i][0] ) && ( val3 == W3C_COLOR_UNDEFINED ) ) {
				if ( ParseInt( arg[i], &val3, NULL ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad color value: \"%s\"\r\n", arg[i] );
					return 1;
				}
			}
			else {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Syntax error: \"%s\"\r\n", arg[i] );
				return 1;
			}

		}
	}

	if ( val1 != W3C_COLOR_UNDEFINED ) {

		if ( val2 == W3C_COLOR_UNDEFINED ) {
			BGColor = val1;

			if ( BGColor > 0xffffff ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Combined color value must be in the range 0x000000 to 0xffffff\r\n" );
				return 1;
			}
		}
		else {
			if ( val3 == W3C_COLOR_UNDEFINED ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Blue value missing\r\n" );
				return 1;
			}

			if ( ( val1 > 0xff ) || ( val2 > 0xff ) || ( val3 > 0xff ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Individual color values must be in the range 0x00 to 0xff\r\n" );
				return 1;
			}

			BGColor = ( val1 << 16 ) | ( val2 << 8 ) | val3;
		}

		BGColorShuffled = ShuffleColors( BGColor );

		if ( SetSysColors( 1, &WhichColor, &BGColorShuffled ) == 0 ) {
			DisplayErrorHeader();
			GetErrorText( GetLastError(), ErrorText );
			Qprintf( ERRHANDLE, L"Error setting background color: %s\r\n", ErrorText );
			return 2;
		}
	}
	else {
		BGColorShuffled = GetSysColor( COLOR_BACKGROUND );
		BGColor = ShuffleColors( BGColorShuffled );
	}

	int ColorFound = W3CColorIndex( BGColor );

	if ( ColorFound == -1 )
		Printf( L"Background color is #%06x.\r\n", BGColor );
	else
		Printf( L"Background color is #%06x (%s).\r\n", BGColor, W3CColor[ColorFound].Name );

	if ( Save ) {
		rv = RegOpenKeyEx( HKEY_CURRENT_USER, KeyName, 0, KEY_READ | KEY_WRITE, &KeyHandle );

		if ( rv == 0 ) {
			wsprintf( Temp, L"%u %u %u", ( BGColor & 0xff0000 ) >> 16, ( BGColor & 0xff00 ) >> 8, ( BGColor & 0xff ) );
			SetRegString( KeyHandle, BackgroundValueName, Temp );
			RegCloseKey( KeyHandle );
		}
		else {
			DisplayErrorHeader();
			GetErrorText( rv, ErrorText );
			Qprintf( ERRHANDLE, L"Error opening registry key: %s\r\n", ErrorText );
			return 2;
		}
	}

	if ( DefaultUser ) {
		rv = RegOpenKeyEx( HKEY_USERS, DefaultUserKeyName, 0, KEY_READ | KEY_WRITE, &KeyHandle );

		if ( rv == 0 ) {
			wsprintf( Temp, L"%u %u %u", ( BGColor & 0xff0000 ) >> 16, ( BGColor & 0xff00 ) >> 8, ( BGColor & 0xff ) );
			SetRegString( KeyHandle, BackgroundValueName, Temp );
			RegCloseKey( KeyHandle );
		}
		else {
			DisplayErrorHeader();
			GetErrorText( rv, ErrorText );
			Qprintf( ERRHANDLE, L"Error opening default-user registry key: %s\r\n", ErrorText );
			return 2;
		}
	}

	return 0;
}



DLLExports int WINAPI _bgcolor( LPTSTR outString )
{
	if ( !outString )
		return 1;


	unsigned int BGColor = W3C_COLOR_UNDEFINED;
	COLORREF BGColorShuffled = 0;

	BGColorShuffled = GetSysColor( COLOR_BACKGROUND );
	BGColor = ShuffleColors( BGColorShuffled );

	wsprintf( outString, L"#%06x", BGColor );
	return 0;
}



DLLExports int WINAPI _bgcolorname( LPTSTR outString )
{
	if ( outString == NULL )
		return 1;

	unsigned int BGColor = W3C_COLOR_UNDEFINED;
	COLORREF BGColorShuffled = 0;

	BGColorShuffled = GetSysColor( COLOR_BACKGROUND );
	BGColor = ShuffleColors( BGColorShuffled );

	int ColorFound = W3CColorIndex( BGColor );

	if ( ColorFound == W3C_COLOR_UNDEFINED )
		wsprintf( outString, L"#%06x", BGColor );
	else
		wcscpy_s( outString, MAX_ARG_LEN, W3CColor[ColorFound].Name );

	return 0;
}


BOOL ScreenSaverFile( LPTSTR inString )
{
	if ( inString == NULL )
		return FALSE;

	LPTSTR ext = NULL;


	for ( size_t i = 0; inString[i]; i++ ) {

		if ( ( inString[i] == '/' ) || ( inString[i] == '\\' ) || ( inString[i] == ':' ) )
			ext = NULL;
		else if ( inString[i] == '.' )
			ext = inString + i;
	}

	if ( ext == NULL )
		return FALSE;

	if ( _wcsicmp( ext, L".scr" ) == 0 )
		return TRUE;
	
	return FALSE;
}


int PickDefaultScreenSaver( LPTSTR Filename )
{
	if ( Filename == NULL )
		return -1;

	wchar_t SysDir[MAX_FILENAME_LEN] = L"";
	wchar_t Temp[MAX_FILENAME_LEN]   = L"";

	wchar_t SmallestName[MAX_FILENAME_LEN] = L"";
	DWORD SmallestSize = 0xffffffff;

	HANDLE SearchHandle = NULL;
	WIN32_FIND_DATA FoundItem;


	if ( GetSystemDirectory( SysDir, MAX_FILENAME_LEN ) == 0 )
		return -1;
	

	//  first try ScrnSave.scr :

	wcscpy_s( Temp, MAX_FILENAME_LEN, SysDir );
	AppendFilename( Temp, L"ScrnSave.scr", MAX_FILENAME_LEN );		//	MakeDirectoryName( Temp, L"ScrnSave.scr" );
	if ( IsAFile( Temp ) ) {
		wcscpy_s( Filename, MAX_ARG_LEN, Temp );
		return 0;
	}


	//  else just search for the smallest one :

	wcscpy_s( Temp, MAX_FILENAME_LEN, SysDir );
	AppendFilename( Temp, L"*.scr", MAX_FILENAME_LEN );				//	MakeDirectoryName( Temp, L"*.scr" );

	SearchHandle = FindFirstFile( Temp, &FoundItem );
	if ( SearchHandle == INVALID_HANDLE_VALUE )
		return -1;

	do {
		if ( FoundItem.dwFileAttributes & ( FILE_ATTRIBUTE_DIRECTORY | FILE_ATTRIBUTE_DEVICE | FILE_ATTRIBUTE_OFFLINE ) )
			continue;

		if ( FoundItem.nFileSizeHigh )
			continue;

		if ( FoundItem.nFileSizeLow >= SmallestSize )
			continue;

		SmallestSize = FoundItem.nFileSizeLow;
		wcscpy_s( SmallestName, MAX_FILENAME_LEN, FoundItem.cFileName );

	} while ( FindNextFile( SearchHandle, &FoundItem ) );

	FindClose( SearchHandle );

	if ( SmallestName[0] ) {
		wcscpy_s( Temp, MAX_FILENAME_LEN, SysDir );
		AppendFilename( Temp, SmallestName, MAX_FILENAME_LEN );			//	MakeDirectoryName( Temp, SmallestName );
		wcscpy_s( Filename, MAX_FILENAME_LEN, Temp );
		return 0;
	}

	return 1;
}


DLLExports int WINAPI scrnsaver( LPTSTR inString )
{
	if ( !inString )
		return -1;

	wchar_t Filename[MAX_FILENAME_LEN]    = L"";
	wchar_t NewFilename[MAX_FILENAME_LEN] = L"";
	wchar_t temp[MAX_FILENAME_LEN]        = L"";
	wchar_t ErrorText[SHORT_BUF_LEN]      = L"";

	unsigned int Timeout = 0, NewTimeout = 0;
	unsigned int Enabled = 0, NewEnabled = 0;
	unsigned int Secure = 0,  NewSecure = 0;
	BOOL ChangeTimeout = FALSE, ChangeEnabled = FALSE, ChangeSecure = FALSE, AnyChange = FALSE;
	BOOL RemoveScreenSaver = FALSE, Activate = FALSE, DefaultUser = FALSE;
	int ErrorLevel = 0;

	const wchar_t SubkeyName[] = L"Control Panel\\Desktop";
	const wchar_t DefaultUserSubkeyName[] = L".DEFAULT\\Control Panel\\Desktop";

	const wchar_t FilenameValueName[] = L"SCRNSAVE.EXE";
	const wchar_t EnabledValueName[]  = L"ScreenSaveActive";
	const wchar_t SecureValueName[]   = L"ScreenSaverIsSecure";
	const wchar_t TimeOutValueName[]  = L"ScreenSaveTimeOut";


	HKEY KeyHandle = NULL;
	DWORD ValueType = 0, DataSize = 0;
	int rv = 0;


	ParseArgs( inString, PARSE_BREAK_SPACES | PARSE_SLASHES_KLUDGE );


	for ( int i = 0; i < numargs; i++ ) {
		if ( arglen[i] ) {
			if ( !wcsncmp( arg[i], L"/?", 2 ) )
				return ShowCmdHelp( ScrnSaverHelpText, ( arg[i][2] == '?' ) );
			else if ( !_wcsnicmp( arg[i], L"/T", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				if ( ParseSeconds( arg[i] + j, &NewTimeout ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad timeout: \"%s\"\r\n", arg[i] );
					return 1;
				}

				if ( NewTimeout > 86400 ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Timeout must be 0 to 86400\r\n" );
					return 1;
				}

				ChangeTimeout = TRUE;
			}
			else if ( !_wcsicmp( arg[i], L"/A" ) )
				Activate = TRUE;
			else if ( !_wcsicmp( arg[i], L"/E" ) ) {
				NewEnabled = 1;
				ChangeEnabled = TRUE;
			}
			else if ( !_wcsicmp( arg[i], L"/D" ) ) {
				NewEnabled = 0;
				ChangeEnabled = TRUE;
			}
			else if ( !_wcsicmp( arg[i], L"/N" ) )
				RemoveScreenSaver = TRUE;
			else if ( !_wcsicmp( arg[i], L"/S" ) ) {
				NewSecure = 1;
				ChangeSecure = TRUE;
			}
			else if ( !_wcsicmp( arg[i], L"/U" ) ) {
				NewSecure = 0;
				ChangeSecure = TRUE;
			}
			else if ( !_wcsicmp( arg[i], L"/DU" ) )
				DefaultUser = TRUE;
			else if ( arg[i][0] == '/' ) {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Unknown option: \"%s\"\r\n", arg[i] );
				return 1;
			}
			else if ( NewFilename[0] == '\0' )
				wcscpy_s( NewFilename, MAX_FILENAME_LEN, arg[i] );
			else {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Syntax error: \"%s\"\r\n", arg[i] );
				return 1;
			}

		}
	}
	
	if ( RemoveScreenSaver && NewFilename[0] ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Can\u2019t combine /N with a filename\r\n" );
		return 1;
	}

	AnyChange = ( NewFilename[0] || RemoveScreenSaver || ChangeTimeout || ChangeEnabled || ChangeSecure );


	if ( NewFilename[0] ) {

		if ( _PathPart( NewFilename, NULL ) == NULL ) {
			GetSystemDirectory( temp, MAX_FILENAME_LEN );
			AppendFilename( temp, NewFilename, MAX_FILENAME_LEN );			//	MakeDirectoryName( temp, NewFilename );
			wcscpy_s( NewFilename, MAX_FILENAME_LEN, temp );
		}

		if ( _ExtensionPart( NewFilename, NULL ) == NULL ) {
			if ( NewFilename[ wcslen( NewFilename ) - 1 ] == '.' )
				wcscat_s( NewFilename, MAX_FILENAME_LEN, L"scr" );
			else
				wcscat_s( NewFilename, MAX_FILENAME_LEN, L".scr" );
		}

		//  QueryTrueName( NewFilename, temp );
		CanonicalizeFilenameEx( NewFilename, temp );
		wcscpy_s( NewFilename, MAX_FILENAME_LEN, temp );

		if ( !IsAFile( NewFilename ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"File not found: \"%s\"\r\n", NewFilename );
			return 2;
		}

		if ( !ScreenSaverFile( NewFilename ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Not a screen saver file: \"%s\"\r\n", NewFilename );
			return 2;
		}
	}

	rv = RegOpenKeyEx( HKEY_CURRENT_USER, SubkeyName, 0, KEY_READ | KEY_WRITE, &KeyHandle );
	if ( rv ) {
		GetErrorText( rv, ErrorText );
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Error opening registry key: %s\r\n", ErrorText );
		return 2;
	}

	DataSize = MAX_FILENAME_LEN * sizeof( wchar_t );
	RegQueryValueEx( KeyHandle, FilenameValueName, NULL, &ValueType, (BYTE *) Filename, &DataSize );

	if ( ( ValueType != REG_SZ ) && ( ValueType != REG_EXPAND_SZ ) )
		Filename[0] = 0x00;

	if ( ValueType == REG_EXPAND_SZ ) {
		if ( wcschr( Filename, '%' ) != NULL ) {
			temp[0] = 0x00;
			rv = ExpandEnvironmentStrings( Filename, temp, MAX_FILENAME_LEN );
			if ( rv && temp[0] )
				wcscpy_s( Filename, MAX_FILENAME_LEN, temp );
		}
	}

	Enabled = GetRegStringValue( KeyHandle, (LPTSTR) EnabledValueName );
	if ( Enabled == -1 )
		Enabled = 0;

	Secure  = GetRegStringValue( KeyHandle, (LPTSTR) SecureValueName );
	if ( Secure == -1 )
		Secure = 0;

	SystemParametersInfo( SPI_GETSCREENSAVETIMEOUT, 0, &Timeout, 0 );


	if ( AnyChange ) {

		if ( ( Filename[0] == 0x00 ) && ( NewFilename[0] == 0x00 ) && !RemoveScreenSaver )
			PickDefaultScreenSaver( NewFilename );

		if ( NewFilename[0] || RemoveScreenSaver ) {
			rv = SetRegString( KeyHandle, FilenameValueName, NewFilename );
			if ( rv ) {
				GetErrorText( rv, ErrorText );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Error setting screen saver name: %s\r\n", ErrorText );
				return 2;
			}

			wcscpy_s( Filename, MAX_FILENAME_LEN, NewFilename );
		}

		if ( ChangeEnabled ) {
			if ( SystemParametersInfo( SPI_SETSCREENSAVEACTIVE, NewEnabled, NULL, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE ) == 0 ) {
				GetErrorText( GetLastError(), ErrorText );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Error setting screen saver enabled: %s\r\n", ErrorText );
				return 2;
			}

			Enabled = NewEnabled;
		}

		if ( ChangeSecure ) {
			rv = SetRegStringValue( KeyHandle, SecureValueName, NewSecure );
			if ( rv ) {
				GetErrorText( rv, ErrorText );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Error setting screen saver secured: %s\r\n", ErrorText );
				return 2;
			}

			Secure = NewSecure;
		}

		if ( ChangeTimeout )
			Timeout = NewTimeout;

		if ( SystemParametersInfo( SPI_SETSCREENSAVETIMEOUT, Timeout, NULL, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE ) == 0 ) {
			GetErrorText( GetLastError(), ErrorText );
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Error setting screen saver timeout: %s\r\n", ErrorText );
			return 2;
		}
	}



	if ( Filename[0] )
		Printf( L"Screen saver \"%s\":\r\n", Filename );
	else
		Printf( L"No screen saver specified:\r\n" );

	Printf( L"%u seconds", Timeout );

	unsigned int h = Timeout / 3600;
	unsigned int m = ( Timeout - ( 3600 * h ) ) / 60;
	unsigned int s = Timeout - ( 3600 * h ) - ( 60 * m );

	if ( h )
		Printf( L" (%u:%02u:%02u)", h, m, s );
	else if ( m )
		Printf( L" (%u:%02u)", m, s );

	if ( Enabled )
		QPuts( L", enabled, " );
	else
		QPuts( L", disabled, " );

	if ( Secure )
		QPuts( L"secure.\r\n" );
	else
		QPuts( L"unsecure.\r\n" );

	RegCloseKey( KeyHandle );


	ErrorLevel = 0;

	if ( DefaultUser ) {
		rv = RegOpenKeyEx( HKEY_USERS, DefaultUserSubkeyName, 0, KEY_READ | KEY_WRITE, &KeyHandle );

		if ( rv ) {
			GetErrorText( rv, ErrorText );
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Error opening default user registry key: %s\r\n", ErrorText );
			ErrorLevel = 2;
		}
		else {
			if ( SetRegString( KeyHandle, FilenameValueName, Filename ) )
				ErrorLevel = 2;

			if ( SetRegStringValue( KeyHandle, EnabledValueName, Enabled ) )
				ErrorLevel = 2;

			if ( SetRegStringValue( KeyHandle, SecureValueName, Secure ) )
				ErrorLevel = 2;

			if ( SetRegStringValue( KeyHandle, TimeOutValueName, Timeout ) )
				ErrorLevel = 2;

			if ( ErrorLevel ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Error writing screen saver settings for default user\r\n" );
			}

			RegCloseKey( KeyHandle );
		}
	}

	if ( Activate )
		SendMessage( GetForegroundWindow(), WM_SYSCOMMAND, SC_SCREENSAVE, 0 );

	return ErrorLevel;
}


int Enquote( LPTSTR String )
{
	if ( String == NULL )
		return -1;

	wchar_t temp[MAX_FILENAME_LEN] = L"\"";
	wcscat_s( temp, MAX_FILENAME_LEN, String );
	wcscat_s( temp, MAX_FILENAME_LEN, L"\"" );

	wcscpy_s( String, MAX_FILENAME_LEN, temp );
	return 0;
}


DLLExports int WINAPI _ssvrname( LPTSTR outString )
{
	if ( outString == NULL )
		return 1;

	const wchar_t SubkeyName[] = L"Control Panel\\Desktop";
	const wchar_t FilenameValueName[] = L"SCRNSAVE.EXE";

	HKEY KeyHandle = NULL;
	DWORD ValueType = 0, DataSize = 0;

	wcscpy_s( outString, MAX_ARG_LEN, ErrorString );

	if ( RegOpenKeyEx( HKEY_CURRENT_USER, SubkeyName, 0, KEY_READ, &KeyHandle ) )
		return 0;

	DataSize = MAX_FILENAME_LEN * sizeof( wchar_t );
	RegQueryValueEx( KeyHandle, FilenameValueName, NULL, &ValueType, (BYTE *) outString, &DataSize );

	RegCloseKey( KeyHandle );

	if ( ( ( ValueType != REG_SZ ) && ( ValueType != REG_EXPAND_SZ ) ) || ( outString[0] == 0x00 ) )
		wcscpy_s( outString, MAX_ARG_LEN, NoneString );
	else
		Enquote( outString );

	return 0;
}


DLLExports int WINAPI _ssvrtime( LPTSTR outString )
{
	if ( outString == NULL )
		return 1;

	unsigned int Timeout = 0;
	
	if ( SystemParametersInfo( SPI_GETSCREENSAVETIMEOUT, 0, &Timeout, 0 ) )
		wsprintf( outString, L"%u", Timeout );
	else
		wcscpy_s( outString, MAX_ARG_LEN, ErrorString );
	
	return 0;
}


DLLExports int WINAPI _ssvrup( LPTSTR outString )
{
	if ( outString == NULL )
		return 1;

	int Running = 0;
	
	if ( SystemParametersInfo( SPI_GETSCREENSAVERRUNNING, 0, &Running, 0 ) )
		wsprintf( outString, L"%d", Running );
	else
		wcscpy_s( outString, MAX_ARG_LEN, ErrorString );
	
	return 0;
}


int ConsoleHandle( HANDLE inHandle )
{
	if ( inHandle == NULL )
		return 0;

	if ( ( inHandle == (HANDLE) STD_INPUT_HANDLE ) || ( inHandle == (HANDLE) STD_OUTPUT_HANDLE ) || ( inHandle == (HANDLE) STD_ERROR_HANDLE ) )
		inHandle = GetStdHandle( (DWORD) inHandle );

	DWORD Mode = UINT_MAX;
	int rv = GetConsoleMode( inHandle, &Mode );

	if ( ( rv == 0 ) || ( Mode == UINT_MAX ) )
		return 0;
	else
		return 1;
}


int GetEncoderClsid( const WCHAR* form, CLSID* pClsid )
{
    UINT num;
    UINT size;
    ImageCodecInfo* pImageCodecInfo=NULL;
    GetImageEncodersSize( &num, &size );
    if ( size == 0 )
        return -1;
    pImageCodecInfo = (ImageCodecInfo *) ( malloc( size ) );
    if ( pImageCodecInfo == NULL )
        return -1;
    GetImageEncoders( num, size, pImageCodecInfo );

    for ( UINT j = 0; j < num; j++ )
    {
        if ( wcscmp( pImageCodecInfo[j].MimeType, form ) == 0 )
        {
            *pClsid = pImageCodecInfo[j].Clsid;
            free( pImageCodecInfo );
            return j;
        }
    }
    free( pImageCodecInfo );
    return -1;
}


int BitmapFromClip( Bitmap **OutBitmap )
{
	if ( OutBitmap == NULL )
		return -1;

	HBITMAP  ClipboardBitmap  = NULL;
	HPALETTE ClipboardPalette = NULL;
	Bitmap   *NewBitmap = NULL;


	if ( OpenClipboard( NULL ) == 0 ) {
		*OutBitmap = NULL;
		return 1;
	}

	ClipboardBitmap  = (HBITMAP)  GetClipboardData( CF_BITMAP );
	ClipboardPalette = (HPALETTE) GetClipboardData( CF_PALETTE );

	if ( ClipboardBitmap == NULL ) {
		CloseClipboard();
		*OutBitmap = NULL;
		return 1;
	}

	NewBitmap = new Bitmap( ClipboardBitmap, ClipboardPalette );

	if ( NewBitmap == NULL ) {
		*OutBitmap = NULL;
		return 1;
	}
	else if ( NewBitmap->GetLastStatus() ) {
		delete NewBitmap;
		*OutBitmap = NULL;
		return 1;
	}

	CloseClipboard();
	*OutBitmap = NewBitmap;
	return 0;
}


int MakeWallpaper( LPTSTR inFile, LPTSTR outFile, unsigned int *ImageX, unsigned int *ImageY, BOOL Debug )
{
	if ( !inFile || !outFile )
		return -1;

	int rv = 0;
	CLSID encoderClsid;
	BOOL ConsoleOutput = FALSE;

	wchar_t Erase[] = L"\r            \r";


	if ( ConsoleHandle( GetStdHandle( STD_OUTPUT_HANDLE ) ) ) {
		ConsoleOutput = TRUE;
		QPuts( L"Converting: " );
	}


	//		load the image:

	Bitmap *SourceImage = NULL;

	if ( IsClipboard( inFile ) )
		BitmapFromClip( &SourceImage );
	else
		SourceImage = new Bitmap( inFile );

	if ( SourceImage == NULL ) {
		if ( Debug )
			Printf( L"   * Error loading SourceImage\r\n" );
		else if ( ConsoleOutput )
			QPuts( Erase );

		return -1;
	}

	rv = SourceImage->GetLastStatus();
	if ( rv ) {
		if ( Debug )
			Printf( L"   * Error %d loading SourceImage\r\n", rv );
		else if ( ConsoleOutput )
			QPuts( Erase );

		delete SourceImage;
		return rv;
	}

	UINT OldHeight = SourceImage->GetHeight();
	UINT OldWidth  = SourceImage->GetWidth();

	if ( ( OldHeight == 0 ) || ( OldWidth == 0 ) ) {
		if ( Debug )
			Printf( L"   * SourceImage has a height or width of zero\r\n" );
		else if ( ConsoleOutput )
			QPuts( Erase );

		delete SourceImage;
		return -2;
	}

	rv = GetEncoderClsid( L"image/bmp", &encoderClsid );

	if ( rv < 0 ) {
		if ( Debug )
			Printf( L"   * Error getting encoder for \"image/bmp\"\r\n" );
		else if ( ConsoleOutput )
			QPuts( Erase );

		delete SourceImage;
		return -3;
	}


	//		resize the image:

	unsigned int MaxHeight = GetSystemMetrics( SM_CYSCREEN );
	unsigned int MaxWidth  = GetSystemMetrics( SM_CXSCREEN );
	unsigned int NewHeight = OldHeight, NewWidth = OldWidth;


	if ( ( NewHeight > MaxHeight ) || ( NewWidth > MaxWidth ) ) {
		double Ratio = (double) OldWidth / (double) OldHeight;
		double xr = (double) OldWidth / (double) MaxWidth;
		double yr = (double) OldHeight / (double) MaxHeight;

		if ( xr >= yr ) {
			//	fit to width

			NewWidth = MaxWidth;
			NewHeight = (unsigned int) ( NewWidth / Ratio );
		}
		else {
			//	fit to height

			NewHeight = MaxHeight;
			NewWidth = (unsigned int) ( NewHeight * Ratio );
		}


		Bitmap *ResizedImage = new Bitmap( NewWidth, NewHeight, PixelFormat24bppRGB );

		rv = ResizedImage->GetLastStatus();
		if ( rv ) {
			if ( Debug )
				Printf( L"   * Error %d creating ResizedImage\r\n", rv );
			else if ( ConsoleOutput )
				QPuts( Erase );

			delete SourceImage;
			return rv;
		}

		ResizedImage->SetResolution( SourceImage->GetHorizontalResolution(), SourceImage->GetVerticalResolution() );


		Graphics *ResizeGraf = new Graphics( ResizedImage );

		rv = ResizeGraf->GetLastStatus();
		if ( rv ) {
			if ( Debug )
				Printf( L"   * Error %d creating ResizeGraf\r\n", rv );
			else if ( ConsoleOutput )
				QPuts( Erase );

			delete SourceImage;
			delete ResizedImage;
			return rv;
		}
		
		ResizeGraf->SetInterpolationMode( InterpolationModeHighQuality );

		rv = ResizeGraf->DrawImage( SourceImage, 0, 0, NewWidth, NewHeight );
		if ( rv ) {
			if ( Debug )
				Printf( L"   * ResizeGraf->DrawImage() returned %d\r\n", rv );
			else if ( ConsoleOutput )
				QPuts( Erase );

			delete SourceImage;
			delete ResizedImage;
			delete ResizeGraf;
			return rv;
		}

		rv = ResizedImage->Save( outFile, &encoderClsid );
		if ( rv ) {
			if ( Debug )
				Printf( L"   * ResizedImage->Save() returned %d\r\n", rv );
			else if ( ConsoleOutput )
				QPuts( Erase );

			delete SourceImage;
			delete ResizedImage;
			delete ResizeGraf;
			return rv;
		}

		if ( ImageX != NULL )
			*ImageX = NewWidth;

		if ( ImageY != NULL )
			*ImageY = NewHeight;

		delete ResizeGraf;
	}
	else {
		rv = SourceImage->Save( outFile, &encoderClsid );
		if ( rv ) {
			if ( Debug )
				Printf( L"   * SourceImage->Save() returned %d\r\n", rv );
			else if ( ConsoleOutput )
				QPuts( Erase );

			delete SourceImage;
			return rv;
		}

		if ( ImageX != NULL )
			*ImageX = OldWidth;

		if ( ImageY != NULL )
			*ImageY = OldHeight;
	}


	//		shut down gdiplus:

	delete SourceImage;

	if ( ConsoleOutput )
		QPuts( Erase );

	return 0;
}


int MakeWallpaperName( LPTSTR outString, BOOL DefaultUser )
{
	if ( outString == NULL )
		return -1;

	wchar_t Filename[MAX_FILENAME_LEN] = L"";
	int rv = 0;

	if ( DefaultUser ) {
		rv = SHGetFolderPath( NULL, CSIDL_COMMON_APPDATA, NULL, SHGFP_TYPE_CURRENT, Filename );

		if ( rv || ( Filename[0] == 0x00 ) )
			return -1;
	}
	else {
		rv = SHGetFolderPath( NULL, CSIDL_LOCAL_APPDATA, NULL, SHGFP_TYPE_CURRENT, Filename );

		if ( rv || ( Filename[0] == 0x00 ) )
			rv = SHGetFolderPath( NULL, CSIDL_APPDATA, NULL, SHGFP_TYPE_CURRENT, Filename );

		if ( rv || ( Filename[0] == 0x00 ) )
			return -1;
	}

	AppendFilename( Filename, L"UIStuff", MAX_FILENAME_LEN );			//	MakeDirectoryName( Filename, L"UIStuff" );

	if ( QueryIsDirectory( Filename ) == 0 ) {
		rv = CreateDirectory( Filename, NULL );

		if ( rv == 0 )
			return -1;
		
		if ( QueryIsDirectory( Filename ) == 0 )
			return -1;
	}

	AppendFilename( Filename, L"Wallpaper.bmp", MAX_FILENAME_LEN );		//	MakeDirectoryName( Filename, L"Wallpaper.bmp" );

	wcscpy_s( outString, MAX_FILENAME_LEN, Filename );
	return 0;
}


int GetImageSize( LPTSTR Filename, unsigned int *X, unsigned int *Y )
{
	if ( ( Filename == NULL ) || ( X == NULL ) || ( Y == NULL ) )
		return -1;

	if ( Filename[0] == 0x00 )
		return -1;


	int rv = 0;


	//		load the image:

	Bitmap *SourceImage = NULL;

	if ( IsClipboard( Filename ) )
		BitmapFromClip( &SourceImage );
	else
		SourceImage = new Bitmap( Filename );

	if ( SourceImage == NULL )
		return -1;

	rv = SourceImage->GetLastStatus();
	if ( rv )
		return rv;

	UINT OldHeight = SourceImage->GetHeight();
	UINT OldWidth  = SourceImage->GetWidth();

	if ( ( OldHeight == 0 ) || ( OldWidth == 0 ) ) {
		delete SourceImage;
		return -2;
	}

	*X = OldWidth;
	*Y = OldHeight;

	delete SourceImage;
	return 0;
}


DLLExports int WINAPI _wallpaper( LPTSTR outString )
{
	if ( outString == NULL )
		return 1;

	if ( SystemParametersInfo( SPI_GETDESKWALLPAPER, MAX_FILENAME_LEN, outString, 0 ) ) {
		if ( outString[0] == 0x00 )
			wcscpy_s( outString, MAX_ARG_LEN, NoneString );
		else
			Enquote( outString );
	}
	else
		wcscpy_s( outString, MAX_ARG_LEN, ErrorString );

	return 0;
}


int GetWallpaperStyle()
{
	wchar_t TileWallpaperString[SHORT_BUF_LEN]		= L"";
	wchar_t WallpaperStyleString[SHORT_BUF_LEN]		= L"";

	long int TileWallpaperValue = 0, WallpaperStyleValue = 0;

	HKEY KeyHandle = NULL;
	DWORD DataType = 0, DataSize = 0;

	const wchar_t KeyName[]				= L"Control Panel\\Desktop";
	const wchar_t TiledValueName[]		= L"TileWallpaper";
	const wchar_t StyleValueName[]		= L"WallpaperStyle";


	if ( RegOpenKeyEx( HKEY_CURRENT_USER, KeyName, 0, KEY_READ, &KeyHandle ) )
		return -1;

	DataSize = SHORT_BUF_LEN * sizeof( wchar_t );
	DataType = 0;

	if ( RegQueryValueEx( KeyHandle, TiledValueName, NULL, &DataType, (BYTE *) TileWallpaperString, &DataSize ) )
		DataSize = 0;

	if ( DataSize && ( DataType == REG_SZ ) )
		TileWallpaperValue = wcstol( TileWallpaperString, NULL, 10 );

	DataSize = SHORT_BUF_LEN * sizeof( wchar_t );
	DataType = 0;

	if ( RegQueryValueEx( KeyHandle, StyleValueName, NULL, &DataType, (BYTE *) WallpaperStyleString, &DataSize ) )
		DataSize = 0;

	if ( DataSize && ( DataType == REG_SZ ) )
		WallpaperStyleValue = wcstol( WallpaperStyleString, NULL, 10 );

	RegCloseKey( KeyHandle );

	if ( TileWallpaperValue & 1 )
		return WP_TILED;
	else if ( WallpaperStyleValue & 2 )
		return WP_STRETCHED;
	else
		return WP_CENTERED;
}


DLLExports int WINAPI _wallstyle( LPTSTR outString )
{
	if ( outString == NULL )
		return 1;

	int Style = GetWallpaperStyle();

	if ( Style == WP_TILED )
		wcscpy_s( outString, MAX_ARG_LEN, L"Tiled" );
	else if ( Style == WP_STRETCHED )
		wcscpy_s( outString, MAX_ARG_LEN, L"Stretched" );
	else
		wcscpy_s( outString, MAX_ARG_LEN, L"Centered" );

	return 0;
}


BOOL HasWildcards( LPTSTR Filename )
{
	if ( Filename == NULL )
		return FALSE;

	int start = 0;

	if ( _wcsnicmp( Filename, L"\\\\?\\", 4 ) == 0 )
		start = 4;

	for ( int i = start; Filename[i]; i++ )
		if ( ( Filename[i] == '?' ) || ( Filename[i] == '*' ) )
			return TRUE;

	return FALSE;
}


BOOL GraphicsFileType( LPTSTR inString )
{
	if ( inString == NULL )
		return FALSE;

	LPTSTR ext = NULL;


	for ( size_t i = 0; inString[i]; i++ ) {

		if ( ( inString[i] == '/' ) || ( inString[i] == '\\' ) || ( inString[i] == ':' ) )
			ext = NULL;
		else if ( inString[i] == '.' )
			ext = inString + i;
	}

	if ( ext == NULL )
		return FALSE;

	if ( _wcsicmp( ext, L".bmp" ) == 0 )
		return TRUE;
	else if ( _wcsicmp( ext, L".jpg" ) == 0 )
		return TRUE;
	else if ( _wcsicmp( ext, L".jpeg" ) == 0 )
		return TRUE;
	else if ( _wcsicmp( ext, L".png" ) == 0 )
		return TRUE;
	else if ( _wcsicmp( ext, L".gif" ) == 0 )
		return TRUE;
	else if ( _wcsicmp( ext, L".tif" ) == 0 )
		return TRUE;
	else if ( _wcsicmp( ext, L".tiff" ) == 0 )
		return TRUE;
	
	return FALSE;
}


BOOL OSSupportedWallpaperType( LPTSTR inString )
{
	if ( inString == NULL )
		return FALSE;

	LPTSTR ext = NULL;


	for ( size_t i = 0; inString[i]; i++ ) {

		if ( ( inString[i] == '/' ) || ( inString[i] == '\\' ) || ( inString[i] == ':' ) )
			ext = NULL;
		else if ( inString[i] == '.' )
			ext = inString + i;
	}

	if ( ext == NULL )
		return FALSE;

	if ( _wcsicmp( ext, L".bmp" ) == 0 )
		return TRUE;

	if ( ( OSVerInfo.dwMajorVersion > 5 ) && ( _wcsicmp( ext, L".jpg" ) == 0 ) )
		return TRUE;

	if ( ( OSVerInfo.dwMajorVersion > 5 ) && ( _wcsicmp( ext, L".jpeg" ) == 0 ) )
		return TRUE;

	return FALSE;
}


int GetRand( int Range )
{
	unsigned int RandVal = 0;
	double real	= 0.0;


	rand_s( &RandVal );
	real = (double) RandVal / ( UINT_MAX + 1.0 );
	real = real * (double) Range;
	return (int) real;
}



struct SaveFilename {
	SaveFilename * Next;
	wchar_t Name;
};


int _PickRandomEnumFiles( LPTSTR Wildspec, BOOL Recurse, SaveFilename **First, SaveFilename **Last, unsigned int *Count )
{
	wchar_t Path[MAX_FILENAME_LEN]			= L"";
	wchar_t FullName[MAX_FILENAME_LEN]		= L"";

	WIN32_FIND_DATA FoundItem;
	HANDLE SearchHandle;

	SaveFilename *NewFile					= NULL;



	_PathPart( Wildspec, Path );

	SearchHandle = FindFirstFile( Wildspec, &FoundItem );
	if ( SearchHandle != INVALID_HANDLE_VALUE ) {

		do {
			if ( FoundItem.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY )
				continue;

			if ( !GraphicsFileType( FoundItem.cFileName ) )
				continue;

			wcscpy_s( FullName, MAX_FILENAME_LEN, Path );
			AppendFilename( FullName, FoundItem.cFileName, MAX_FILENAME_LEN );

			NewFile = (SaveFilename *) AllocMem( sizeof( SaveFilename ) + ( sizeof( wchar_t ) * (int) wcslen( FullName ) ) );

			if ( NewFile == NULL )
				continue;

			NewFile->Next = NULL;
			wcscpy_s( &NewFile->Name, wcslen( FullName ) + 1, FullName );

			if ( *Count ) {
				(*Last)->Next = NewFile;
				*Last = NewFile;
			}
			else {
				*First = NewFile;
				*Last = NewFile;
			}

			(*Count)++;
		}
		while ( FindNextFile( SearchHandle, &FoundItem ) );

		FindClose( SearchHandle );
	}

	if ( Recurse ) {
		SearchHandle = FindFirstFile( Wildspec, &FoundItem );
		if ( SearchHandle != INVALID_HANDLE_VALUE ) {

			do {
				if ( ( FoundItem.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ) == 0 )
					continue;

				if ( FoundItem.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT )
					continue;

				if ( !wcscmp( FoundItem.cFileName, L"." ) )
					continue;

				if ( !wcscmp( FoundItem.cFileName, L".." ) )
					continue;

				wcscpy_s( FullName, MAX_FILENAME_LEN, Path );
				AppendFilename( FullName, FoundItem.cFileName, MAX_FILENAME_LEN );
				AppendFilename( FullName, L"*", MAX_FILENAME_LEN );
				_PickRandomEnumFiles( FullName, Recurse, First, Last, Count );
			}
			while ( FindNextFile( SearchHandle, &FoundItem ) );

			FindClose( SearchHandle );
		}
	}

	return 0;
}


int PickRandomImageFile( LPTSTR Filename, BOOL Recurse )
{
	if ( Filename == NULL )
		return -1;


	wchar_t Wildspec[MAX_FILENAME_LEN] = L"";

	unsigned int FilesCount = 0, RandomIndex = 0;
	static unsigned int LastRandom = -1;

	SaveFilename *First = NULL, *Last = NULL, *NewFile = NULL;


	wcscpy_s( Wildspec, MAX_FILENAME_LEN, Filename );
	_AddWildcardIfDirectory( Wildspec, MAX_FILENAME_LEN );			//	AddWildcardIfDirectory( Wildspec );

	if ( ConsoleHandle( GetStdHandle( STD_OUTPUT_HANDLE ) ) )
		_cputws( L"Finding matching files.... " );

	_PickRandomEnumFiles( Wildspec, Recurse, &First, &Last, &FilesCount );

	if ( ConsoleHandle( GetStdHandle( STD_OUTPUT_HANDLE ) ) )
		_cputws( L"\r                           \r" );

	if ( !FilesCount )
		return -2;


	RandomIndex = GetRand( FilesCount );

	if ( ( LastRandom != -1 ) && ( FilesCount > 2 ) )
		while ( RandomIndex == LastRandom )
			RandomIndex = GetRand( 1000 );

	LastRandom = RandomIndex;

	for ( unsigned int i = 0; i < RandomIndex; i++ ) {
		NewFile = First->Next;
		FreeMem( First );
		First = NewFile;
	}

	wcscpy_s( Filename, MAX_FILENAME_LEN, &(First->Name) );

	while ( First != NULL ) {
		NewFile = First->Next;
		FreeMem( First );
		First = NewFile;
	}

	return 0;
}


int SetWallpaperStyle( int *Style, unsigned int ScreenX, unsigned int ScreenY, unsigned int ImageX, unsigned int ImageY, BOOL DefaultUser )
{
	if ( *Style == WP_BEST_GUESS ) {

		*Style = WP_CENTERED;

		if ( ( ImageX == ScreenX ) && ( ImageY == ScreenY ) )
			*Style = WP_CENTERED;
		else if ( ( ImageX <= ( ScreenX / 4 ) ) && ( ImageY <= ( ScreenY / 3 ) ) )
			*Style = WP_TILED;
		else if ( ScreenX && ScreenY && ImageX && ImageY ) {
			double ScreenRatio = ScreenX / ScreenY;
			double ImageRatio  = ImageX / ImageY;

			if ( ( (double) ImageX >= ( ScreenX * 0.60 ) ) && ( ImageRatio >= ( ScreenRatio * 0.92 ) ) && ( ImageRatio <= ( ScreenRatio * 1.08 ) ) )
				*Style = WP_STRETCHED;
		}
	}

	if ( DefaultUser && ( Style == WP_NO_CHANGE ) ) {
		*Style = GetWallpaperStyle();

		if ( Style <= WP_NO_CHANGE )
			*Style = WP_CENTERED;
	}


	const wchar_t KeyName[]					= L"Control Panel\\Desktop";
	const wchar_t DefaultUserKeyName[]		= L".DEFAULT\\Control Panel\\Desktop";
	const wchar_t TiledValueName[]			= L"TileWallpaper";
	const wchar_t StyleValueName[]			= L"WallpaperStyle";


	HKEY KeyHandle = NULL;

	if ( RegOpenKeyEx( DefaultUser ? HKEY_USERS : HKEY_CURRENT_USER, DefaultUser ? DefaultUserKeyName : KeyName, 0, KEY_READ | KEY_WRITE, &KeyHandle ) )
		return -1;

	SetRegStringValue( KeyHandle, TiledValueName, ( *Style == WP_TILED ) ? 1 : 0 );
	SetRegStringValue( KeyHandle, StyleValueName, ( *Style == WP_STRETCHED ) ? 2 : 0 );

	RegCloseKey( KeyHandle );
	return 0;
}


DLLExports int WINAPI wallpaper( LPTSTR inString )
{
	if ( !inString )
		return -1;


	wchar_t Filename[MAX_FILENAME_LEN] = L"";
	wchar_t ConvertedFilename[MAX_FILENAME_LEN] = L"";

	int WallpaperStyle = WP_NO_CHANGE;
	BOOL RemoveWallpaper  = FALSE;
	BOOL MustShrink = FALSE;
	BOOL DefaultUser = FALSE;
	BOOL Recurse = FALSE;
	BOOL Debug = FALSE;
	unsigned int ScreenHeight = GetSystemMetrics( SM_CYSCREEN );
	unsigned int ScreenWidth  = GetSystemMetrics( SM_CXSCREEN );
	unsigned int ImageHeight = 0, ImageWidth = 0;
	int rv = 0;
	int ErrorLevel = 0;

	const wchar_t DefaultUserSubkeyName[] = L".DEFAULT\\Control Panel\\Desktop";
	const wchar_t FilenameValueName[] = L"Wallpaper";
	HKEY KeyHandle = NULL;
	wchar_t ErrorText[SHORT_BUF_LEN]      = L"";


	ParseArgs( inString, PARSE_BREAK_SPACES | PARSE_SLASHES_KLUDGE );


	for ( int i = 0; i < numargs; i++ ) {
		if ( arglen[i] ) {

			if ( !wcsncmp( arg[i], L"/?", 2 ) )
				return ShowCmdHelp( WallpaperHelpText, ( arg[i][2] == '?' ) );
			else if ( !_wcsicmp( arg[i], L"/$" ) )
				Debug = TRUE;
			else if ( !_wcsicmp( arg[i], L"/C" ) || !_wcsnicmp( arg[i], L"/CENTER", 7 ) )
				WallpaperStyle = WP_CENTERED;
			else if ( !_wcsicmp( arg[i], L"/S" ) || !_wcsnicmp( arg[i], L"/STRETCH", 8 ) )
				WallpaperStyle = WP_STRETCHED;
			else if ( !_wcsicmp( arg[i], L"/T" ) || !_wcsnicmp( arg[i], L"/TILE", 5 ) )
				WallpaperStyle = WP_TILED;
			else if ( !_wcsicmp( arg[i], L"/B" ) || !_wcsnicmp( arg[i], L"/BEST", 5 ) )
				WallpaperStyle = WP_BEST_GUESS;
			else if ( !_wcsicmp( arg[i], L"/N" ) )
				RemoveWallpaper = TRUE;
			else if ( !_wcsicmp( arg[i], L"/DU" ) )
				DefaultUser = TRUE;
			else if ( !_wcsicmp( arg[i], L"/R" ) )
				Recurse = TRUE;
			else if ( arg[i][0] == '/' ) {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Unknown option: \"%s\"\r\n", arg[i] );
				return 1;
			}
			else if ( Filename[0] == '\0' )
				CanonicalizeFilenameEx( arg[i], Filename );
			else {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Syntax error: \"%s\"\r\n", arg[i] );
				return 1;
			}
		}
	}

	if ( RemoveWallpaper && Filename[0] ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Can\u2019t combine /N with a filename\r\n" );
		return 1;
	}


	if ( WallpaperStyle && ( Filename[0] == '\0' ) )
		SystemParametersInfo( SPI_GETDESKWALLPAPER, MAX_FILENAME_LEN, Filename, 0 );


	if ( RemoveWallpaper ) {
		WallpaperStyle = WP_CENTERED;
		SetWallpaperStyle( &WallpaperStyle, ScreenWidth, ScreenHeight, ImageWidth, ImageHeight, FALSE );
		Filename[0] = 0x00;
		SystemParametersInfo( SPI_SETDESKWALLPAPER, 0, Filename, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE );
		Printf( L"Wallpaper removed.\r\n" );
	}
	else if ( Filename[0] ) {

		_AddWildcardIfDirectory( Filename, MAX_FILENAME_LEN );

		if ( HasWildcards( Filename ) )
			PickRandomImageFile( Filename, Recurse );

		if ( !IsClipboard( Filename ) ) {
			if ( !IsAFile( Filename ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"File not found: \"%s\"\r\n", Filename );
				return 2;
			}
			else if ( !GraphicsFileType( Filename ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"File must be .BMP .JPG .PNG or .GIF: \"%s\"\r\n", Filename );
				return 2;
			}
		}

		GetImageSize( Filename, &ImageWidth, &ImageHeight );

		if ( ( ImageWidth > ScreenWidth ) || ( ImageHeight > ScreenHeight ) )
			MustShrink = TRUE;


		if ( OSSupportedWallpaperType( Filename ) && !MustShrink ) {

			if ( WallpaperStyle )
				SetWallpaperStyle( &WallpaperStyle, ScreenWidth, ScreenHeight, ImageWidth, ImageHeight, FALSE );

			rv = SystemParametersInfo( SPI_SETDESKWALLPAPER, 0, Filename, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE );

			if ( rv == 0 ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Error setting wallpaper \"%s\"\r\n", Filename );
				return 2;
			}
		}
		else {
			if ( MakeWallpaperName( ConvertedFilename, DefaultUser ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Error making .BMP filename\r\n" );
				return 2;
			}

			rv = MakeWallpaper( Filename, ConvertedFilename, &ImageWidth, &ImageHeight, Debug );
			if ( rv ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Error %d converting \"%s\" to \"%s\"\r\n", rv, Filename, ConvertedFilename );
				return 2;
			}

			if ( WallpaperStyle )
				SetWallpaperStyle( &WallpaperStyle, ScreenWidth, ScreenHeight, ImageWidth, ImageHeight, FALSE );

			rv = SystemParametersInfo( SPI_SETDESKWALLPAPER, 0, ConvertedFilename, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE );

			if ( rv == 0 ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Error setting wallpaper \"%s\"\r\n", ConvertedFilename );
				return 2;
			}
		}

		if ( ( WallpaperStyle > 0 ) && ( WallpaperStyle < 4 ) )
			Printf( L"Wallpaper set to \"%s\" (%s).\n", Filename, StyleName[WallpaperStyle] );
		else
			Printf( L"Wallpaper set to \"%s\".\r\n", Filename );
	}
	else {
		if ( SystemParametersInfo( SPI_GETDESKWALLPAPER, MAX_FILENAME_LEN, Filename, 0 ) ) {
			if ( Filename[0] )
				Printf( L"%s\r\n", Filename );
			else
				Printf( L"No wallpaper.\r\n" );
		}
		else {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Error getting wallpaper filename\r\n" );
			return 2;
		}
	}

	ErrorLevel = 0;

	if ( DefaultUser ) {
		rv = RegOpenKeyEx( HKEY_USERS, DefaultUserSubkeyName, 0, KEY_READ | KEY_WRITE, &KeyHandle );

		if ( rv ) {
			GetErrorText( rv, ErrorText );
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Error opening default user registry key: %s\r\n", ErrorText );
			ErrorLevel = 2;
		}
		else {
			if ( SetRegString( KeyHandle, FilenameValueName, ConvertedFilename[0] ? ConvertedFilename : Filename ) )
				ErrorLevel = 2;

			RegCloseKey( KeyHandle );

			if ( SetWallpaperStyle( &WallpaperStyle, ScreenWidth, ScreenHeight, ImageWidth, ImageHeight, TRUE ) )
				ErrorLevel = 2;
		}

		if ( ErrorLevel ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Error writing wallpaper settings for default user\r\n" );
		}
	}

	return ErrorLevel;
}



DLLExports int WINAPI minimizeall( LPTSTR inString )
{
	if ( !inString )
		return -1;


	BOOL Undo = FALSE;


	ParseArgs( inString, PARSE_BREAK_SPACES | PARSE_SLASHES_KLUDGE );


	for ( int i = 0; i < numargs; i++ ) {
		if ( arglen[i] ) {

			if ( !wcsncmp( arg[i], L"/?", 2 ) )
				return ShowCmdHelp( MinimizeAllHelpText, ( arg[i][2] == '?' ) );
			else if ( !_wcsnicmp( arg[i], L"/U", 2 ) )
				Undo = TRUE;
			else if ( arg[i][0] == '/' ) {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Unknown option: \"%s\"\r\n", arg[i] );
				return 1;
			}
			else {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Syntax error: \"%s\"\r\n", arg[i] );
				return 1;
			}
		}
	}

	IShellDispatch* Shell = NULL;
	HRESULT rv = CoCreateInstance( CLSID_Shell, NULL, CLSCTX_SERVER, IID_IDispatch, (void**) &Shell );

	if ( FAILED( rv ) || ( Shell == NULL ) ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Failed to create Shell instance\r\n" );
		return 1;
	}

	if ( Undo )
		Shell->UndoMinimizeALL();
	else
		Shell->MinimizeAll();

	Shell->Release();
	return 0;
}



BOOL IsUnsafe( wchar_t ch )
{
	if ( ( ch == '%' ) || ( ch == '&' ) || ( ch == '(' ) || ( ch == ')' ) || ( ch == '<' ) || ( ch == '>' ) || ( ch == '[' ) || ( ch == ']' ) || ( ch == '^' ) || ( ch == '`' ) || ( ch == '|' ) )
		return TRUE;
	else
		return FALSE;
}


int MakeStringUnsafe( LPTSTR String )
{
	if ( String == NULL )
		return -1;

	for ( int i = 0; String[i]; i++ ) {
		if ( ( String[i] >= 0xff01 ) && ( String[i] <= 0xff5e ) )
			String[i] -= 0xfee0;
	}

	return 0;
}


int MakeStringSafe( LPTSTR String )
{
	if ( String == NULL )
		return -1;

	for ( int i = 0; String[i]; i++ ) {
		wchar_t ch = String[i];

		if ( IsUnsafe( ch ) )
			String[i] = ch + 0xfee0;
	}

	return 0;
}


int VerbGetRegString( LPTSTR KeyName, LPTSTR ValueName, BOOL User, LPTSTR outString, unsigned int BufferSize )
{
	if ( ( KeyName == NULL ) || ( outString == NULL ) )
		return -1;

	wchar_t FullKeyName[SHORT_BUF_LEN] = L"";

	if ( User )
		wcscpy_s( FullKeyName, SHORT_BUF_LEN, L"Software\\Classes\\" );

	wcscat_s( FullKeyName, SHORT_BUF_LEN, KeyName );

	HKEY KeyHandle = NULL;
	DWORD DataType = 0, DataSize = BufferSize * sizeof( wchar_t );
	int rv = 0;

	outString[0] = 0x00;


	if ( RegOpenKeyEx( User ? HKEY_CURRENT_USER : HKEY_CLASSES_ROOT, FullKeyName, 0, KEY_READ, &KeyHandle ) != ERROR_SUCCESS )
		return 1;

	rv  = RegQueryValueEx( KeyHandle, ValueName, NULL, &DataType, (BYTE *) outString, &DataSize );

	RegCloseKey( KeyHandle );

	if ( rv != ERROR_SUCCESS ) {
		outString[0] = 0x00;
		return 2;
	}

	if ( ( DataType != REG_SZ ) && ( DataType != REG_EXPAND_SZ ) ) {
		outString[0] = 0x00;
		return 3;
	}

	if ( DataType == REG_EXPAND_SZ ) {
		wchar_t temp[SHORT_BUF_LEN] = L"";
		ExpandEnvironmentStrings( outString, temp, SHORT_BUF_LEN );
		wcscpy_s( outString, SHORT_BUF_LEN, temp );
	}
	
	return 0;
}


int VerbSetRegString( LPTSTR KeyName, LPTSTR ValueName, BOOL User, LPTSTR ValueString )
{
	wchar_t FullKeyName[SHORT_BUF_LEN] = L"";

	if ( User )
		wcscpy_s( FullKeyName, SHORT_BUF_LEN, L"Software\\Classes\\" );

	if ( KeyName != NULL )
		wcscat_s( FullKeyName, SHORT_BUF_LEN, KeyName );


	HKEY KeyHandle = NULL;
	int rv = 0;


	if ( RegCreateKeyEx( User ? HKEY_CURRENT_USER : HKEY_CLASSES_ROOT, FullKeyName, 0, NULL, 0, KEY_READ | KEY_WRITE, NULL, &KeyHandle, NULL ) != ERROR_SUCCESS )
		return 1;


	if ( ValueString == NULL )
		rv = RegDeleteValue( KeyHandle, ValueName );
	else if ( ValueString[0] == 0x00 )
		rv = RegDeleteValue( KeyHandle, ValueName );
	else
		rv = RegSetValueEx( KeyHandle, ValueName, 0, REG_SZ, (BYTE *) ValueString, ( (int) wcslen( ValueString ) + 1 ) * sizeof( wchar_t ) );

	RegCloseKey( KeyHandle );

	return ( rv == ERROR_SUCCESS ) ? 0 : 1;
}


int FindDefaultVerb( LPTSTR FileType, BOOL User, LPTSTR DefaultVerb )
{
	if ( ( FileType == NULL ) || ( DefaultVerb == NULL ) )
		return -1;
	else if ( FileType[0] == 0x00 )
		return -1;

	wchar_t KeyName[SHORT_BUF_LEN]		= L"";
	wchar_t ShellDefault[SHORT_BUF_LEN]	= L"";
	wchar_t Command[MAX_ARG_LEN]		= L"";


	wcscpy_s( KeyName, SHORT_BUF_LEN, FileType );					//  try the default value in the SHELL subkey :
	wcscat_s( KeyName, SHORT_BUF_LEN, L"\\shell" );
	VerbGetRegString( KeyName, NULL, User, ShellDefault, SHORT_BUF_LEN );

	if ( ShellDefault[0] ) {
		wcscat_s( KeyName, SHORT_BUF_LEN, L"\\" );
		wcscat_s( KeyName, SHORT_BUF_LEN, ShellDefault );
		wcscat_s( KeyName, SHORT_BUF_LEN, L"\\command" );
		VerbGetRegString( KeyName, NULL, User, Command, MAX_ARG_LEN );

		if ( Command[0] ) {
			// Printf( L"   * Registry default of \"%s\" looks good.\n", ShellDefault );
			wcscpy_s( DefaultVerb, SHORT_BUF_LEN, ShellDefault );
			return 0;
		}
	}

	wcscpy_s( KeyName, SHORT_BUF_LEN, FileType );					//  try the OPEN verb :
	wcscat_s( KeyName, SHORT_BUF_LEN, L"\\shell\\open\\command" );
	VerbGetRegString( KeyName, NULL, User, Command, MAX_ARG_LEN );

	if ( Command[0] ) {
		// Printf( L"   * The OPEN verb looks good.\n" );
		wcscpy_s( DefaultVerb, SHORT_BUF_LEN, L"open" );
		return 0;
	}
	

	//  attempt to find the first verb:

	wchar_t VerbName[SHORT_BUF_LEN]		= L"";
	wchar_t CommandKey[SHORT_BUF_LEN]	= L"";
	HKEY KeyHandle = NULL;
	DWORD Index = 0, VerbNameSize = SHORT_BUF_LEN;

	if ( User )
		wcscpy_s( KeyName, SHORT_BUF_LEN, L"Software\\Classes\\" );
	else
		KeyName[0] = 0x00;

	wcscat_s( KeyName, SHORT_BUF_LEN, FileType );

	RegOpenKeyEx( User ? HKEY_CURRENT_USER : HKEY_CLASSES_ROOT, KeyName, 0, KEY_READ, &KeyHandle );

	if ( KeyHandle == NULL ) {
		DefaultVerb[0] = 0x00;
		return ERROR_FILE_NOT_FOUND;
	}

	while ( RegEnumKeyEx( KeyHandle, Index, VerbName, &VerbNameSize, NULL, NULL, NULL, NULL ) == 0 ) {

		wcscpy_s( CommandKey, SHORT_BUF_LEN, FileType );
		wcscat_s( CommandKey, SHORT_BUF_LEN, L"\\shell\\" );
		wcscat_s( CommandKey, SHORT_BUF_LEN, VerbName );
		wcscat_s( CommandKey, SHORT_BUF_LEN, L"\\command" );
		Command[0] = 0x00;

		VerbGetRegString( CommandKey, NULL, User, Command, MAX_ARG_LEN );

		if ( Command[0] ) {
			wcscpy_s( DefaultVerb, SHORT_BUF_LEN, VerbName );
			RegCloseKey( KeyHandle );
			return 0;
		}

		VerbNameSize = SHORT_BUF_LEN;
		Index++;
	}

	RegCloseKey( KeyHandle );
	DefaultVerb[0] = 0x00;
	return 1;
}


/*
int StripAmps( LPTSTR String )
{
	if ( String == NULL )
		return -1;
	else if ( String[0] == 0x00 )
		return 0;

	int j = 0;
	wchar_t ch = 0x00;

	for ( int i = 0; String[i]; i++ ) {
		ch = String[i];

		if ( ch == '&' ) {
			ch = String[++i];
			if ( ch == 0x00 )
				return 0;
		}

		String[j++] = ch;
	}

	String[j] = 0x00;
	return 0;
}
*/


int DumpOneVerb( LPTSTR FileType, BOOL User, LPTSTR VerbToDump, BOOL Default )
{
	if ( ( FileType == NULL ) || ( VerbToDump == NULL ) )
		return -1;
	else if ( ( FileType[0] == 0x00 ) || ( VerbToDump[0] == 0x00 ) )
		return -1;


	wchar_t VerbName[SHORT_BUF_LEN]		= L"";
	wchar_t KeyName[SHORT_BUF_LEN]		= L"";
	wchar_t CosmeticName[SHORT_BUF_LEN]	= L"";
	wchar_t Command[MAX_ARG_LEN]		= L"";

	wcscpy_s( VerbName, SHORT_BUF_LEN, VerbToDump );
	VerbName[0] = towupper( VerbName[0] );

	wcscpy_s( KeyName, SHORT_BUF_LEN, FileType );
	wcscat_s( KeyName, SHORT_BUF_LEN, L"\\shell\\" );
	wcscat_s( KeyName, SHORT_BUF_LEN, VerbToDump );

	VerbGetRegString( KeyName, NULL, User, CosmeticName, SHORT_BUF_LEN );

	wcscat_s( KeyName, SHORT_BUF_LEN, L"\\command" );

	VerbGetRegString( KeyName, NULL, User, Command, MAX_ARG_LEN );

	if ( Command[0] == 0x00 )
		return ERROR_INVALID_DATA;

	Printf( L"  %c %s ", Default ? '*' : 0x20, VerbName );

	if ( CosmeticName[0] )
		if ( _wcsicmp( VerbName, CosmeticName ) )
			Printf( L"(%s) ", CosmeticName );

	Printf( L"\u2192 %s\r\n", Command );
	
	return 0;
}


int DumpAllVerbs( LPTSTR FileType, BOOL User, LPTSTR DefaultVerb )
{
	if ( FileType == NULL )
		return -1;
	else if ( FileType[0] == 0x00 )
		return -1;


	wchar_t VerbName[SHORT_BUF_LEN]		= L"";
	wchar_t KeyName[SHORT_BUF_LEN]		= L"";
	wchar_t CommandKey[SHORT_BUF_LEN]	= L"";
	wchar_t Command[MAX_ARG_LEN]		= L"";

	
	DWORD VerbNameSize = SHORT_BUF_LEN;
	HKEY KeyHandle = NULL;
	DWORD Index = 0;
	BOOL FoundAny = FALSE;


	if ( User )
		wcscpy_s( KeyName, SHORT_BUF_LEN, L"Software\\Classes\\" );
	else
		KeyName[0] = 0x00;

	wcscat_s( KeyName, SHORT_BUF_LEN, FileType );
	wcscat_s( KeyName, SHORT_BUF_LEN, L"\\shell" );

	if ( RegOpenKeyEx( User ? HKEY_CURRENT_USER : HKEY_CLASSES_ROOT, KeyName, 0, KEY_READ, &KeyHandle ) != ERROR_SUCCESS )
		return ERROR_FILE_NOT_FOUND;

	while ( RegEnumKeyEx( KeyHandle, Index, VerbName, &VerbNameSize, NULL, NULL, NULL, NULL ) == ERROR_SUCCESS ) {

		wcscpy_s( CommandKey, SHORT_BUF_LEN, FileType );
		wcscat_s( CommandKey, SHORT_BUF_LEN, L"\\shell\\" );
		wcscat_s( CommandKey, SHORT_BUF_LEN, VerbName );
		wcscat_s( CommandKey, SHORT_BUF_LEN, L"\\command" );
		Command[0] = 0x00;

		VerbGetRegString( CommandKey, NULL, User, Command, MAX_ARG_LEN );

		if ( Command[0] ) {
			DumpOneVerb( FileType, User, VerbName, ( _wcsicmp( VerbName, DefaultVerb ) == 0 ) );
			FoundAny = TRUE;
		}
		
		VerbNameSize = SHORT_BUF_LEN;
		Index++;
	}

	if ( !FoundAny )
		Printf( L"    (none)\r\n" );

	RegCloseKey( KeyHandle );
	return FoundAny ? 0 : ERROR_FILE_NOT_FOUND;
}


int DisplayShellVerbs( LPTSTR Extension, int Which, LPTSTR VerbToShow )
{
	if ( Extension == NULL )
		return -1;
	else if ( Extension[0] == 0x00 )
		return -1;

	
	if ( Which == VERB_BOTH ) {
		int rv1 = DisplayShellVerbs( Extension, VERB_USER, VerbToShow );
		int rv2 = DisplayShellVerbs( Extension, VERB_SYSTEM, VerbToShow );

		return ( rv1 == 0 ) ? rv1 : rv2;
	}

	if ( ( Which != VERB_USER ) && ( Which != VERB_SYSTEM ) )
		return -2;


	wchar_t FileType[SHORT_BUF_LEN]		= L"";
	wchar_t CosmeticName[SHORT_BUF_LEN]	= L"";
	wchar_t DefaultVerb[SHORT_BUF_LEN]	= L"";

	BOOL User = ( Which == VERB_USER );


	if ( Extension[0] == '.' ) {					//  get file type from extension
		FileType[0] = 0x00;

		if ( VerbGetRegString( Extension, NULL, User, FileType, SHORT_BUF_LEN ) )
			return ERROR_FILE_NOT_FOUND;

		if ( FileType[0] == 0x00 )		//  no association with this extension
			return ERROR_FILE_NOT_FOUND;
	}
	else
		wcscpy_s( FileType, SHORT_BUF_LEN, Extension );


	//  get the cosmetic name for this file type:

	VerbGetRegString( FileType, NULL, User, CosmeticName, SHORT_BUF_LEN );


	//  get the default verb for this file type:

	FindDefaultVerb( FileType, User, DefaultVerb );


	if ( User )
		QPuts( L"\r\nUSER  :  " );
	else
		QPuts( L"\r\nSYSTEM:  " );

	if ( Extension[0] == '.' ) {
		_wcsupr_s( Extension, SHORT_BUF_LEN );
		Printf( L"%s = ", Extension );
	}

	QPuts( FileType );

	if ( CosmeticName[0] )
		Printf( L"  (%s)", CosmeticName );

	QPuts( L"\r\n" );


	if ( VerbToShow == NULL )
		DumpOneVerb( FileType, User, DefaultVerb, TRUE );
	else if ( VerbToShow[0] == 0x00 )
		DumpOneVerb( FileType, User, DefaultVerb, TRUE );
	else if ( wcscmp( VerbToShow, L"*" ) == 0 )
		DumpAllVerbs( FileType, User, DefaultVerb );
	else
		DumpOneVerb( FileType, User, VerbToShow, ( _wcsicmp( VerbToShow, DefaultVerb ) == 0 ) );

	return 0;
}


int DisplayShellVerbsBoth( LPTSTR Extension, LPTSTR VerbToShow )
{
	if ( Extension == NULL )
		return -1;
	else if ( Extension[0] == 0x00 )
		return -1;


	HKEY UserKeyHandle = NULL;

	wchar_t UserExtension[SHORT_BUF_LEN]	= L"";
	wchar_t SysExtension[SHORT_BUF_LEN]		= L"";
	DWORD UserIndex = 0, SysIndex = 0, DataSize = SHORT_BUF_LEN;
	BOOL UserDone = FALSE, SysDone = FALSE, FoundAny = FALSE;

	int Next = 0;		//  0 - get next from system key, 1 - get next from user key

	RegOpenKeyEx( HKEY_CURRENT_USER, L"Software\\Classes", 0, KEY_READ, &UserKeyHandle );

	UserDone = RegEnumKeyEx( UserKeyHandle, UserIndex++, UserExtension, &DataSize, NULL, NULL, NULL, NULL ) != ERROR_SUCCESS;
	DataSize = SHORT_BUF_LEN;
	SysDone  = RegEnumKeyEx( HKEY_CLASSES_ROOT, SysIndex++, SysExtension, &DataSize, NULL, NULL, NULL, NULL ) != ERROR_SUCCESS;
	DataSize = SHORT_BUF_LEN;
	
	do {
		if ( UserDone )
			Next = 0;
		else if ( SysDone )
			Next = 1;
		else if ( _wcsicmp( UserExtension, SysExtension ) <= 0 )
			Next = 1;
		else
			Next = 0;

		if ( Next == 0 ) {
			if ( WildcardComparison( Extension, SysExtension, 1, 0 ) == 0 ) {
				DisplayShellVerbs( SysExtension, VERB_SYSTEM, VerbToShow );
				FoundAny = TRUE;
			}

			SysDone = RegEnumKeyEx( HKEY_CLASSES_ROOT, SysIndex++, SysExtension, &DataSize, NULL, NULL, NULL, NULL ) != ERROR_SUCCESS;
			DataSize = SHORT_BUF_LEN;
		}
		else {
			if ( WildcardComparison( Extension, UserExtension, 1, 0 ) == 0 ) {
				DisplayShellVerbs( UserExtension, VERB_USER, VerbToShow );
				FoundAny = TRUE;
			}

			UserDone = RegEnumKeyEx( UserKeyHandle, UserIndex++, UserExtension, &DataSize, NULL, NULL, NULL, NULL ) != ERROR_SUCCESS;
			DataSize = SHORT_BUF_LEN;
		}

	} while ( !UserDone || !SysDone );

	
	if ( UserKeyHandle != NULL )
		RegCloseKey( UserKeyHandle );

	if ( !FoundAny ) {
		DisplayErrorHeader();
		_wcsupr_s( Extension, SHORT_BUF_LEN );
		Qprintf( ERRHANDLE, L"No extensions matching %s found.\r\n", Extension );
		return 2;
	}
	else
		return 0;
}


int DisplayShellVerbsMulti( LPTSTR Extension, int Which, LPTSTR VerbToShow )
{
	if ( Extension == NULL )
		return -1;
	else if ( Extension[0] == 0x00 )
		return -1;


	if ( Which == VERB_BOTH )
		return DisplayShellVerbsBoth( Extension, VerbToShow );


	BOOL User = ( Which & VERB_USER ) != 0;
	HKEY KeyHandle = NULL;

	wchar_t FoundExtension[SHORT_BUF_LEN]	= L"";
	DWORD Index = 0, DataSize = SHORT_BUF_LEN;
	BOOL FoundAny = FALSE;


	if ( User ) {
		RegOpenKeyEx( HKEY_CURRENT_USER, L"Software\\Classes", 0, KEY_READ, &KeyHandle );
		if ( KeyHandle == NULL )
			return 1;
	}
	else
		KeyHandle = HKEY_CLASSES_ROOT;


	while ( RegEnumKeyEx( KeyHandle, Index, FoundExtension, &DataSize, NULL, NULL, NULL, NULL ) == ERROR_SUCCESS ) {

		if ( WildcardComparison( Extension, FoundExtension, 1, 0 ) == 0 ) {
			DisplayShellVerbs( FoundExtension, Which, VerbToShow );
			FoundAny = TRUE;
		}
		
		DataSize = SHORT_BUF_LEN;
		Index++;
	}
	

	if ( User )
		RegCloseKey( KeyHandle );
	
	if ( !FoundAny ) {
		DisplayErrorHeader();
		_wcsupr_s( Extension, SHORT_BUF_LEN );
		Qprintf( ERRHANDLE, L"No extensions matching %s found.\r\n", Extension );
		return 2;
	}
	else
		return 0;
}


int DeleteRegTree( HKEY KeyHandle, LPTSTR SubkeyName )
{
	if ( ( KeyHandle == NULL ) || ( SubkeyName == NULL ) )
		return -1;
	else if ( SubkeyName[0] == 0x00 )
		return -1;


	wchar_t FoundItem[SHORT_BUF_LEN]	= L"";
	wchar_t Working[SHORT_BUF_LEN]		= L"";
	HKEY SubkeyHandle = NULL;
	DWORD DataSize = SHORT_BUF_LEN;

	RegOpenKeyEx( KeyHandle, SubkeyName, 0, KEY_READ | KEY_WRITE, &SubkeyHandle );
	if ( SubkeyHandle == NULL )
		return 1;


	while ( RegEnumKeyEx( SubkeyHandle, 0, FoundItem, &DataSize, NULL, NULL, NULL, NULL ) == ERROR_SUCCESS ) {

		wcscpy_s( Working, SHORT_BUF_LEN, SubkeyName );
		wcscat_s( Working, SHORT_BUF_LEN, L"\\" );
		wcscat_s( Working, SHORT_BUF_LEN, FoundItem );

		if ( DeleteRegTree( KeyHandle, Working ) != ERROR_SUCCESS )
			break;

		DataSize = SHORT_BUF_LEN;
	}

	RegCloseKey( SubkeyHandle );


	if ( RegDeleteKey( KeyHandle, SubkeyName ) != ERROR_SUCCESS )
		return 1;
	else
		return 0;
}


int SetShellVerb( LPTSTR Extension, LPTSTR FileType, int Which, LPTSTR TypeDescription, LPTSTR Verb, LPTSTR MenuName, LPTSTR Command, BOOL MakeDefault, BOOL Delete )
{
	if ( Extension == NULL )
		return -1;
	else if ( Extension[0] == 0x00 )
		return -1;


	if ( Which == VERB_BOTH ) {
		int rv1 = SetShellVerb( Extension, FileType, VERB_USER,   TypeDescription, Verb, MenuName, Command, MakeDefault, Delete );
		int rv2 = SetShellVerb( Extension, FileType, VERB_SYSTEM, TypeDescription, Verb, MenuName, Command, MakeDefault, Delete );
		return rv1 ? rv1 : rv2;
	}

	if ( ( Which != VERB_USER ) && ( Which != VERB_SYSTEM ) )
		return -2;


	wchar_t FileTypeBuf[SHORT_BUF_LEN]	= L"";
	wchar_t DefaultVerb[SHORT_BUF_LEN]	= L"";
	wchar_t VerbPath[SHORT_BUF_LEN]		= L"";
	wchar_t temp[SHORT_BUF_LEN]			= L"";

	BOOL User = ( Which & VERB_USER ) != 0;
	BOOL Dirty = FALSE;
	int rv = 0;

	wchar_t KeyName[SHORT_BUF_LEN] = L"";



	if ( Delete && ( Verb == NULL ) ) {

		if ( Extension[0] == '.' ) {										//  remove an association
			if ( VerbSetRegString( Extension, NULL, User, NULL ) ) {
				DisplayErrorHeader();
				_wcsupr_s( Extension, SHORT_BUF_LEN );
				Qprintf( ERRHANDLE, L"Error removing association for extension %s.\r\n", Extension );
				return 1;
			}
			
			return 0;
		}
		else {																//  remove a filetype
			if ( User )
				wcscpy_s( temp, SHORT_BUF_LEN, L"Software\\Classes\\" );
			else
				temp[0] = 0x00;

			wcscat_s( temp, SHORT_BUF_LEN, Extension );

			if ( DeleteRegTree( User ? HKEY_CURRENT_USER : HKEY_CLASSES_ROOT, temp ) != ERROR_SUCCESS ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Error removing filetype %s.\r\n", Extension );
				return 1;
			}

			return 0;
		}
	}


	if ( Extension[0] == '.' ) {

		if ( FileType == NULL ) {
			VerbGetRegString( Extension, NULL, User, FileTypeBuf, SHORT_BUF_LEN );

			if ( FileTypeBuf[0] == 0x00 ) {
				wcscpy_s( FileTypeBuf, SHORT_BUF_LEN, Extension + 1 );
				wcscat_s( FileTypeBuf, SHORT_BUF_LEN, L"file" );
				_wcslwr_s( FileTypeBuf, SHORT_BUF_LEN );
				Dirty = TRUE;
			}
			else
				Dirty = FALSE;

			FileType = FileTypeBuf;
		}
		else
			Dirty = TRUE;

		if ( Dirty ) {
			if ( VerbSetRegString( Extension, NULL, User, FileType ) ) {
				DisplayErrorHeader();
				_wcsupr_s( Extension, SHORT_BUF_LEN );
				Qprintf( ERRHANDLE, L"Error associating extension %s with filetype %s.\r\n", Extension, FileType );
				return 1;
			}
		}
	}
	else
		FileType = Extension;


	if ( TypeDescription != NULL ) {
		if ( VerbSetRegString( FileType, NULL, User, TypeDescription ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Error setting description for filetype %s.\r\n", FileType );
			return 1;
		}
	}


	if ( Verb != NULL ) {

		if ( Delete ) {
			if ( Verb[0] == 0x00 )
				return -1;

			if ( User )
				wcscpy_s( temp, SHORT_BUF_LEN, L"Software\\Classes\\" );
			else
				temp[0] = 0x00;

			wcscat_s( temp, SHORT_BUF_LEN, FileType );
			wcscat_s( temp, SHORT_BUF_LEN, L"\\shell\\" );
			wcscat_s( temp, SHORT_BUF_LEN, Verb );

			if ( DeleteRegTree( User ? HKEY_CURRENT_USER : HKEY_CLASSES_ROOT, temp ) != ERROR_SUCCESS ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Error removing shell verb \"%s\" from filetype %s.\r\n", Verb, FileType );
				return 1;
			}

			wcscpy_s( temp, SHORT_BUF_LEN, FileType );
			wcscat_s( temp, SHORT_BUF_LEN, L"\\shell" );

			VerbGetRegString( temp, NULL, User, DefaultVerb, SHORT_BUF_LEN );

			if ( DefaultVerb[0] )
				if ( _wcsicmp( Verb, DefaultVerb ) == 0 )
					VerbSetRegString( temp, NULL, User, NULL );
			
			return 0;
		}

		if ( Verb[0] == 0x00 ) {
			FindDefaultVerb( FileType, User, DefaultVerb );
			if ( DefaultVerb[0] == 0x00 )
				wcscpy_s( DefaultVerb, SHORT_BUF_LEN, L"open" );

			Verb = DefaultVerb;
		}

		wcscpy_s( VerbPath, SHORT_BUF_LEN, FileType );
		wcscat_s( VerbPath, SHORT_BUF_LEN, L"\\shell\\" );
		wcscat_s( VerbPath, SHORT_BUF_LEN, Verb );


		if ( MenuName != NULL ) {
			if ( VerbSetRegString( VerbPath, NULL, User, MenuName ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Error setting menu name to %s filetype %s.\r\n", Verb, FileType );
				return 1;
			}
		}


		if ( Command != NULL ) {
			wcscpy_s( temp, SHORT_BUF_LEN, VerbPath );
			wcscat_s( temp, SHORT_BUF_LEN, L"\\command" );

			if ( VerbSetRegString( temp, NULL, User, Command ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Error setting command string to %s filetype %s.\r\n", Verb, FileType );
				return 1;
			}
		}

		if ( MakeDefault ) {
			wcscpy_s( temp, SHORT_BUF_LEN, FileType );
			wcscat_s( temp, SHORT_BUF_LEN, L"\\shell" );

			if ( VerbSetRegString( temp, NULL, User, Verb ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Error setting default verb for filetype %s to %s.\r\n", FileType, Verb );
				return 1;
			}
		}
	}


	return 0;
}


int GetYorN()
{
	unsigned int ch = 0x00;

	EatKeystrokes();

	do {
		if ( QueryKeyWaiting() ) {

			ch = GetKeystroke( 0x0030 );

			ch = towupper( ch );

			if ( ch == 'Y' ) {
				_putwch( ch );
				_putwch( LF );
				return 1;
			}
			else if ( ( ch == 'N' ) || ( ch == ESC ) ) {
				_putwch( 'N' );
				_putwch( LF );
				return 0;
			}
			else
				honk();
		}
		else
			tty_yield( 0 );

	} while ( TRUE );

	return 0;
}



DLLExports int WINAPI shellverb( LPTSTR inString )
{
	if ( !inString )
		return -1;


	ParseArgs( inString, PARSE_BREAK_SPACES | PARSE_SLASHES_KLUDGE | PARSE_EQUALS_KLUDGE | PARSE_EQ_QT_KLUDGE );


	LPTSTR Source				= NULL;
	LPTSTR Command				= NULL;

	LPTSTR FileType				= NULL;
	LPTSTR FileTypeDescription	= NULL;
	LPTSTR Verb					= NULL;
	LPTSTR MenuName				= NULL;

	wchar_t AllVerbs[]			= L"*";
	wchar_t OpenVerb[]			= L"open";


	unsigned int Which = VERB_UNKNOWN;
	BOOL SourceIsExtension = FALSE, MakeVerbDefault = FALSE, Remove = FALSE, SafeChars = FALSE;
	BOOL Changes = FALSE, Quiet = FALSE;
	int rv = 0;


	for ( int i = 0; i < numargs; i++ ) {
		if ( arglen[i] ) {

			if ( !wcsncmp( arg[i], L"/?", 2 ) )
				return ShowCmdHelp( ShellVerbHelpText, ( arg[i][2] == '?' ) );
			else if ( !_wcsicmp( arg[i], L"/C" ) )
				SafeChars = TRUE;
			else if ( !_wcsnicmp( arg[i], L"/D", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				FileTypeDescription = arg[i] + j;
				Changes = TRUE;
			}
			else if ( !_wcsnicmp( arg[i], L"/M", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				MenuName = arg[i] + j;
				Changes = TRUE;
			}
			else if ( !_wcsicmp( arg[i], L"/Q" ) )
				Quiet = TRUE;
			else if ( !_wcsnicmp( arg[i], L"/R", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				if ( arg[i][j] )
					Verb = arg[i] + j;

				Changes = Remove = TRUE;
			}
			else if ( !_wcsicmp( arg[i], L"/S" ) )
				Which |= VERB_SYSTEM;
			else if ( !_wcsnicmp( arg[i], L"/T", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				if ( ( arg[i][j] == 0x00 ) || ( arg[i][j] == '.' ) ) {
					DisplayErrorHeader();
					_wcsupr_s( arg[i], SHORT_BUF_LEN );
					Qprintf( ERRHANDLE, L"Bad filetype: \"%s\"\r\n", arg[i][j] );
					return 1;
				}

				FileType = arg[i] + j;
				Changes = TRUE;
			}
			else if ( !_wcsicmp( arg[i], L"/U" ) )
				Which |= VERB_USER;
			else if ( !_wcsnicmp( arg[i], L"/V", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				Verb = arg[i] + j;
			}
			else if ( !_wcsnicmp( arg[i], L"/Z", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				if ( arg[i][j] )
					Verb = arg[i] + j;

				Changes = MakeVerbDefault = TRUE;
			}
			else if ( arg[i][0] == '/' ) {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Unknown option: \"%s\"\r\n", arg[i] );
				return 1;
			}
			else if ( !Source )
				Source = arg[i];
			else if ( !Command ) {
				Command = arg[i];

				if ( Command[0] == '=' )
					Command++;

				Changes = TRUE;
			}
			else {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Syntax error: \"%s\"\r\n", arg[i] );
				return 1;
			}
		}
	}


	if ( !Source ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Missing filetype or extension\r\n" );
		return 1;
	}

	if ( Source[0] == '*' )
		if ( Source[1] == '.' )
			Source++;

	SourceIsExtension = ( Source[0] == '.' );

	if ( SourceIsExtension && ( Source[ wcslen( Source) - 1 ] == '.' ) ) {
		DisplayErrorHeader();
		_wcsupr_s( Source, SHORT_BUF_LEN );
		Qprintf( ERRHANDLE, L"Invalid extension: \"%s\"\r\n", Source );
		return 1;
	}

	if ( ( FileType != NULL ) && !SourceIsExtension ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Only use /T: when ftype is an extension\r\n" );
		return 1;
	}

	if ( Which == VERB_UNKNOWN )
		Which = VERB_SYSTEM;


	if ( !Changes ) {
		if ( Verb == NULL )
			Verb = AllVerbs;

		if ( SourceIsExtension && HasWildcards( Source ) ) {
			if ( DisplayShellVerbsMulti( Source, Which, Verb ) )
				rv = 2;
		}
		else {
			if ( DisplayShellVerbs( Source, Which, Verb ) == ERROR_FILE_NOT_FOUND ) {
				DisplayErrorHeader();
				
				if ( SourceIsExtension ) {
					_wcsupr_s( Source, SHORT_BUF_LEN );
					Qprintf( ERRHANDLE, L"Extension %s not found!\r\n", Source );
				}
				else
					Qprintf( ERRHANDLE, L"Filetype %s not found.\r\n", Source );

				rv = 2;
			}
		}

		return rv;
	}


	if ( SourceIsExtension && HasWildcards( Source ) ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Extension may not contain wildcards when making changes.\r\n" );
		return 1;
	}

	if ( MakeVerbDefault && !Verb ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Must specify a verb when using /Z.\r\n" );
		return 1;
	}

	if ( Remove ) {
		if ( FileTypeDescription || MenuName || FileType || MakeVerbDefault || Command ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Can\u2019t combine /R with other options.\r\n" );
			return 1;
		}

		if ( Verb ) {
			if ( Verb[0] == '\0' ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Must specify the verb to delete.\r\n" );
				return 1;
			}
		}

		if ( !Quiet ) {
			wchar_t PromptString[SHORT_BUF_LEN] = L"";

			if ( Verb != NULL )
				wsprintf( PromptString, L"\nRemove the shell verb %s for %s %s:\n", Verb, SourceIsExtension ? L"extension" : L"filetype", Source );
			else if ( SourceIsExtension )
				wsprintf( PromptString, L"\nRemove the association for extension %s:\n", Source );
			else
				wsprintf( PromptString, L"\nRemove the filetype %s:\n", Source );

			_cputws( PromptString );
			_cputws( L"Are you sure? " );

			if ( GetYorN() == 0 )
				return 3;
		}
	}

	if ( Command ) {
		if ( SafeChars )
			MakeStringUnsafe( Command );

		if ( !Verb && ( Command[0] == '\0' ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Must specify a verb to delete a command.\r\n" );
			return 1;
		}
	}


	if ( !Verb && !Remove )
		Verb = OpenVerb;


	if ( SetShellVerb( Source, FileType, Which, FileTypeDescription, Verb, MenuName, Command, MakeVerbDefault, Remove ) )
		return 2;
	
	if ( Remove && !Verb )
		Quiet = TRUE;

	if ( !Quiet )
		DisplayShellVerbs( Source, Which, AllVerbs );
	
	return 0;
}



DLLExports int WINAPI f_shellverb( LPTSTR String )
{
	if ( String == NULL )
		return -1;


	ParseArgs( String, PARSE_BREAK_COMMAS );

	LPTSTR Source = NULL;
	wchar_t FileType[SHORT_BUF_LEN]	= L"";
	wchar_t Verb[SHORT_BUF_LEN]		= L"";
	wchar_t KeyName[SHORT_BUF_LEN]	= L"";
	wchar_t Command[MAX_ARG_LEN]	= L"";

	unsigned int Flags = 0;
	BOOL SourceIsExtension = FALSE;

	if ( arglen[0] == 0 ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Missing filetype or extension\r\n" );
		return -1;
	}

	if ( arglen[1] )
		wcscpy_s( Verb, SHORT_BUF_LEN, arg[1] );

	if ( arglen[2] ) {
		if ( ParseInt( arg[2], &Flags, NULL ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad flags \"%s\"\r\n", arg[2] );
			return -1;
		}
	}

	Source = arg[0];
	if ( Source[0] == '*' )
		if ( Source[1] == '.' )
			Source++;

	SourceIsExtension = ( Source[0] == '.' );

	if ( SourceIsExtension && ( Source[ wcslen( Source) - 1 ] == '.' ) ) {
		DisplayErrorHeader();
		_wcsupr_s( Source, SHORT_BUF_LEN );
		Qprintf( ERRHANDLE, L"Invalid extension: \"%s\"\r\n", Source );
		return -1;
	}

	if ( ( Flags & VERB_BOTH ) == 0 )
		Flags |= VERB_SYSTEM;

	if ( SourceIsExtension ) {
		if ( Flags & VERB_USER )
			VerbGetRegString( Source, NULL, TRUE, FileType, SHORT_BUF_LEN );

		if ( ( Flags & VERB_SYSTEM ) && ( FileType[0] == 0x00 ) )
			VerbGetRegString( Source, NULL, FALSE, FileType, SHORT_BUF_LEN );

		if ( FileType[0] == 0x00 ) {
			wcscpy_s( String, MAX_ARG_LEN, ErrorString );		//  unknown extension
			return 0;
		}
	}
	else
		wcscpy_s( FileType, SHORT_BUF_LEN, Source );

	if ( Verb[0] == 0x00 ) {

		if ( Flags & VERB_USER )
			FindDefaultVerb( FileType, TRUE, Verb );

		if ( ( Flags & VERB_SYSTEM ) && ( Verb[0] == 0x00 ) )
			FindDefaultVerb( FileType, FALSE, Verb );

		if ( Verb[0] == 0x00 ) {
			wcscpy_s( String, MAX_ARG_LEN, ErrorString );		//  can't get default verb
			return 0;
		}
	}


	wcscpy_s( KeyName, SHORT_BUF_LEN, FileType );
	wcscat_s( KeyName, SHORT_BUF_LEN, L"\\shell\\" );
	wcscat_s( KeyName, SHORT_BUF_LEN, Verb );
	wcscat_s( KeyName, SHORT_BUF_LEN, L"\\command" );

	if ( Flags & VERB_USER )
		VerbGetRegString( KeyName, NULL, TRUE, Command, MAX_ARG_LEN );

	if ( ( Flags & VERB_SYSTEM ) && ( Command[0] == 0x00 ) )
		VerbGetRegString( KeyName, NULL, FALSE, Command, MAX_ARG_LEN );

	if ( Command[0] == 0x00 ) {
		wcscpy_s( String, MAX_ARG_LEN, ErrorString );			//  can't get command string
		return 0;
	}

	if ( Flags & VERB_F_SAFECHARS )
		MakeStringSafe( Command );

	wcscpy_s( String, MAX_ARG_LEN, Command );
	return 0;
}


unsigned int InputColors()
{
	unsigned int Colors = 10, Temp = 0;
	GetAttribute( &Colors, &Temp );

	wchar_t ShortBuf[SHORT_BUF_LEN] = L"%@option[inputcolors]";
	ExpandVariables( ShortBuf, 1 );

	if ( iswdigit( ShortBuf[0] ) == 0 )
		return Colors;

	if ( ParseInt( ShortBuf, &Temp, NULL ) )
		return Colors;

	if ( Temp > 255 )
		return Colors;
	else if ( ( Temp >> 4 ) == ( Temp & 0x0f ) )
		return Colors;

	return Temp;
}


int InputWithTimeout( LPTSTR outString, unsigned int MaxLen, int Timeout )
{
	if ( outString == NULL )
		return -1;

	if ( ( MaxLen < 2 ) || ( MaxLen > MAX_ARG_LEN ) || ( Timeout < 5 ) || ( Timeout > 3600 ) )
		return -1;

	DWORD TimeNow = GetTickCount();
	DWORD EndTime   = TimeNow + ( 1000 * Timeout );
	DWORD BelowTime = ( EndTime < TimeNow ) ? TimeNow : 0;
	unsigned int ch = 0x00;
	size_t len = 0;
	unsigned int Colors = InputColors();

	outString[0] = 0x00;
	EatKeystrokes();

	do {
		if ( QueryKeyWaiting() ) {

			ch = GetKeystroke( 0x0030 );

			if ( ch == CR ) {
				_cputws( L"\r\n" );
				return 0;
			}
			else if ( ch == ESC ) {
				if ( outString[0] == 0x00 ) {
					_cputws( L"\r\n" );
					return 2;
				}

				for ( size_t i = 0; i < len; i++ )
					_putwch( BS );

				for ( size_t i = 0; i < len; i++ )
					_putwch( 0x20);

				for ( size_t i = 0; i < len; i++ )
					_putwch( BS );

				len = 0;
				outString[len] = 0x00;
			}
			else if ( ch == BS ) {
				if ( len ) {
					len--;
					outString[len] = 0x00;
					_cputws( L"\b \b" );
				}
				else
					honk();
			}
			else if ( ch <= 0xffff ) {
				if ( iswprint( ch ) && !iswcntrl(ch ) && ( len < ( MaxLen - 1 ) ) ) {
					outString[len++] = ch;
					outString[len] = 0x00;
					// _putwch( ch );
					ColorPrintf( Colors, L"%c", ch );
				}
				else
					honk();
			}

		}
		else
			tty_yield( 0 );

		TimeNow = GetTickCount();
		if ( ( TimeNow >= EndTime ) && ( ( BelowTime == 0 ) || ( TimeNow < BelowTime ) ) ) {
			_cputws( L"\r\n" );
			outString[0] = 0x00;
			return 1;
		}

	} while ( TRUE );

	return 0;
}


int GetMonitorName( LPTSTR AdaptorName, LPTSTR MonitorName )
{
	if ( ( AdaptorName == NULL ) || ( MonitorName == NULL ) )
		return -1;

	DISPLAY_DEVICE MonitorInfo;

	MonitorInfo.cb = sizeof( DISPLAY_DEVICE );

	for ( int i = 0; EnumDisplayDevices( AdaptorName, i, &MonitorInfo, 0 ); i++ ) {
		// Printf( L"   * Found monitor \"%s\"  %s  %s  %s  %u\r\n", MonitorInfo.DeviceString, MonitorInfo.DeviceName, MonitorInfo.DeviceKey, MonitorInfo.DeviceID, MonitorInfo.StateFlags );

		if ( MonitorInfo.StateFlags & DISPLAY_DEVICE_ACTIVE ) {
			wcscpy_s( MonitorName, MAX_DISPLAY_NAME_LEN, MonitorInfo.DeviceString );
			return 0;
		}
	}

	wcscpy_s( MonitorName, MAX_DISPLAY_NAME_LEN, L"Default monitor" );
	return 0;
}


int ShowVideoSettings( int n, LPTSTR AdaptorName, LPTSTR MonitorName, LPTSTR DescString, DWORD Flags, unsigned int Width, unsigned int Height, unsigned int ColorDepth, unsigned int RefreshRate )
{
	if ( n >= 0 )
		Printf( L"%u%c ", n, ( Flags & DISPLAY_DEVICE_PRIMARY_DEVICE ) ? '*' : 0x20 );
	else if ( n == -42 )
		QPuts( L"   " );

	if ( AdaptorName && MonitorName ) {
		Printf( L"%s on %s", MonitorName, AdaptorName );

		if ( DescString == NULL )
			QPuts( L": " );
		else
			QPuts( DescString );
	}

	Printf( L"%4u x %4u (%2u) at ", Width, Height, ColorDepth );

	if ( RefreshRate < 2 )
		Printf( L"default refresh rate" );
	else
		Printf( L"%3u Hz", RefreshRate );

	if ( n != -43 )
		QPuts( L"\r\n" );

	return 0;
}


int ChangeResolution( LPTSTR AdaptorName, DWORD XRes, DWORD YRes, DWORD ColorDepth, DWORD RefreshRate, int Flags, LPTSTR AdaptorPrettyName, LPTSTR MonitorName )
{
	DEVMODE OldVideoSettings, NewVideoSettings;
	int rv = 0;
	wchar_t ConfirmationString[5] = L"";
	wchar_t UserEntry[SHORT_BUF_LEN] = L"";
	BOOL ChangeNeeded = FALSE;
	BOOL Prompt			= ( ( Flags & SR_FLAG_PROMPT ) != 0 );
	BOOL SaveToRegistry	= ( ( Flags & SR_FLAG_SAVE ) != 0 );
	BOOL NoReport		= ( ( Flags & SR_FLAG_NO_REPORT ) != 0 );
	BOOL Verbose		= ( ( Flags & SR_FLAG_VERBOSE ) != 0 );

	EnumDisplaySettings( AdaptorName, ENUM_CURRENT_SETTINGS, &OldVideoSettings );
	NewVideoSettings = OldVideoSettings;
	NewVideoSettings.dmFields = 0;

	if ( XRes ) {
		NewVideoSettings.dmPelsWidth = XRes;
		NewVideoSettings.dmPelsHeight = YRes;
		NewVideoSettings.dmFields = ( DM_PELSWIDTH | DM_PELSHEIGHT );
		ChangeNeeded |= ( ( XRes != OldVideoSettings.dmPelsWidth ) || ( YRes != OldVideoSettings.dmPelsHeight ) );
	}

	if ( ColorDepth ) {
		NewVideoSettings.dmBitsPerPel = ColorDepth;
		NewVideoSettings.dmFields |= DM_BITSPERPEL;
		ChangeNeeded |= ( ColorDepth != OldVideoSettings.dmBitsPerPel );
	}

	if ( RefreshRate ) {
		NewVideoSettings.dmDisplayFrequency = RefreshRate;
		NewVideoSettings.dmFields |= DM_DISPLAYFREQUENCY;
		ChangeNeeded |= ( RefreshRate != OldVideoSettings.dmDisplayFrequency );
	}

	if ( !ChangeNeeded ) {
		if ( ( Flags & SR_FLAG_NO_REPORT ) == 0 )
			ShowVideoSettings( -1, AdaptorPrettyName, MonitorName, L" is already ", 0, NewVideoSettings.dmPelsWidth, NewVideoSettings.dmPelsHeight, NewVideoSettings.dmBitsPerPel, NewVideoSettings.dmDisplayFrequency );

		return 0;
	}


	rv = ChangeDisplaySettingsEx( AdaptorName, &NewVideoSettings, NULL, SaveToRegistry ? CDS_UPDATEREGISTRY : 0, NULL );

	if ( rv == DISP_CHANGE_RESTART ) {
		QPuts( L"The computer must be restarted for the graphics mode to work.\r\n" );
		return 2;
	}

	if ( rv ) {

		if ( Verbose ) {
			ShowVideoSettings( -43, AdaptorPrettyName, MonitorName, L" not set to ", 0, NewVideoSettings.dmPelsWidth, NewVideoSettings.dmPelsHeight, NewVideoSettings.dmBitsPerPel, NewVideoSettings.dmDisplayFrequency );
			QPuts( L": " );
		}
		else
			QPuts( L"Display change failed: " );

		switch ( rv ) {
			case DISP_CHANGE_BADDUALVIEW :
				QPuts( L"The system is DualView capable.\r\n" );
				break;

			case DISP_CHANGE_BADFLAGS :
				QPuts( L"Invalid flags.\r\n" );
				break;

			case DISP_CHANGE_BADMODE :
				QPuts( L"The graphics mode is not supported.\r\n" );
				break;

			case DISP_CHANGE_BADPARAM :
				QPuts( L"Invalid parameter.\r\n" );
				break;

			case DISP_CHANGE_FAILED :
				QPuts( L"The display driver failed the specified graphics mode.\r\n" );
				break;

			case DISP_CHANGE_NOTUPDATED :
				QPuts( L"Unable to write settings to the registry.\r\n" );
				break;

			default :
				Printf( L"Readon unknown.\r\n" );
		}
		return 2;
	}

	if ( Prompt ) {
		Sprintf( ConfirmationString, L"%03u", GetRand( 1000 ) );
		_cputws( L"Type " );
		ColorPrintf( InputColors(), L"%s", ConfirmationString );
		_cputws( L" and press Enter within the next 15 seconds\r\nto keep these settings: " );

		InputWithTimeout( UserEntry, SHORT_BUF_LEN, 15 );

		if ( _wcsicmp( UserEntry, ConfirmationString ) ) {
			OldVideoSettings.dmFields = ( DM_PELSWIDTH | DM_PELSHEIGHT | DM_BITSPERPEL | DM_DISPLAYFREQUENCY );
			ChangeDisplaySettingsEx( AdaptorName, &OldVideoSettings, NULL, SaveToRegistry ? CDS_UPDATEREGISTRY : 0, NULL );
			Printf( L"Canceled.\r\n" );
			return 3;
		}
	}

	if ( ( Flags & SR_FLAG_NO_REPORT ) == 0 )
		ShowVideoSettings( -1, AdaptorPrettyName, MonitorName, L" set to ", 0, NewVideoSettings.dmPelsWidth, NewVideoSettings.dmPelsHeight, NewVideoSettings.dmBitsPerPel, NewVideoSettings.dmDisplayFrequency );

	return 0;
}


int ListResolutions( unsigned int MonitorIndex, BOOL ListAll, unsigned int XRes, unsigned int YRes, unsigned int ColorDepth, unsigned int RefreshRate )
{
	DISPLAY_DEVICE AdaptorInfo;
	wchar_t MonitorName[MAX_DISPLAY_NAME_LEN] = L"";
	BOOL Found = FALSE, ModesFound = FALSE;

	DEVMODE VideoMode;
	int rv = 0, i = 0;

	AdaptorInfo.cb = sizeof( DISPLAY_DEVICE );

	for ( int DeviceIndex = 0; EnumDisplayDevices( NULL, DeviceIndex, &AdaptorInfo, 0 ); DeviceIndex++ ) {

		if ( ( AdaptorInfo.StateFlags & DISPLAY_DEVICE_ACTIVE ) == 0 )
			continue;
		else if ( AdaptorInfo.StateFlags & DISPLAY_DEVICE_MIRRORING_DRIVER )
			continue;

		if ( !ListAll && ( MonitorIndex != UINT_MAX ) && ( DeviceIndex != MonitorIndex ) )
			continue;

		if ( !ListAll && ( MonitorIndex == UINT_MAX ) && ( ( AdaptorInfo.StateFlags & DISPLAY_DEVICE_PRIMARY_DEVICE ) == 0 ) )
			continue;

		Found = TRUE;
		GetMonitorName( AdaptorInfo.DeviceName, MonitorName );

		Printf( L"%u%s ", DeviceIndex, ( AdaptorInfo.StateFlags & DISPLAY_DEVICE_PRIMARY_DEVICE ) ? L"*" : L" " );
		Printf( L"%s on %s:\r\n", MonitorName, AdaptorInfo.DeviceString );

		VideoMode.dmSize = sizeof( DEVMODE );
		i = 0;
		ModesFound = FALSE;

		while ( EnumDisplaySettings( AdaptorInfo.DeviceName, i++, &VideoMode ) ) {
			if ( VideoMode.dmDisplayFrequency == 0 )
				VideoMode.dmDisplayFrequency = 1;

			if ( XRes )
				if ( VideoMode.dmPelsWidth != XRes )
					continue;

			if ( YRes )
				if ( VideoMode.dmPelsHeight != YRes )
					continue;

			if ( ColorDepth )
				if ( VideoMode.dmBitsPerPel != ColorDepth )
					continue;

			if ( RefreshRate )
				if ( VideoMode.dmDisplayFrequency != RefreshRate )
					continue;


			ShowVideoSettings( -42, NULL, NULL, NULL, 0, VideoMode.dmPelsWidth, VideoMode.dmPelsHeight, VideoMode.dmBitsPerPel, VideoMode.dmDisplayFrequency );
			ModesFound = TRUE;
		}

		if ( !ModesFound ) {
			Printf( L"   No matching display modes found.\r\n" );
			rv = 2;
		}

		Printf( L"\r\n" );
	}

	if ( !Found ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Monitor %u not found\r\n", MonitorIndex );
		return 2;
	}

	return rv;
}


DLLExports int WINAPI screenres( LPTSTR inString )
{
	if ( inString == NULL )
		return -1;

	unsigned int NewXRes = 0, NewYRes = 0, NewColorDepth = 0, NewRefreshRate = 0;
	unsigned int MonitorIndex = UINT_MAX;
	unsigned int inVal = 0;
	int rv = 0, crv = 0;

	BOOL ListAll = FALSE, ChangeSettings = FALSE, Found = FALSE, ListModes = FALSE;
	int Flags = SR_FLAG_PROMPT | SR_FLAG_SAVE;

	DISPLAY_DEVICE AdaptorInfo;
	wchar_t MonitorName[MAX_DISPLAY_NAME_LEN] = L"";
	DEVMODE VideoSettings;

	ParseArgs( inString, PARSE_BREAK_SPACES | PARSE_SLASHES_KLUDGE );


	for ( int i = 0; i < numargs; i++ ) {
		if ( arglen[i] ) {

			if ( !wcsncmp( arg[i], L"/?", 2 ) )
				return ShowCmdHelp( ScreenResHelpText, ( arg[i][2] == '?' ) );
			else if ( !_wcsicmp( arg[i], L"/A" ) )
				ListAll = TRUE;
			else if ( !_wcsnicmp( arg[i], L"/C", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				if ( ParseInt( arg[i] + j, &NewColorDepth, NULL ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad color depth: \"%s\"\r\n", arg[i] );
					return 1;
				}

				if ( ( NewColorDepth != 4 ) && ( NewColorDepth != 8 ) && ( NewColorDepth != 16 ) && ( NewColorDepth != 24 ) && ( NewColorDepth != 32 ) && ( NewColorDepth != 64 ) && ( NewColorDepth != 128 ) && ( NewColorDepth != 256 ) ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Color depth must be 4 to 256\r\n" );
					return 1;
				}
			}
			else if ( !_wcsicmp( arg[i], L"/D" ) )
				Flags &= ~SR_FLAG_SAVE;
			else if ( !_wcsicmp( arg[i], L"/L" ) )
				ListModes = TRUE;
			else if ( !_wcsnicmp( arg[i], L"/M", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				if ( ParseInt( arg[i] + j, &MonitorIndex, NULL ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad monitor number: \"%s\"\r\n", arg[i] );
					return 1;
				}

				if ( MonitorIndex > ( MAX_DISPLAY_MONITORS - 1 ) ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Monitor number must be 0 - %u\r\n", MAX_DISPLAY_MONITORS - 1 );
					return 1;
				}
			}
			else if ( !_wcsnicmp( arg[i], L"/N", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				while ( arg[i][j] ) {
					switch ( towupper( arg[i][j] ) ) {
						case 'S' :
							Flags &= ~SR_FLAG_SAVE;
							break;

						case 'R' :
							Flags |= SR_FLAG_NO_REPORT;
							break;

						default :
							DisplayErrorHeader();
							_wcsupr_s( arg[i], MAX_ARG_LEN );
							Qprintf( L"Unknown suboption: \"%s\"\r\n", arg[i] );
							return 1;
					}
					j++;
				}
			}
			else if ( !_wcsicmp( arg[i], L"/Q" ) )
				Flags &= ~SR_FLAG_PROMPT;
			else if ( !_wcsnicmp( arg[i], L"/R", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				if ( ParseInt( arg[i] + j, &NewRefreshRate, NULL ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad rate: \"%s\"\r\n", arg[i] );
					return 1;
				}

				if ( ( NewRefreshRate < MIN_REFRESH ) || ( NewRefreshRate > MAX_REFRESH ) ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Rate must be %u - %u\r\n", MIN_REFRESH, MAX_REFRESH );
					return 1;
				}
			}
			else if ( !_wcsicmp( arg[i], L"/S" )  )		//  ignore /S -- do-nothing option for QRes compatibility
				;
			else if ( !_wcsicmp( arg[i], L"/V" ) )
				Flags |= SR_FLAG_VERBOSE;
			else if ( !_wcsnicmp( arg[i], L"/X", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				if ( ParseInt( arg[i] + j, &NewXRes, NULL ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad width: \"%s\"\r\n", arg[i] );
					return 1;
				}

				if ( ( NewXRes < MIN_X_RES ) || ( NewXRes > MAX_X_RES ) ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Width must be at least %u\r\n", MIN_X_RES );
					return 1;
				}
			}
			else if ( !_wcsnicmp( arg[i], L"/Y", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				if ( ParseInt( arg[i] + j, &NewYRes, NULL ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad height: \"%s\"\r\n", arg[i] );
					return 1;
				}

				if ( ( NewYRes < MIN_Y_RES ) || ( NewYRes > MAX_Y_RES ) ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Height must be at least %u\r\n", MIN_Y_RES );
					return 1;
				}
			}
			else if ( arg[i][0] == '/' ) {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Unknown option: \"%s\"\r\n", arg[i] );
				return 1;
			}
			else {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Syntax error: \"%s\"\r\n", arg[i] );
				return 1;
			}

		}
	}


	if ( ListModes )
		return ListResolutions( MonitorIndex, ListAll, NewXRes, NewYRes, NewColorDepth, NewRefreshRate );


	if ( NewYRes == 0 ) {				//  if only /X: supplied, try a few standard resolutions:
		switch ( NewXRes ) {
			case 640:
				NewYRes = 480;
				break;

			case 800:
				NewYRes = 600;
				break;

			case 1024:
				NewYRes = 768;
				break;

			case 1280:
				NewYRes = 1024;
				break;

			case 1600:
				NewYRes = 1200;
				break;
		}
	}
	else if ( NewXRes == 0 ) {				//  if only /Y: supplied, try a few standard resolutions:
		switch ( NewYRes ) {
			case 480:
				NewXRes = 640;
				break;

			case 600:
				NewXRes = 800;
				break;

			case 768:
				NewXRes = 1024;
				break;

			case 1024:
				NewXRes = 1280;
				break;

			case 1200:
				NewXRes = 1600;
				break;
		}
	}

	if ( ( ( NewXRes != 0 ) && ( NewYRes == 0 ) ) || ( ( NewXRes == 0 ) && ( NewYRes != 0 ) ) ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Please supply both /X: and /Y:\r\n" );
		return 1;
	}

	ChangeSettings = ( NewXRes || NewColorDepth || NewRefreshRate );

	if ( ListAll )
		MonitorIndex = UINT_MAX;



	if ( ChangeSettings ) {
		//  change display resolution

		AdaptorInfo.cb = sizeof( DISPLAY_DEVICE );
		for ( int DeviceIndex = 0; EnumDisplayDevices( NULL, DeviceIndex, &AdaptorInfo, 0 ); DeviceIndex++ ) {

			if ( ( AdaptorInfo.StateFlags & DISPLAY_DEVICE_ACTIVE ) == 0 )
				continue;
			else if ( AdaptorInfo.StateFlags & DISPLAY_DEVICE_MIRRORING_DRIVER )
				continue;

			if ( !ListAll && ( MonitorIndex != UINT_MAX ) && ( DeviceIndex != MonitorIndex ) )
				continue;

			if ( !ListAll && ( MonitorIndex == UINT_MAX ) && ( ( AdaptorInfo.StateFlags & DISPLAY_DEVICE_PRIMARY_DEVICE ) == 0 ) )
				continue;

			Found = TRUE;
			GetMonitorName( AdaptorInfo.DeviceName, MonitorName );
			crv = ChangeResolution( AdaptorInfo.DeviceName, NewXRes, NewYRes, NewColorDepth, NewRefreshRate, Flags, AdaptorInfo.DeviceString[0] ? AdaptorInfo.DeviceString : AdaptorInfo.DeviceName, MonitorName );
			if ( crv > rv )
				rv = crv;
		}

		if ( !Found ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Monitor %u not found\r\n", MonitorIndex );
			return 2;
		}
	}
	else {
		//  report display resolution

		AdaptorInfo.cb = sizeof( DISPLAY_DEVICE );
		for ( int DeviceIndex = 0; EnumDisplayDevices( NULL, DeviceIndex, &AdaptorInfo, 0 ); DeviceIndex++ ) {

			if ( ( AdaptorInfo.StateFlags & DISPLAY_DEVICE_ACTIVE ) == 0 )
				continue;
			else if ( AdaptorInfo.StateFlags & DISPLAY_DEVICE_MIRRORING_DRIVER )
				continue;

			if ( !ListAll && ( MonitorIndex != UINT_MAX ) && ( DeviceIndex != MonitorIndex ) )
				continue;

			if ( !ListAll && ( MonitorIndex == UINT_MAX ) && ( ( AdaptorInfo.StateFlags & DISPLAY_DEVICE_PRIMARY_DEVICE ) == 0 ) )
				continue;

			Found = TRUE;
			GetMonitorName( AdaptorInfo.DeviceName, MonitorName );
			EnumDisplaySettings( AdaptorInfo.DeviceName, ENUM_CURRENT_SETTINGS, &VideoSettings );
			ShowVideoSettings( DeviceIndex, AdaptorInfo.DeviceString[0] ? AdaptorInfo.DeviceString : AdaptorInfo.DeviceName, MonitorName, NULL, AdaptorInfo.StateFlags, VideoSettings.dmPelsWidth, VideoSettings.dmPelsHeight, VideoSettings.dmBitsPerPel, VideoSettings.dmDisplayFrequency );
		}

		if ( !Found ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Monitor %u not found\r\n", MonitorIndex );
			return 2;
		}
	}

	return rv;
}


DLLExports int WINAPI _monitors( LPTSTR outString )
{
	if ( outString == NULL )
		return 1;

	Sprintf( outString, L"%d", GetSystemMetrics( SM_CMONITORS ) );
	return 0;
}


DLLExports int WINAPI f_screenres( LPTSTR inString )
{
	if ( inString == NULL )
		return -1;

	unsigned int MonitorIndex = UINT_MAX;
	unsigned int Field = 0;

	DISPLAY_DEVICE AdaptorInfo;
	DEVMODE VideoSettings;

	ParseArgs( inString, PARSE_BREAK_COMMAS | PARSE_FORCE_UPPERCASE );


	if ( arglen[0] ) {
		if ( ParseInt( arg[0], &MonitorIndex, NULL ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad monitor number: \"%s\"\r\n", arg[0] );
			return -1;
		}

		if ( MonitorIndex > ( MAX_DISPLAY_MONITORS - 1 ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Monitor number must be 0 - %u\r\n", MAX_DISPLAY_MONITORS - 1 );
			return -1;
		}
	}

	if ( arglen[1] ) {
		wchar_t ch = 0x00;

		if ( iswalpha( arg[1][0] ) )
			ch = arg[1][0];
		else if ( ( arg[1][0] == '/' ) && iswalpha( arg[1][1] ) )
			ch = arg[1][1];

		if ( ch ) {
			switch ( towupper( ch ) ) {
				case 'I' :
					Field = 0;
					break;

				case 'X' :
					Field = 1;
					break;

				case 'Y' :
					Field = 2;
					break;

				case 'C' :
					Field = 3;
					break;

				case 'R' :
					Field = 4;
					break;

				case 'D' :
					Field = 5;
					break;

				case 'M' :
					Field = 6;
					break;

				case 'P' :
					Field = 7;
					break;

				case 'T' :
					Field = 8;
					break;

				default:
					_wcsupr_s( arg[1], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad field code: \"%s\"\r\n", arg[1] );
					return -1;
			}
		}
		else if ( ParseInt( arg[1], &Field, NULL ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad field number: \"%s\"\r\n", arg[1] );
			return -1;
		}
	}

	AdaptorInfo.cb = sizeof( DISPLAY_DEVICE );
	for ( int DeviceIndex = 0; EnumDisplayDevices( NULL, DeviceIndex, &AdaptorInfo, 0 ); DeviceIndex++ ) {

		if ( ( AdaptorInfo.StateFlags & DISPLAY_DEVICE_ACTIVE ) == 0 )
			continue;
		else if ( AdaptorInfo.StateFlags & DISPLAY_DEVICE_MIRRORING_DRIVER )
			continue;

		if ( ( MonitorIndex != UINT_MAX ) && ( DeviceIndex != MonitorIndex ) )
			continue;

		if ( ( MonitorIndex == UINT_MAX ) && ( ( AdaptorInfo.StateFlags & DISPLAY_DEVICE_PRIMARY_DEVICE ) == 0 ) )
			continue;

		EnumDisplaySettings( AdaptorInfo.DeviceName, ENUM_CURRENT_SETTINGS, &VideoSettings );

		switch( Field ) {

			case 1 :
				Sprintf( inString, L"%u", VideoSettings.dmPelsWidth );
				break;

			case 2 :
				Sprintf( inString, L"%u", VideoSettings.dmPelsHeight );
				break;

			case 3 :
				Sprintf( inString, L"%u", VideoSettings.dmBitsPerPel );
				break;

			case 4 :
				if ( VideoSettings.dmDisplayFrequency < 2 )
					wcscpy_s( inString, MAX_ARG_LEN, L"Default" );
				else
					Sprintf( inString, L"%u", VideoSettings.dmDisplayFrequency );

				break;

			case 5 :
				wcscpy_s( inString, MAX_ARG_LEN, AdaptorInfo.DeviceString );
				break;

			case 6 :
				GetMonitorName( AdaptorInfo.DeviceName, inString );
				break;

			case 7 :
				if ( AdaptorInfo.StateFlags & DISPLAY_DEVICE_PRIMARY_DEVICE )
					wcscpy_s( inString, MAX_ARG_LEN, L"1" );
				else
					wcscpy_s( inString, MAX_ARG_LEN, L"0" );
				break;

			case 8 :
				Sprintf( inString, L"%ux%u", VideoSettings.dmPelsWidth, VideoSettings.dmPelsHeight );
				break;

			default:
				if ( VideoSettings.dmDisplayFrequency < 2 )
					Sprintf( inString, L"%u x %u (%u) at default refresh rate", VideoSettings.dmPelsWidth, VideoSettings.dmPelsHeight, VideoSettings.dmBitsPerPel );
				else
					Sprintf( inString, L"%u x %u (%u) at %u Hz", VideoSettings.dmPelsWidth, VideoSettings.dmPelsHeight, VideoSettings.dmBitsPerPel, VideoSettings.dmDisplayFrequency );
				break;
		}

		return 0;
	}

	DisplayErrorHeader();
	Qprintf( ERRHANDLE, L"Monitor %u not found\r\n", MonitorIndex );
	return -2;
}



#include "MkScCmd.cpp"



int TrimLine( LPTSTR String )
{
	if ( String == NULL )
		return -1;
	else if ( String[0] == 0x00 )
		return 0;

	int FirstNonSpace = -1, LastNonSpace = -1;
	wchar_t ch = 0x00;

	for ( int i = 0; String[i]; i++ ) {
		ch = String[i];

		if ( iswspace( ch ) == 0 ) {
			LastNonSpace = i;

			if ( FirstNonSpace == -1 )
				FirstNonSpace = i;
		}
	}

	if ( FirstNonSpace == -1 ) {
		String[0] = 0x00;
		return 0;
	}

	String[LastNonSpace + 1] = 0x00;

	if ( FirstNonSpace ) {
		int i = 0;

		do {
			ch = String[FirstNonSpace + i];
			String[i++] = ch;

		} while ( ch );
	}

	return 0;
}



BOOL Compare2( int Value, LPTSTR Name )
{
	if ( Name == NULL )
		return FALSE;

	wchar_t temp[SHORT_BUF_LEN] = L"";
	int i = 0, j = 0;
	wchar_t ch = 0x00;
	
	while ( CSIDLNames[Value][i] ) {
		ch = towupper( CSIDLNames[Value][i++] );

		if ( ( j < ( SHORT_BUF_LEN - 1 ) ) && ( ch != '_' ) ) {
			temp[j++] = ch;
			temp[j] = 0x00;
		}
	}

	return ( wcscmp( Name, temp ) == 0 );
}


int NameToCSIDL( LPTSTR String )
{
	if ( String == NULL )
		return -1;
	else if ( String[0] == 0x00 )
		return -1;


	wchar_t temp[SHORT_BUF_LEN] = L"";
	int i = 0, j = 0;
	wchar_t ch = 0x00;

	if ( ( String[0] == '<' ) && ( String[ (int) wcslen( String ) - 1 ] == '>' ) )
		i = 1;

	if ( _wcsnicmp( String + i, L"CSIDL_", 6 ) == 0 )
		i += 6;

	while ( String[i] ) {
		ch = String[i++];

		if ( ( ch == '>' ) && ( String[i] == 0x00 ) )
			break;

		if ( !iswspace( ch ) && ( ch != '_' ) && ( ch != QUOTE ) && ( j < ( SHORT_BUF_LEN - 1 ) ) ) {
			temp[j++] = towupper( ch );
			temp[j] = 0x00;
		}
	}

	for ( i = 0; i < NUM_CSIDL_NAMES; i++ )
		if ( Compare2( i, temp ) )
			return CSIDLValues[i];

	for ( i = 0; i < NUM_CSIDL_NAMES; i++ )
		if ( _wcsicmp( String, CSIDLFancyNames[i] ) == 0 )
			return CSIDLValues[i];

	return -1;
}


DLLExports int WINAPI f_shfolder( LPTSTR String )
{
	if ( String == NULL )
		return -1;
	else if ( String[0] == 0x00 ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Missing value\r\n" );
		return -1;
	}


	TrimLine( String );
	_wcsupr_s( String, MAX_ARG_LEN );

	unsigned int Value = UINT_MAX;
	
	if ( iswdigit( String[0] ) ) {
		if ( ParseInt( String, &Value, NULL ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad value \"%s\"\r\n", String );
			return -1;
		}
	}
	else {
		Value = NameToCSIDL( String );

		if ( Value == UINT_MAX ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Unknown CSIDL name \"%s\"\r\n", String );
			return -1;
		}
	}

	// Printf( L"   * Value = %u\r\n", Value );
	Value &= 0x0ff;

	String[0] = 0x00;
	SHGetFolderPath( NULL, Value, NULL, SHGFP_TYPE_CURRENT, String );
	return 0;
}


DLLExports int WINAPI f_imgcolor( LPTSTR String )
{
	if ( String == NULL )
		return -1;


	ParseArgs( String, PARSE_BREAK_COMMAS );


	wchar_t Filename[MAX_FILENAME_LEN] = L"";
	Bitmap *SourceImage = NULL;
	Color TestPixel;
	unsigned int X = 0, Y = 0, Position = 0, PixelColor = 0;
	unsigned int Width = 0, Height = 0, MaxX = 0, MaxY = 0;
	int rv = 0;
	BOOL NegX = FALSE, NegY = FALSE, PctX = FALSE, PctY = FALSE;
	wchar_t *ch = NULL;



	if ( arglen[0] )
		//  QueryTrueName( arg[0], Filename );
		CanonicalizeFilenameEx( arg[0], Filename );
	else {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Missing filename\r\n" );
		return -1;
	}

	if ( arglen[1] ) {
		if ( arglen[2] ) {
			ch = arg[1];
			if ( *ch == '-' )
				NegX = TRUE, ch++;
			else if ( *ch == '+' )
				ch++;

			if ( ParsePercentage( ch, &X ) == 0 )
				PctX = TRUE;
			else if ( ParseInt( ch, &X, NULL ) ) {
				DisplayErrorHeader();
				_wcsupr_s( arg[1], MAX_ARG_LEN );
				Qprintf( ERRHANDLE, L"Bad X value: \"%s\"\r\n", arg[1] );
				return -1;
			}

			ch = arg[2];
			if ( *ch == '-' )
				NegY = TRUE, ch++;
			else if ( *ch == '+' )
				ch++;

			if ( ParsePercentage( ch, &Y ) == 0 )
				PctY = TRUE;
			else if ( ParseInt( ch, &Y, NULL ) ) {
				DisplayErrorHeader();
				_wcsupr_s( arg[2], MAX_ARG_LEN );
				Qprintf( ERRHANDLE, L"Bad Y value: \"%s\"\r\n", arg[2] );
				return -1;
			}
		}
		else {
			if ( ParseInt( arg[1], &Position, NULL ) ) {
				DisplayErrorHeader();
				_wcsupr_s( arg[1], MAX_ARG_LEN );
				Qprintf( ERRHANDLE, L"Bad position value: \"%s\"\r\n", arg[1] );
				return -1;
			}

			if ( ( Position == 0 ) || ( Position > 9 ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Position must be 1 - 9\r\n" );
				return -1;
			}
		}
	}
	else {
		Position = 5;

		if ( arglen[2] ) {
			DisplayErrorHeader();
			_wcsupr_s( arg[2], MAX_ARG_LEN );
			Qprintf( ERRHANDLE, L"Syntax error: \"%s\"\r\n", arg[2] );
			return -1;
		}
	}


	if ( !IsAFile( Filename ) ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"File not found: \"%s\"\r\n", Filename );
		return -1;
	}

	SourceImage = new Bitmap( Filename );

	if ( SourceImage == NULL ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Error loading file \"%s\"\r\n", Filename );
		return -1;
	}

	rv = SourceImage->GetLastStatus();

	if ( rv ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Error %u loading file \"%s\"\r\n", rv, Filename );
		delete SourceImage;
		return -1;
	}

	Width	= SourceImage->GetWidth();
	Height	= SourceImage->GetHeight();
	MaxX	= Width  - 1;
	MaxY	= Height - 1;

	if ( Position ) {
		unsigned int MidX = Width / 2, MidY = Height / 2;

		switch ( Position ) {
			case 2 :
				X = MidX;
				break;

			case 3 :
				X = MaxX;
				break;

			case 4 :
				Y = MidY;
				break;

			case 5 :
				X = MidX;
				Y = MidY;
				break;

			case 6 :
				X = MaxX;
				Y = MidY;
				break;

			case 7 :
				Y = MaxY;
				break;

			case 8 :
				X = MidX;
				Y = MaxY;
				break;

			case 9 :
				X = MaxX;
				Y = MaxY;
				break;
		}
	}
	else {
		if ( PctX )
			X = ( X * MaxX ) / 10000;
		else if ( X > MaxX )
			X = MaxX;

		if ( PctY )
			Y = ( Y * MaxY ) / 10000;
		else if ( Y > MaxY )
			Y = MaxY;

		if ( NegX )
			X = MaxX - X;

		if ( NegY )
			Y = MaxY - Y;
	}

	//  wprintf( L"   * Width = %u   Height = %u  X,Y = %u,%u\r\n", Width, Height, X, Y );

	SourceImage->GetPixel( X, Y, &TestPixel );
	PixelColor = TestPixel.GetValue() & 0xffffff;

	delete SourceImage;

	wsprintf( String, L"#%06x", PixelColor );
	return 0;
}


int RGBtoHSL( unsigned int RGBColor, double *Hue, double *Saturation, double *Lightness )
{
	if ( ( Hue == NULL ) && ( Saturation == NULL ) && ( Lightness == NULL ) )
		return -1;

	unsigned int Red	= ( RGBColor & 0xff0000 ) >> 16;
	unsigned int Green	= ( RGBColor & 0x00ff00 ) >> 8;
	unsigned int Blue	= RGBColor & 0x0000ff;

	double R = Red / 255.0, G = Green / 255.0, B = Blue / 255.0;
	double Cmax = R, Cmin = R, Diff = 0.0, H = 0.0, S = 0.0, L = 0.0;


	if ( G > Cmax )
		Cmax = G;

	if ( B > Cmax )
		Cmax = B;

	if ( G < Cmin )
		Cmin = G;

	if ( B < Cmin )
		Cmin = B;

	Diff = Cmax - Cmin;

	if ( Diff ) {
		if ( Cmax == R ) {
			H = ( G - B ) / Diff;

			if ( H < 0.0 )
				H += 6.0;
		}
		else if ( Cmax == G )
			H = ( ( B - R ) / Diff ) + 2.0;
		else
			H = ( ( R - G ) / Diff ) + 4.0;
	}

	H *= 60.0;

	L = ( Cmax + Cmin ) / 2.0;

	if ( Diff )
		S = Diff / ( 1.0 - fabs( ( 2.0 * L ) - 1.0 ) );

	if ( Hue )
		*Hue = H;

	if ( Saturation )
		*Saturation = ( S * 100.0 );

	if ( Lightness )
		*Lightness = ( L * 100.0 );

	return 0;
}


int HSLtoRGB( double Hue, double Saturation, double Lightness, unsigned int *Red, unsigned int *Green, unsigned int *Blue )
{
	if ( ( Red == NULL ) || ( Green == NULL ) || ( Blue == NULL ) )
		return -1;

	if ( ( Hue < 0.0 ) || ( Hue >= 360.0 ) || ( Saturation < 0.0 ) || ( Saturation > 100.0 ) || ( Lightness < 0.0 ) || ( Lightness > 100.0 ) )
		return -2;

	Saturation /= 100.0;
	Lightness /= 100.0;

	double C = ( 1.0 - fabs( ( 2.0 * Lightness ) - 1.0 ) ) * Saturation;
	double X = C * ( 1.0 - fabs( fmod( ( Hue / 60.0 ), 2.0 ) - 1.0 ) );
	double m = Lightness - ( C / 2.0 );
	double R = 0.0, G = 0.0, B = 0.0;

	if ( Hue < 60.0 )
		R = C, G = X, B = 0.0;
	else if ( Hue < 120.0 )
		R = X, G = C, B = 0.0;
	else if ( Hue < 180.0 )
		R = 0.0, G = C, B = X;
	else if ( Hue < 240.0 )
		R = 0.0, G = X, B = C;
	else if ( Hue < 300.0 )
		R = X, G = 0.0, B = C;
	else
		R = C, G = 0.0, B = X;

	*Red	= (unsigned int) ( ( ( R + m ) * 255.0 ) + 0.9 );
	*Green	= (unsigned int) ( ( ( G + m ) * 255.0 ) + 0.9 );
	*Blue	= (unsigned int) ( ( ( B + m ) * 255.0 ) + 0.9 );
	
	return 0;
}


DLLExports int WINAPI f_rgbcompl( LPTSTR String )
{
	if ( !String )
		return -1;


	unsigned int Color = 0;
	double Hue = 0.0, Saturation = 0.0, Lightness = 0.0, NewLightness = 0.0;
	double Rotate = 180.0;
	unsigned int Red = 0, Green = 0, Blue = 0;
	wchar_t *sep1 = NULL;
	BOOL Error = FALSE;


	ParseArgs( String, PARSE_BREAK_COMMAS | PARSE_FORCE_UPPERCASE );


	if ( arglen[0] ) {
		if ( ( arg[0][0] == '0' ) && ( towupper( arg[0][1] ) == 'X' ) ) {
			if ( ParseInt( arg[0], &Color, NULL ) ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad color value: \"%s\"\r\n", arg[0] );
				return -1;
			}

			if ( Color > 0x00ffffff ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Color must be 0x000000 - 0xFFFFFF: \"%s\"\r\n", arg[0] );
				return -1;
			}
		}
		else {
			Color = W3CColorValue( arg[0], TRUE );

			if ( Color == W3C_COLOR_UNDEFINED ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Unknown color: \"%s\"\r\n", arg[0] );
				return -1;
			}
		}
	}
	else {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Missing color\r\n" );
		return -1;
	}

	if ( arglen[1] ) {
		_set_errno( 0 );
		sep1 = NULL;
		Rotate = wcstod( arg[1], &sep1 );

		if ( errno || ( sep1 == NULL ) || ( sep1 == arg[1] ) )
			Error = TRUE;
		else if ( *sep1 )
			Error = TRUE;

		if ( Error ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad rotation value \"%s\"\r\n", arg[1] );
			return -1;
		}

		if ( ( Rotate < -360.0 ) || ( Rotate > 360.0 ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Rotation angle must be -360 to +360\r\n" );
			return -1;
		}
	}

	if ( arglen[2] ) {
		_set_errno( 0 );
		sep1 = NULL;
		NewLightness = wcstod( arg[2], &sep1 );

		if ( errno || ( sep1 == NULL ) || ( sep1 == arg[2] ) )
			Error = TRUE;
		else if ( *sep1 )
			Error = TRUE;

		if ( Error ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad lightness value \"%s\"\r\n", arg[2] );
			return -1;
		}

		if ( ( NewLightness < 0.0 ) || ( NewLightness > 100.0 ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Lightness must be 0 - 100\r\n" );
			return -1;
		}
	}


	if ( RGBtoHSL( (unsigned int) Color, &Hue, &Saturation, &Lightness ) ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Error converting HSL to RGB\r\n" );
		return -1;
	}

	Hue = fmod( Hue + Rotate, 360.0 );
	if ( Hue < 0.0 )
		Hue += 360.0;

	if ( arglen[2] )
		Lightness = NewLightness;

	HSLtoRGB( Hue, Saturation, Lightness, &Red, &Green, &Blue );

	wsprintf( String, L"#%06x", ( Red << 16 ) | ( Green << 8 ) | Blue );
	return 0;
}


DLLExports int WINAPI f_rgblum( LPTSTR String )
{
	if ( !String )
		return -1;


	unsigned int Color = 0;


	ParseArgs( String, PARSE_BREAK_COMMAS | PARSE_FORCE_UPPERCASE );


	if ( arglen[0] == 0 ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Missing RGB values\r\n" );
		return -1;
	}


	if ( ( arg[0][0] == '0' ) && ( towupper( arg[0][1] ) == 'X' ) ) {
		if ( ParseInt( arg[0], &Color, NULL ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad color value: \"%s\"\r\n", arg[0] );
			return -1;
		}

		if ( Color > 0x00ffffff ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Color must be 0x000000 - 0xFFFFFF: \"%s\"\r\n", arg[0] );
			return -1;
		}
	}
	else {
		Color = W3CColorValue( arg[0], TRUE );

		if ( Color == W3C_COLOR_UNDEFINED ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Unknown color: \"%s\"\r\n", arg[0] );
			return -1;
		}
	}


	unsigned int Red	= ( Color & 0xff0000 ) >> 16;
	unsigned int Green	= ( Color & 0x00ff00 ) >> 8;
	unsigned int Blue	= Color & 0x0000ff;

	int L = ( Red * 299 / 255 ) + ( Green * 587 / 255 ) + ( Blue * 114 / 255 );

	wsprintf( String, L"%d", L );
	return 0;
}



/*
int GetDefaultBrowser( BOOL User, LPTSTR outFilename )
{
	if ( outFilename == FALSE )
		return -1;

	wchar_t KeyName[SHORT_BUF_LEN]	= L"";
	wchar_t Data[MAX_FILENAME_LEN]	= L"";
	HKEY KeyHandle = NULL;
	DWORD DataType = 0, DataSize = MAX_FILENAME_LEN * sizeof( wchar_t );
	int rv = 0;


	if ( User )
		wcscpy_s( KeyName, SHORT_BUF_LEN, L"Software\\Classes\\" );

	wcscat_s( KeyName, SHORT_BUF_LEN, L"http\\shell\\open\\command" );

	if ( RegOpenKeyEx( User ? HKEY_CURRENT_USER : HKEY_CLASSES_ROOT, KeyName, 0, KEY_READ, &KeyHandle ) )
		return 1;

	rv = RegQueryValueEx( KeyHandle, NULL, NULL, &DataType, (BYTE *) Data, &DataSize );

	RegCloseKey( KeyHandle );

	if ( rv != ERROR_SUCCESS )
		return 1;

	if ( DataType != REG_SZ )
		return 1;

	wchar_t temp[MAX_FILENAME_LEN] = L"";
	wchar_t ch = '\0';
	BOOL quotes = FALSE;
	int j = 0;

	for ( int i = 0; Data[i]; i++ ) {
		ch = Data[i];

		if ( ch == QUOTE ) {
			quotes = !quotes;
			continue;
		}
		else if ( !quotes && iswspace( ch ) && j )
			break;
		else if ( !quotes && iswspace( ch ) )
			continue;

		if ( j < ( MAX_FILENAME_LEN - 1 ) ) {
			temp[j++] = ch;
			temp[j] = '\0';
		}
	}

	if ( j == 0 )
		return 1;

	wcscpy_s( outFilename, MAX_FILENAME_LEN + 2, L"\"" );
	wcscat_s( outFilename, MAX_FILENAME_LEN + 2, temp );
	wcscat_s( outFilename, MAX_FILENAME_LEN + 2, L"\"" );
	return 0;
}



DLLExports int WINAPI _browser( LPTSTR outString )
{
	if ( outString == NULL )
		return -1;

	if ( GetDefaultBrowser( TRUE, outString ) == 0 )
		return 0;

	GetDefaultBrowser( FALSE, outString );
	return 0;
}
*/



DLLExports int WINAPI _browser( LPTSTR outString )
{
	if ( !outString )
		return 1;


	DWORD BufLen		= MAX_ARG_LEN;
	BOOL Good			= FALSE;
	int rv				= 0;


	outString[0] = '\0';

	if ( ( OSVerInfo.dwMajorVersion > 6 ) || ( ( OSVerInfo.dwMajorVersion == 6 ) && ( OSVerInfo.dwMinorVersion >= 2 ) ) )
		//		Windows 8 and later:  get association for HTTP protocol
		rv = AssocQueryString( ASSOCF_NOTRUNCATE | ASSOCF_IS_PROTOCOL, ASSOCSTR_EXECUTABLE, L"http", NULL, outString, &BufLen );
	else
		//		Pre-Windows 8:  get association for .HTML files
		rv = AssocQueryString( ASSOCF_NOTRUNCATE, ASSOCSTR_EXECUTABLE, L".html", NULL, outString, &BufLen );


	if ( rv == S_OK )
		if ( outString[0] )
			if ( IsAFile( outString ) )
				Good = TRUE;

	if ( !Good )
		outString[0] = '\0';

	return 0;
}



DLLExports int WINAPI conicon( LPTSTR inString )
{
	if ( !inString )
		return -1;


	wchar_t Filename[MAX_FILENAME_LEN]	= L"";
	unsigned int IconIndex				= 0;
	BOOL Default						= FALSE;


	ParseArgs( inString, PARSE_BREAK_SPACES );


	for ( int i = 0; i < numargs; i++ ) {
		if ( arglen[i] ) {

			if ( !wcsncmp( arg[i], L"/?", 2 ) )
				return ShowCmdHelp( ConIconHelpText, ( arg[i][2] == '?' ) );
			else if ( !_wcsicmp( arg[i], L"/C" ) ) {
				wcscpy_s( Filename, MAX_FILENAME_LEN, L"%_cmdspec" );
				ExpandVariables( Filename, 1 );
				IconIndex = 0;
			}
			else if ( !_wcsicmp( arg[i], L"/D" ) )
				Default = TRUE;
			else if ( !_wcsnicmp( arg[i], L"/I", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				if ( ParseInt( arg[i] + j, &IconIndex, NULL ) ) {
					DisplayErrorHeader();
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					Qprintf( ERRHANDLE, L"Bad icon index: \"%s\"\r\n", arg[i] );
					return 1;
				}
			}
			else if ( arg[i][0] == '/' ) {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Unknown option: \"%s\"\r\n", arg[i] );
				return 1;
			}
			else if ( Filename[0] == '\0' )
				//  QueryTrueName( arg[i], Filename );
				CanonicalizeFilenameEx( arg[i], Filename );
			else {
				DisplayErrorHeader();
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				Qprintf( ERRHANDLE, L"Syntax error: \"%s\"\r\n", arg[i] );
				return 1;
			}
		}
	}


	if ( !Default && ( Filename[0] == '\0' ) ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Missing filename\r\n" );
		return 1;
	}


	HICON IconHandle = NULL;


	if ( Filename[0] ) {
		if ( !IsAFile( Filename ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"File does not exist: \"%s\"\r\n", Filename );
			return 2;
		}

		IconHandle = ExtractIcon( MyDLLHandle, Filename, IconIndex );

		if ( !IconHandle ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Icon not found: \"%s\"\r\n", Filename );
			return 2;
		}
	}
	

	HMODULE Kernel32 = NULL;
	Kernel32 = GetModuleHandle( L"kernel32.dll" );

	if ( !Kernel32 ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Error loading kernel32.dll\r\n" );

		if ( IconHandle )
			DestroyIcon( IconHandle );

		return 2;
	}

	typedef DWORD (__stdcall *_SetConsoleIcon)(HICON);
	_SetConsoleIcon SetConsoleIcon = NULL;
	SetConsoleIcon = (_SetConsoleIcon) GetProcAddress( Kernel32, "SetConsoleIcon" );

	if ( !SetConsoleIcon ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Error getting address for GetConsoleIcon()\r\n" );

		if ( IconHandle )
			DestroyIcon( IconHandle );

		return 2;
	}
	

	int rv = SetConsoleIcon( IconHandle );

	if ( IconHandle  )
		DestroyIcon( IconHandle );

	if ( !rv ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Error setting console icon\r\n" );
		return 2;
	}

	return 0;
}


DLLExports int WINAPI _safemode( LPTSTR outString )
{
	if ( outString == NULL )
		return 1;

	wsprintf( outString, L"%d", GetSystemMetrics( SM_CLEANBOOT ) );
	return 0;
}


DLLExports int WINAPI _shortcut( LPTSTR outString )
{
	if ( outString == NULL )
		return 1;

	STARTUPINFO StartupInfo;

	memset( &StartupInfo, 0x00, sizeof( StartupInfo ) );
	StartupInfo.cb = sizeof( STARTUPINFO );

	GetStartupInfo( &StartupInfo );

	if ( StartupInfo.dwFlags & STARTF_TITLEISLINKNAME )
		wcscpy_s( outString, MAX_ARG_LEN, StartupInfo.lpTitle );
	else
		outString[0] = 0x00;

	return 0;
}



/*
int Tab( int i )
{
	if ( i <= 0 )
		return 0;

	for ( int j = 0; j < i; j++ )
		QPuts( L" " );

	return 0;
}


int DumpShellFolder( IShellFolder *Folder, int Recurse )
{
	if ( Folder == NULL )
		return -1;

	IEnumIDList *EnumIDList = NULL;
	ITEMIDLIST *FoundItem = NULL;
	STRRET StrRet;
	HRESULT Result = 0;
	wchar_t DisplayName[MAX_FILENAME_LEN] = L"";

	IShellFolder *Subfolder = NULL;
	ULONG SubfolderAttribs = 0;


	Folder->EnumObjects( NULL, SHCONTF_NONFOLDERS | SHCONTF_INCLUDEHIDDEN, &EnumIDList );

	if ( EnumIDList != NULL ) {
		Result = EnumIDList->Next( 1, &FoundItem, NULL );

		while ( Result != S_FALSE ) {
			if ( Result != NOERROR )
				break;

			StrRet.uType = STRRET_WSTR;
			Folder->GetDisplayNameOf( FoundItem, SHGDN_NORMAL, &StrRet );
			DisplayName[0] = 0x00;
			StrRetToBuf( &StrRet, FoundItem, DisplayName, MAX_FILENAME_LEN );

			Tab( 3 * Recurse );
			Printf( L"%s\r\n", DisplayName );

			CoTaskMemFree( FoundItem );
			Result = EnumIDList->Next( 1, &FoundItem, NULL );
		}

		EnumIDList->Release();
		EnumIDList = NULL;
	}

	Folder->EnumObjects( NULL, SHCONTF_FOLDERS | SHCONTF_INCLUDEHIDDEN, &EnumIDList );

	if ( EnumIDList != NULL ) {
		Result = EnumIDList->Next( 1, &FoundItem, NULL );

		while ( Result != S_FALSE ) {
			if ( Result != NOERROR )
				break;

			StrRet.uType = STRRET_WSTR;
			Folder->GetDisplayNameOf( FoundItem, SHGDN_NORMAL, &StrRet );
			DisplayName[0] = 0x00;
			StrRetToBuf( &StrRet, FoundItem, DisplayName, MAX_FILENAME_LEN );

			Tab( 3 * Recurse );
			Printf( L"%s\r\n", DisplayName );

			SubfolderAttribs = SFGAO_FILESYSTEM | SFGAO_ISSLOW;
			Folder->GetAttributesOf( 1, (LPCITEMIDLIST*) &FoundItem, &SubfolderAttribs );

			if ( _wcsicmp( DisplayName, L"Entire Network" ) == 0 ) {
				SubfolderAttribs |= 1;
				Tab( 3 * ( Recurse + 1 ) );
				Printf( L"- recursion skipped -\r\n" );
			}
			else if ( Recurse == 0 )
				SubfolderAttribs |= 2;

			if ( SubfolderAttribs == 0 ) {
				Subfolder = NULL;
				Folder->BindToObject( FoundItem, NULL, IID_IShellFolder, (void**) &Subfolder );

				if ( Subfolder != NULL ) {
					DumpShellFolder( Subfolder, Recurse + 1 );
					Subfolder->Release();
				}
			}

			CoTaskMemFree( FoundItem );
			Result = EnumIDList->Next( 1, &FoundItem, NULL );
		}

		EnumIDList->Release();
		EnumIDList = NULL;
	}

	return 0;
}


DLLExports int WINAPI xtest( LPTSTR inString )
{

	IShellFolder *Desktop = NULL;

	SHGetDesktopFolder( &Desktop );

	if ( Desktop == NULL ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Can\u2019t get desktop folder\r\n" );
		return 2;
	}

	Printf( L"DESKTOP\r\n" );
	DumpShellFolder( Desktop, 1 );

	Desktop->Release();
	return 0;
}


DLLExports int WINAPI ytest( LPTSTR inString )
{
	IShellFolder *Desktop		= NULL;
	IShellFolder *ControlPanel	= NULL;
	ITEMIDLIST *ControlPanelID	= NULL;

	SHGetDesktopFolder( &Desktop );
	if ( Desktop == NULL )
		return -1;

	SHGetFolderLocation( NULL, CSIDL_CONTROLS, NULL, 0, &ControlPanelID );
	if ( ControlPanelID == NULL ) {
		Desktop->Release();
		return -1;
	}

	Desktop->BindToObject( ControlPanelID, NULL, IID_IShellFolder, (void**) &ControlPanel );

	ILFree( ControlPanelID );
	Desktop->Release();

	if ( ControlPanel == NULL )
		return -1;

	Printf( L"CONTROL PANEL:\r\n" );

	DumpShellFolder( ControlPanel, 0 );

	ControlPanel->Release();
	return 0;
}
*/


int ForceForegroundWindow( HWND WindowHandle )
{
	//		http://www.tek-tips.com/faqs.cfm?fid=4262
	//		http://www.codeproject.com/Tips/76427/How-to-bring-window-to-top-with-SetForegroundWindo

	if ( WindowHandle == NULL )
		return -1;

	DWORD ForegroundThread = GetWindowThreadProcessId( GetForegroundWindow(), NULL );
	DWORD AppThread = GetCurrentThreadId();
	UINT ShowMode = SW_RESTORE;

	if ( IsZoomed( WindowHandle ) )
		ShowMode = SW_MAXIMIZE;

	if ( ForegroundThread != AppThread ) {
		AttachThreadInput( ForegroundThread, AppThread, TRUE );
		SystemParametersInfo( SPI_SETFOREGROUNDLOCKTIMEOUT, 0, 0, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE );
		AllowSetForegroundWindow( GetCurrentProcessId() );
		BringWindowToTop( WindowHandle );
		ShowWindow( WindowHandle, ShowMode );
		SetForegroundWindow( WindowHandle );
		SystemParametersInfo( SPI_SETFOREGROUNDLOCKTIMEOUT, 0, (void*) ForegroundLockTimeoutSave, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE );
		AttachThreadInput( ForegroundThread, AppThread, FALSE );
	}
	else {
		BringWindowToTop( WindowHandle );
		ShowWindow( WindowHandle, ShowMode );
		SetForegroundWindow( WindowHandle );
	}

	return 0;
}


DLLExports int WINAPI setfocus( LPTSTR inString )
{
	if ( inString == NULL )
		return -1;


	LPTSTR WindowName	= NULL;
	LPTSTR ClassName	= NULL;
	BOOL Quiet			= FALSE;
	HWND WindowHandle	= NULL;

	wchar_t DefaultWindowName[] = L"*";


	ParseArgs( inString, PARSE_BREAK_SPACES | PARSE_ONE_ARG_KLUDGE );

	for ( int i = 0; i < numargs; i++ ) {
		if ( arglen[i] ) {
			if ( !wcsncmp( arg[i], L"/?", 2 ) )
				return ShowCmdHelp( SetFocusHelpText, ( arg[i][2] == '?' ) );
			else if ( !_wcsnicmp( arg[i], L"/C", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				if ( arg[i][j] )
					ClassName = arg[i] + j;
				else
					ClassName = NULL;
			}
			else if ( !_wcsicmp( arg[i], L"/Q" ) )
				Quiet = TRUE;
			else if ( arg[i][0] == '/' ) {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Unknown option: \"%s\"\r\n", arg[i] );
				return 1;
			}
			else if ( WindowName == NULL )
				WindowName = arg[i];
			else {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Syntax error: \"%s\"\r\n", arg[i] );
				return 1;
			}
		}
	}


	if ( ClassName && ( WindowName == NULL ) )
		WindowName = DefaultWindowName;


	if ( WindowName ) {
		if ( ParseInt( WindowName, (unsigned int*) &WindowHandle, NULL ) == 0 )
			if ( !IsWindow( WindowHandle ) )
				WindowHandle = NULL;

		if ( WindowHandle == NULL )
			WindowHandle = FuzzyFindWindow( WindowName, ClassName );

		if ( !IsWindow( WindowHandle ) ) {
			DisplayErrorHeader();

			if ( ClassName )
				Qprintf( ERRHANDLE, L"Can\u2019t find window \"%s\" of class \"%s\"\r\n", WindowName, ClassName );
			else
				Qprintf( ERRHANDLE, L"Can\u2019t find window \"%s\"\r\n", WindowName );

			return 2;
		}

		if ( !Quiet )
			Printf( L"Setting focus to window 0x%08x.\r\n", WindowHandle );
	}
	else {
		if ( Console2WindowHandle ) {
			WindowHandle = Console2WindowHandle;

			if ( !Quiet )
				Printf( L"Setting focus to Console2 window 0x%08x.\r\n", WindowHandle );
		}
		else {
			WindowHandle = GetTakeCommandWindow();

			if ( WindowHandle ) {
				if ( !Quiet )
					Printf( L"Setting focus to Take Command window 0x%08x.\r\n", WindowHandle );
			}
			else {
				WindowHandle = GetConEmuWindow();

				if ( WindowHandle ) {
					if ( !Quiet )
						Printf( L"Setting focus to ConEmu window 0x%08x.\r\n", WindowHandle );
				}
				else {
					WindowHandle = GetConsoleWindow();

					if ( !Quiet )
						Printf( L"Setting focus to console window 0x%08x.\r\n", WindowHandle );
				}
			}
		}
	}

	ForceForegroundWindow( WindowHandle );
	return 0;
}


int NewEvaluate( LPTSTR String )
{
	if ( !String )
		return -1;
	else if ( String[0] == '\0' )
		return -1;


	wchar_t temp[MAX_ARG_LEN]	= L"";
	HANDLE OldStderrHandle		= GetStdHandle( STD_ERROR_HANDLE );
	HANDLE OldStdoutHandle		= GetStdHandle( STD_OUTPUT_HANDLE );
	HANDLE NewOutputHandle		= CreateFile( L"nul", GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_ALWAYS, 0, NULL );
	int rv						= 0;


	if ( NewOutputHandle != INVALID_HANDLE_VALUE ) {
		SetStdHandle( STD_ERROR_HANDLE, NewOutputHandle );
		SetStdHandle( STD_OUTPUT_HANDLE, NewOutputHandle );
	}

	wcscpy_s( temp, MAX_ARG_LEN, L"%@eval[" );
	wcscat_s( temp, MAX_ARG_LEN, String );
	wcscat_s( temp, MAX_ARG_LEN, L"]" );

	ExpandVariables( temp, 1 );

	if ( NewOutputHandle != INVALID_HANDLE_VALUE ) {
		SetStdHandle( STD_ERROR_HANDLE, OldStderrHandle );
		SetStdHandle( STD_OUTPUT_HANDLE, OldStdoutHandle );
		CloseHandle( NewOutputHandle );
	}

	if ( rv )
		return 1;
	else if ( temp[0] == '\0' )
		return 1;

	wcscpy_s( String, MAX_ARG_LEN, temp );
	return 0;
}


int ParseIntExpression( LPTSTR inString, int *outValue )
{
	if ( !inString )
		return -1;
	else if ( inString[0] == 0x00 )
		return -1;


	wchar_t temp[MAX_ARG_LEN]	= L"";
	int Value					= 0;
	int rv						= 0;
	wchar_t *sep1				= NULL;



	wcscpy_s( temp, MAX_ARG_LEN, inString );

	//	wprintf( L"   * Before NewEvaluate() :  temp = '%s'\r\n", temp );

	if ( NewEvaluate( temp ) )
		return 1;

	//	wprintf( L"   * After  NewEvaluate() :  temp = '%s'\r\n", temp );

	Value = wcstol( temp, &sep1, 10 );

	if ( errno ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Bad integer: \"%s\"\r\n", temp );
		return 1;
	}
	else if ( *sep1 && ( *sep1 != '.' ) && ( *sep1 != ',' ) ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Bad integer: \"%s\"\r\n", temp );
		return 2;
	}

	*outValue = Value;
	return 0;
}



DLLExports int WINAPI setmousepos( LPTSTR inString )
{
	if ( !inString )
		return -1;


	int NewX		= 0;
	int NewY		= 0;
	POINT MouseNow	= { 0, 0 };

	BOOL ChangeX = FALSE, ChangeY = FALSE;
	BOOL Quiet		= FALSE;


	GetCursorPos( &MouseNow );
	NewX	= MouseNow.x;
	NewY	= MouseNow.y;


	ParseArgs( inString, PARSE_BREAK_SPACES | PARSE_FORCE_UPPERCASE );


	for ( int i = 0; i < numargs; i++ ) {
		if ( arglen[i] ) {
			if ( !wcsncmp( arg[i], L"/?", 2 ) )
				return ShowCmdHelp( SetMousePosHelpText, ( arg[i][2] == '?' ) );
			else if ( !wcscmp( arg[i], L"/Q" ) )
				Quiet = TRUE;
			else if ( !wcsncmp( arg[i], L"/X", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				if ( ParseIntExpression( arg[i] + j, &NewX ) )
					return 1;

				ChangeX = TRUE;
			}
			else if ( !wcsncmp( arg[i], L"/Y", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				if ( ParseIntExpression( arg[i] + j, &NewY ) )
					return 1;

				ChangeY = TRUE;
			}
			else {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Syntax error: \"%s\"\r\n", arg[i] );
				return 1;
			}

		}
	}



	if ( ChangeX || ChangeY ) {
		if ( !SetCursorPos( NewX, NewY ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Error on SetCursorPos()\r\n" );
			return 2;
		}
	}

	if ( !Quiet ) {
		if ( ChangeX || ChangeY )
			Printf( L"Mouse pointer moved to %d, %d.\r\n", NewX, NewY );
		else
			Printf( L"Mouse pointer is at %d, %d.\r\n", NewX, NewY );
	}

	return 0;
}


DLLExports int WINAPI _mousex( LPTSTR outString )
{
	if ( !outString )
		return -1;


	POINT MouseNow		= { 0, 0 };


	GetCursorPos( &MouseNow );
	wsprintf( outString, L"%d", MouseNow.x );
	return 0;
}


DLLExports int WINAPI _mousey( LPTSTR outString )
{
	if ( !outString )
		return -1;


	POINT MouseNow		= { 0, 0 };


	GetCursorPos( &MouseNow );
	wsprintf( outString, L"%d", MouseNow.y );
	return 0;
}



struct _CwbcArgs {
	LPTSTR Class;
	int Count;
};


BOOL CALLBACK _CloseWinByClass( HWND hWnd, LPARAM Args )
{
	wchar_t Class[SHORT_BUF_LEN]		= L"";
	_CwbcArgs *args						= (_CwbcArgs*) Args;


	RealGetWindowClass( hWnd, Class, SHORT_BUF_LEN );

	if ( wcscmp( Class, args->Class ) )
		return TRUE;

	SendMessage( hWnd, WM_CLOSE, 0, NULL );
	args->Count += 1;
	return TRUE;
}


int CloseWindowsByClass( LPTSTR Class )
{
	if ( !Class )
		return -1;
	else if ( Class[0] == '\0' )
		return -1;


	_CwbcArgs Args;
	Args.Class		= Class;
	Args.Count		= 0;


	EnumWindows( _CloseWinByClass, (LPARAM) &Args );

	return Args.Count;
}


HWND FindWindowByTwoClasses( LPTSTR Class1, LPTSTR Class2 )
{
	if ( !Class1 || !Class2 )
		return NULL;
	else if ( ( Class1[0] == '\0' ) || ( Class2[0] == '\0' ) )
		return NULL;


	HWND rv = FindWindow( Class1, NULL );

	if ( rv == NULL )
		rv = FindWindow( Class2, NULL );


	return rv;
}


/*
DLLExports int WINAPI settheme( LPTSTR inString )
{
	if ( !inString )
		return -1;


	wchar_t Filename[MAX_FILENAME_LEN]		= L"";
	unsigned int Seconds					= 8;
	BOOL Quiet								= FALSE;
	BOOL Debug								= FALSE;

	LPTSTR Ext								= NULL;
	HWND hWnd								= NULL;
	HWND FgWindow							= NULL;
	unsigned int Count						= 0;
	BOOL Found								= FALSE;
	
	wchar_t WinClass1[]						= L"CabinetWClass";
	wchar_t WinClass2[]						= L"ApplicationFrameWindow";


	ParseArgs( inString, PARSE_BREAK_SPACES | PARSE_SLASHES_KLUDGE );


	for ( int i = 0; i < numargs; i++ ) {
		if ( arglen[i] ) {
			if ( !wcsncmp( arg[i], L"/?", 2 ) )
				return ShowCmdHelp( SetThemeHelpText, ( arg[i][2] == '?' ) );
			else if ( !_wcsicmp( arg[i], L"/Q" ) )
				Quiet = TRUE;
			else if ( !_wcsicmp( arg[i], L"/$" ) )
				Debug = TRUE;
			else if ( !_wcsnicmp( arg[i], L"/T", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				if ( ParseInt( arg[i] + j, &Seconds, NULL ) ) {
					_wcsupr_s( arg[i], MAX_ARG_LEN );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad time: \"%s\"\r\n", arg[i] );
					return 1;
				}

				if ( ( Seconds < 1 ) || ( Seconds > 30 ) ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Time must be 1 - 30: %u\r\n", Seconds );
					return 1;
				}
			}
			else if ( arg[i][0] == '/' ) {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Unknown option: \"%s\"\r\n", arg[i] );
				return 1;
			}
			else if ( Filename[0] == '\0' )
				QueryTrueName( arg[i], Filename );
			else {
				_wcsupr_s( arg[i], MAX_ARG_LEN );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Syntax error: \"%s\"\r\n", arg[i] );
				return 1;
			}
		}
	}


	if ( Filename[0] == '\0' ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Missing filename\r\n" );
		return 1;
	}


	if ( _ExtensionPart( Filename, NULL ) == NULL )
		wcscat_s( Filename, MAX_FILENAME_LEN, L".theme" );

	Ext = _ExtensionPart( Filename, NULL );

	if ( Ext )
		if ( _wcsicmp( Ext, L".theme" ) )
			Ext = NULL;

	if ( !Ext ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Extension must be .THEME: \"%s\"\r\n", Filename );
		return 1;
	}
	
	if ( !IsAFile( Filename ) ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"File not found: \"%s\"\r\n", Filename );
		return 2;
	}


	FgWindow = GetForegroundWindow();

	if ( Debug )
		_cputws( L"  *  Close any open Themes windows:\r\n" );


	do {
		hWnd = FindWindowByTwoClasses( WinClass1, WinClass2 );

		if ( hWnd ) {
			SendMessage( hWnd, WM_CLOSE, 0, NULL );
			Found = TRUE;
		}

	} while ( hWnd );

	if ( Found )
		Sleep( 200 );


	if ( Debug )
		_cputws( L"  *  Call ShellExecute() :\r\n" );

	ShellExecute( FgWindow, NULL, Filename, NULL, NULL, SW_MINIMIZE );

	do {
		hWnd = FindWindowByTwoClasses( WinClass1, WinClass2 );
		Count++;

		if ( !hWnd )
			Sleep( 10 );
	}
	while ( !hWnd && ( Count < ( Seconds * 100 ) ) );

	if ( !hWnd ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Personalization window not opening\r\n" );
		return 2;
	}


	if ( Debug )
		_cputws( L"  *  Move Themes window offscreen:\r\n" );

	MoveWindow( hWnd, -32000, -32000, 1200, 1000, FALSE );
	Sleep( 25 );
	MoveWindow( hWnd, -32000, -32000, 1200, 1000, FALSE );
	Sleep( 50 );
	MoveWindow( hWnd, -32000, -32000, 1200, 1000, FALSE );
	Sleep( 50 );
	MoveWindow( hWnd, -32000, -32000, 1200, 1000, FALSE );



	if ( !Quiet )
		_cputws( L"Wait: " );

	Sleep( 5000 );

	SendMessage( hWnd, WM_CLOSE, 0, NULL );

	if ( !Quiet )
		_cputws( L"\r      \r" );
	
	ForceForegroundWindow( FgWindow );
	return 0;
}
*/



LPTSTR FontTypeStr( DWORD FontType )
{
	if ( FontType & TRUETYPE_FONTTYPE )
		return (LPTSTR) _FontTypeStr[3];
	else if ( FontType & DEVICE_FONTTYPE )
		return (LPTSTR) _FontTypeStr[2];
	else if ( FontType & RASTER_FONTTYPE )
		return (LPTSTR) _FontTypeStr[1];
	else
		return (LPTSTR) _FontTypeStr[0];
}


int CALLBACK ListFontsProc( const LOGFONT *LogFont, const TEXTMETRIC *TextMetric, DWORD FontType, LPARAM lParam )
{
	ENUMLOGFONTEX *LogFontEx = (ENUMLOGFONTEX*) LogFont;
	_FindFontInfo *FindFont = (_FindFontInfo*) lParam;


	if ( FindFont->WildSpec )
		if ( WildcardComparison( FindFont->WildSpec, (LPTSTR) LogFontEx->elfFullName, 0, 1 ) )
			return 1;

	if ( FindFont->ReqFontType ) {
		DWORD Type = FontType;
		if ( ( Type & ( RASTER_FONTTYPE | DEVICE_FONTTYPE | TRUETYPE_FONTTYPE ) ) == 0 )
			Type |= FFT_VECTOR;

		if ( Type & ( ~(FindFont->ReqFontType) ) )
			return 1;
	}

	if ( FindFont->ReqPitchAndFamily & 0x0003 ) {
		if ( ( LogFont->lfPitchAndFamily & 0x0003 ) != ( FindFont->ReqPitchAndFamily & 0x0003 ) )
			return 1;
	}

	if ( FindFont->ReqPitchAndFamily & 0xfffc ) {
		BYTE Family = ( LogFont->lfPitchAndFamily & 0xf0 );
		if ( !Family )
			Family = FFT_NO_FAMILY;

		if ( Family != ( FindFont->ReqPitchAndFamily & 0xf0 ) )
			return 1;
	}

	(FindFont->Index)++;
	if ( ( FindFont->Flags ) & FFT_SHOW_LINE_NOS )
		Printf( L"%4u: ", FindFont->Index );

	Printf( L"%-40s", LogFontEx->elfFullName );

	if ( ( FindFont->Flags ) & FFT_SHOW_TYPES )
		Printf( L"  %s", FontTypeStr( FontType ) );

	if ( ( FindFont->Flags ) & FFT_SHOW_PAF ) {
		switch ( ( LogFont->lfPitchAndFamily ) & 0x00f0 ) {
		case FF_ROMAN :
			QPuts( L"  R" );
			break;

		case FF_SWISS :
			QPuts( L"  S" );
			break;

		case FF_MODERN :
			QPuts( L"  M" );
			break;

		case FF_SCRIPT :
			QPuts( L"  H" );
			break;

		case FF_DECORATIVE :
			QPuts( L"  D" );
			break;

		default :
			QPuts( L"  N" );
		}

		if ( ( LogFont->lfPitchAndFamily ) & FIXED_PITCH )
			QPuts( L"F" );
		else if ( ( LogFont->lfPitchAndFamily ) & VARIABLE_PITCH )
			QPuts( L"V" );
		else
			QPuts( L"-" );
	}

	if ( ( FindFont->Flags ) & FFT_SHOW_SCRIPTS )
		Printf( L"  %s", LogFontEx->elfScript );

	CrLf();

	return 1;
}


DLLExports int WINAPI listfonts( LPTSTR inString )
{
	if ( !inString )
		return -1;


	_FindFontInfo FindFont;
	LOGFONT LogFont;
	HDC MyContext					= NULL;

	LPTSTR WildSpec					= NULL;
	unsigned int CharSet			= ANSI_CHARSET;
	DWORD ReqFontType				= 0;
	unsigned int ReqPitchAndFamily	= 0;
	DWORD Flags						= 0;
	BOOL ShowCount					= FALSE;


	ParseArgs( inString, PARSE_BREAK_SPACES | PARSE_SLASHES_KLUDGE | PARSE_FORCE_UPPERCASE );


	for ( int i = 0; i < numargs; i++ ) {
		if ( arglen[i] ) {
			if ( !wcsncmp( arg[i], L"/?", 2 ) )
				return ShowCmdHelp( ListFontsHelpText, ( arg[i][2] == '?' ) );
			else if ( !_wcsnicmp( arg[i], L"/C", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				if ( ParseInt( arg[i] + j, &CharSet, NULL ) ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad charset value: \"%s\"\r\n", arg[i] );
					return 1;
				}

				if ( CharSet > 255 ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Charset must be 0 - 255: %u\r\n", CharSet );
					return 1;
				}
			}
			else if ( !_wcsnicmp( arg[i], L"/D", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				while ( arg[i][j] ) {
					switch( towupper( arg[i][j] ) ) {
					case 'L' :
						Flags |= FFT_SHOW_LINE_NOS;
						break;

					case 'F' :
						Flags |= FFT_SHOW_PAF;
						break;

					case 'S' :
						Flags |= FFT_SHOW_SCRIPTS;
						break;

					case 'T' :
						Flags |= FFT_SHOW_TYPES;
						break;

					case 'K' :
						ShowCount = TRUE;
						break;
					}

					j++;
				}
			}
			else if ( !_wcsnicmp( arg[i], L"/F", 2 )) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				switch ( towupper( arg[i][j] ) ) {
				case 'R' :
					ReqPitchAndFamily = ( ReqPitchAndFamily & 0xff0f ) | FF_ROMAN;
					break;

				case 'S' :
					ReqPitchAndFamily = ( ReqPitchAndFamily & 0xff0f ) | FF_SWISS;
					break;

				case 'M' :
					ReqPitchAndFamily = ( ReqPitchAndFamily & 0xff0f ) | FF_MODERN;
					break;

				case 'H' :
					ReqPitchAndFamily = ( ReqPitchAndFamily & 0xff0f ) | FF_SCRIPT;
					break;

				case 'D' :
					ReqPitchAndFamily = ( ReqPitchAndFamily & 0xff0f ) | FF_DECORATIVE;
					break;

				case 'N' :
					ReqPitchAndFamily = ( ReqPitchAndFamily & 0xff0f ) | FFT_NO_FAMILY;
					break;

				default :
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad font family: \"%s\"\r\n", arg[i] );
					return 1;					
				}
			}
			else if ( !_wcsnicmp( arg[i], L"/P", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				switch ( towupper( arg[i][j] ) ) {
				case 'F' :
					ReqPitchAndFamily = ( ReqPitchAndFamily & 0xfff0 ) | FIXED_PITCH;
					break;

				case 'V' :
					ReqPitchAndFamily = ( ReqPitchAndFamily & 0xfff0 ) | VARIABLE_PITCH;
					break;

				default :
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Bad pitch: \"%s\"\r\n", arg[i] );
					return 1;
				}
			}
			else if ( !_wcsnicmp( arg[i], L"/T", 2 ) ) {
				int j = 2;
				if ( IsColonOrEquals( arg[i][j] ) )
					j++;

				ReqFontType = 0;

				while ( arg[i][j] ) {
					switch ( towupper( arg[i][j] ) ) {
					case 'R' :
						ReqFontType |= RASTER_FONTTYPE;
						break;

					case 'V' :
						ReqFontType |= FFT_VECTOR;
						break;

					case 'O' :
						ReqFontType |= DEVICE_FONTTYPE;
						break;

					case 'T' :
						ReqFontType |= TRUETYPE_FONTTYPE;
						break;

					default :
						DisplayErrorHeader();
						Qprintf( ERRHANDLE, L"Unknown font type: '%c'\r\n", towupper( arg[i][j] ) );
						return 1;
					}

					j++;
				}

				if ( !ReqFontType ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Missing font type: \"%s\"\r\n", arg[i] );
					return 1;
				}
			}
			else if ( arg[i][0] == '/' ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Unknown option: \"%s\"\r\n", arg[i] );
				return 1;
			}
			else if ( !WildSpec )
				WildSpec = arg[i];
			else {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Syntax error: \"%s\"\r\n", arg[i] );
				return 1;
			}
		}
	}


	memset( &FindFont, 0x00, sizeof( _FindFontInfo ) );
	FindFont.WildSpec = WildSpec;
	FindFont.ReqFontType = ReqFontType;
	FindFont.ReqPitchAndFamily = ReqPitchAndFamily;
	FindFont.Flags = Flags;

	memset( &LogFont, 0x00, sizeof( LOGFONT ) );
	LogFont.lfCharSet	= (BYTE) CharSet;


	MyContext = GetDC( NULL );

	if ( !MyContext )
		return 2;

	EnumFontFamiliesEx( MyContext, &LogFont, ListFontsProc, (LPARAM) &FindFont, 0 );
	ReleaseDC( NULL, MyContext );

	if ( ShowCount ) {
		if ( FindFont.Index > 1 )
			Printf( L"\r\n%u matching fonts found.\r\n", FindFont.Index );
		else if ( FindFont.Index )
			Printf( L"\r\n%u matching font found.\r\n", FindFont.Index );
		else
			Printf( L"\r\nNo matching fonts found.\r\n" );
	}

	return 0;
}



int CALLBACK StashFontsProc( const LOGFONT *LogFont, const TEXTMETRIC *TextMetric, DWORD FontType, LPARAM lParam )
{
	ENUMLOGFONTEX *LogFontEx = (ENUMLOGFONTEX*) LogFont;
	_FindFontInfo *FindFont = (_FindFontInfo*) lParam;

	_FontListItem *NewItem = NULL;


	if ( FindFont->WildSpec )
		if ( WildcardComparison( FindFont->WildSpec, (LPTSTR) LogFontEx->elfFullName, 0, 1 ) )
			return 1;

	if ( FindFont->ReqFontType ) {
		DWORD Type = FontType;
		if ( ( Type & ( RASTER_FONTTYPE | DEVICE_FONTTYPE | TRUETYPE_FONTTYPE ) ) == 0 )
			Type |= FFT_VECTOR;

		if ( Type & ( ~(FindFont->ReqFontType) ) )
			return 1;
	}

	if ( FindFont->ReqPitchAndFamily & 0x0003 ) {
		if ( ( LogFont->lfPitchAndFamily & 0x0003 ) != ( FindFont->ReqPitchAndFamily & 0x0003 ) )
			return 1;
	}

	if ( FindFont->ReqPitchAndFamily & 0xfffc ) {
		BYTE Family = ( LogFont->lfPitchAndFamily & 0xf0 );
		if ( !Family )
			Family = FFT_NO_FAMILY;

		if ( Family != ( FindFont->ReqPitchAndFamily & 0xf0 ) )
			return 1;
	}


	NewItem = (_FontListItem*) malloc( sizeof( _FontListItem ) + ( wcslen( LogFontEx->elfFullName ) * sizeof( wchar_t ) ) );
	if ( !NewItem )
		return 1;

	NewItem->Next = NULL;
	wcscpy_s( NewItem->Name, wcslen( LogFontEx->elfFullName ) + 1, LogFontEx->elfFullName );

	if ( FirstFont ) {
		LastFont->Next = NewItem;
		LastFont = NewItem;
	}
	else
		FirstFont = LastFont = NewItem;

	//	wprintf( L"   * Stashed item '%s'\n", LogFontEx->elfFullName );

	return 1;
}


DLLExports int WINAPI f_firstfont( LPTSTR String )
{
	if ( !String )
		return -1;


	_FindFontInfo FindFont;
	LOGFONT LogFont;
	HDC MyContext					= NULL;

	LPTSTR WildSpec					= NULL;
	unsigned int CharSet			= ANSI_CHARSET;
	DWORD ReqFontType				= 0;
	unsigned int ReqPitchAndFamily	= 0;
	DWORD Flags						= 0;

	_FontListItem *NextFont		= NULL;


	ParseArgs( String, PARSE_BREAK_COMMAS | PARSE_FORCE_UPPERCASE );


	if ( arglen[0] )
		WildSpec = arg[0];

	if ( arglen[1] ) {
		if ( ParseInt( arg[1], &CharSet, NULL ) ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Bad charset value: \"%s\"\r\n", arg[1] );
			return -1;
		}

		if ( CharSet > 255 ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Charset must be 0 - 255: %u\r\n", CharSet );
			return -1;
		}
	}

	if ( arglen[2] ) {
		int j = 0;
		while ( arg[2][j] ) {
			switch( towupper( arg[2][j] ) ) {
			case 'R' :
				ReqFontType |= RASTER_FONTTYPE;
				break;

			case 'V' :
				ReqFontType |= FFT_VECTOR;
				break;

			case 'O' :
				ReqFontType |= DEVICE_FONTTYPE;
				break;

			case 'T' :
				ReqFontType |= TRUETYPE_FONTTYPE;
				break;

			default :
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Unknown font type: %c\r\n", arg[2][j] );
				return -1;
			}

			j++;			
		}
	}

	if ( arglen[3] ) {
		wchar_t *ch = arg[3];

		while ( *ch ) {
			switch ( towupper( *ch ) ) {
			case 'R' :
				ReqPitchAndFamily = ( ReqPitchAndFamily & 0xff0f ) | FF_ROMAN;
				break;

			case 'S' :
				ReqPitchAndFamily = ( ReqPitchAndFamily & 0xff0f ) | FF_SWISS;
				break;

			case 'M' :
				ReqPitchAndFamily = ( ReqPitchAndFamily & 0xff0f ) | FF_MODERN;
				break;

			case 'H' :
				ReqPitchAndFamily = ( ReqPitchAndFamily & 0xff0f ) | FF_SCRIPT;
				break;

			case 'D' :
				ReqPitchAndFamily = ( ReqPitchAndFamily & 0xff0f ) | FF_DECORATIVE;
				break;

			case 'N' :
				ReqPitchAndFamily = ( ReqPitchAndFamily & 0xff0f ) | FFT_NO_FAMILY;
				break;

			case 'F' :
				ReqPitchAndFamily = ( ReqPitchAndFamily & 0xfff0 ) | FIXED_PITCH;
				break;

			case 'V' :
				ReqPitchAndFamily = ( ReqPitchAndFamily & 0xfff0 ) | VARIABLE_PITCH;
				break;

			default :
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad pitch/family flag: '%c'\r\n", toupper( *ch ) );
				return 1;
			}

			ch++;
		}
	}


	FreeLinkedList( (void**) &FirstFont );
	LastFont = NULL;
	String[0] = 0x00;

	memset( &FindFont, 0x00, sizeof( _FindFontInfo ) );
	FindFont.WildSpec = WildSpec;
	FindFont.ReqFontType = ReqFontType;
	FindFont.ReqPitchAndFamily = ReqPitchAndFamily;

	memset( &LogFont, 0x00, sizeof( LOGFONT ) );
	LogFont.lfCharSet = (BYTE) CharSet;


	MyContext = GetDC( NULL );

	if ( !MyContext )
		return -1;

	EnumFontFamiliesEx( MyContext, &LogFont, StashFontsProc, (LPARAM) &FindFont, 0 );
	ReleaseDC( NULL, MyContext );
	LastFont = NULL;

	if ( FirstFont ) {
		wcscpy_s( String, MAX_ARG_LEN, FirstFont->Name );
		NextFont = FirstFont->Next;
		free( FirstFont );
		FirstFont = NextFont;
	}

	return 0;
}



DLLExports int WINAPI f_nextfont( LPTSTR String )
{
	if ( !String )
		return -1;


	_FontListItem *NextFont		= NULL;


	String[0] = 0x00;

	if ( FirstFont ) {
		wcscpy_s( String, MAX_ARG_LEN, FirstFont->Name );
		NextFont = FirstFont->Next;
		free( FirstFont );
		FirstFont = NextFont;
	}

	return 0;
}



int InstallFontFile( LPTSTR Filename, LPTSTR FontsDir, BOOL Overwrite, BOOL Delete )
{
	if ( !Filename || !FontsDir )
		return -1;


	wchar_t Path[MAX_FILENAME_LEN]			= L"";
	wchar_t TargetName[MAX_FILENAME_LEN]	= L"";
	wchar_t FontName[SHORT_BUF_LEN]			= L"";
	wchar_t ErrorText[SHORT_BUF_LEN]		= L"";

	LPTSTR NamePart					= _FilenamePart( Filename, NULL );
	BOOL AlreadyThere				= FALSE;
	DWORD BufSize					= 0;
	wchar_t *ext					= NULL;

	const wchar_t FontsKeyName[]	= L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Fonts";
	HKEY FontsKey					= NULL;

	int erv							= 0;
	int rv							= 0;


	_PathPart( Filename, Path );
	AppendFilename( Path, L"", MAX_FILENAME_LEN );

	wcscpy_s( TargetName, FontsDir );
	AppendFilename( TargetName, NamePart, MAX_FILENAME_LEN );


	if ( !_wcsicmp( Path, FontsDir ) ) {
		AlreadyThere = TRUE;
		Delete = FALSE;
	}
	else if ( !Overwrite && IsAFile( TargetName ) ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"File exists: \"%s\"\r\n", TargetName );
		return 0;
	}

	if ( !AlreadyThere ) {
		if ( !CopyFile( Filename, TargetName, !Overwrite ) ) {
			GetErrorText( GetLastError(), ErrorText );
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Error copying file \"%s\" to \"%s\" :\r\n", Filename, FontsDir );
			Qprintf( ERRHANDLE, L"   %s\r\n", ErrorText );
			return 0;
		}
	}

	if ( !AddFontResource( TargetName ) ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Error installing file \"%s\"\r\n", TargetName );

		if ( !AlreadyThere )
			DeleteFile( TargetName );

		return 0;
	}

	SendMessage( HWND_BROADCAST, WM_FONTCHANGE, 0, 0 );


	if ( GetFontResourceInfo ) {
		BufSize = SHORT_BUF_LEN;
		GetFontResourceInfo( TargetName, &BufSize, FontName, 1 );
	}

	if ( FontName[0] == '\0' ) {
		wcscpy_s( FontName, NamePart );
		wchar_t *ch = wcschr( FontName, '.' );
		if ( ch )
			if ( ch > FontName )
				*ch = '\0';
	}

	ext = wcsrchr( Filename, '.' );
	if ( ext ) {
		if ( !_wcsicmp( ext, L".ttf" ) )
			wcscat_s( FontName, SHORT_BUF_LEN, L" (TrueType)" );
		else if ( !_wcsicmp( ext, L".otf" ) )
			wcscat_s( FontName, SHORT_BUF_LEN, L" (OpenType)" );
	}


	if ( erv = RegOpenKeyEx( HKEY_LOCAL_MACHINE, FontsKeyName, 0, KEY_READ | KEY_WRITE, &FontsKey ) ) {
		GetErrorText( erv, ErrorText );
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"Error opening fonts registry key \"%s\" :\r\n", FontsKeyName );
		Qprintf( ERRHANDLE, L"   %s\r\n", ErrorText );
	}
	else {
		if ( erv = RegSetValueEx( FontsKey, FontName, 0, REG_SZ, (BYTE*) NamePart, (DWORD) ( sizeof( wchar_t ) * ( wcslen( TargetName ) + 1 ) ) ) ) {
			GetErrorText( erv, ErrorText );
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Error writing value \"%s\\%s\" :\r\n", FontsKeyName, FontName );
			Qprintf( ERRHANDLE, L"   %s\r\n", ErrorText );
		}
		else {
			rv = 1;
			Printf( L"%-35s \u2192 %s\r\n", FontName, TargetName );

			if ( Delete ) {
				if ( !DeleteFile( Filename ) ) {
					GetErrorText( GetLastError(), ErrorText );
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"Error deleting file \"%s\" :\r\n", Filename );
					Qprintf( ERRHANDLE, L"   %s\r\n", ErrorText );
				}
			}
		}

		RegCloseKey( FontsKey );
	}
	
	return rv;
}



BOOL IsFontFile( LPTSTR Filename )
{
	if ( !Filename )
		return FALSE;


	LPTSTR Ext		= wcsrchr( Filename, '.' );


	if ( !Ext )
		return FALSE;

	for ( int i = 0; i < NUM_FONT_EXTENSIONS; i++ )
		if ( !_wcsicmp( Ext, FontExtension[i] ) )
			return TRUE;

	return FALSE;
}



DLLExports int WINAPI installfonts( LPTSTR inString )
{
	if ( !inString )
		return -1;


	wchar_t FontsDir[MAX_FILENAME_LEN]		= L"";
	wchar_t Filespec[MAX_FILENAME_LEN]		= L"";
	wchar_t Path[MAX_FILENAME_LEN]			= L"";
	wchar_t WildPart[MAX_FILENAME_LEN]		= L"";
	wchar_t SearchSpec[MAX_FILENAME_LEN]	= L"";
	wchar_t FoundFullName[MAX_FILENAME_LEN]	= L"";

	BOOL Overwrite			= FALSE;
	BOOL Delete				= FALSE;
	int AnyNames			= 0;

	HANDLE SearchHandle		= NULL;
	WIN32_FIND_DATA Found;

	int FoundInDir			= 0;
	int InstalledFromDir	= 0;
	int DeletedFromDir		= 0;
	int FoundTotal			= 0;
	int InstalledTotal		= 0;
	int DeletedTotal		= 0;

	int rv					= 0;


	ParseArgs( inString, PARSE_BREAK_SPACES | PARSE_SLASHES_KLUDGE );


	for ( int i = 0; i < numargs; i++ ) {
		if ( !wcsncmp( arg[i], L"/?", 2 ) )
			return ShowCmdHelp( InstallFontsHelpText, ( arg[i][2] == '?' ) );
		else if ( !_wcsicmp( arg[i], L"/O" ) )
			Overwrite = TRUE;
		else if ( !_wcsicmp( arg[i], L"/X" ) )
			Delete = TRUE;
		else if ( arg[i][0] == '/' ) {
			_wcsupr_s( arg[i], MAX_ARG_LEN );
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"Unknown option: \"%s\"\r\n", arg[i] );
			return 1;
		}
		else
			AnyNames++;
	}


	if ( !AnyNames ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"No filename specified!\r\n" );
		return 1;
	}


	if ( !RunningElevated() ) {
		DisplayErrorHeader();
		Qprintf( ERRHANDLE, L"This command requires elevation.\r\n" );
		return 2;
	}


	SHGetFolderPath( NULL, CSIDL_FONTS, NULL, 0, FontsDir );
	AppendFilename( FontsDir, L"", MAX_FILENAME_LEN );


	for ( int i = 0; i < numargs; i++ ) {
		if ( arg[i][0] != '/' ) {
			Filespec[0] = '\0';
			QueryTrueName( arg[i], Filespec );

			if ( Filespec[0] ) {
				Path[0]		= '\0';
				WildPart[0]	= '\0';

				_PathPart( Filespec, Path );
				if ( Path[0] == '\0' )
					GetCurrentDirectory( MAX_FILENAME_LEN, Path );

				_FilenamePart( Filespec, WildPart );
				if ( WildPart[0] == '\0' )
					wcscpy_s( WildPart, MAX_FILENAME_LEN, L"*" );

				wcscpy_s( SearchSpec, MAX_FILENAME_LEN, Path );
				AppendFilename( SearchSpec, L"*", MAX_FILENAME_LEN );

				FoundInDir			= 0;
				InstalledFromDir	= 0;
				DeletedFromDir		= 0;

				SearchHandle = FindFirstFile( SearchSpec, &Found );
				if ( SearchHandle == INVALID_HANDLE_VALUE ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"No matching files found: \"%s\"\r\n", Filespec );
					rv = 2;
					continue;
				}


				do {
					if ( Found.dwFileAttributes & ( FILE_ATTRIBUTE_DIRECTORY | FILE_ATTRIBUTE_DEVICE | FILE_ATTRIBUTE_REPARSE_POINT ) )
						continue;

					if ( WildcardComparison( WildPart, Found.cFileName, 1, 1 ) )
						continue;

					if ( !wcscmp( WildPart, L"*" ) )
						if ( !IsFontFile( Found.cFileName ) )
							continue;

					wcscpy_s( FoundFullName, MAX_FILENAME_LEN, Path );
					AppendFilename( FoundFullName, Found.cFileName, MAX_FILENAME_LEN );
					FoundInDir++;
					FoundTotal++;


					if ( InstallFontFile( FoundFullName, FontsDir, Overwrite, Delete ) > 0 ) {
						InstalledFromDir++;
						InstalledTotal++;

						if ( Delete ) {
							if ( !IsAFile( FoundFullName ) ) {
								DeletedFromDir++;
								DeletedTotal++;
							}
						}
					}
					else
						rv = 2;
				}
				while ( FindNextFile( SearchHandle, &Found ) );

				FindClose( SearchHandle );
				SearchHandle = NULL;

				if ( !FoundInDir ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"No matching files found: \"%s\"\r\n", Filespec );
					rv = 2;
				}
			}
			else {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Bad filespec: \"%s\"\r\n", arg[i] );
				if ( !rv )
					rv = 1;
			}
		}
	}


	if ( InstalledTotal ) {
		if ( Delete )
			Printf( L"\nInstalled %u font file%s; deleted %u.\r\n", InstalledTotal, ( InstalledTotal == 1 ) ? L"" : L"s", DeletedTotal );
		else
			Printf( L"\nInstalled %u font file%s.\r\n", InstalledTotal, ( InstalledTotal == 1 ) ? L"" : L"s" );
	}

	return rv;
}



DLLExports int WINAPI _winosver( LPTSTR outString )
{
	if ( !outString )
		return 1;


	wsprintf( outString, L"%u.%u.%u", OSVerInfo.dwMajorVersion, OSVerInfo.dwMinorVersion, OSVerInfo.dwBuildNumber );
	return 0;
}



const int NumHelpTexts			= 13;

const wchar_t HelpFeature[NumHelpTexts][12]		= { L"bgcolor", L"conicon", L"listfonts", L"minimizeall", L"mksc",
		L"screenres", L"scrnsaver", L"setfocus", L"setmousepos", L"shellverb", L"soundvol",
		L"uistuffhelp", L"wallpaper" };

const wchar_t *HelpText[NumHelpTexts]			= { BGColorHelpText, ConIconHelpText, ListFontsHelpText, MinimizeAllHelpText, MkScHelpText,
		ScreenResHelpText, ScrnSaverHelpText, SetFocusHelpText, SetMousePosHelpText, ShellVerbHelpText, SoundVolHelpText,
		UIStuffHelpHelpText, WallpaperHelpText };



DLLExports int WINAPI uistuffhelp( LPTSTR inString )
{
	return PluginHelpCmd( inString, UIStuffHelpHelpText );
}




DLLExports int WINAPI Usage( LPTSTR inString, LPTSTR outString )
{
	if ( ( inString[0] == '@' ) || ( inString[0] == '_' ) )
		return 0;

	for ( int i = 0; i < NumHelpTexts; i++ ) {
		if ( !_wcsicmp( inString, HelpFeature[i] ) ) {
			wcscpy_s( outString, SHORT_BUF_LEN, UsageText( HelpText[i] ) );
			return 1;
		}
	}

	return 0;
}

