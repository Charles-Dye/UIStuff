
//		Call the HTML help system.
//
//		It appears that recent IE updates have thoroughly broken the documented
//		HtmlHelp() API.  Thanks, Microsoft!


#ifndef NEWHELP_VERSION
#define NEWHELP_VERSION			1.0.8.10


#ifndef NEWHELP_EXCLUDE
#define NEWHELP_EXCLUDE			NULL
#endif

#ifndef NEWHELP_ALIASES
#define NEWHELP_ALIASES			NULL
#endif


#ifndef MACRO_STR
#define MACRO_EXP( arg )		#arg
#define MACRO_STR( arg )		MACRO_EXP( arg )
#endif

#define TCM_SETCURFOCUS$		0x1330



HANDLE NH_HelpViewerHandle		= NULL;




BOOL NH_IsAFile( LPCTSTR Filename )
{
	if ( !Filename )
		return FALSE;
	else if ( Filename[0] == '\0' )
		return FALSE;


	DWORD attr		= GetFileAttributes( Filename );


	if ( attr == INVALID_FILE_ATTRIBUTES )
		return FALSE;

	if ( attr & ( FILE_ATTRIBUTE_DIRECTORY | FILE_ATTRIBUTE_DEVICE ) )
		return FALSE;

	return TRUE;
}



int CloseHelpWindow()
{
	wchar_t shortbuf[SHORT_BUF_LEN]		= L"";

	if ( NH_HelpViewerHandle )
		TerminateProcess( NH_HelpViewerHandle, 0 );

	NH_HelpViewerHandle = NULL;
	return 0;
}



struct _FindHelpWindowData {
	DWORD Pid;
	HWND WindowHandle;
};


BOOL CALLBACK FindHelpWindowProc$( HWND hWnd, LPARAM lParam )
{
	_FindHelpWindowData *Args	= (_FindHelpWindowData*) lParam;
	DWORD Pid					= 0;

	wchar_t ClassName[SHORT_BUF_LEN]	= L"";


	GetWindowThreadProcessId( hWnd, &Pid );
	if ( Pid != Args->Pid )
		return TRUE;

	GetClassName( hWnd, ClassName, SHORT_BUF_LEN );
	if ( wcscmp( ClassName, L"HH Parent" ) )
		return TRUE;

	Args->WindowHandle = hWnd;
	return FALSE;
}


BOOL CALLBACK FindHelpTabCtrlProc$( HWND hWnd, LPARAM lParam )
{
	HWND *TabControl		= (HWND*) lParam;


	wchar_t ClassName[SHORT_BUF_LEN]		= L"";


	GetClassName( hWnd, ClassName, SHORT_BUF_LEN );

	if ( wcscmp( ClassName, L"SysTabControl32" ) )
		return TRUE;

	*TabControl = hWnd;
	return FALSE;
}


BOOL CALLBACK FindHelpComboBoxProc$( HWND hWnd, LPARAM lParam )
{
	HWND *ComboBox			= (HWND*) lParam;


	wchar_t ClassName[SHORT_BUF_LEN]		= L"";


	if ( GetDlgCtrlID( hWnd ) != 1001 )
		return TRUE;

	GetClassName( hWnd, ClassName, SHORT_BUF_LEN );

	if ( wcscmp( ClassName, L"ComboBox" ) )
		return TRUE;

	*ComboBox = hWnd;
	return FALSE;
}


BOOL CALLBACK FindHelpSearchButtonProc$( HWND hWnd, LPARAM lParam )
{
	HWND *SearchButton		= (HWND*) lParam;


	wchar_t ClassName[SHORT_BUF_LEN]		= L"";


	if ( GetDlgCtrlID( hWnd ) != 1006 )
		return TRUE;

	GetClassName( hWnd, ClassName, SHORT_BUF_LEN );

	if ( wcscmp( ClassName, L"Button" ) )
		return TRUE;

	*SearchButton = hWnd;
	return FALSE;
}


int SelectHelpTab( DWORD Pid, HANDLE ProcessHandle, unsigned int n, LPCTSTR SearchText )
{
	if ( !Pid )
		return 0;


	_FindHelpWindowData FindData;

	HWND TabControl				= NULL;
	HWND ComboBox				= NULL;
	HWND SearchButton			= NULL;


	FindData.Pid				= Pid;
	FindData.WindowHandle		= NULL;

	int rv						= 0;


	if ( WaitForInputIdle( ProcessHandle, 8000 ) == WAIT_TIMEOUT )
		return WAIT_TIMEOUT;

	EnumWindows( FindHelpWindowProc$, (LPARAM) &FindData );
	if ( FindData.WindowHandle == NULL )
		return ERROR_FILE_NOT_FOUND;

	//	wprintf( L"   * WindowHandle = 0x%08X\n", FindData.WindowHandle );

	EnumChildWindows( FindData.WindowHandle, FindHelpTabCtrlProc$, (LPARAM) &TabControl );
	//	wprintf( L"   * TabControl = 0x%08X\n", TabControl );


	if ( TabControl )
		PostMessage( TabControl, TCM_SETCURFOCUS$, n, 0 );
	else
		rv = ERROR_FILE_NOT_FOUND;


	if ( SearchText && ( n == 1 ) ) {
		//	wprintf( L"   * SearchText = '%s'\n", SearchText );

		for ( int i = 50; i; i-- ) {
			EnumChildWindows( FindData.WindowHandle, FindHelpComboBoxProc$, (LPARAM) &ComboBox );
			EnumChildWindows( FindData.WindowHandle, FindHelpSearchButtonProc$, (LPARAM) &SearchButton );
			//	wprintf( L"   * i = %d   ComboBox = 0x%04X   SearchButton = 0x%04X\n", i, ComboBox, SearchButton );

			if ( ComboBox && SearchButton )
				break;

			Sleep( 20 );
		}

		if ( ComboBox && SearchButton ) {
			SendMessage( ComboBox, WM_SETTEXT, NULL, (LPARAM) SearchText );
			Sleep( 20 );
			SendMessage( SearchButton, WM_LBUTTONDOWN, MK_LBUTTON, NULL );
			SendMessage( SearchButton, WM_LBUTTONUP, 0, 0 );
		}
		else
			rv = ERROR_FILE_NOT_FOUND;
	}

	return rv;
}



BOOL NH_Excluded( LPTSTR Topic, LPCTSTR Excluded )
{
	if ( !Topic || !Excluded )
		return FALSE;


	const int BufLen		= 64;
	wchar_t temp[BufLen]	= L"";
	wchar_t *ch				= NULL;
	int j					= 0;
	BOOL Done				= FALSE;


	for ( ch = (wchar_t*) Excluded; !Done; ch++ ) {

		if ( ( *ch == ',' ) || ( *ch == '\0' ) ) {
			if ( j )
				if ( !_wcsicmp( Topic, temp ) )
					return TRUE;

			j = 0;
			temp[j] = '\0';
			Done |= ( *ch == '\0' );
		}
		else {
			if ( j < ( BufLen - 1 ) ) {
				temp[j++] = *ch;
				temp[j] = '\0';
			}
		}
	}

	return FALSE;
}


BOOL NH_SubAlias( LPTSTR Topic, LPCTSTR AliasList )
{
	if ( !Topic || !AliasList )
		return FALSE;


	wchar_t Alias[SHORT_BUF_LEN]		= L"";
	unsigned int i						= 0;
	wchar_t *ch							= (wchar_t*) AliasList;
	wchar_t *sep						= NULL;
	wchar_t *value						= NULL;


	do {
		if ( ( *ch == '\0' ) || ( *ch == ',' ) || ( *ch == ';' ) ) {

			if ( Alias[0] ) {
				sep = wcschr( Alias, '=' );
				if ( sep ) {
					value = sep + 1;
					if ( *value ) {
						*sep = '\0';
						if ( !_wcsicmp( Topic, Alias ) ) {
							wcscpy_s( Topic, SHORT_BUF_LEN, value );
							return TRUE;
						}
					}
				}
			}

			i = 0;
			Alias[i] = '\0';

			if ( *ch )
				ch++;
			else
				return FALSE;
		}
		else {
			if ( i < ( SHORT_BUF_LEN - 1 ) ) {
				Alias[i++] = *ch;
				Alias[i] = '\0';
			}

			ch++;
		}

	} while ( TRUE );

	return FALSE;
}



int LaunchHelp( LPTSTR HelpFile, LPTSTR Topic, unsigned int SelectTab, LPCTSTR SearchText )
{
	if ( !HelpFile || !Topic )
		return 0;


	wchar_t Filename[MAX_FILENAME_LEN]			= L"";
	wchar_t ViewerFilename[MAX_FILENAME_LEN]	= L"";
	wchar_t buf2[MAX_FILENAME_LEN] = L"";
	wchar_t *lastbs;


	wcscpy_s( Filename, MAX_FILENAME_LEN, HelpFile);

	if ( ( Filename[0] == '~' ) && ( Filename[1] == '\\' ) ) {
		//	~ = the directory where the .DLL resides

		GetModuleFileName( MyDLLHandle, Filename, MAX_FILENAME_LEN );
		lastbs = wcsrchr( Filename, L'\\' );
		if ( lastbs )
			wcscpy_s( lastbs, MAX_FILENAME_LEN - ( lastbs - Filename ), HelpFile + 1);
	}


	BOOL envcheck = ( ( Filename[0] == '%' ) && ( Filename[1] == '[' ) );

	ExpandVariables( Filename, 1 );
	if ( envcheck && ( Filename[0] == '\\' ) )
		return 0;	//		%PLUGINHELP not defined?

	QueryTrueName( Filename, buf2 );
	wcscpy_s( Filename, MAX_FILENAME_LEN, buf2 );

	//	Printf( L"   * Trying %s\r\n", Filename );

	if ( !NH_IsAFile( Filename ) )		//	if ( !QueryIsFile( Filename ) )
		return 0;


	SearchPath( NULL, L"hh.exe", NULL, MAX_FILENAME_LEN, ViewerFilename, NULL );
	if ( ViewerFilename[0] == '\0' )
		return 0;
	else if	( !NH_IsAFile( Filename ) )		//	else if ( !QueryIsFile( Filename ) )
		return 0;

	//	Printf( L"   * ViewerFilename = '%s'\r\n", ViewerFilename );


	wcscat_s( Filename, MAX_FILENAME_LEN, L"::/" );
	wcscat_s( Filename, MAX_FILENAME_LEN, Topic );
	wcscat_s( Filename, MAX_FILENAME_LEN, L".html" );
	//	Printf( L"   * Filename = %s\r\n", Filename );

	STARTUPINFO StartupInfo;
	PROCESS_INFORMATION ProcessInfo;

	memset( &StartupInfo, 0x00, sizeof( STARTUPINFO ) );
	StartupInfo.cb = sizeof( STARTUPINFO );
	memset( &ProcessInfo, 0x00, sizeof( PROCESS_INFORMATION ) );


	wcscpy_s( buf2, MAX_FILENAME_LEN, L"\"" );
	wcscat_s( buf2, MAX_FILENAME_LEN, ViewerFilename );
	wcscat_s( buf2, MAX_FILENAME_LEN, L"\" \"" );
	wcscat_s( buf2, MAX_FILENAME_LEN, Filename );
	wcscat_s( buf2, MAX_FILENAME_LEN, L"\"" );
	//	Printf( L"   * buf2 = %s\r\n", buf2 );

	if ( !CreateProcess( ViewerFilename, buf2, NULL, NULL, FALSE, 0, NULL, NULL, &StartupInfo, &ProcessInfo ) )
		return 0;

	if ( SelectTab ) 
		SelectHelpTab( ProcessInfo.dwProcessId, ProcessInfo.hProcess, SelectTab - 1, SearchText );

	CloseHandle( ProcessInfo.hThread );

	CloseHelpWindow();
	NH_HelpViewerHandle = ProcessInfo.hProcess;
	return 1;
}


int TopicHelp( LPTSTR topic, unsigned int tab, LPCTSTR SearchText, LPCTSTR Exclude, LPCTSTR Aliases )
{
	if ( Exclude )
		if ( NH_Excluded( topic, Exclude ) )
			return 0;

	if ( Aliases )
		NH_SubAlias( topic, Aliases );


	wchar_t WinDir[MAX_PATH]			= L"";
	wchar_t shortbuf[SHORT_BUF_LEN]		= L"";


	wsprintf( shortbuf, L"%%[%sHelp]\\%s.chm", PLUGIN_NAME, PLUGIN_NAME );
	if ( LaunchHelp( shortbuf, topic, tab, SearchText ) )
		return 1;

	wsprintf( shortbuf, L"%%[PluginHelp]\\%s.chm", PLUGIN_NAME );
	if ( LaunchHelp( shortbuf, topic, tab, SearchText ) )
		return 1;

	wsprintf( shortbuf, L"~\\%s.chm", PLUGIN_NAME );
	if ( LaunchHelp( shortbuf, topic, tab, SearchText ) )
		return 1;

	wsprintf( shortbuf, L"~\\Help\\%s.chm", PLUGIN_NAME );
	if ( LaunchHelp( shortbuf, topic, tab, SearchText ) )
		return 1;

	wsprintf( shortbuf, L"%%@path[%%_cmdspec]%s.chm", PLUGIN_NAME );
	if ( LaunchHelp( shortbuf, topic, tab, SearchText ) )
		return 1;

	wsprintf( shortbuf, L"%%@path[%%_cmdspec]help\\%s.chm", PLUGIN_NAME );
	if ( LaunchHelp( shortbuf, topic, tab, SearchText ) )
		return 1;

	wsprintf( shortbuf, L"%%windir\\help\\%s.chm", PLUGIN_NAME );
	if ( LaunchHelp( shortbuf, topic, tab, SearchText ) )
		return 1;


	wchar_t MsgBuf[SHORT_BUF_LEN]		= L"";

	wcscpy_s( shortbuf, SHORT_BUF_LEN, PLUGIN_NAME );
	_wcsupr_s( shortbuf, SHORT_BUF_LEN );
	GetWindowsDirectory( WinDir, MAX_PATH );

	wsprintf( MsgBuf, L"I can\u2019t find the help file %s.chm.  It should be:\n\n\
    \u2022  in a directory specified in %%%sHELP\n\
    \u2022  in a directory specified in %%PLUGINHELP\n\
    \u2022  in the same directory as the .DLL file\n\
    \u2022  in a HELP directory within the .DLL\u2019s directory  \n\
    \u2022  in the same directory as the command shell\n\
    \u2022  in a HELP directory within the shell\u2019s directory  \n\
    \u2022  or in %s\\Help.\n", PLUGIN_NAME, shortbuf, WinDir );

	MessageBox( GetForegroundWindow(), MsgBuf, L"Missing Help File", MB_OK );

	return 1;
}


int WINAPI Help2( LPTSTR Name, LPCTSTR Exclude, LPCTSTR Aliases )
{
	if ( !Name )
		return 0;


	wchar_t shortbuf[SHORT_BUF_LEN]		= L"f";

	int wordindex = 0, charindex = 0;
	wchar_t ch;
	BOOL done = FALSE, wordend = FALSE, match = FALSE;


	do {
		charindex = 0;
		wordend = FALSE;
		match = TRUE;

		do {
			ch = PluginFeatures[wordindex + charindex];
			shortbuf[charindex + 1] = towlower(ch);

			if ( ( ch == '\0' ) || ( ch == ',' ) ) {
				wordend = TRUE;
				match &= ( Name[charindex] == '\0' );
				wordindex = wordindex + charindex + 1;
				shortbuf[charindex + 1] = '\0';
				done = ( ch == '\0' );
			}
			else if ( towlower( Name[charindex] ) != towlower( ch ) )
				match = FALSE;

			charindex++;

		} while ( !wordend ) ;

		if ( match ) {
			if ( shortbuf[1] == '@' ) {
				shortbuf[0] = 'f';
				shortbuf[1] = '_';
				return TopicHelp( shortbuf, 0, NULL, Exclude, Aliases );
			}
			else if ( shortbuf[1] == '_' ) {
				shortbuf[0] = 'v';
				return TopicHelp( shortbuf, 0, NULL, Exclude, Aliases );
			}
			else
				return TopicHelp( shortbuf + 1, 0, NULL, Exclude, Aliases );
		}

	} while ( !done );

	return 0;
}



DLLExports int WINAPI Help( LPTSTR Name )
{
	return Help2( Name, NEWHELP_EXCLUDE, NEWHELP_ALIASES );
}




int NH_Requote( LPTSTR String, size_t BufSize )
{
	if ( !String )
		return -1;


	size_t len			= wcslen( String );
	BOOL NeedQuotes		= FALSE;


	for ( size_t i = 0; String[i]; i++ )
		if ( iswspace( String[i] ) )
			NeedQuotes = TRUE;

	if ( !NeedQuotes )
		return 0;

	if ( ( len + 2 ) >= BufSize )
		return ERROR_NOT_ENOUGH_MEMORY;

	for ( size_t i = len - 1; i != (size_t) -1; i-- )
		String[i + 1] = String[i];

	String[0]		= 0x22;
	String[len + 1]	= 0x22;
	String[len + 2]	= '\0';
	return 0;
}



int UnscrambleDateMacro( LPTSTR outString )
{
	if ( !outString )
		return -1;


	char Temp[SHORT_BUF_LEN] = "";
	char MonthNames[12][4] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
	unsigned int Month = 0, Year = 0, Date = 0;
	char *sep1 = NULL;

	strcpy_s( Temp, SHORT_BUF_LEN, __DATE__ );

	for ( unsigned int i = 0; i < 12; i++ )
		if ( !_strnicmp( Temp, MonthNames[i], 3 ) )
			Month = i + 1;

	if ( !Month )
		return 1;

	sep1 = Temp + 3;
	if ( !isspace( *sep1 ) )
		return 2;

	while ( isspace( *sep1 ) )
		sep1++;

	Date = strtoul( sep1, &sep1, 10 );
	if ( ( Date < 1 ) || ( Date > 31 ) )
		return 2;

	if ( !sep1 )
		return 3;
	else if ( !isspace( *sep1 ) )
		return 3;

	while ( isspace( *sep1 ) )
		sep1++;

	Year = strtoul( sep1, &sep1, 10 );
	if ( ( Year < 2014 ) || ( Year > 2099 ) )
		return 3;

	Sprintf( outString, L"%04u-%02u-%02u", Year, Month, Date );
	return 0;
}


int GetTimeMacro( LPTSTR outString )
{
	if ( !outString )
		return -1;

	ASCIIToUnicode( __TIME__, outString, SHORT_BUF_LEN );
	return 0;
}


int WINAPI PluginHelpCmd( LPTSTR inString, LPCTSTR HelpText )
{
	if ( !inString )
		return 1;

	wchar_t temp[MAX_ARG_LEN + 1]		= L"f";
	wchar_t SearchText[MAX_ARG_LEN]		= L"";

	int i = 0, j = 1;
	BOOL quote	= FALSE;
	unsigned int SelectTab		= 0;


Retry:

	j = 1;
	temp[j] = '\0';

	while ( iswspace( inString[i] ) )
		i++;

	while ( inString[i] && ( !iswspace( inString[i] | quote ) ) ) {

		if ( inString[i] == 0x22 )
			quote = !quote;
		else if ( j < MAX_ARG_LEN ) {
			temp[j++] = inString[i];
			temp[j] = '\0';
		}

		i++;
	}

	if ( j == 1 ) {
		TopicHelp( L"overview", SelectTab, SearchText, NULL, NULL );
		return 0;
	}


	if ( !_wcsicmp( temp + 1, L"/C" ) ) {
		SelectTab = 1;
		SearchText[0] = '\0';
		goto Retry;
	}
	else if ( !_wcsicmp( temp + 1, L"/S" ) ) {
		SelectTab = 2;
		SearchText[0] = '\0';
		goto Retry;
	}
	else if ( !_wcsnicmp( temp + 1, L"/S", 2 ) ) {
		int k		= 3;
		if ( ( temp[k] == ':' ) || ( temp[k] == '=' ) )
			k++;

		wcscpy_s( SearchText, MAX_ARG_LEN, temp + k );
		NH_Requote( SearchText, MAX_ARG_LEN );
		SelectTab = 2;
		goto Retry;
	}
	else if ( !_wcsicmp( temp + 1, L"/F" ) ) {
		SelectTab = 3;
		SearchText[0] = '\0';
		goto Retry;
	}


	if ( !wcscmp( temp + 1, L"/?" ) ) {
		QPuts( (LPTSTR) HelpText );
		return 0;
	}
	else if ( !wcscmp( temp + 1, L"/??" ) ) {
		temp[0] = '\0';

		QPuts( (LPTSTR) HelpText );
		Printf( L"\r\n\t\t\t\t%s  %u.%u.%u (%s)\r\n", PLUGIN_NAME, VER_MAJOR, VER_MINOR, VER_BUILD, PLATFORM );

		MultiByteToWideChar( CP_ACP, MB_PRECOMPOSED, MACRO_STR( NEWHELP_VERSION ), -1, temp, SHORT_BUF_LEN );
		if ( temp[0] )
			Printf( L"\t\t\t\tNewHelp.cpp  %s\r\n", temp );

		return 0;
	}
	else if ( !_wcsicmp( temp + 1, L"/Q" ) ) {
		CloseHelpWindow();
		return 0;
	}
	else if ( !_wcsicmp( temp + 1, L"/V" ) ) {
		wchar_t DateBuf[SHORT_BUF_LEN] = L"";
		wchar_t TimeBuf[SHORT_BUF_LEN] = L"";

		UnscrambleDateMacro( DateBuf );
		GetTimeMacro( TimeBuf );

#ifdef VER_PATCH
		Printf( L"%s plugin  %d.%d.%d.%d  %s %s  (%s)\r\n", PLUGIN_NAME, VER_MAJOR, VER_MINOR, VER_BUILD, VER_PATCH, DateBuf, TimeBuf, PLATFORM );
#else
		Printf( L"%s plugin  %d.%d.%d.%d  %s %s  (%s)\r\n", PLUGIN_NAME, VER_MAJOR, VER_MINOR, VER_BUILD, 0, DateBuf, TimeBuf, PLATFORM );
#endif


		DateBuf[0] = '\0';
		MultiByteToWideChar( CP_ACP, MB_PRECOMPOSED, MACRO_STR( NEWHELP_VERSION ), -1, DateBuf, SHORT_BUF_LEN );
		if ( DateBuf[0] )
			Printf( L"\r\n   NewHelp.cpp . . . . . . . %s\r\n", DateBuf );

#ifdef		PARSE_ARGS

		DateBuf[0] = '\0';
		MultiByteToWideChar( CP_ACP, MB_PRECOMPOSED, MACRO_STR( PARSE_ARGS ), -1, DateBuf, SHORT_BUF_LEN );
		if ( DateBuf[0] )
			Printf( L"   ParseArgs.cpp . . . . . . %s\r\n", DateBuf );

#endif	//	PARSE_ARGS

#ifdef		C_CONLIST

		DateBuf[0] = '\0';
		MultiByteToWideChar( CP_ACP, MB_PRECOMPOSED, MACRO_STR( C_CONLIST ), -1, DateBuf, SHORT_BUF_LEN );
		if ( DateBuf[0] )
			Printf( L"   ConList.cpp . . . . . . . %s\r\n", DateBuf );

#endif	//	C_CONLIST

#ifdef		FILE_HANDLER_VERSION

		DateBuf[0] = '\0';
		MultiByteToWideChar( CP_ACP, MB_PRECOMPOSED, MACRO_STR( FILE_HANDLER_VERSION ), -1, DateBuf, SHORT_BUF_LEN );
		if ( DateBuf[0] )
			Printf( L"   FileHandler.cpp . . . . . %s\r\n", DateBuf );

#endif	//	FILE_HANDLER_VERSION

#ifdef		MMFILES_VERSION

		DateBuf[0] = '\0';
		MultiByteToWideChar( CP_ACP, MB_PRECOMPOSED, MACRO_STR( MMFILES_VERSION ), -1, DateBuf, SHORT_BUF_LEN );
		if ( DateBuf[0] )
			Printf( L"   MMFiles.cpp . . . . . . . %s\r\n", DateBuf );

#endif	//	MMFILES_VERSION

#ifdef		CODE_PAGES_VERSION

		DateBuf[0] = '\0';
		MultiByteToWideChar( CP_ACP, MB_PRECOMPOSED, MACRO_STR( CODE_PAGES_VERSION ), -1, DateBuf, SHORT_BUF_LEN );
		if ( DateBuf[0] )
			Printf( L"   CodePages.cpp . . . . . . %s\r\n", DateBuf );

#endif	//	CODE_PAGES_VERSION

#ifdef EXPAND_ESCAPES_CPP

		DateBuf[0] = '\0';
		MultiByteToWideChar( CP_ACP, MB_PRECOMPOSED, MACRO_STR( EXPAND_ESCAPES_CPP ), -1 , DateBuf, SHORT_BUF_LEN );
		if ( DateBuf[0] )
			Printf( L"   ExpandEscapes.cpp . . . . %s\r\n", DateBuf );

#endif	//	EXPAND_ESCAPES_CPP

		return 0;
	}
	else if ( temp[1] == '/' ) {
		_wcsupr_s( temp, MAX_ARG_LEN );
		DisplayErrorHeader();
		Qprintf( GetStdHandle( STD_ERROR_HANDLE ), L"Unknown option: \"%s\"\r\n", temp + 1 );
		return 1;
	}


	_wcslwr_s( temp, MAX_ARG_LEN + 1 );

	if ( temp[1] == '@' ) {
		temp[0] = 'f';
		temp[1] = '_';
		TopicHelp( temp, SelectTab, SearchText, NULL, NULL );
	}
	else if ( temp[1] == '_' ) {
		temp[0] = 'v';
		TopicHelp( temp, SelectTab, SearchText, NULL, NULL );
	}
	else
		TopicHelp( temp + 1, SelectTab, SearchText, NULL, NULL );

	return 0;
}


LPTSTR UsageText( const wchar_t *inString )
{
	if ( !inString )
		return NULL;


	wchar_t *ch = wcschr( (wchar_t*) inString, '\n' );


	if ( !ch )
		return NULL;

	while ( *ch == '\n' )
		ch++;

	return ch;
}


#endif		//	NEWHELP_VERSION


/*

	1.0.8.6		2020-02-20

	1.0.8.7		2020-03-26
				Fix for TCM_SETCURFOCUS not defined.
	
	1.0.8.8		2021-11-01
				Changed /?? to look more like my other plugins.
				/V now includes ExpandEscapes.cpp.

	1.0.8.9		2022-06-02
				TCM_SETCURFOCUS is now TCM_SETCURFOCUS$

	1.0.8.10	2023-06-13
				Removed calls to QueryIsFile().

*/
