
//			Functions to open and read text files as memory-mapped files:


#ifndef MMFILES_VERSION
#define MMFILES_VERSION				1.4.4.1


#define FILE_OEM					0
#define FILE_UTF16LE				1
#define FILE_UTF16BE				2
#define FILE_UTF8					3
#define FILE_EBCDIC					16
#define FILE_UTF32LE				32
#define FILE_UTF32BE				33
#define FILE_RAW					64
#define FILE_ASCII					128
#define FILE_NONE					-1

#define FMT_UNKNOWN					0
#define FMT_UNFORMATTED				1
#define FMT_PREWRAPPED				2
#define FMT_UNFORMATTED_BLANKS		3
#define FMT_MAX_VALUE				3

#define ERROR_EMPTY_FILE			-100
#define MM_INVALID_CHAR				0xfffd

//	#define MM_INTERNET_FEATURES		1
//	#define MM_ALLOW_CESU8				1

#define MM_CLIP_FILENAME			L"clip:"
#define MM_STDIN_FILENAME			L"-"

#define MM_FLAG_ERROR_MESSAGES		0x0001
#define MM_FLAG_TCC_NATIVE_INET		0x0002
#define MM_FLAG_SHARE_WRITE			0x0004
#define MM_FLAG_ALLOW_EBCDIC		0x0080
#define MM_FLAG_HIGH_CHARS			0x0100
#define MM_FLAG_SKIP_NULLS			0x0400
#define MM_FLAG_NULLS_TO_INVCHAR	0x0800

#define MMGL_FLAG_SKIP_BLANKS		0x0001
#define MMGL_FLAG_SPLIT_LONG_LINES	0x0002

#define MM_NUM_HTTP_ERROR_TEXTS		8

#define MM_SURROGATE_SIG_MASK		0xfc00
#define MM_SURROGATE_SIG_HIGH		0xd800
#define MM_SURROGATE_SIG_LOW		0xdc00
#define MM_SURROGATE_MASK			0x03ff
#define MM_SURROGATE_OFFSET			0x10000

#define MM_UNICODE_MAX				0x10ffff
#define MM_BMP_MAX					0xffff

#ifndef BOM
#define BOM							0xfeff
#endif	//	BOM

#ifndef ERRHANDLE
#define ERRHANDLE					GetStdHandle( STD_ERROR_HANDLE )
#endif	//	ERRHANDLE



#include "codepages.cpp"



const short int MM_HttpErrorCode[MM_NUM_HTTP_ERROR_TEXTS]	=	{ 400, 401, 402, 403, 404, 408, 500, 503 };

const wchar_t MM_HttpErrorText[MM_NUM_HTTP_ERROR_TEXTS][20] =	{ L"Bad request", L"Unauthorized", L"Payment required", L"Forbidden",
		L"Not found", L"Request timeout", L"Internal error", L"Service unavailable" };



struct _MMFile {
	BYTE *Buffer;
	LPTSTR Filename;
	LPTSTR TempFilename;
	HANDLE FileHandle;
	HANDLE FileMapping;
	int ErrorCode;
	int FileEncoding;
	int FileFormat;
	size_t FileSize;
	size_t Index;
	size_t BOMSize;
	BOOL HighChars;
	unsigned int CodePage;
	unsigned int CodePageIndex;
	unsigned int EbcdicCodePage;
	unsigned int EbcdicCodePageIndex;
	wchar_t InvalidChar;
	int Flags;
};



int CloseMMFile( _MMFile *MMFile )
{
	if ( !MMFile )
		return -1;


	int ErrorCode		= MMFile->ErrorCode;


	if ( MMFile->Buffer && ( MMFile->FileMapping == NULL ) && ( MMFile->FileHandle == NULL ) ) {
		free( MMFile->Buffer );
		MMFile->Buffer = NULL;
	}

	if ( MMFile->Buffer )
		UnmapViewOfFile( MMFile->Buffer );

	if ( MMFile->FileMapping )
		CloseHandle( MMFile->FileMapping );

	if ( MMFile->FileHandle )
		CloseHandle( MMFile->FileHandle );

	if ( MMFile->TempFilename ) {
		DeleteFile( MMFile->TempFilename );
		free( MMFile->TempFilename );
	}

	free( MMFile->Filename );

	memset( MMFile, 0x00, sizeof( _MMFile ) );
	MMFile->ErrorCode = ErrorCode;
	return 0;
}


int MMHasWildcards( LPTSTR inString )
{
	if ( !inString )
		return 0;

	int rv = 0, brackets = 0;

	if ( _wcsnicmp( inString, L"http://", 7 ) == 0 )
		return 0;
	else if ( _wcsnicmp( inString, L"https://", 8 ) == 0 )
		return 0;

	for ( int i = 0; inString[i]; i++ ) {
		if ( ( inString[i] == '*' ) || ( inString[i] == '?' ) )
			rv++;
	
		if ( !brackets && ( inString[i] == '[' ) )
			brackets++;
		else if ( brackets && ( inString[i] == ']' ) ) {
			brackets--;
			rv++;
		}
	}

	return rv;
}


int MM_AppendFilename( LPTSTR Path, LPTSTR Filename )
{
	if ( !Path || !Filename )
		return -1;

	
	BOOL NeedSlash		= FALSE;

	for ( size_t i = 0; Path[i]; i++ ) {
		if ( ( Path[i] == '/' ) || ( Path[i] == '\\' ) || ( Path[i] == ':' ) )
			NeedSlash = FALSE;
		else
			NeedSlash = TRUE;
	}

	if ( ( Filename[0] == '/' ) || ( Filename[0] == '\\' ) )
		NeedSlash = FALSE;
	
	if ( NeedSlash )
		wcscat_s( Path, MAX_FILENAME_LEN, L"\\" );

	wcscat_s( Path, MAX_FILENAME_LEN, Filename );
	return 0;
}


int MM_ConsoleHandle( HANDLE inHandle ) {
	if ( inHandle == NULL )
		return 0;

	if ( ( inHandle == (HANDLE) STD_INPUT_HANDLE ) || ( inHandle == (HANDLE) STD_OUTPUT_HANDLE ) || ( inHandle == (HANDLE) STD_ERROR_HANDLE ) )
		inHandle = GetStdHandle( (DWORD) inHandle );

	DWORD Mode = UINT_MAX;
	int rv = GetConsoleMode( inHandle, &Mode );

	if ( ( rv == 0 ) || ( Mode == UINT_MAX ) )
		return 0;
	else
		return 1;
}


int MM_GetErrorText( int err, LPTSTR outString )
{
	if ( !outString )
		return -1;


	HANDLE ModuleHandle			= NULL;
	DWORD FM_Flags				= FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS | FORMAT_MESSAGE_MAX_WIDTH_MASK;


	if ( ( err >= 12000 ) && ( err <= 12199 ) ) {
		ModuleHandle = GetModuleHandle( L"wininet.dll" );
		if ( ModuleHandle )
			FM_Flags |= FORMAT_MESSAGE_FROM_HMODULE;
	}


	if ( err == -1 )
		wcscpy_s( outString, SHORT_BUF_LEN, L"Unknown error" );
	else if ( err == ERROR_EMPTY_FILE )
		wcscpy_s( outString, SHORT_BUF_LEN, L"The file is empty." );
	else if ( ( err >= -599 ) && ( err <= -400 ) ) {
		err = -err;
		wsprintf( outString, L"HTTP error %d", err );

		for ( int i = 0; i < MM_NUM_HTTP_ERROR_TEXTS; i++ ) {
			if ( MM_HttpErrorCode[i] == err ) {
				wcscat_s( outString, SHORT_BUF_LEN, L":  " );
				wcscat_s( outString, SHORT_BUF_LEN, MM_HttpErrorText[i] );
			}
		}
	}
	else if ( FormatMessage( FM_Flags, ModuleHandle, err, 0, outString, SHORT_BUF_LEN, NULL ) == 0 )
		wsprintf( outString, L"Error %d", err );

	size_t l = wcslen( outString );

	if ( l > 0 )
		while ( iswspace( outString[l - 1] ) ) {
			l--;
			outString[l] = '\0';
		}

	return 0;
}



int MM_PrependStr( LPTSTR String, LPTSTR Prefix )
{
	if ( !String || !Prefix )
		return -1;


	wchar_t temp[MAX_FILENAME_LEN]			= L"";


	wcscpy_s( temp, MAX_FILENAME_LEN, String );
	wcscpy_s( String, MAX_FILENAME_LEN, Prefix );
	wcscat_s( String, MAX_FILENAME_LEN, temp );
	return 0;
}



#ifdef MM_INTERNET_FEATURES

#include <WinInet.h>



DWORD MMGetHttpStatus( HINTERNET InternetHandle )
{
	DWORD Status = 0;
	DWORD BufferSize = sizeof( Status );

	HttpQueryInfo( InternetHandle, HTTP_QUERY_STATUS_CODE | HTTP_QUERY_FLAG_NUMBER, &Status, &BufferSize, 0 );

	if ( Status >= 400 )
		return Status;
	else
		return 0;
}


int MMFetchInternetFile( LPTSTR inURL, LPTSTR outLocalFilename )
{
	if ( !inURL || !outLocalFilename )
		return -1;
	else if ( inURL[0] == '\0' )
		return -1;

	
	const unsigned int BufferSize		= 8192;
	BYTE Buffer[BufferSize]				= { 0 };

	DWORD BytesRead						= 0;
	DWORD BytesWritten					= 0;

	wchar_t AgentString[SHORT_BUF_LEN]	= L"";
	wchar_t ErrorText[SHORT_BUF_LEN]	= L"";

	HINTERNET Connection				= NULL;
	HINTERNET RemoteFileHandle			= NULL;
	HANDLE LocalFileHandle				= NULL;

	int ReadReturn				= 0;
	int WriteReturn				= 0;
	int ReadErrors				= 0;
	int WriteErrors				= 0;
	int rv						= 42;
	int UrlProtocol				= 0;
	DWORD HttpStatus			= 0;
	DWORD OpenUrlFlags			= INTERNET_FLAG_NO_CACHE_WRITE | INTERNET_FLAG_RELOAD;

	unsigned __int64 TotalBytesWritten	= 0;
	unsigned __int64 ExpectedFileSize	= 0;



	if ( _wcsnicmp( inURL, L"ftp://", 6 ) == 0 )
		UrlProtocol = 2, OpenUrlFlags |= INTERNET_FLAG_PASSIVE;
	else if ( _wcsnicmp( inURL, L"http://", 7 ) == 0 )
		UrlProtocol = 1;
	else if ( _wcsnicmp( inURL, L"https://", 8 ) == 0 )
		UrlProtocol = 1;
	else
		return -2;

	
	GetTempPath( MAX_FILENAME_LEN, outLocalFilename );
	GetTempFileName( outLocalFilename, L"MMF", 0, outLocalFilename );


	wsprintf( AgentString, L"%s v%u.%u.%u", PLUGIN_NAME, VER_MAJOR, VER_MINOR, VER_BUILD );

	Connection = InternetOpen( AgentString, INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0 );

	if ( Connection ) {
		RemoteFileHandle = InternetOpenUrl( Connection, inURL, NULL, 0, OpenUrlFlags, NULL );

		if ( RemoteFileHandle ) {
			if ( UrlProtocol == 1 )
				HttpStatus = MMGetHttpStatus( RemoteFileHandle );

			if ( HttpStatus == 0 ) {
				LocalFileHandle = CreateFile( outLocalFilename, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL );

				if ( LocalFileHandle != INVALID_HANDLE_VALUE ) {

					do {
						BytesRead = 0;
						ReadReturn = InternetReadFile( RemoteFileHandle, Buffer, BufferSize, &BytesRead );

						if ( ReadReturn ) {
							BytesWritten = 0;
							WriteReturn = WriteFile( LocalFileHandle, Buffer, BytesRead, &BytesWritten, NULL );

							if ( WriteReturn == 0 ) {		//	error writing to local file
								WriteErrors++;
								if ( rv == 42 )
									rv = GetLastError();
							}
						}
						else {								//	error reading from remote file
							ReadErrors++;
							if ( rv == 42 )
								rv = GetLastError();
						}

					} while ( ReadReturn && BytesRead );

					CloseHandle( LocalFileHandle );

					if ( ReadErrors || WriteErrors ) {
						Sleep( 50 );
						DeleteFile( outLocalFilename );
					}
					else
						rv = 0;
				}
			}
			else								//	bad HttpStatus
				rv = 0 - HttpStatus;

			InternetCloseHandle( RemoteFileHandle );
		}
		else									//	InternetOpenUrl() failed
			rv = GetLastError();

		InternetCloseHandle( Connection );
	}
	else										//	InternetOpen() failed
		rv = GetLastError();

	return rv;
}

#else

int MMFetchInternetFile( LPTSTR inURL, LPTSTR outLocalFilename )
{
	if ( !inURL || !outLocalFilename )
		return -1;
	else if ( inURL[0] == '\0' )
		return -1;


	wchar_t temp[SHORT_BUF_LEN]			= L"";
	wchar_t cmdbuf[MAX_FILENAME_LEN]	= L"";
	int rv = 0;


	GetTempPath( MAX_FILENAME_LEN, outLocalFilename) ;


	DWORD pid = GetCurrentProcessId();
	wsprintf( temp, L"%s-%04x.tmp", PLUGIN_NAME, pid );
	MM_AppendFilename( outLocalFilename, temp );


	wsprintf( cmdbuf, L"*copy /q /ne \"%s\" \"%s\"", inURL, outLocalFilename );

	if ( Command( cmdbuf, 0 ) ) {
		DeleteFile( outLocalFilename );
		return 2;
	}

	return 0;
}

#endif



int GuessFileEncoding( _MMFile *MMFile, BOOL TryEbcdic );


int OpenMMFile( _MMFile *MMFile, LPTSTR inFilename, int Flags, unsigned int CodePage, unsigned int EbcdicCodePage )
{
	if ( !inFilename || !MMFile )
		return -1;
	else if ( inFilename[0] == '\0' )
		return -1;


	wchar_t FullName[MAX_FILENAME_LEN]		= L"";
	wchar_t ErrorText[SHORT_BUF_LEN]		= L"";

	BY_HANDLE_FILE_INFORMATION	FileInfo;
	int rv									= 0;


	memset( MMFile, 0x00, sizeof( _MMFile ) );


	if ( !CodePage )
		CodePage = GetACP();

	if ( !EbcdicCodePage )
		EbcdicCodePage = CP_GetLocalEbcdicCodePage();


	MMFile->CodePage		= CodePage;
	MMFile->EbcdicCodePage	= EbcdicCodePage;
	CodePagesToIndices( CodePage, EbcdicCodePage, &(MMFile->CodePageIndex), &(MMFile->EbcdicCodePageIndex) );

	if ( Flags & MM_FLAG_HIGH_CHARS )
		MMFile->HighChars = TRUE;

	MMFile->InvalidChar = MM_INVALID_CHAR;
	MMFile->Flags		= Flags;



	MMFile->Filename = (LPTSTR) malloc( sizeof( wchar_t ) * ( wcslen( inFilename ) + 1 ) );
	if ( MMFile->Filename == NULL )
		goto MemoryAbort;

	wcscpy_s( MMFile->Filename, wcslen( inFilename ) + 1, inFilename );



#ifdef MM_INTERNET_FEATURES

	if ( !MMHasWildcards( inFilename ) && QueryIsURL( inFilename ) ) {
		MMFile->ErrorCode = MMFetchInternetFile( inFilename, FullName );
		if ( MMFile->ErrorCode ) {
			if ( Flags & MM_FLAG_ERROR_MESSAGES ) {
				DisplayErrorHeader();
				MM_GetErrorText( MMFile->ErrorCode, ErrorText );
				Qprintf( ERRHANDLE, L"Error fetching \"%s\" :\r\n", inFilename );
				Qprintf( ERRHANDLE, L"   %s\r\n", ErrorText );
			}
			goto ErrorAbort;
		}

		MMFile->TempFilename	= (LPTSTR) malloc( sizeof( wchar_t ) * ( wcslen( FullName ) + 1 ) );
		if ( MMFile->TempFilename == NULL )
			goto MemoryAbort;

		wcscpy_s( MMFile->TempFilename, wcslen( FullName ) + 1, FullName );


		MMFile->FileHandle = CreateFile( FullName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL );
		MMFile->ErrorCode = GetLastError();

		if ( MMFile->FileHandle == INVALID_HANDLE_VALUE ) {
			if ( Flags & MM_FLAG_ERROR_MESSAGES ) {
				MM_GetErrorText( MMFile->ErrorCode, ErrorText );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Error opening \"%s\" :\r\n", MMFile->Filename );
				Qprintf( ERRHANDLE, L"   %s\r\n", ErrorText );
			}
			goto ErrorAbort;
		}
	}
	else

#else

	if ( ( Flags & MM_FLAG_TCC_NATIVE_INET ) && !MMHasWildcards( inFilename ) && QueryIsURL( inFilename ) ) {
		MMFile->ErrorCode = MMFetchInternetFile( inFilename, FullName );
		if ( MMFile->ErrorCode ) {
			if ( Flags & MM_FLAG_ERROR_MESSAGES ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Error fetching \"%s\"\r\n", inFilename );
			}
			goto ErrorAbort;
		}

		MMFile->TempFilename	= (LPTSTR) malloc( sizeof( wchar_t ) * ( wcslen( FullName ) + 1 ) );
		if ( MMFile->TempFilename == NULL )
			goto MemoryAbort;

		wcscpy_s( MMFile->TempFilename, wcslen( FullName ) + 1, FullName );

		MMFile->FileHandle = CreateFile( FullName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL );
		MMFile->ErrorCode = GetLastError();

		if ( MMFile->FileHandle == INVALID_HANDLE_VALUE ) {
			if ( Flags & MM_FLAG_ERROR_MESSAGES ) {
				MM_GetErrorText( MMFile->ErrorCode, ErrorText );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Error opening \"%s\" :\r\n", MMFile->Filename );
				Qprintf( ERRHANDLE, L"   %s\r\n", ErrorText );
			}
			goto ErrorAbort;
		}
	}
	else

#endif

	if ( !_wcsicmp( inFilename, MM_CLIP_FILENAME ) ) {
		rv = -1;

		if ( OpenClipboard( GetConsoleWindow() ) ) {

			HANDLE ClipboardHandle = GetClipboardData( CF_UNICODETEXT );

			if ( ClipboardHandle ) {

				BYTE *ClipboardData = (BYTE*) GlobalLock( ClipboardHandle );
				size_t ClipboardSize = 0;

				if ( ClipboardData ) {
					ClipboardSize = ( wcslen( (LPTSTR) ClipboardData ) + 1 ) * sizeof( wchar_t );

					if ( ClipboardSize >= ( 2 * sizeof( wchar_t ) ) ) {
						MMFile->Buffer = (BYTE*) malloc( ClipboardSize );

						if ( MMFile->Buffer ) {
							memcpy( MMFile->Buffer, ClipboardData, ClipboardSize );
							MMFile->FileHandle = NULL;
							MMFile->FileMapping = NULL;
							MMFile->FileSize = ClipboardSize - sizeof( wchar_t );
							MMFile->FileEncoding = FILE_UTF16LE;
							rv = 0;
						}
						else {
							if ( Flags & MM_FLAG_ERROR_MESSAGES ) {
								DisplayErrorHeader();
								Qprintf( ERRHANDLE, L"Can\u2019t allocate buffer for clipboard data\r\n" );
							}
						}
					}
					else {
						if ( Flags & MM_FLAG_ERROR_MESSAGES ) {
							DisplayErrorHeader();
							Qprintf( ERRHANDLE, L"No text on the clipboard\r\n" );
						}
					}

					GlobalUnlock( ClipboardHandle );
				}
				else {
					if ( Flags & MM_FLAG_ERROR_MESSAGES ) {
						DisplayErrorHeader();
						Qprintf( ERRHANDLE, L"Can\u2019t get clipboard text data address\r\n" );
					}
				}
			}
			else {
				if ( Flags & MM_FLAG_ERROR_MESSAGES ) {
					DisplayErrorHeader();
					Qprintf( ERRHANDLE, L"No text on the clipboard\r\n" );
				}
			}

			CloseClipboard();
		}
		else {
			if ( Flags & MM_FLAG_ERROR_MESSAGES ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Can\u2019t open the clipboard\r\n" );
			}
		}

		return rv;
	}
	else if ( wcscmp( inFilename, MM_STDIN_FILENAME ) ) {
		QueryTrueName( inFilename, FullName );

		if ( !wcsncmp( FullName, L"Volume{", 7 ) && iswxdigit( FullName[7] ) )		//	virtual disk mounted to a junction?
			MM_PrependStr( FullName, L"\\\\.\\" );

		free( MMFile->Filename );
		MMFile->Filename = (LPTSTR) malloc( sizeof( wchar_t ) * ( wcslen( FullName ) + 1 ) );
		if ( MMFile->Filename == NULL )
			goto MemoryAbort;

		wcscpy_s( MMFile->Filename, wcslen( FullName ) + 1, FullName );

		MMFile->FileHandle = CreateFile( FullName, GENERIC_READ, ( Flags & MM_FLAG_SHARE_WRITE ) ? FILE_SHARE_READ | FILE_SHARE_WRITE : FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL );
		MMFile->ErrorCode = GetLastError();

		if ( MMFile->FileHandle == INVALID_HANDLE_VALUE ) {
			if ( Flags & MM_FLAG_ERROR_MESSAGES ) {
				MM_GetErrorText( MMFile->ErrorCode, ErrorText );
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Error opening \"%s\" :\r\n", MMFile->Filename );
				Qprintf( ERRHANDLE, L"   %s\r\n", ErrorText );
			}
			goto ErrorAbort;
		}
	}
	else {
		MMFile->FileHandle = GetStdHandle( STD_INPUT_HANDLE );

		if ( MM_ConsoleHandle( MMFile->FileHandle ) )
			_cputws( L"Reading text from the console: (^Z ends)\r\n" );
	}

	memset( &FileInfo, 0, sizeof( BY_HANDLE_FILE_INFORMATION ) );
	GetFileInformationByHandle( MMFile->FileHandle, &FileInfo );

	if ( ( FileInfo.ftCreationTime.dwHighDateTime | FileInfo.ftCreationTime.dwLowDateTime | FileInfo.ftLastAccessTime.dwHighDateTime | FileInfo.ftLastAccessTime.dwLowDateTime | FileInfo.ftLastWriteTime.dwHighDateTime | FileInfo.ftLastWriteTime.dwLowDateTime ) == 0 ) {

		wchar_t temp[SHORT_BUF_LEN]		= L"";

		GetTempPath( MAX_FILENAME_LEN, FullName );

		DWORD pid = GetCurrentProcessId();
		wsprintf( temp, L"%s-%04x.tmp", PLUGIN_NAME, pid );
		MM_AppendFilename( FullName, temp );

		MMFile->TempFilename = (LPTSTR) malloc( sizeof( wchar_t ) * ( wcslen( FullName ) + 1 ) );
		if ( MMFile->TempFilename == NULL )
			goto MemoryAbort;

		wcscpy_s( MMFile->TempFilename, wcslen( FullName ) + 1, FullName );

		//	Printf( L"   * Copying to temp file \"%s\":\n", FullName );

		const int BufferSize = 8192;

		BYTE *CopyBuffer = (BYTE *) malloc( BufferSize );
		DWORD BytesRead = 0, BytesWritten = 0;

		if ( !CopyBuffer ) {
			if ( Flags & MM_FLAG_ERROR_MESSAGES ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Can\u2019t allocate buffer for copy\n" );
			}
			goto MemoryAbort;
		}

		HANDLE TempFileHandle = NULL;
		TempFileHandle = CreateFile( MMFile->TempFilename, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL );

		if ( TempFileHandle == INVALID_HANDLE_VALUE ) {
			MMFile->ErrorCode = GetLastError();
			free( CopyBuffer );
			if ( Flags & MM_FLAG_ERROR_MESSAGES ) {
				DisplayErrorHeader();
				Qprintf( ERRHANDLE, L"Can\u2019t create temp file for pipe copy\n" );
			}
			goto ErrorAbort;
		}

		while ( ReadFile( MMFile->FileHandle, CopyBuffer, BufferSize, &BytesRead, NULL ) ) {
			if ( BytesRead == 0 )
				break;

			if ( WriteFile( TempFileHandle, CopyBuffer, BytesRead, &BytesWritten, NULL ) == 0 ) {
				MMFile->ErrorCode = GetLastError();
				free( CopyBuffer );
				if ( Flags & MM_FLAG_ERROR_MESSAGES ) {
					DisplayErrorHeader();
					MM_GetErrorText( MMFile->ErrorCode, ErrorText );
					Qprintf( ERRHANDLE, L"Error writing temp file \"%s\" :\r\n", MMFile->TempFilename );
					Qprintf( ERRHANDLE, L"   %s\r\n", ErrorText );
				}
				goto ErrorAbort;
			}

			BytesRead = 0;
		}

		if ( !MM_ConsoleHandle( MMFile->FileHandle ) )
			CloseHandle( MMFile->FileHandle );

		MMFile->FileHandle = TempFileHandle;
		FlushFileBuffers( MMFile->FileHandle );
		SetFilePointer( MMFile->FileHandle, 0, NULL, FILE_BEGIN );
		free( CopyBuffer );

		memset( &FileInfo, 0, sizeof( BY_HANDLE_FILE_INFORMATION ) );
		GetFileInformationByHandle( MMFile->FileHandle, &FileInfo );
	}

	if ( ( FileInfo.nFileSizeHigh | FileInfo.nFileSizeLow ) == 0 ) {
		CloseHandle( MMFile->FileHandle );
		MMFile->ErrorCode = ERROR_EMPTY_FILE;
		goto ErrorAbort;
	}

#ifdef _WIN64

	MMFile->FileSize = FileInfo.nFileSizeLow | ( (size_t) FileInfo.nFileSizeHigh << 32 );

#else

	else if ( FileInfo.nFileSizeHigh ) {
		CloseHandle( MMFile->FileHandle );
		MMFile->ErrorCode = ERROR_FILE_TOO_LARGE;
		if ( Flags & MM_FLAG_ERROR_MESSAGES ) {
			DisplayErrorHeader();
			Qprintf( ERRHANDLE, L"File is way too big!\r\n" );
		}
		goto ErrorAbort;
	}

	MMFile->FileSize = FileInfo.nFileSizeLow;

#endif

	MMFile->FileMapping = CreateFileMapping( MMFile->FileHandle, NULL, PAGE_READONLY, 0, 0, NULL );

	if ( MMFile->FileMapping == NULL ) {
		MMFile->ErrorCode = GetLastError();
		CloseHandle( MMFile->FileHandle );
		if ( Flags & MM_FLAG_ERROR_MESSAGES ) {
			DisplayErrorHeader();
			MM_GetErrorText( MMFile->ErrorCode, ErrorText );
			Qprintf( ERRHANDLE, L"Error mapping file: %s\r\n", ErrorText );
		}
		goto ErrorAbort;
	}

	MMFile->Buffer = (BYTE *) MapViewOfFile( MMFile->FileMapping, FILE_MAP_READ, 0, 0, 0 );

	if ( MMFile->Buffer == NULL ) {
		MMFile->ErrorCode = GetLastError();
		CloseHandle( MMFile->FileHandle );
		if ( Flags & MM_FLAG_ERROR_MESSAGES ) {
			DisplayErrorHeader();
			MM_GetErrorText( MMFile->ErrorCode, ErrorText );
			Qprintf( ERRHANDLE, L"Error mapping view of file: %s\r\n", ErrorText );
		}
		goto ErrorAbort;
	}

	GuessFileEncoding( MMFile, ( Flags & MM_FLAG_ALLOW_EBCDIC ) > 0 );
	return 0;


MemoryAbort :

	MMFile->ErrorCode = ERROR_NOT_ENOUGH_MEMORY;

ErrorAbort :

	if ( MMFile->Buffer && ( MMFile->FileMapping == NULL ) && ( MMFile->FileHandle == NULL ) ) {
		free( MMFile->Buffer );
		MMFile->Buffer = NULL;
	}

	if ( MMFile->Buffer )
		UnmapViewOfFile( MMFile->Buffer );

	if ( MMFile->FileMapping )
		CloseHandle( MMFile->FileMapping );

	if ( MMFile->FileHandle )
		CloseHandle( MMFile->FileHandle );

	if ( MMFile->TempFilename )
		DeleteFile( MMFile->TempFilename );

	free( MMFile->Filename );
	free( MMFile->TempFilename );

	rv = MMFile->ErrorCode;
	memset( MMFile, 0x00, sizeof( _MMFile ) );
	MMFile->ErrorCode = rv;
	return rv;
}



int OpenMMFile( _MMFile *MMFile, LPTSTR inFilename, int Flags )
{
	return OpenMMFile( MMFile, inFilename, Flags, 0, 0 );
}



__int64 _MMGetFileSize( HANDLE FileHandle )
{
	BY_HANDLE_FILE_INFORMATION fi;

	memset( &fi, 0x00, sizeof( BY_HANDLE_FILE_INFORMATION ) );
	GetFileInformationByHandle( FileHandle, &fi );
	return fi.nFileSizeLow | ( (__int64) fi.nFileSizeHigh << 32 );
}


int RemapMMFile( _MMFile *MMFile )
{
	if ( !MMFile )
		return -1;

	if ( ( MMFile->FileHandle == NULL ) || ( MMFile->FileHandle == INVALID_HANDLE_VALUE ) )
		return -1;


	HANDLE NewFileMapping	= NULL;
	BYTE *NewBuffer			= NULL;
	int rv					= 1;


#ifndef _WIN64

	if ( _MMGetFileSize( MMFile->FileHandle ) > UINT_MAX )
		return -2;

#endif

	NewFileMapping = CreateFileMapping( MMFile->FileHandle, NULL, PAGE_READONLY, 0, 0, NULL );

	if ( NewFileMapping ) {
		NewBuffer = (BYTE*) MapViewOfFile( NewFileMapping, FILE_MAP_READ, 0, 0, 0 );

		if ( NewBuffer ) {
			UnmapViewOfFile( MMFile->Buffer );
			CloseHandle( MMFile->FileMapping );

			MMFile->FileMapping = NewFileMapping;
			MMFile->Buffer = NewBuffer;
			MMFile->FileSize = (size_t) _MMGetFileSize( MMFile->FileHandle );
			rv = 0;
		}
		else {
			CloseHandle( NewFileMapping );
			rv = 2;
		}
	}

	return rv;
}



int _MM_UTF8Len( BYTE Byte )
{
	if ( Byte < 0x80 )
		return 1;
	else if ( Byte < 0xc0 )
		return -1;
	else if ( Byte < 0xe0 )
		return 2;
	else if ( Byte < 0xf0 )
		return 3;
	else if ( Byte < 0xf8 )
		return 4;
	else
		return -1;
}



int _MM_UTF8ToChar( BYTE *Data )
{
	if ( Data[0] < 0x80 )
		return Data[0];
	else if ( Data[0] < 0xc0 )
		return -1;
	else if ( Data[0] < 0xe0 ) {
		if ( ( Data[1] & 0xc0 ) != 0x80 )
			return -1;
		else
			return ( ( Data[0] & 0x1f ) << 6 ) | ( Data[1] & 0x3f );
	}
	else if ( Data[0] < 0xf0 ) {
		if ( ( ( Data[1] & 0xc0 ) != 0x80 ) | ( ( Data[2] & 0xc0 ) != 0x80 ) )
			return -1;
		else
			return ( ( Data[0] & 0x0f ) << 12 ) | ( ( Data[1] & 0x3f ) << 6 ) | ( Data[2] & 0x3f );
	}
	else if ( Data[0] < 0xf8 ) {
		if ( ( ( Data[1] & 0xc0 ) != 0x80 ) | ( ( Data[2] & 0xc0 ) != 0x80 ) | ( ( Data[3] & 0xc0 ) != 0x80 ) )
			return -1;
		else
			return ( ( Data[0] & 0x07 ) << 18 ) | ( ( Data[1] & 0x3f ) << 12 ) | ( ( Data[2] & 0x3f ) << 6 ) | ( Data[3] & 0x3f );
	}
	else
		return -1;
}



int MMGetChar( _MMFile *MMFile )
{
	if ( !MMFile )
		return -1;

	if ( MMFile->Index >= MMFile->FileSize )
		return -1;


	int ch				= 0;
	int ch2				= 0;
	BYTE b1				= 0;
	int ulen			= 0;
	WORD LowSurrogate	= 0;


SkipNull:

	b1		= MMFile->Buffer[MMFile->Index];

	if ( MMFile->FileEncoding == FILE_UTF16LE ) {
		if ( ( MMFile->Index + 1 ) >= MMFile->FileSize )
			return -1;

		ch = b1 | ( MMFile->Buffer[MMFile->Index + 1] << 8 );
		MMFile->Index += 2;

		if ( MMFile->HighChars && ( ( ch & MM_SURROGATE_SIG_MASK ) == MM_SURROGATE_SIG_HIGH ) ) {
			if ( ( MMFile->Index + 2 ) < MMFile->FileSize ) {
				LowSurrogate = MMFile->Buffer[MMFile->Index] | ( ( MMFile->Buffer[MMFile->Index + 1] ) << 8 );
				if ( ( LowSurrogate & MM_SURROGATE_SIG_MASK ) == MM_SURROGATE_SIG_LOW ) {
					ch = ( ( ( ch & MM_SURROGATE_MASK ) << 10 ) | ( LowSurrogate & MM_SURROGATE_MASK ) ) + MM_SURROGATE_OFFSET;
					MMFile->Index += 2;
				}
			}
		}
	}
	else if ( MMFile->FileEncoding == FILE_UTF16BE ) {
		if ( ( MMFile->Index + 1 ) >= MMFile->FileSize )
			return -1;

		ch = ( b1 << 8 ) | MMFile->Buffer[MMFile->Index + 1];
		MMFile->Index += 2;

		if ( MMFile->HighChars && ( ( ch & MM_SURROGATE_SIG_MASK ) == MM_SURROGATE_SIG_HIGH ) ) {
			if ( ( MMFile->Index + 2 ) < MMFile->FileSize ) {
				LowSurrogate = ( MMFile->Buffer[MMFile->Index] << 8 ) | MMFile->Buffer[MMFile->Index + 1];
				if ( ( LowSurrogate & MM_SURROGATE_SIG_MASK ) == MM_SURROGATE_SIG_LOW ) {
					ch = ( ( ( ch & MM_SURROGATE_MASK ) << 10 ) | ( LowSurrogate & MM_SURROGATE_MASK ) ) + MM_SURROGATE_OFFSET;
					MMFile->Index += 2;
				}
			}
		}
	}
	else if ( MMFile->FileEncoding == FILE_UTF8 ) {
		ulen = _MM_UTF8Len( b1 );

		if ( ulen < 1 ) {
			ch = MMFile->InvalidChar;
			MMFile->Index++;
		}
		else if ( ( MMFile->Index + ulen ) > MMFile->FileSize ) {
			ch = MMFile->InvalidChar;
			MMFile->Index++;
		}
		else {
			ch = _MM_UTF8ToChar( MMFile->Buffer + MMFile->Index );

			if ( ch < 0 )
				ch = MMFile->InvalidChar, MMFile->Index++;
			else
				MMFile->Index += ulen;
		}

#ifdef		MM_ALLOW_CESU8

		if ( ( MMFile->HighChars ) && ( ( ch & MM_SURROGATE_SIG_MASK ) == MM_SURROGATE_SIG_HIGH ) && ( ( MMFile->Index + 3 ) <= MMFile->FileSize ) ) {
			if ( MMFile->Buffer[MMFile->Index] == 0xed ) {
				ch2 = _MM_UTF8ToChar( MMFile->Buffer + MMFile->Index );
				if ( ( ch2 > 0 ) && ( ch2 <= MM_BMP_MAX ) && ( ( ch2 & MM_SURROGATE_SIG_MASK ) == MM_SURROGATE_SIG_LOW ) ) {
					ch = ( ( ( ch & MM_SURROGATE_MASK ) << 10 ) | ( ch2 & MM_SURROGATE_MASK ) ) + MM_SURROGATE_OFFSET;
					MMFile->Index += 3;
				}
			}
		}

#else	//	MM_ALLOW_CESU8

		if ( ( ch >= 0xd800 ) && ( ch <= 0xdfff ) )
			ch = MMFile->InvalidChar;

#endif	//	MM_ALLOW_CESU8

		if ( ( MMFile->HighChars == 0 ) && ( ch > MM_BMP_MAX ) )
			ch = MMFile->InvalidChar;
		
		if ( ch > MM_UNICODE_MAX )
			ch = MMFile->InvalidChar;
	}
	else if ( MMFile->FileEncoding == FILE_UTF32LE ) {
		if ( ( MMFile->Index + 3 ) >= MMFile->FileSize )
			return -1;

		ch = b1 | ( MMFile->Buffer[MMFile->Index + 1] << 8 ) | ( MMFile->Buffer[MMFile->Index + 2] << 16 ) | ( MMFile->Buffer[MMFile->Index + 3] << 24 );
		MMFile->Index += 4;

		if ( ( MMFile->HighChars == 0 ) && ( ch > MM_BMP_MAX ) )
			ch = MMFile->InvalidChar;

		if ( ( ch > MM_UNICODE_MAX ) || ( ch < 0 ) )
			ch = MMFile->InvalidChar;
	}
	else if ( MMFile->FileEncoding == FILE_UTF32BE ) {
		if ( ( MMFile->Index + 3) >= MMFile->FileSize )
			return -1;

		ch = ( b1 << 24 ) | ( MMFile->Buffer[MMFile->Index + 1] << 16 ) | ( MMFile->Buffer[MMFile->Index + 2] << 8 ) | MMFile->Buffer[MMFile->Index + 3];
		MMFile->Index += 4;

		if ( ( MMFile->HighChars == 0 ) && ( ch > MM_BMP_MAX ) )
			ch = MMFile->InvalidChar;

		if ( ( ch > MM_UNICODE_MAX ) || ( ch < 0 ) )
			ch = MMFile->InvalidChar;
	}
	else if ( MMFile->FileEncoding == FILE_RAW ) {
		ch = b1;
		MMFile->Index++;
	}
	else if ( MMFile->FileEncoding == FILE_EBCDIC ) {
		ch = CodePageBigTable[MMFile->EbcdicCodePageIndex][b1];
		MMFile->Index++;
	}
	else {
		if ( b1 & 0x80 )
			ch = CodePageTable[MMFile->CodePageIndex][b1 & 0x7f];
		else
			ch = b1;

		MMFile->Index++;
	}

	if ( ch == 0 ) {
		if ( ( MMFile->Flags & ( MM_FLAG_SKIP_NULLS | MM_FLAG_NULLS_TO_INVCHAR ) ) == MM_FLAG_SKIP_NULLS )
			goto SkipNull;
		else if ( ( MMFile->Flags & ( MM_FLAG_SKIP_NULLS | MM_FLAG_NULLS_TO_INVCHAR ) ) == MM_FLAG_NULLS_TO_INVCHAR )
			ch = MMFile->InvalidChar;
	}

	return ch;
}


int MMPeekAhead( _MMFile *MMFile, unsigned int Count )
{
	if ( !MMFile )
		return -1;


	int ch				= 0;
	WORD LowSurrogate	= 0;


	if ( MMFile->FileEncoding == FILE_OEM ) {
		size_t i = ( MMFile->Index ) + Count;

		if ( i >= MMFile->FileSize )
			return -1;

		ch = MMFile->Buffer[i];

		if ( ch & 0x80 )
			ch = CodePageTable[MMFile->CodePageIndex][ch & 0x7f];
	}
	else if ( MMFile->FileEncoding == FILE_EBCDIC ) {
		size_t i = ( MMFile->Index + Count );

		if ( i >= MMFile->FileSize )
			return -1;

		ch = MMFile->Buffer[i];
		return CodePageBigTable[MMFile->EbcdicCodePageIndex][ch];
	}
	else if ( MMFile->FileEncoding == FILE_UTF16LE ) {
		size_t i = ( MMFile->Index ) + ( 2 * Count );

		if ( ( i + 1 ) >= MMFile->FileSize )
			return -1;

		ch = MMFile->Buffer[i] | ( MMFile->Buffer[i + 1] << 8 );

		if ( MMFile->HighChars && ( ( ch & MM_SURROGATE_SIG_MASK ) == MM_SURROGATE_SIG_HIGH ) ) {
			if ( ( i + 3 ) < MMFile->FileSize ) {
				LowSurrogate = MMFile->Buffer[i + 2] | ( ( MMFile->Buffer[i + 3] ) << 8 );
				if ( ( LowSurrogate & MM_SURROGATE_SIG_MASK ) == MM_SURROGATE_SIG_LOW )
					ch = ( ( ( ch & MM_SURROGATE_MASK ) << 10 ) | ( LowSurrogate & MM_SURROGATE_MASK ) ) + MM_SURROGATE_OFFSET;
			}
		}
	}
	else if ( MMFile->FileEncoding == FILE_UTF16BE ) {
		size_t i = ( MMFile->Index ) + ( 2 * Count );

		if ( ( i + 1 ) >= MMFile->FileSize )
			return -1;

		ch = ( MMFile->Buffer[i] << 8 ) | MMFile->Buffer[i + 1];

		if ( MMFile->HighChars && ( ( ch & MM_SURROGATE_SIG_MASK ) == MM_SURROGATE_SIG_HIGH ) ) {
			if ( ( i + 3 ) < MMFile->FileSize ) {
				LowSurrogate = ( MMFile->Buffer[i + 2] << 8 ) | MMFile->Buffer[i + 3];
				if ( ( LowSurrogate & MM_SURROGATE_SIG_MASK ) == MM_SURROGATE_SIG_LOW )
					ch = ( ( ( ch & MM_SURROGATE_MASK ) << 10 ) | ( LowSurrogate & MM_SURROGATE_MASK ) ) + MM_SURROGATE_OFFSET;
			}
		}
	}
	else if ( MMFile->FileEncoding == FILE_UTF8 ) {

		size_t i		= MMFile->Index;
		int ulen		= 0;
		int ch2			= 0;

		do {
			if ( i >= MMFile->FileSize )
				return -1;

			ulen = _MM_UTF8Len( MMFile->Buffer[i] );

			if ( ulen < 1 )
				ch = MMFile->InvalidChar, i++;
			else if ( ( i + ulen ) > MMFile->FileSize )
				return -1;
			else {

				ch = _MM_UTF8ToChar( MMFile->Buffer + i );

				if ( ch < 0 )
					ch = MMFile->InvalidChar, i++;
				else {
					i += ulen;

#ifdef		MM_ALLOW_CESU8

					if ( ( MMFile->HighChars ) && ( ( ch & MM_SURROGATE_SIG_MASK ) == MM_SURROGATE_SIG_HIGH ) && ( ( i + 3 ) <= MMFile->FileSize ) ) {
						if ( MMFile->Buffer[i] == 0xed ) {
							ch2 = _MM_UTF8ToChar( MMFile->Buffer + i );
							if ( ( ch2 > 0 ) && ( ch2 <= MM_BMP_MAX ) && ( ( ch2 & MM_SURROGATE_SIG_MASK ) == MM_SURROGATE_SIG_LOW ) ) {
								ch = ( ( ( ch & MM_SURROGATE_MASK ) << 10 ) | ( ch2 & MM_SURROGATE_SIG_MASK ) ) + MM_SURROGATE_OFFSET;
								i += 3;
							}
						}
					}

#else	//	MM_ALLOW_CESU8

					if ( ( ch >= 0xd800 ) && ( ch <= 0xdfff ) )
						ch = MMFile->InvalidChar;

#endif	//	MM_ALLOW_CESU8

					if ( ( MMFile->HighChars == 0 ) && ( ch > MM_BMP_MAX ) )
						ch = MMFile->InvalidChar;

					if ( ch > MM_UNICODE_MAX )
						ch = MMFile->InvalidChar;
				}
			}
		}
		while ( Count-- );
	}
	else if ( MMFile->FileEncoding == FILE_UTF32LE ) {
		size_t i = MMFile->Index + ( 2 * Count );

		if ( ( i + 3 ) >= MMFile->FileSize )
			return -1;

		ch = MMFile->Buffer[i] | ( MMFile->Buffer[i + 1] << 8 ) | ( MMFile->Buffer[i + 2] << 16 ) | ( MMFile->Buffer[i + 3] << 24 );

		if ( ( MMFile->HighChars == 0 ) && ( ch > MM_BMP_MAX ) )
			ch = MMFile->InvalidChar;

		if ( ( ch > MM_UNICODE_MAX ) || ( ch < 0 ) )
			ch = MMFile->InvalidChar;
	}
	else if ( MMFile->FileEncoding == FILE_UTF32BE ) {
		size_t i = MMFile->Index + ( 2 * Count );

		if ( ( i + 3 ) >= MMFile->FileSize )
			return -1;

		ch = ( MMFile->Buffer[i] << 24 ) | ( MMFile->Buffer[i + 1] << 16 ) | ( MMFile->Buffer[i + 2] << 8 ) | MMFile->Buffer[i + 3];

		if ( ( MMFile->HighChars == 0 ) && ( ch > MM_BMP_MAX ) )
			ch = MMFile->InvalidChar;

		if ( ( ch > MM_UNICODE_MAX ) || ( ch < 0 ) )
			ch = MMFile->InvalidChar;
	}
	else {											//	otherwise, assume FILE_RAW :
		size_t i = ( MMFile->Index ) + Count;

		if ( i >= MMFile->FileSize )
			return -1;

		ch = MMFile->Buffer[i];
	}

	return ch;
}



int MMPrevChar( _MMFile *MMFile, size_t Index, size_t *NewIndex )
{
	if ( !MMFile )
		return -1;
	else if ( MMFile->FileSize == 0 )
		return -1;


	int ch					= 0;
	size_t i				= 0;
	size_t CharSize			= 1;
	WORD HighSurrogate		= 0;


	if ( ( MMFile->FileEncoding == FILE_UTF16LE ) || ( MMFile->FileEncoding == FILE_UTF16BE ) )
		CharSize = 2;
	else if ( ( MMFile->FileEncoding == FILE_UTF32LE ) || ( MMFile->FileEncoding == FILE_UTF32BE ) )
		CharSize = 4;

	if ( Index == (size_t) -1 )
		Index = MMFile->FileSize;

	if ( ( MMFile->BOMSize + CharSize ) > Index )
		return -1;

	i = Index - CharSize;

	if ( ( i + CharSize - 1 ) > MMFile->FileSize )
		return -1;

	if ( MMFile->FileEncoding == FILE_UTF16LE ) {
		ch = MMFile->Buffer[i] | ( MMFile->Buffer[i + 1] << 8 );

		if ( MMFile->HighChars && ( ( ch & MM_SURROGATE_SIG_MASK ) == MM_SURROGATE_SIG_LOW ) ) {
			if ( ( i >= 2 ) && ( i >= ( MMFile->BOMSize + 2 ) ) ) {
				HighSurrogate = MMFile->Buffer[i - 2] | ( MMFile->Buffer[i - 1] << 8 );
				if ( ( HighSurrogate & MM_SURROGATE_SIG_MASK ) == MM_SURROGATE_SIG_HIGH ) {
					ch = ( ( HighSurrogate & MM_SURROGATE_MASK ) << 10 ) | ( ch & MM_SURROGATE_MASK );
					i -= 2;
				}
			}
		}
	}
	else if ( MMFile->FileEncoding == FILE_UTF16BE ) {
		ch = ( MMFile->Buffer[i] << 8 ) | MMFile->Buffer[i + 1];

		if ( MMFile->HighChars && ( ( ch & MM_SURROGATE_SIG_MASK ) == MM_SURROGATE_SIG_LOW ) ) {
			if ( ( i >= 2 ) && ( i >= ( MMFile->BOMSize + 2 ) ) ) {
				HighSurrogate = ( MMFile->Buffer[i - 2] << 8 ) | MMFile->Buffer[i - 1];
				if ( ( HighSurrogate & MM_SURROGATE_SIG_MASK ) == MM_SURROGATE_SIG_HIGH ) {
					ch = ( ( HighSurrogate & MM_SURROGATE_MASK ) << 10 ) | ( ch & MM_SURROGATE_MASK );
					i -= 2;
				}
			}
		}
	}
	else if ( MMFile->FileEncoding == FILE_UTF8 ) {
		ch = MMFile->Buffer[i];
		size_t t = i;
		BYTE b1 = 0, b2 = 0, b3 = 0, b4 = 0;

		while ( ( ch >= 0x80 ) && ( ch < 0xc0 ) ) {
			t--;
			if ( ( t < MMFile->BOMSize ) || ( t > MMFile->FileSize ) )
				ch = MMFile->InvalidChar;
			else
				ch = MMFile->Buffer[t];
		}

		b1 = MMFile->Buffer[t];
		if ( ( t + 1 ) < MMFile->FileSize )
			b2 = MMFile->Buffer[t + 1];
		if ( ( t + 2 ) < MMFile->FileSize )
			b3 = MMFile->Buffer[t + 2];
		if ( ( t + 3 ) < MMFile->FileSize )
			b4 = MMFile->Buffer[t + 3];

		if ( ch == MMFile->InvalidChar )
			;
		else if ( ( ( b1 & 0x80 ) == 0x00 ) && ( t == i ) )
			ch = b1;
		else if ( ( ( b1 & 0xe0 ) == 0xc0 ) && ( ( b2 & 0xc0 ) == 0x80 ) && ( t == ( i - 1 ) ) )
			ch = ( ( b1 & 0x1f ) << 6 ) | ( b2 & 0x3f ), i = t;
		else if ( ( ( b1 & 0xf0 ) == 0xe0 ) && ( ( b2 & 0xc0 ) == 0x80 ) && ( ( b3 & 0xc0 ) == 0x80 ) && ( t == ( i - 2 ) ) )
			ch = ( ( b1 & 0x0f ) << 12 ) | ( ( b2 & 0x3f ) << 6 ) | ( b3 & 0x3f ), i = t;
		else if ( ( ( b1 & 0xf8 ) == 0xf0 ) && ( ( b2 & 0xc0 ) == 0x80 ) && ( ( b3 & 0xc0 ) == 0x80 ) && ( ( b4 & 0xc0 ) == 0x80 ) && ( t == ( i - 3 ) ) )
			ch = ( ( b1 & 0x07 ) << 18 ) | ( ( b2 & 0x3f ) << 12 ) | ( ( b3 & 0x3f ) << 6 ) | ( b4 & 0x3f ), i = t;
		else
			ch = MMFile->InvalidChar;

#ifdef		MM_ALLOW_CESU8

		if ( ( ( ch >= 0xdc00 ) && ( ch <= 0xdfff ) ) && ( i >= ( MMFile->BOMSize + 3 ) ) && ( MMFile->HighChars ) ) {
			if ( MMFile->Buffer[i - 3] == 0xed ) {
				int ch2 = _MM_UTF8ToChar( MMFile->Buffer + i - 3 );
				if ( ( ch2 >= 0xd800 ) && ( ch2 <= 0xdbff ) ) {
					ch = ( ( ( ch2 & MM_SURROGATE_MASK ) << 10 ) | ( ch & MM_SURROGATE_MASK ) ) + MM_SURROGATE_OFFSET;
					i -= 3;
				}
			}
		}

#else	//	MM_ALLOW_CESU8

		if ( ( ch >= 0xd800 ) && ( ch <= 0xdfff ) )
			ch = MMFile->InvalidChar;

#endif	//	MM_ALLOW_CESU8

		if ( ( MMFile->HighChars == 0 ) && ( ch > MM_BMP_MAX ) )
			ch = MMFile->InvalidChar;

		if ( ch > MM_UNICODE_MAX )
			ch = MMFile->InvalidChar;
	}
	else if ( MMFile->FileEncoding == FILE_UTF32LE ) {
		ch = MMFile->Buffer[i] | ( MMFile->Buffer[i + 1] << 8 ) | ( MMFile->Buffer[i + 2] << 16 ) | ( MMFile->Buffer[i + 3] << 24 );

		if ( ( MMFile->HighChars == 0 ) && ( ch > MM_BMP_MAX ) )
			ch = MMFile->InvalidChar;

		if ( ( ch > MM_UNICODE_MAX ) || ( ch < 0 ) )
			ch = MMFile->InvalidChar;
	}
	else if ( MMFile->FileEncoding == FILE_UTF32BE ) {
		ch = ( MMFile->Buffer[i] << 24 ) | ( MMFile->Buffer[i + 1] << 16 ) | ( MMFile->Buffer[i + 2] << 8 ) | MMFile->Buffer[i + 3];

		if ( ( MMFile->HighChars == 0 ) && ( ch > MM_BMP_MAX ) )
			ch = MMFile->InvalidChar;

		if ( ( ch > MM_UNICODE_MAX ) || ( ch < 0 ) )
			ch = MMFile->InvalidChar;
	}
	else if ( MMFile->FileEncoding == FILE_OEM ) {
		ch = MMFile->Buffer[i];
		if ( ch & 0x80 )
			ch = CodePageTable[MMFile->CodePageIndex][ch & 0x7f];
	}
	else if ( MMFile->FileEncoding == FILE_EBCDIC ) {
		ch = MMFile->Buffer[i];
		ch = CodePageBigTable[MMFile->EbcdicCodePageIndex][ch];
	}
	else		//	FILE_RAW
		ch = MMFile->Buffer[i];


	if ( NewIndex )
		*NewIndex = i;

	return ch;
}



int MMPrevChar( _MMFile *MMFile )
{
	if ( !MMFile )
		return -1;

	return MMPrevChar( MMFile, MMFile->Index, &(MMFile->Index) );
}



int _MMIsEOL( wchar_t ch )
{
	if ( ( ch == 0x0d ) || ( ch == 0x0a ) || ( ch == 0x85 ) )
		return TRUE;
	
	return FALSE;
}



int _MM2PartEOL( wchar_t ch )
{
	if ( ( ch == 0x0d ) || ( ch == 0x0a ) )
		return ch ^ 0x07;

	return -9999;
}



int MM_DecodeSurrogatePair( wchar_t High, wchar_t Low )
{
	if ( ( ( High & MM_SURROGATE_SIG_MASK ) != MM_SURROGATE_SIG_HIGH ) || ( ( Low & MM_SURROGATE_SIG_MASK ) != MM_SURROGATE_SIG_LOW ) )
		return 0;

	return ( ( ( High & MM_SURROGATE_MASK ) << 10 ) | ( Low & MM_SURROGATE_MASK ) ) + MM_SURROGATE_OFFSET;
}



int MM_CreateSurrogatePair( int ch, wchar_t *out )
{
	if ( !out )
		return -1;

	if ( ( ch < 0 ) || ( ch > MM_UNICODE_MAX ) )
		return -1;


	if ( ch <= MM_BMP_MAX ) {
		*out = ch;
		return 1;
	}

	out[0] = ( ( ch - MM_SURROGATE_OFFSET ) >> 10 ) | MM_SURROGATE_SIG_HIGH;
	out[1] = ( ( ch - MM_SURROGATE_OFFSET ) & MM_SURROGATE_MASK ) | MM_SURROGATE_SIG_LOW;
	return 2;
}



int MMGetLine( _MMFile *MMFile, LPTSTR outLine, unsigned int BufSize, int Flags )
{
	if ( !MMFile || !outLine )
		return -1;

	int ch					= 0;
	BOOL NonBlanks			= FALSE;
	BOOL SkipBlanks			= Flags & MMGL_FLAG_SKIP_BLANKS;
	BOOL SplitLongLines		= Flags & MMGL_FLAG_SPLIT_LONG_LINES;
	unsigned int j			= 0;
	unsigned int k			= 0;


	do {
		j = 0;
		outLine[j] = '\0';

		do {
			ch = MMGetChar( MMFile );

			if ( ( ch <= 0 ) || _MMIsEOL( ch ) )
				break;


			k = ( ch > MM_BMP_MAX ) ? 2 : 1;

			if ( k == 1 ) {
				if ( iswspace( ch ) == 0 )
					NonBlanks = TRUE;
			}
			else
				NonBlanks = TRUE;


			if ( k == 2 ) {
				if ( SplitLongLines && ( j >= ( BufSize - 2 ) ) ) {
					MMPrevChar( MMFile );
					break;
				}
			}
			else if ( ( ch & MM_SURROGATE_SIG_MASK ) == MM_SURROGATE_SIG_HIGH ) {
				if ( SplitLongLines && ( j >= ( BufSize - 2 ) ) ) {
					MMPrevChar( MMFile );
					break;
				}
			}


			if ( k == 1 ) {
				if ( j < ( BufSize - 1 ) ) {
					outLine[j++] = ch;
					outLine[j] = '\0';
				}
			}
			else {
				if ( j < ( BufSize - 2 ) ) {
					MM_CreateSurrogatePair( ch, outLine + j );
					j += 2;
					outLine[j] = '\0';
				}
			}


			if ( SplitLongLines && ( j == ( BufSize - 1 ) ) )
				break;

		} while ( TRUE );

		if ( ch < 0 )
			break;
		else if ( _MMIsEOL( ch ) )
			if ( MMPeekAhead( MMFile, 0 ) == _MM2PartEOL( ch ) )
				MMGetChar( MMFile );

	} while ( SkipBlanks && !NonBlanks );


	if ( ( j == 0 ) && ( ch < 0 ) )
		return -1;

	return 0;
}



int LooksLikeUTF16( _MMFile *MMFile )
{
	if ( MMFile == NULL )
		return FILE_OEM;
	else if ( MMFile->Buffer == NULL )
		return FILE_OEM;

	size_t NumBytes = MMFile->FileSize;

	if ( NumBytes < 2 )
		return FILE_OEM;
	/*
	else if ( NumBytes & 1 )
		return FILE_OEM;
	*/

	if ( ( MMFile->Buffer[0] == 0xff ) && ( MMFile->Buffer[1] == 0xfe ) ) {
		MMFile->BOMSize = 2;
		return FILE_UTF16LE;
	}

	if ( ( MMFile->Buffer[0] == 0xfe ) && ( MMFile->Buffer[1] == 0xff ) ) {
		MMFile->BOMSize = 2;
		return FILE_UTF16BE;
	}


	if ( NumBytes > 0x20000 )
		NumBytes = 0x20000;


	unsigned int Spaces[2] = { 0, 0 };
	unsigned int Nulls[2]  = { 0, 0 };
	int k = ( NumBytes <= 128 ) ? 2 : 4;

	for ( unsigned int i = 0; i < NumBytes; i++ ) {
		if ( MMFile->Buffer[i] == 0x20 )
			Spaces[i & 1]++;
		else if ( MMFile->Buffer[i] == 0x00 )
			Nulls[i & 1]++;
	}

	//	wprintf( L"   * Spaces = { %u, %u }   Nulls = { %u, %u }   k = %u\n", Spaces[0], Spaces[1], Nulls[0], Nulls[1], k );

	if ( NumBytes <= 32 ) {
		if ( Nulls[1] > Nulls[0] )
			return FILE_UTF16LE;
		else if ( Nulls[0] > Nulls[1] )
			return FILE_UTF16BE;
	}

	if ( ( Spaces[0] > ( k * Spaces[1] ) ) && ( Nulls[1] > ( k * Nulls[0] ) ) )
		return FILE_UTF16LE;
	else if ( ( Spaces[1] > ( k * Spaces[0] ) ) && ( Nulls[0] > ( k * Nulls[1] ) ) )
		return FILE_UTF16BE;

	return FILE_OEM;
}



int LooksLikeUTF8( _MMFile *MMFile )
{
	if ( MMFile == NULL )
		return FILE_OEM;
	else if ( MMFile->Buffer == NULL )
		return FILE_OEM;

	size_t NumBytes = MMFile->FileSize;

	if ( NumBytes < 2 )
		return FILE_OEM;

	if ( NumBytes >= 3 ) {
		if ( ( MMFile->Buffer[0] == 0xef ) && ( MMFile->Buffer[1] == 0xbb ) && ( MMFile->Buffer[2] == 0xbf ) ) {
			MMFile->BOMSize = 3;
			return FILE_UTF8;
		}
	}

	if ( NumBytes > 0x40000 )
		NumBytes = 0x40000;

	BYTE b = 0;
	int c = 0, mbs = 0;

	for ( unsigned int i = 0; i < NumBytes; i++ ) {
		b = MMFile->Buffer[i];

		if ( c ) {
			if ( ( b & 0xc0 ) != 0x80 )
				return FILE_OEM;

			c--;
		}
		else {
			if ( b < 0x80 )
				;
			else if ( b < 0xc0 )
				return FILE_OEM;
			else if ( b < 0xe0 ) {
				c = 1;
				mbs++;
			}
			else if ( b < 0xf0 ) {
				c = 2;
				mbs++;
			}
			else if ( b < 0xf8 ) {
				c = 3;
				mbs++;
			}
			else
				return FILE_OEM;
		}
	}

	if ( mbs )
		return FILE_UTF8;
	else
		return FILE_OEM;
}



BOOL LooksLikeAscii( _MMFile *MMFile )
{
	if ( MMFile == NULL )
		return FALSE;
	else if ( MMFile->Buffer == NULL )
		return FALSE;

	size_t NumBytes = MMFile->FileSize;

	if ( NumBytes > 0x20000 )
		NumBytes = 0x20000;

	for ( unsigned int i = 0; i < NumBytes; i++ )
		if ( MMFile->Buffer[i] & 0x80 )
			return FALSE;

	return TRUE;
}



BOOL IsEbcdicAlnum( BYTE ch )
{
	if ( ( ch >= 0x81 ) && ( ch <= 0x89 ) )
		return TRUE;

	if ( ( ch >= 0x91 ) && ( ch <= 0x99 ) )
		return TRUE;

	if ( ( ch >= 0xa2 ) && ( ch <= 0xa9 ) )
		return TRUE;

	if ( ( ch >= 0xc1 ) && ( ch >= 0xc9 ) )
		return TRUE;

	if ( ( ch >= 0xd1 ) && ( ch <= 0xd9 ) )
		return TRUE;

	if ( ( ch >= 0xe2 ) && ( ch <= 0xe9 ) )
		return TRUE;

	if ( ( ch >= 0xf0 ) && ( ch <= 0xf9 ) )
		return TRUE;

	return FALSE;
}



int LooksLikeEBCDIC( _MMFile *MMFile )
{
	if ( !MMFile )
		return FILE_OEM;
	else if ( MMFile->FileSize < 128 )
		return FILE_OEM;


	unsigned int nAsciiAlnums		= 0;
	unsigned int nAsciiBlanks		= 0;
	unsigned int nEbcdicAlnums		= 0;
	unsigned int nOtherHighChars	= 0;
	unsigned int nEbcdicBlanks		= 0;
	BYTE ch							= 0;

	size_t NumBytes					= MMFile->FileSize;
	int n							= 4;


	if ( NumBytes >= 0x0400 )
		n = 5;

	if ( NumBytes > 0x20000 )
		NumBytes = 0x20000;

	for ( size_t i = 0; i < NumBytes; i++ ) {
		ch = MMFile->Buffer[i];

		if ( isalnum( ch ) )
			nAsciiAlnums++;

		if ( ch == 0x20 )
			nAsciiBlanks++;

		if ( IsEbcdicAlnum( ch ) )
			nEbcdicAlnums++;
		else if ( ch & 0x80 )
			nOtherHighChars++;

		if ( ch == 0x40 )
			nEbcdicBlanks++;
	}

	//	wprintf( L"   * nAsciiAlnums = %u   nAsciiBlanks = %u   nEbcdicAlnums = %u   nOtherHighChars = %u   nEbcdicBlanks = %u\r\n", nAsciiAlnums, nAsciiBlanks, nEbcdicAlnums, nOtherHighChars, nEbcdicBlanks );

	if ( ( nEbcdicAlnums >= ( n * nAsciiAlnums ) ) && ( nEbcdicAlnums >= ( n * nOtherHighChars ) ) && ( nEbcdicBlanks >= ( n * nAsciiBlanks ) ) )
		return FILE_EBCDIC;

	return FILE_OEM;
}



int LooksLikeUTF32( _MMFile *MMFile )
{
	if ( MMFile == NULL )
		return FILE_OEM;
	else if ( MMFile->Buffer == NULL )
		return FILE_OEM;


	if ( MMFile->FileSize < 4 )
		return FILE_OEM;
	else if ( MMFile->FileSize & 0x03 )
		return FILE_OEM;


	size_t NumWords		= MMFile->FileSize >> 1;
	size_t Threshold	= NumWords * 3 / 8;

	WORD *Word					= (WORD*) MMFile->Buffer;

	unsigned int BigWords[2]	= { 0, 0 };
	unsigned int BigDrows[2]	= { 0, 0 };
	unsigned int Nulls[2]		= { 0, 0 };


	if ( NumWords > 0x10000 )
		NumWords = 0x10000;

	for ( unsigned int i = 0; i < NumWords; i++ ) {
		if ( Word[i] > 0x0010 )
			BigWords[i & 1]++;
		else if ( Word[i] == 0x0000 )
			Nulls[i & 1]++;

		if ( Word[i] & 0xe0ff )
			BigDrows[i & 1]++;
	}

	//	wprintf( L"   * BigWords = { %u, %u }   BigDrows = { %u, %u }   Nulls = { %u, %u }   Threshold = %I64u\n", BigWords[0], BigWords[1], BigDrows[0], BigDrows[1], Nulls[0], Nulls[1], (unsigned __int64) Threshold );

	if ( ( BigWords[0] >= Threshold ) && ( BigWords[1] == 0 ) && ( Nulls[1] >= Threshold ) ) {
		if ( ( Word[0] == BOM ) && ( Word[1] == 0x0000 ) )
			MMFile->BOMSize = 4;

		return FILE_UTF32LE;
	}

	if ( ( BigDrows[1] >= Threshold ) && ( BigDrows[0] == 0 ) && ( Nulls[0] >= Threshold ) ) {
		if ( ( Word[0] == 0x0000 ) && ( Word[1] == 0xfffe ) )
			MMFile->BOMSize = 4;

		return FILE_UTF32BE;
	}

	return FILE_OEM;
}



int GuessFileEncoding( _MMFile *MMFile, BOOL TryEbcdic )
{
	if ( MMFile == NULL )
		return FILE_OEM;

	if ( MMFile->Buffer && ( MMFile->FileMapping == NULL ) && ( MMFile->FileHandle == NULL ) )
		if ( _wcsicmp( MMFile->Filename, MM_CLIP_FILENAME ) == 0 ) {
			if ( ( MMFile->Buffer[0] == 0xff ) && ( MMFile->Buffer[1] == 0xfe ) )
				MMFile->BOMSize = 2;
			else
				MMFile->BOMSize = 0;

			if ( MMFile->Index < MMFile->BOMSize )
				MMFile->Index = MMFile->BOMSize;

			MMFile->FileEncoding = FILE_UTF16LE;
			return FILE_UTF16LE;
		}

	int rv = LooksLikeUTF32( MMFile );

	if ( rv == FILE_OEM )
		rv = LooksLikeUTF16( MMFile );

	if ( ( rv == FILE_OEM ) && ( MMFile->CodePage == UTF8_CODEPAGE ) ) {
		rv = FILE_UTF8;
		if ( ( MMFile->Buffer[0] == 0xef ) && ( MMFile->Buffer[1] == 0xbb ) && ( MMFile->Buffer[2] == 0xbf ) )
			MMFile->BOMSize = 3;
	}

	if ( rv == FILE_OEM )
		rv = LooksLikeUTF8( MMFile );

	if ( ( rv == FILE_OEM ) && TryEbcdic )
		rv = LooksLikeEBCDIC( MMFile );

	if ( MMFile->Index < MMFile->BOMSize )
		MMFile->Index = MMFile->BOMSize;

	MMFile->FileEncoding = rv;
	return rv;
}



int GuessFileFormat( _MMFile *MMFile )
{
	if ( MMFile == NULL )
		return FMT_UNKNOWN;

	int LongLines = 0, LinesLower = 0, LinesUpper = 0, EmptyLines = 0, NonEmptyLines = 0;
	int CharsInLine = 0, FoundLetter = 0, FoundNonBlank = 0;
	wchar_t EOLchar = 0x00;

	size_t i			= MMFile->BOMSize;
	unsigned int ch		= 0x00;
	int CharSize		= 1;
	
	size_t NumBytes = MMFile->FileSize;


	if ( NumBytes > 0x10000 )
		NumBytes = 0x10000;

	if ( ( MMFile->FileEncoding == FILE_UTF16LE ) || ( MMFile->FileEncoding == FILE_UTF16BE ) )
		CharSize = 2;
	else if ( ( MMFile->FileEncoding == FILE_UTF32LE ) || ( MMFile->FileEncoding == FILE_UTF32BE ) )
		CharSize = 4;


	while ( i < NumBytes ) {
		ch = MMFile->Buffer[i++];

		if ( MMFile->FileEncoding == FILE_UTF16LE )
			ch |= ( MMFile->Buffer[i++] << 8 );
		else if ( MMFile->FileEncoding == FILE_UTF16BE )
			ch = ( ch << 8 ) | MMFile->Buffer[i++];
		else if ( MMFile->FileEncoding == FILE_UTF8 ) {
			if ( ch & 0x80 )
				ch = '#';
			while ( ( i < ( NumBytes - 1 ) ) && ( MMFile->Buffer[i] & 0x80 ) )
				i++;
		}
		else if ( MMFile->FileEncoding == FILE_UTF32LE ) {
			ch = ch | ( MMFile->Buffer[i] << 8 ) | ( MMFile->Buffer[i + 1] << 16 ) | ( MMFile->Buffer[i + 2] << 24 );
			i += 3;
		}
		else if ( MMFile->FileEncoding == FILE_UTF32BE ) {
			ch = ( ch << 24 ) | ( MMFile->Buffer[i] << 16 ) | ( MMFile->Buffer[i + 1] << 8 ) | MMFile->Buffer[i + 2];
			i += 3;
		}

		if ( EOLchar == 0x00 ) {
			if ( _MMIsEOL( ch ) )
				EOLchar = ch;
		}
		else if ( ch == _MM2PartEOL( EOLchar ) )
			continue;

		if ( ch == EOLchar ) {

			if ( CharsInLine >= 80 )
				LongLines++;

			if ( FoundLetter == 1 )
				LinesLower++;
			else if ( FoundLetter == 2 )
				LinesUpper++;

			if ( FoundNonBlank )
				NonEmptyLines++;
			else
				EmptyLines++;

			CharsInLine		= 0;
			FoundLetter		= 0;
			FoundNonBlank	= 0;
		}
		else {
			CharsInLine++;

			if ( ( FoundLetter == 0 ) && iswalpha( ch ) ) {
				if ( iswlower( ch ) )
					FoundLetter = 1;
				else
					FoundLetter = 2;
			}

			if ( iswspace( ch ) == 0 )
				FoundNonBlank = 1;
		}
	}
	
	/*
	Printf( L"   * LinesUpper    = %u\r\n", LinesUpper );
	Printf( L"   * LinesLower    = %u\r\n", LinesLower );
	Printf( L"   * LongLines     = %u\r\n", LongLines );
	Printf( L"   * EmptyLines    = %u\r\n", EmptyLines );
	Printf( L"   * NonEmptyLines = %u\r\n", NonEmptyLines );
	*/

	if ( LinesLower >= LongLines )
		MMFile->FileFormat = FMT_PREWRAPPED;
	else if ( ( LinesLower > ( 3 * ( LinesUpper + 1 ) / 2 ) ) && ( LinesUpper >= ( NonEmptyLines / 8 ) ) )
		MMFile->FileFormat = FMT_PREWRAPPED;
	else if ( EmptyLines > ( NonEmptyLines * 4 / 5 ) )
		MMFile->FileFormat = FMT_UNFORMATTED_BLANKS;
	else
		MMFile->FileFormat = FMT_UNFORMATTED;

	return MMFile->FileFormat;
}



unsigned __int64 MM_CountLines( _MMFile *MMFile, BOOL SkipBlanks )
{
	if ( !MMFile )
		return 0;


	const int MaxLineLen				= 65536;
	wchar_t LineBuffer[MaxLineLen]		= L"";

	unsigned __int64 Count				= 0;
	size_t SaveIndex					= MMFile->Index;


	while ( MMGetLine( MMFile, LineBuffer, MaxLineLen, SkipBlanks ) == 0 )
		Count++;

	MMFile->Index = SaveIndex;
	return Count;
}



int MM_SetInvalidChar( _MMFile *MMFile, wchar_t ch )
{
	if ( !MMFile )
		return -1;


	MMFile->InvalidChar = ch;
	return 0;
}



int MM_FileToClipboard( LPTSTR Filename, unsigned int Flags, unsigned __int64 *nChars )
{
	if ( !Filename )
		return -1;
	else if ( Filename[0] == '\0' )
		return -1;


	_MMFile MMFile;

	size_t nEOLs				= 0;
	size_t nHighChars			= 0;
	size_t nOtherChars			= 0;
	size_t BufferSize			= 0;
	HGLOBAL GlobalHandle		= NULL;
	wchar_t *Buffer				= NULL;
	int ch						= 0;
	size_t i					= 0;

	BOOL ReadFail				= FALSE;
	int rv						= 0;



	if ( OpenMMFile( &MMFile, Filename, MM_FLAG_HIGH_CHARS ) )
		return -2;

	GuessFileEncoding( &MMFile, ( Flags & 0x0001 ) );


	//		count characters in the file:

	while ( MMFile.Index < MMFile.FileSize ) {

		ch = MMGetChar( &MMFile );

		if ( ch < 0 ) {
			ReadFail = TRUE;
			break;
		}
		else if ( ch == 0 )
			;
		else if ( _MMIsEOL( ch ) ) {
			nEOLs++;
			if ( MMPeekAhead( &MMFile, 0 ) == _MM2PartEOL( ch ) )
				MMGetChar( &MMFile );
		}
		else if ( ch > MM_BMP_MAX )
			nHighChars++;
		else
			nOtherChars++;
	}

	if ( ReadFail ) {
		CloseMMFile( &MMFile );
		return -3;
	}

	BufferSize = ( 2 * nEOLs ) + ( 2 * nHighChars ) + nOtherChars + 17;
	//	wprintf( L"   * nEOLs = %I64u   nHighChars = %I64u   nOtherChars = %I64u   BufferSize = %I64u\n", (unsigned __int64) nEOLs, (unsigned __int64) nHighChars, (unsigned __int64) nOtherChars, (unsigned __int64) BufferSize );


	MMFile.Index = MMFile.BOMSize;
	ReadFail = TRUE;

	GlobalHandle = GlobalAlloc( GHND, BufferSize * sizeof( wchar_t ) );
	if ( GlobalHandle ) {
		Buffer = (wchar_t*) GlobalLock( GlobalHandle );
		if ( Buffer ) {
			ReadFail = FALSE;

			while ( MMFile.Index < MMFile.FileSize ) {

				ch = MMGetChar( &MMFile );

				if ( ch < 0 ) {
					ReadFail = TRUE;
					break;
				}
				else if ( ch == 0 )
					;
				else if ( _MMIsEOL( ch ) ) {
					Buffer[i++] = 0x0d;
					Buffer[i++] = 0x0a;

					if ( MMPeekAhead( &MMFile, 0 ) == _MM2PartEOL( ch ) )
						MMGetChar( &MMFile );
				}
				else if ( ch > MM_BMP_MAX ) {
					MM_CreateSurrogatePair( ch, Buffer + i );
					i += 2;
				}
				else {
					Buffer[i++] = ch;
				}
			}

			Buffer[i] = '\0';
			GlobalUnlock( GlobalHandle );
		}
	}

	CloseMMFile( &MMFile );


	if ( ReadFail ) {
		GlobalFree( GlobalHandle );
		return -4;
	}


	if ( OpenClipboard( GetConsoleWindow() ) ) {
		if ( EmptyClipboard() ) {

			if ( SetClipboardData( CF_UNICODETEXT, GlobalHandle ) )
				rv = 0;
			else {
				rv = GetLastError();
				GlobalFree( GlobalHandle );
			}
		}
		else
			rv = GetLastError();
		
		CloseClipboard();
	}
	else
		rv = GetLastError();

	if ( !rv && nChars )
		*nChars = ( 2 * nEOLs ) + nHighChars + nOtherChars;

	return rv;
}



int MM_GetEncodingString( int Encoding, int BOMSize, LPTSTR outString, size_t buflen )
{
	if ( !outString || !buflen )
		return -1;


	wchar_t BomStr0[]		= L" without BOM";
	wchar_t BomStr1[]		= L" with BOM";


	switch ( Encoding ) {

	case FILE_OEM :
		wcscpy_s( outString, buflen, L"OEM" );
		break;

	case FILE_UTF16LE :
		wcscpy_s( outString, buflen, L"UTF-16LE" );

		if ( BOMSize == 0 )
			wcscat_s( outString, buflen, BomStr0 );
		else if ( BOMSize > 0 )
			wcscat_s( outString, buflen, BomStr1 );

		break;

	case FILE_UTF16BE :
		wcscpy_s( outString, buflen, L"UTF-16BE" );

		if ( BOMSize == 0 )
			wcscat_s( outString, buflen, BomStr0 );
		else if ( BOMSize > 0 )
			wcscat_s( outString, buflen, BomStr1 );

		break;

	case FILE_UTF8 :
		wcscpy_s( outString, buflen, L"UTF-8" );

		if ( BOMSize == 0 )
			wcscat_s( outString, buflen, BomStr0 );
		else if ( BOMSize > 0 )
			wcscat_s( outString, buflen, BomStr1 );

		break;

	case FILE_UTF32LE :
		wcscpy_s( outString, buflen, L"UTF-32LE" );

		if ( BOMSize == 0 )
			wcscat_s( outString, buflen, BomStr0 );
		else if ( BOMSize > 0 )
			wcscat_s( outString, buflen, BomStr1 );

		break;

	case FILE_UTF32BE :
		wcscpy_s( outString, buflen, L"UTF-32BE" );

		if ( BOMSize == 0 )
			wcscat_s( outString, buflen, BomStr0 );
		else if ( BOMSize > 0 )
			wcscat_s( outString, buflen, BomStr1 );

		break;

	case FILE_EBCDIC :
		wcscpy_s( outString, buflen, L"EBCDIC" );
		break;

	case FILE_RAW :
		wcscpy_s( outString, buflen, L"raw" );
		break;

	case FILE_ASCII :
		wcscpy_s( outString, buflen, L"ASCII" );
		break;

	default :
		wcscpy_s( outString, buflen, L"unknown" );
	}

	return 0;
}



int MM_GetEncodingString( _MMFile *MMFile, BOOL ShowBOM, BOOL ShowCodePage, LPTSTR outString, size_t buflen )
{
	if ( !MMFile || !outString || !buflen )
		return -1;


	wchar_t temp[SHORT_BUF_LEN]		= L"";


	MM_GetEncodingString( MMFile->FileEncoding, ShowBOM ? (int) MMFile->BOMSize : -1, outString, buflen );


	if ( ShowCodePage ) {

		if ( MMFile->CodePage && ( MMFile->FileEncoding == FILE_OEM ) ) {
			wsprintf( temp, L" (code page %u)", MMFile->CodePage );
			wcscat_s( outString, buflen, temp );
		}
		else if ( MMFile->EbcdicCodePage && ( MMFile->FileEncoding == FILE_EBCDIC ) ) {
			wsprintf( temp, L" (code page %u)", MMFile->EbcdicCodePage );
			wcscat_s( outString, buflen, temp );
		}
	}
	
	return 0;
}



size_t MM_CodePointsIn( LPTSTR String )
{
	if ( !String )
		return -1;


	size_t n		= 0;
	wchar_t *ch		= String;


	while ( *ch ) {
		n++;

		if ( ( ( ch[0] & MM_SURROGATE_SIG_MASK ) == MM_SURROGATE_SIG_HIGH ) && ( ( ch[1] & MM_SURROGATE_SIG_MASK ) == MM_SURROGATE_SIG_LOW ) )
			ch++;

		ch++;
	}

	return n;
}



#endif //	MMFILES_VERSION


/*

	1.4.4.0		2021-07-09

	1.4.4.1		2022-11-28
				Bug fix:  Broken test in MMPrevChar()

*/
